using System;
using System.Collections.Generic;
using System.Text;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    public class MockInfoDescriptor : InfoDescriptor
    {
        public MockInfoDescriptor(RuntimeTypeHandle runtimeTypeHandle, string name)
            : base(runtimeTypeHandle, name)
        {
        }

        public override object GetValue(object target)
        {
            throw new NotImplementedException();
        }
    }
    public class MockParameterDescriptor<T> : ParameterDescriptor
    {
        public MockParameterDescriptor(string name)
            : base(typeof(T).TypeHandle, name)
        {
        }
    }

    public class MockPropertyDescriptor<T> : PropertyDescriptor
    {
        public MockPropertyDescriptor(string name)
            : base(typeof(T).TypeHandle, name)
        {
        }
    }


}
