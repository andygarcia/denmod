﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ValidationFramework.Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("ValidationFramework.Tests")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("5478097f-6908-4699-bdfb-bc3f7c898f02")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
