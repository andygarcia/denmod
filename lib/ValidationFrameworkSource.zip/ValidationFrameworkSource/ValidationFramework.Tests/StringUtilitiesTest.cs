using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class StringUtilitiesTest
    {

        [Test]
        public void GetTokenizedMemberName()
        {
            string tokenizedMemberName = StringUtilities.GetTokenizedValue("FirstNameProperty");
            Assert.AreEqual("First Name Property", tokenizedMemberName);
        }
        
    }

}