using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

namespace ValidationFramework.Tests.Utilities
{
    [TestFixture]
    public class AutoKeyDictionaryTests
    {

        #region Constructors

        [Test]
        public void DefaultConstructorTest()
        {
            new MockStringDictionary();
        }


        [Test]
        public void ConstructorComparerTest()
        {
            new MockStringDictionary(StringComparer.InvariantCultureIgnoreCase);
        }


        [Test]
        public void CapacityComparerConstructorTest()
        {
            MockStringDictionary target = new MockStringDictionary(StringComparer.InvariantCultureIgnoreCase, 1);
            Assert.AreEqual(StringComparer.InvariantCultureIgnoreCase, target.Comparer);
        }



        #endregion


        [Test]
        public void KeysTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(2);
            target.Add(4);
            target.Add(9);
            Dictionary<string, int>.KeyCollection keys = target.Keys;

            IEnumerable<string> enumerable = keys;
            IEnumerator<string> enumerator = enumerable.GetEnumerator();
            string current;

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual("2", current);

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual("4", current);

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual("9", current);

        }
        [Test]
        public void ValuesTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(2);
            target.Add(4);
            target.Add(9);
            Dictionary<string, int>.ValueCollection valueCollection = target.Values;

            IEnumerable<int> enumerable = valueCollection;
            IEnumerator<int> enumerator = enumerable.GetEnumerator();
            int current;

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual(2, current);

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual(4, current);

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual(9, current);

        }

        [Test]
        public void ContainsKeyTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(2);
            Assert.IsTrue(target.ContainsKey("2"));
            Assert.IsFalse(target.ContainsKey("1"));
            Assert.IsFalse(target.ContainsKey("3"));
        }
        [Test]
        public void RemoveKeyTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(2);
            Assert.IsTrue(target.ContainsKey("2"));
            Assert.IsTrue(target.RemoveKey("2"));
            Assert.IsFalse(target.ContainsKey("2"));
        }



        [Test]
        public void IsReadOnlyTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            Assert.IsFalse(target.IsReadOnly);
            target.SetToReadOnly();
            Assert.IsTrue(target.IsReadOnly);
        }

        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "Dictionary is read-only.")]
        public void ReadOnlyAdd()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.SetToReadOnly();
            target.Add(1);
        }

        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "Dictionary is read-only.")]
        public void ReadOnlyClear()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.SetToReadOnly();
            target.Clear();
        }

        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "Dictionary is read-only.")]
        public void ReadOnlyRemove()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.SetToReadOnly();
            target.Remove(1);
        }

        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "Dictionary is read-only.")]
        public void ReadOnlyRemoveKey()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.SetToReadOnly();
            target.RemoveKey("1");
        }



    }


    [TestFixture]
    public class AutoKeyDictionaryIEnumerableGenericTests
    {



        [Test]
        public void GetEnumeratorTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(2);
            target.Add(4);
            target.Add(9);
            IEnumerable<int> enumerable = target;
            IEnumerator<int> enumerator = enumerable.GetEnumerator();
            int current;

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual(2, current);

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual(4, current);

            enumerator.MoveNext();
            current = enumerator.Current;
            Assert.AreEqual(9, current);

        }

    }
    [TestFixture]
    public class AutoKeyDictionaryIEnumerableTests
    {



        [Test]
        public void GetEnumeratorTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(2);
            target.Add(4);
            target.Add(9);
            IEnumerable enumerable = target;
            IEnumerator enumerator = enumerable.GetEnumerator();
            int current;

            enumerator.MoveNext();
            current = (int) enumerator.Current;
            Assert.AreEqual(2, current);

            enumerator.MoveNext();
            current = (int) enumerator.Current;
            Assert.AreEqual(4, current);

            enumerator.MoveNext();
            current = (int) enumerator.Current;
            Assert.AreEqual(9, current);

        }


      

    }
    [TestFixture]
    public class AutoKeyDictionaryICollectionGenericTests
    {

        [Test]
        public void AddTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            ICollection<int> collection = target;
            collection.Add(1);
            Assert.IsTrue(target.Contains(1));
        }

        [Test]
        public void ContainsTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(2);
            ICollection<int> collection = target;
            Assert.IsTrue(collection.Contains(2));
            Assert.IsFalse(collection.Contains(1));
            Assert.IsFalse(collection.Contains(3));
        }

        [Test]
        public void ClearTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(2);
            Assert.IsTrue(target.Contains(2));
            target.Clear();
            Assert.IsFalse(target.Contains(2));
        }



        [Test]
        public void CopyToTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(1);
            target.Add(2);
            target.Add(3);
            ICollection<int> collection = target;
            int[] pairs = new int[3];
            collection.CopyTo(pairs, 0);
            Assert.AreEqual(1, pairs[0]);
            Assert.AreEqual(2, pairs[1]);
            Assert.AreEqual(3, pairs[2]);
        }



        [Test]
        public void IsReadOnlyTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            ICollection<int> collection = target;
            Assert.IsFalse(collection.IsReadOnly);
        }

        [Test]
        public void RemoveNonExistingTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(1);
            ICollection<int> collection = target;
            Assert.IsFalse(collection.Remove(2));
        }


        [Test]
        public void RemoveTest()
        {
            MockStringDictionary target = new MockStringDictionary();
            target.Add(3);
            ICollection<int> collection = target;
            Assert.IsTrue(collection.Remove(3));
            Assert.IsFalse(target.ContainsKey("3"));
            Assert.IsFalse(collection.Remove(3));
        }


    }


    //[TestFixture]
    //public class DictionaryBaseICollectionTest
    //{


    //    [Test]
    //    public void CopyToTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        target.Add("g", "s");
    //        target.Add("h", "x");
    //        ICollection collection = target;
    //        KeyValuePair<string, string>[] pairs = new KeyValuePair<string, string>[3];
    //        collection.CopyTo(pairs, 0);
    //        Assert.AreEqual("a", pairs[0].Key);
    //        Assert.AreEqual("g", pairs[1].Key);
    //        Assert.AreEqual("h", pairs[2].Key);
    //        Assert.AreEqual("b", pairs[0].Value);
    //        Assert.AreEqual("s", pairs[1].Value);
    //        Assert.AreEqual("x", pairs[2].Value);
    //    }


    //    [Test]
    //    public void GetEnumeratorTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        target.Add("s", "r");
    //        target.Add("f", "t");
    //        ICollection collection = target;
    //        IEnumerator enumerator = collection.GetEnumerator();
    //        KeyValuePair<string, string> current;

    //        enumerator.MoveNext();
    //        current = (KeyValuePair<string, string>)enumerator.Current;
    //        Assert.AreEqual("a", current.Key);
    //        Assert.AreEqual("b", current.Value);


    //        enumerator.MoveNext();
    //        current = (KeyValuePair<string, string>)enumerator.Current;
    //        Assert.AreEqual("s", current.Key);
    //        Assert.AreEqual("r", current.Value);

    //        enumerator.MoveNext();
    //        current = (KeyValuePair<string, string>)enumerator.Current;
    //        Assert.AreEqual("f", current.Key);
    //        Assert.AreEqual("t", current.Value);

    //    }


    //    [Test]
    //    public void IsSynchronizedTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        ICollection collection = target;
    //        Assert.IsFalse(collection.IsSynchronized);
    //    }


    //    [Test]
    //    public void IsSyncRootTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        ICollection collection = target;
    //        Assert.IsNotNull(collection.SyncRoot);

    //    }
    //}

    //[TestFixture]
    //public class DictionaryBaseIDictionaryGenericTest
    //{


    //    [Test]
    //    [ExpectedException(typeof(Exception), ExpectedMessage = "AddItem")]
    //    public void AddTest()
    //    {
    //        MockExceptionDictionary target = new MockExceptionDictionary();
    //        target.Add(2, 2);
    //    }


    //    [Test]
    //    [ExpectedException(typeof(Exception), ExpectedMessage = "ClearItems")]
    //    public void ClearTest()
    //    {
    //        MockExceptionDictionary target = new MockExceptionDictionary();
    //        target.Clear();
    //    }


    //    [Test]
    //    public void KeysTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        target.Add("f", "b");
    //        target.Add("g", "b");
    //        ICollection<string> keys = target.Keys;

    //        Assert.AreEqual(3, keys.Count);
    //        Assert.IsTrue(keys.Contains("a"));
    //        Assert.IsTrue(keys.Contains("f"));
    //        Assert.IsTrue(keys.Contains("g"));
    //    }


    //    [Test]
    //    [ExpectedException(typeof(Exception), ExpectedMessage = "SetItem")]
    //    public void IndexerTest()
    //    {
    //        MockExceptionDictionary target = new MockExceptionDictionary();
    //        target[2] = 2;
    //    }


    //    [Test]
    //    [ExpectedException(typeof(Exception), ExpectedMessage = "RemoveItem")]
    //    public void RemoveTest()
    //    {
    //        MockExceptionDictionary target = new MockExceptionDictionary();
    //        target.Remove(2);
    //    }


    //    [Test]
    //    public void ValuesTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        target.Add("f", "s");
    //        target.Add("g", "z");
    //        ICollection<string> values = target.Values;

    //        Assert.AreEqual(3, values.Count);
    //        Assert.IsTrue(values.Contains("b"));
    //        Assert.IsTrue(values.Contains("s"));
    //        Assert.IsTrue(values.Contains("z"));
    //    }

    //}

    //[TestFixture]
    //public class DictionaryBaseIDictionaryTest
    //{

    //    [Test]
    //    public void AddTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        ((IDictionary)target).Add("a", "b");
    //        Assert.IsTrue(target.ContainsKey("a"));
    //    }


    //    [Test]
    //    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
    //    public void AddInvalidKeyTypeTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        ((IDictionary)target).Add(2, "a");
    //    }


    //    [Test]
    //    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
    //    public void AddInvalidValueTypeTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        ((IDictionary)target).Add("a", 2);
    //    }


    //    [Test]
    //    public void ContainsTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        IDictionary dictionary = target;
    //        Assert.IsTrue(dictionary.Contains("a"));
    //        Assert.IsFalse(dictionary.Contains("b"));
    //        Assert.IsFalse(dictionary.Contains("c"));
    //        Assert.IsFalse(dictionary.Contains(2));
    //    }


    //    [Test]
    //    public void GetEnumeratorTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        target.Add("s", "r");
    //        target.Add("f", "t");
    //        IDictionary dictionary = target;
    //        IDictionaryEnumerator enumerator = dictionary.GetEnumerator();
    //        DictionaryEntry current;

    //        enumerator.MoveNext();
    //        current = (DictionaryEntry)enumerator.Current;
    //        Assert.AreEqual("a", current.Key);
    //        Assert.AreEqual("b", current.Value);


    //        enumerator.MoveNext();
    //        current = (DictionaryEntry)enumerator.Current;
    //        Assert.AreEqual("s", current.Key);
    //        Assert.AreEqual("r", current.Value);

    //        enumerator.MoveNext();
    //        current = (DictionaryEntry)enumerator.Current;
    //        Assert.AreEqual("f", current.Key);
    //        Assert.AreEqual("t", current.Value);
    //    }


    //    [Test]
    //    public void KeysTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        target.Add("f", "b");
    //        target.Add("g", "b");
    //        ICollection keys = ((IDictionary)target).Keys;

    //        Assert.AreEqual(3, keys.Count);
    //        string[] strings = new string[3];
    //        keys.CopyTo(strings, 0);
    //        Assert.AreEqual("a", strings[0]);
    //        Assert.AreEqual("f", strings[1]);
    //        Assert.AreEqual("g", strings[2]);
    //    }


    //    [Test]
    //    public void ValuesTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        target.Add("f", "z");
    //        target.Add("g", "x");
    //        ICollection values = ((IDictionary)target).Values;

    //        Assert.AreEqual(3, values.Count);
    //        string[] strings = new string[3];
    //        values.CopyTo(strings, 0);
    //        Assert.AreEqual("b", strings[0]);
    //        Assert.AreEqual("z", strings[1]);
    //        Assert.AreEqual("x", strings[2]);
    //    }


    //    [Test]
    //    public void IndexerSetTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        ((IDictionary)target)["a"] = "b";
    //        Assert.IsTrue(target.ContainsKey("a"));
    //    }


    //    [Test]
    //    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
    //    public void IndexerSetInvalidKeyTypeTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        ((IDictionary)target)[2] = "a";
    //    }


    //    [Test]
    //    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
    //    public void IndexerSetInvalidValueTypeTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        ((IDictionary)target)["a"] = 2;
    //    }


    //    [Test]
    //    public void IndexerGetTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        Assert.AreEqual("b", ((IDictionary)target)["a"]);
    //    }


    //    [Test]
    //    public void IsFixedSizeTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        Assert.IsFalse(((IDictionary)target).IsFixedSize);
    //    }


    //    [Test]
    //    public void IsReadOnlyTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        Assert.IsFalse(((IDictionary)target).IsReadOnly);
    //    }


    //    [Test]
    //    public void RemoveTest()
    //    {
    //        MockStringDictionary target = new MockStringDictionary();
    //        target.Add("a", "b");
    //        ((IDictionary)target).Remove("a");

    //        Assert.IsFalse(target.ContainsKey("a"));
    //    }

    //}



    internal class MockStringDictionary : AutoKeyDictionary<string, int>
    {
        public MockStringDictionary()
        {
        }



        public MockStringDictionary(IEqualityComparer<string> comparer)
            : base(comparer)
        {
        }




        public MockStringDictionary(IEqualityComparer<string> comparer, int capacity)
            : base(comparer, capacity)
        {
        }


        protected override string GetKeyForItem(int item)
        {
            return item.ToString();
        }
    }
}