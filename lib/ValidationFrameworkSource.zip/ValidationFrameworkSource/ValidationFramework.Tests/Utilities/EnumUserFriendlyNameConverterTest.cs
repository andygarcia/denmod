using NUnit.Framework;
using ValidationFramework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class EnumUserFriendlyNameConverterTest
    {
        private enum Values
        {
            [EnumUserFriendlyName("O_n_e")]
            One,
            [EnumUserFriendlyName("T_w_o")]
            Two,
            TwentyFour
        }



        [Test]
        public void ConvertToString1Test()
        {
            Values value = Values.One;

            string expected = "O_n_e";
            string actual = EnumUserFriendlyNameConverter.Convert(value);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ConvertToString2Test()
        {
            Values value = Values.TwentyFour;

            string expected = "Twenty Four";
            string actual = EnumUserFriendlyNameConverter.Convert(value);
            Assert.AreEqual(expected, actual);
        }

    }
}
