using System.Collections.Generic;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    /// <summary>
    ///This is a test class for ValidationFramework.ValidatableBase and is intended
    ///to contain all ValidationFramework.ValidatableBase Unit Tests
    ///</summary>
    [TestFixture]
    public class ValidatableBaseTest
    {
        [Test]
        public void AllRuleTest()
        {
            ValidatableBaseTestClass validatableBaseTestClass = new ValidatableBaseTestClass(null);
            IList<ValidationResult> validationResults = validatableBaseTestClass.ValidatorResultsInError;
            Assert.AreEqual(3, validationResults.Count);
            validatableBaseTestClass.Foo = "asasd";
            bool isValid = validatableBaseTestClass.IsValid;
            Assert.AreEqual(0, validatableBaseTestClass.ValidatorResultsInError.Count);
        }

        [Test]
        public void SingleRuleSetRuleTest()
        {
            ValidatableBaseTestClass validatableBaseTestClass = new ValidatableBaseTestClass("B");
            Assert.AreEqual(1, validatableBaseTestClass.ValidatorResultsInError.Count);
            validatableBaseTestClass.Foo = "asasd";
            bool isValid = validatableBaseTestClass.IsValid;
            Assert.AreEqual(0, validatableBaseTestClass.ValidatorResultsInError.Count);
        }

    }
    public class ValidatableBaseTestClass : ValidatableBase
    {
        public ValidatableBaseTestClass(string ruleSet)
            : base(true, ruleSet)
        {

        }

        [RequiredStringRule]
        [RequiredStringRule(RuleSet = "a")]
        [RequiredStringRule(RuleSet = "b")]
        public string Foo
        {
            get;
            set;
        }
    }
}