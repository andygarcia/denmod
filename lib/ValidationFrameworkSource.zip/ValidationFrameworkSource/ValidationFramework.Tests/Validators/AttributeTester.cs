using NUnit.Framework;

namespace ValidationFramework.Tests
{
    public static class AttributeTester
    {

        public static void CheckDefaultValues<T>(RuleAttribute ruleAttribute)
        {

            Rule propertyRule = TypeHelper.CreatePropertyRule<Rule>(ruleAttribute, new MockPropertyDescriptor<T>("foo"));
            Rule parameterRule = TypeHelper.CreateParameterRule<Rule>(ruleAttribute, new MockParameterDescriptor<T>("foo"));

            Assert.IsNull(ruleAttribute.ErrorMessage);
            Assert.IsNull(ruleAttribute.RuleSet);
            Assert.IsFalse(ruleAttribute.UseErrorMessageProvider);
            Assert.IsNull(propertyRule.ErrorMessage);
            Assert.IsNull(parameterRule.ErrorMessage);
            Assert.IsFalse(parameterRule.UseErrorMessageProvider);
            Assert.IsFalse(propertyRule.UseErrorMessageProvider);
            Assert.IsNull(parameterRule.RuleSet);
            Assert.IsNull(propertyRule.RuleSet);

        }

        public static void CheckNonDefaultValues<T>(RuleAttribute ruleAttribute)
        {
            string expectedRuleSet = "MYRULESET";
            string expectedErrorMessage = "ErrorMessage";

            ruleAttribute.UseErrorMessageProvider = true;
            ruleAttribute.RuleSet = expectedRuleSet;
            ruleAttribute.ErrorMessage = expectedErrorMessage;

            Rule propertyRule = TypeHelper.CreatePropertyRule<Rule>(ruleAttribute, new MockPropertyDescriptor<T>("foo"));
            Rule parameterRule = TypeHelper.CreateParameterRule<Rule>(ruleAttribute, new MockParameterDescriptor<T>("foo"));


            Assert.AreEqual(expectedErrorMessage, ruleAttribute.ErrorMessage);
            Assert.IsTrue(ruleAttribute.UseErrorMessageProvider);
            Assert.AreEqual(expectedRuleSet, ruleAttribute.RuleSet);
            Assert.AreEqual(expectedErrorMessage, propertyRule.ErrorMessage);
            Assert.AreEqual(expectedErrorMessage, parameterRule.ErrorMessage);
            Assert.IsTrue(parameterRule.UseErrorMessageProvider);
            Assert.IsTrue(propertyRule.UseErrorMessageProvider);
            Assert.AreEqual(expectedRuleSet, parameterRule.RuleSet);
            Assert.AreEqual(expectedRuleSet, propertyRule.RuleSet);

        }
    }
}
