using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace ValidationFramework.Tests.Validators
{
    [TestFixture]
    public class CustomValidationEventArgsTests
    {


        const string expectedValidationTypeName = "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests";
        const string expectedValidationMethod = "ValidateValid";
        const string expectedRuleInterpretation = "expectedRuleInterpretation";
        const string expectedRuleErrorMessage = "expectedRuleErrorMessage";
        const string expectedTargetObject = "expectedTargetObject";
        const string expectedTargetMemberValue = "expectedTargetMemberValue";
        const string expectedContext = "expectedContext";
        const string expectedRuleSet = "EXPECTEDRULESET";

        [Test]
        public void Test()
        {

            CustomRule rule = new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, expectedValidationTypeName, expectedValidationMethod, expectedRuleInterpretation);
            CustomValidationEventArgs customValidationEventArgs = new CustomValidationEventArgs(rule, expectedTargetObject, expectedTargetMemberValue, expectedContext);

            Assert.AreEqual(rule, customValidationEventArgs.CustomRule);
            Assert.AreEqual(expectedTargetObject, customValidationEventArgs.TargetObjectValue);
            Assert.AreEqual(expectedTargetMemberValue, customValidationEventArgs.TargetMemberValue);
            Assert.AreEqual(expectedContext, customValidationEventArgs.Context);
            Assert.AreEqual(rule, customValidationEventArgs.CustomRule);

            Assert.IsFalse(customValidationEventArgs.IsValid);
            customValidationEventArgs.IsValid = true;
            Assert.IsTrue(customValidationEventArgs.IsValid);

            Assert.IsNull(customValidationEventArgs.ErrorMessage);
            customValidationEventArgs.ErrorMessage = expectedRuleErrorMessage;
            Assert.AreEqual(expectedRuleErrorMessage, customValidationEventArgs.ErrorMessage);

        }
    }
}
