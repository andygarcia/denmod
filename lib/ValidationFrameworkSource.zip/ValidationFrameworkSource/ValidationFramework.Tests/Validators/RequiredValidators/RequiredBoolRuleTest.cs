using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class RequiredBoolRuleTest
    {


        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";



        [Test]
        public void Constructor1()
        {
            RequiredBoolRule rule = new RequiredBoolRule(expectedErrorMessage, expectedRuleSet, false);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);

        }


        [Test]
        public void Constructor2()
        {
            RequiredBoolRule rule = new RequiredBoolRule(expectedErrorMessage);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);

        }


        [Test]
        public void Constructor3()
        {
            RequiredBoolRule rule = new RequiredBoolRule();
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);

        }


        [Test]
        public void RuleRuleInterpretation()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(bool).TypeHandle, "foo");
            RequiredBoolRule rule = new RequiredBoolRule(null, null, false);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule.RuleInterpretation);
        }



        [Test]
        public void Equality()
        {
            RequiredBoolRule rule1 = new RequiredBoolRule(null, null, false);
            RequiredBoolRule rule2 = new RequiredBoolRule(null, null, false);
            Assert.IsTrue(rule1.IsEquivalent(rule2));
            rule2 = new RequiredBoolRule("foo", null, false);
            Assert.IsTrue(rule1.IsEquivalent(rule2));

        }

        [Test]
        public void Validate()
        {

            RequiredBoolRule nullableRule = new RequiredBoolRule(null, null, false);
            Assert.IsNotNull(nullableRule.Validate(null, null, null));
            Assert.IsNull(nullableRule.Validate(null, false, null));
            Assert.IsNull(nullableRule.Validate(null, true, null));

        }


        [Test]
        public void CheckTypes()
        {
            RequiredBoolRule rule = new RequiredBoolRule(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(bool).TypeHandle, "foo"), "InfoDescriptor");
        }

        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.Boolean' to be used for the ValidationFramework.RequiredBoolRule. Actual Type 'System.Object'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            RequiredBoolRule rule = new RequiredBoolRule(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(object).TypeHandle, "foo"), "InfoDescriptor");
        }
        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.Boolean' to be used for the ValidationFramework.RequiredBoolRule. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException2()
        {
            RequiredBoolRule rule = new RequiredBoolRule(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.Boolean' to be used for the ValidationFramework.RequiredBoolRule. Actual Type 'System.Collections.Generic.List<T>'.\r\nParameter name: value")]
        public void CheckTypesException3()
        {
            RequiredBoolRule rule = new RequiredBoolRule(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(List<>).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}