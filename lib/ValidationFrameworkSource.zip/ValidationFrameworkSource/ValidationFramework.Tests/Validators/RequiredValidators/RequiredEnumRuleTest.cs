using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class RequiredEnumRuleTest
    {
        private enum Values
        {
            Two,
            One
        }


        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";


        [Test]
        public void Construction1()
        {
            RequiredRule<Values> rule = new RequiredRule<Values>(expectedErrorMessage, expectedRuleSet, false, Values.One);
            Assert.AreEqual(Values.One, rule.InitialValue);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction2()
        {
            RequiredRule<Values> rule = new RequiredRule<Values>(expectedErrorMessage, expectedRuleSet, false);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction3()
        {
            RequiredRule<Values> rule = new RequiredRule<Values>(expectedErrorMessage);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction4()
        {
            RequiredRule<Values> rule = new RequiredRule<Values>();
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }

        
        [Test]
        public void Equality()
        {
            RequiredRule<Values> rule1 = new RequiredRule<Values>(null, null, false, Values.One);
            RequiredRule<Values> rule2 = new RequiredRule<Values>(null, null, false, Values.One);
            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule1 = new RequiredRule<Values>(null, null, false, Values.One);
            rule2 = new RequiredRule<Values>(null, null, false, Values.Two);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

        }


        [Test]
        public void ValidateNotNullable()
        {

            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(Values).TypeHandle, "foo");

            RequiredRule<Values> rule = new RequiredRule<Values>(null, null, false);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNull(rule.Validate(null, Values.One, null));
            Assert.IsNull(rule.Validate(null, Values.Two, null));

            RequiredRule<Values> rule2 = new RequiredRule<Values>(null, null, false, Values.One);
            ReflectionUtilities.SetField<Rule>(rule2, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNull(rule2.Validate(null, Values.Two, null));
            Assert.IsNotNull(rule2.Validate(null, Values.One, null));

        }

        
        [Test]
        public void RuleRuleInterpretation()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(Values?).TypeHandle, "foo");
            RequiredRule<Values> rule = new RequiredRule<Values>(null, null, false);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule.RuleInterpretation);
        }


        [Test]
        public void ValidateNullable()
        {

            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(Values?).TypeHandle, "foo");
            RequiredRule<Values> rule = new RequiredRule<Values>(null, null, false);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule.Validate(null, null, null));
            Assert.IsNull(rule.Validate(null, Values.One, null));
            Assert.IsNull(rule.Validate(null, Values.Two, null));

            RequiredRule<Values> rule2 = new RequiredRule<Values>(null, null, false, Values.Two);
            ReflectionUtilities.SetField<Rule>(rule2, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNull(rule2.Validate(null, null, null));
            Assert.IsNotNull(rule2.Validate(null, Values.Two, null));
            Assert.IsNull(rule2.Validate(null, Values.One, null));
        }


        [Test]
        public void CheckTypes()
        {
            RequiredRule<Values> rule = new RequiredRule<Values>(null, null, false, Values.Two);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(Values).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'ValidationFramework.Tests.RequiredEnumRuleTest+Values' to be used for the ValidationFramework.RequiredRule<ValidationFramework.Tests.RequiredEnumRuleTest+Values>. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            RequiredRule<Values> rule = new RequiredRule<Values>(null, null, false, Values.Two);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}