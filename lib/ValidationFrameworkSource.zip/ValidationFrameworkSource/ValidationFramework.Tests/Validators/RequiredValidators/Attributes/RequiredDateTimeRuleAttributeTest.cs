using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
  [TestFixture]
  public class RequiredDateTimeRuleAttributeTest
  {
    [Test]
    public void CheckDefaultValues()
    {
      RequiredDateTimeRuleAttribute ruleAttribute = new RequiredDateTimeRuleAttribute();
      Assert.AreEqual(null, ruleAttribute.InitialValue);
      RequiredRule<DateTime> propertyRule = (RequiredRule<DateTime>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<DateTime>("foo"));
      RequiredRule<DateTime> parameterRule = (RequiredRule<DateTime>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<DateTime>("foo"));
      Assert.IsFalse(propertyRule.HasInitialValue);
      Assert.IsFalse(parameterRule.HasInitialValue);
    }

    [Test]
    public void CheckNonDefaultValues()
    {
      RequiredDateTimeRuleAttribute ruleAttribute = new RequiredDateTimeRuleAttribute();
      string expectedInitialValueString = "01 Jan 2006";
      DateTime  expectedInitialValueDateTime = new DateTime(2006,1,1);
      ruleAttribute.InitialValue = expectedInitialValueString;
      Assert.AreEqual(expectedInitialValueString, ruleAttribute.InitialValue);
      RequiredRule<DateTime> propertyRule = (RequiredRule<DateTime>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<DateTime>("foo"));
      RequiredRule<DateTime> parameterRule = (RequiredRule<DateTime>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<DateTime>("foo"));
      Assert.AreEqual(expectedInitialValueDateTime, propertyRule.InitialValue);
      Assert.AreEqual(expectedInitialValueDateTime, parameterRule.InitialValue);
      Assert.IsTrue(propertyRule.HasInitialValue);
      Assert.IsTrue(parameterRule.HasInitialValue);
    }


      [Test]
      public void CallAttributeTester()
      {
          AttributeTester.CheckDefaultValues<DateTime>(new RequiredDateTimeRuleAttribute());
          AttributeTester.CheckNonDefaultValues<DateTime>(new RequiredDateTimeRuleAttribute());
      }

  }
}