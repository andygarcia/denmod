using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RequiredStringRuleAttributeTest
    {
        [Test]
        public void CheckDefaultValues()
        {
            RequiredStringRuleAttribute ruleAttribute = new RequiredStringRuleAttribute();
            Assert.IsTrue(ruleAttribute.IgnoreCase);
            Assert.IsTrue(ruleAttribute.TrimWhiteSpace);

            RequiredStringRule propertyRule = (RequiredStringRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            RequiredStringRule parameterRule = (RequiredStringRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.IsFalse(parameterRule.HasInitialValue);
            Assert.IsFalse(propertyRule.HasInitialValue);

            Assert.IsNull(parameterRule.IgnoreCase);
            Assert.IsNull(parameterRule.IgnoreCase);

            Assert.IsTrue(parameterRule.TrimWhiteSpace);
            Assert.IsTrue(propertyRule.TrimWhiteSpace);
        }

        [Test]
        public void CheckNonDefaultValuesIgnoreSpaces()
        {
            RequiredStringRuleAttribute ruleAttribute = new RequiredStringRuleAttribute();
            ruleAttribute.TrimWhiteSpace = true;
            Assert.IsNull(ruleAttribute.InitialValue);

            RequiredStringRule propertyRule = (RequiredStringRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            RequiredStringRule parameterRule = (RequiredStringRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.IsFalse(parameterRule.HasInitialValue);
            Assert.IsFalse(propertyRule.HasInitialValue);
            Assert.IsTrue(propertyRule.TrimWhiteSpace);
            Assert.IsTrue(parameterRule.TrimWhiteSpace);
        }


        [Test]
        public void CheckNonDefaultValuesInitialValue()
        {
            string expectedInitialValue = "InitialValue";
            bool expectedUseErrorMessageProvider = true;
            RequiredStringRuleAttribute ruleAttribute = new RequiredStringRuleAttribute();
            ruleAttribute.InitialValue = expectedInitialValue;
            ruleAttribute.UseErrorMessageProvider = expectedUseErrorMessageProvider;
            ruleAttribute.IgnoreCase = true;
            Assert.AreEqual(expectedInitialValue, ruleAttribute.InitialValue);
            Assert.AreEqual(expectedUseErrorMessageProvider, ruleAttribute.UseErrorMessageProvider);
            Assert.IsNotNull(ruleAttribute.InitialValue);
            Assert.IsTrue(ruleAttribute.IgnoreCase);
            Assert.IsTrue(ruleAttribute.TrimWhiteSpace);

            RequiredStringRule propertyRule = (RequiredStringRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            RequiredStringRule parameterRule = (RequiredStringRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.AreEqual(expectedInitialValue, parameterRule.InitialValue);
            Assert.AreEqual(expectedInitialValue, propertyRule.InitialValue);

            Assert.IsTrue(propertyRule.TrimWhiteSpace);
            Assert.IsTrue(parameterRule.TrimWhiteSpace);

            Assert.IsTrue(parameterRule.HasInitialValue);
            Assert.IsTrue(propertyRule.HasInitialValue);

            Assert.IsTrue(propertyRule.IgnoreCase.Value);
            Assert.IsTrue(parameterRule.IgnoreCase.Value);
        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<string>(new RequiredStringRuleAttribute());
            AttributeTester.CheckNonDefaultValues<string>(new RequiredStringRuleAttribute());
        }

    }
}