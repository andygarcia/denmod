using System;
using System.Xml.Serialization;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RequiredObjectRuleAttributeTest
    {

        [XmlRoot("person")]
        public class Person : IEquatable<Person>
        {
            [XmlAttribute("name")]
            public string Name
            {
                get;
                set;
            }

            [XmlAttribute("age")]
            public int Age
            {
                get;
                set;
            }

            public bool Equals(Person other)
            {
                return Name == other.Name && Age == other.Age;
            }
        }

        [Test]
        public void CheckDefaultValues()
        {
            RequiredObjectRuleAttribute ruleAttribute = new RequiredObjectRuleAttribute();
            RequiredRule<Person> propertyRule = (RequiredRule<Person>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<Person>("foo"));
            RequiredRule<Person> parameterRule = (RequiredRule<Person>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<Person>("foo"));
            Assert.IsFalse(parameterRule.HasInitialValue);
            Assert.IsFalse(propertyRule.HasInitialValue);
        }

        [Test]
        public void CheckNonDefaultValues()
        {
            Person expectedPerson = new Person();
            expectedPerson.Name = "john";
            expectedPerson.Age = 23;
            string validatorXml = "<person name='john' age='23'/>";
            RequiredObjectRuleAttribute ruleAttribute = new RequiredObjectRuleAttribute();
            string expectedInitialValue = validatorXml;
            ruleAttribute.InitialValue = expectedInitialValue; ;
            Assert.AreEqual(expectedInitialValue, ruleAttribute.InitialValue);
            RequiredRule<Person> propertyRule = (RequiredRule<Person>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<Person>("foo"));
            RequiredRule<Person> parameterRule = (RequiredRule<Person>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<Person>("foo"));
            Assert.IsTrue(expectedPerson.Equals(parameterRule.InitialValue));
            Assert.IsTrue(expectedPerson.Equals(propertyRule.InitialValue));
            Assert.IsTrue(parameterRule.HasInitialValue);
            Assert.IsTrue(propertyRule.HasInitialValue);
        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<object>(new RequiredObjectRuleAttribute());
            AttributeTester.CheckNonDefaultValues<object>(new RequiredObjectRuleAttribute());
        }
    }
}