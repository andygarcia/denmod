using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RequiredBoolRuleAttributeTest
    {

        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<bool>(new RequiredBoolRuleAttribute());
            AttributeTester.CheckNonDefaultValues<bool>(new RequiredBoolRuleAttribute());
        }


    }
}