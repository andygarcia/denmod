using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
  [TestFixture]
  public class RequiredGuidRuleAttributeTest
  {
    [Test]
    public void CheckDefaultValues()
    {
      RequiredGuidRuleAttribute ruleAttribute = new RequiredGuidRuleAttribute();
      Assert.AreEqual(null, ruleAttribute.InitialValue);
      RequiredRule<Guid> propertyRule = (RequiredRule<Guid>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<Guid>("foo"));
      RequiredRule<Guid> parameterRule = (RequiredRule<Guid>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<Guid>("foo"));
      Assert.IsFalse(propertyRule.HasInitialValue);
      Assert.IsFalse(parameterRule.HasInitialValue);
    }

    [Test]
    public void CheckNonDefaultValues()
    { 
      string expectedInitialValueString = "11111111-1111-1111-1111-111111111111";
      Guid expectedInitialValueGuid = new Guid(expectedInitialValueString);
      RequiredGuidRuleAttribute ruleAttribute = new RequiredGuidRuleAttribute();
      ruleAttribute.InitialValue = expectedInitialValueString;
      Assert.AreEqual(expectedInitialValueString, ruleAttribute.InitialValue);
      RequiredRule<Guid> propertyRule = (RequiredRule<Guid>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<Guid>("foo"));
      RequiredRule<Guid> parameterRule = (RequiredRule<Guid>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<Guid>("foo"));
      Assert.AreEqual(expectedInitialValueGuid, propertyRule.InitialValue);
      Assert.AreEqual(expectedInitialValueGuid, parameterRule.InitialValue);
      Assert.IsTrue(propertyRule.HasInitialValue);
      Assert.IsTrue(parameterRule.HasInitialValue);
    }




      [Test]
      public void CallAttributeTester()
      {
          AttributeTester.CheckDefaultValues<Guid>(new RequiredGuidRuleAttribute());
          AttributeTester.CheckNonDefaultValues<Guid>(new RequiredGuidRuleAttribute());
      }
  }
}