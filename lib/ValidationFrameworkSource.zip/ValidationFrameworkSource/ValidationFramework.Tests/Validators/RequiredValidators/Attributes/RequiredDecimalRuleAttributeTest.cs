using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RequiredDecimalRuleAttributeTest
    {
        [Test]
        public void CheckDefaultValues()
        {
            RequiredDecimalRuleAttribute ruleAttribute = new RequiredDecimalRuleAttribute();
            RequiredRule<decimal> propertyRule = (RequiredRule<decimal>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<decimal>("foo"));
            RequiredRule<decimal> parameterRule = (RequiredRule<decimal>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<decimal>("foo"));
            Assert.IsFalse(propertyRule.HasInitialValue);
            Assert.IsFalse(parameterRule.HasInitialValue);
        }

        [Test]
        public void CheckNonDefaultValues()
        {
            RequiredDecimalRuleAttribute ruleAttribute = new RequiredDecimalRuleAttribute();
            decimal expectedInitialValueDecimal = 3;
            double expectedInitialValueDouble = 3;
            ruleAttribute.InitialValue = expectedInitialValueDouble;
            Assert.AreEqual(expectedInitialValueDouble, ruleAttribute.InitialValue);
            RequiredRule<decimal> propertyRule = (RequiredRule<decimal>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<decimal>("foo"));
            RequiredRule<decimal> parameterRule = (RequiredRule<decimal>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<decimal>("foo"));
            Assert.AreEqual(expectedInitialValueDecimal, propertyRule.InitialValue);
            Assert.AreEqual(expectedInitialValueDecimal, parameterRule.InitialValue);
            Assert.IsTrue(propertyRule.HasInitialValue);
            Assert.IsTrue(parameterRule.HasInitialValue);
        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<decimal>(new RequiredDecimalRuleAttribute());
            AttributeTester.CheckNonDefaultValues<decimal>(new RequiredDecimalRuleAttribute());
        }
    }
}