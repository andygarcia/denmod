using NUnit.Framework;

namespace ValidationFramework.Tests
{

    enum Value
    {
        good,
        bad
    }
    [TestFixture]
    public class RequiredEnumRuleAttributeTest
    {
        [Test]
        public void CheckDefaultValuesNotNullable()
        {
            RequiredEnumRuleAttribute ruleAttribute = new RequiredEnumRuleAttribute();
            Assert.IsNull(ruleAttribute.ErrorMessage);
            Assert.IsNull(ruleAttribute.InitialValue);
            RequiredRule<Value> propertyRule = (RequiredRule<Value>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<Value>("foo"));
            RequiredRule<Value> parameterRule = (RequiredRule<Value>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<Value>("foo"));
            Assert.IsNull(propertyRule.ErrorMessage);
            Assert.AreEqual(Value.good, propertyRule.InitialValue);
            Assert.IsNull(parameterRule.ErrorMessage);
            Assert.AreEqual(Value.good, parameterRule.InitialValue);
        }

        [Test]
        public void CheckDefaultValuesNullable()
        {
            RequiredEnumRuleAttribute ruleAttribute = new RequiredEnumRuleAttribute();
            Assert.IsNull(ruleAttribute.InitialValue);
            RequiredRule<Value> propertyRule = (RequiredRule<Value>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<Value?>("foo"));
            RequiredRule<Value> parameterRule = (RequiredRule<Value>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<Value?>("foo"));
            Assert.IsFalse(propertyRule.HasInitialValue);
            Assert.IsFalse(parameterRule.HasInitialValue);
        }

        [Test]
        public void CheckNonDefaultValues()
        {
            RequiredEnumRuleAttribute ruleAttribute = new RequiredEnumRuleAttribute();
            string expectedInitialValueString = "bad";
            ruleAttribute.InitialValue = expectedInitialValueString;
            Assert.AreEqual(expectedInitialValueString, ruleAttribute.InitialValue);
            RequiredRule<Value> propertyRule = (RequiredRule<Value>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<Value>("foo"));
            RequiredRule<Value> parameterRule = (RequiredRule<Value>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<Value>("foo"));
            Assert.AreEqual(Value.bad, propertyRule.InitialValue);
            Assert.AreEqual(Value.bad, parameterRule.InitialValue);
            Assert.IsTrue(propertyRule.HasInitialValue);
            Assert.IsTrue(parameterRule.HasInitialValue);
        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<Value>(new RequiredEnumRuleAttribute());
            AttributeTester.CheckNonDefaultValues<Value>(new RequiredEnumRuleAttribute());
        }
    }
}