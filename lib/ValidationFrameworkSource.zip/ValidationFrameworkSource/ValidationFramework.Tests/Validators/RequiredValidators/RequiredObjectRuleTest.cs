using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class RequiredObjectRuleTest
    {


        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";
        const string expectedInitialValue = "a";

        [Test]
        public void Construction1()
        {
            RequiredRule<object> rule = new RequiredRule<object>(expectedErrorMessage, expectedRuleSet, false, expectedInitialValue);
            Assert.AreEqual(expectedInitialValue, rule.InitialValue);
            Assert.IsTrue(rule.HasInitialValue);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }
        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: initialValue")]
        public void Construction1InitialValueNull()
        {
            RequiredRule<object> rule = new RequiredRule<object>(expectedErrorMessage, expectedRuleSet, false, null);
        }


        [Test]
        public void Construction2()
        {
            RequiredRule<object> rule = new RequiredRule<object>(expectedErrorMessage, expectedRuleSet, false);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction3()
        {
            RequiredRule<object> rule = new RequiredRule<object>(expectedErrorMessage);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction4()
        {
            RequiredRule<object> rule = new RequiredRule<object>();
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Validate()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(object).TypeHandle, "foo");

            RequiredRule<object> rule = new RequiredRule<object>(null, null, false);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");

            Assert.IsNotNull(rule.Validate(null, null, null));
            Assert.IsNull(rule.Validate(null, "s", null));

            RequiredStringRule nullableRule2 = new RequiredStringRule(null, null, false, "a", true, true);
            Assert.IsNotNull(nullableRule2.Validate(null, "a", null));
            Assert.IsNull(nullableRule2.Validate(null, "s", null));
        }


        [Test]
        public void RuleRuleInterpretation()
        {

            RequiredRule<object> nullableRule = new RequiredRule<object>(null, null, false);
            Assert.IsNotNull(nullableRule.RuleInterpretation);

        }
    }
}