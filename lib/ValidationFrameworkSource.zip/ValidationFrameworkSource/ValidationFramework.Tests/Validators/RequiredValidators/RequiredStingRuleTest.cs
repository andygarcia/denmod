using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class RequiredStringRuleTest
    {


        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";
        const string expectedInitialValue = "a";

        [Test]
        public void Construction1()
        {
            RequiredStringRule rule = new RequiredStringRule(expectedErrorMessage, expectedRuleSet, false, true);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsTrue(rule.TrimWhiteSpace);
            Assert.IsNull(rule.IgnoreCase);
        }


        [Test]
        public void Construction2()
        {
            RequiredStringRule rule = new RequiredStringRule(expectedErrorMessage, expectedRuleSet, false, expectedInitialValue, true, true);
            Assert.IsTrue(rule.HasInitialValue);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.AreEqual(expectedInitialValue, rule.InitialValue);
            Assert.IsTrue(rule.TrimWhiteSpace);
            Assert.IsTrue(rule.IgnoreCase.Value);
        }


        [Test]
        [ExpectedException(typeof(NullReferenceException))]
        public void Construction2InitialValueNull()
        {
             new RequiredStringRule(expectedErrorMessage, expectedRuleSet, false, null, true, true);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: initialValue")]
        public void Construction2InitialValueEmpty()
        {
            RequiredStringRule rule = new RequiredStringRule(expectedErrorMessage, expectedRuleSet, false, string.Empty, true, true);
        }


        [Test]
        public void Construction3()
        {
            RequiredStringRule rule = new RequiredStringRule(expectedErrorMessage);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsTrue(rule.TrimWhiteSpace);
            Assert.IsNull(rule.IgnoreCase);
        }


        [Test]
        public void Construction4()
        {
            RequiredStringRule rule = new RequiredStringRule();
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsTrue(rule.TrimWhiteSpace);
            Assert.IsNull(rule.IgnoreCase);
        }




        [Test]
        public void Equality()
        {
            RequiredStringRule rule1 = new RequiredStringRule(null, null, false, "a", true, true);
            RequiredStringRule rule2 = new RequiredStringRule(null, null, false, "a", true, true);
            Assert.IsTrue(rule1.IsEquivalent(rule2));


            rule1 = new RequiredStringRule(null, null, false, "a", true, true);
            rule2 = new RequiredStringRule(null, null, false, "a", true, false);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

            rule1 = new RequiredStringRule(null, null, false, "a", true, true);
            rule2 = new RequiredStringRule(null, null, false, "a", false, true);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

            rule1 = new RequiredStringRule(null, null, false, "a", true, true);
            rule2 = new RequiredStringRule(null, null, false, " a ", true, true);
            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule1 = new RequiredStringRule(null, null, false, "a", true, true);
            rule2 = new RequiredStringRule(null, null, false, "b", true, true);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

        }

        [Test]
        public void ValidateNoInitialValueTrimSpacesIgnoreCase()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, true);

            Assert.IsNotNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, string.Empty, null));
            Assert.IsNotNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "s", null));
            Assert.IsNull(rule.Validate(null, " s ", null));
            Assert.IsNull(rule.Validate(null, "A", null));
            Assert.IsNull(rule.Validate(null, " A ", null));

        }
        [Test]
        public void ValidateInitialValueTrimSpacesIgnoreCase()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, " a ", true, true);

            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNull(rule.Validate(null, string.Empty, null));
            Assert.IsNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "s", null));
            Assert.IsNull(rule.Validate(null, " s ", null));
            Assert.IsNotNull(rule.Validate(null, "a", null));
            Assert.IsNotNull(rule.Validate(null, "\t a ", null));
            Assert.IsNotNull(rule.Validate(null, "A", null));
            Assert.IsNotNull(rule.Validate(null, "\t A ", null));

        }

        [Test]
        public void ValidateInitialValueNoTrimSpacesIgnoreCase()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, "a", false, true);

            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNull(rule.Validate(null, string.Empty, null));
            Assert.IsNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "s", null));
            Assert.IsNull(rule.Validate(null, " s ", null));
            Assert.IsNotNull(rule.Validate(null, "a", null));
            Assert.IsNull(rule.Validate(null, "\t a ", null));
            Assert.IsNotNull(rule.Validate(null, "A", null));
            Assert.IsNull(rule.Validate(null, "\t A ", null));

        }
        [Test]
        public void ValidateInitialValueTrimSpacesNoIgnoreCase()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, "a", true, false);

            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNull(rule.Validate(null, string.Empty, null));
            Assert.IsNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "s", null));
            Assert.IsNull(rule.Validate(null, " s ", null));
            Assert.IsNotNull(rule.Validate(null, "a", null));
            Assert.IsNotNull(rule.Validate(null, "\t a ", null));
            Assert.IsNull(rule.Validate(null, "A", null));
            Assert.IsNull(rule.Validate(null, "\t A ", null));

        }

        [Test]
        public void ValidateInitialValueNoTrimSpacesNoIgnoreCase()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, "a", false, false);

            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNull(rule.Validate(null, string.Empty, null));
            Assert.IsNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "s", null));
            Assert.IsNull(rule.Validate(null, " s ", null));
            Assert.IsNotNull(rule.Validate(null, "a", null));
            Assert.IsNull(rule.Validate(null, " a ", null));
            Assert.IsNull(rule.Validate(null, "A", null));
            Assert.IsNull(rule.Validate(null, " A ", null));

        }
        [Test]
        public void ValidateNoInitialValueNoTrimSpacesNoIgnoreCase()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, false);

            Assert.IsNotNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, string.Empty, null));
            Assert.IsNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "s", null));
            Assert.IsNull(rule.Validate(null, " s ", null));
            Assert.IsNull(rule.Validate(null, "a", null));
            Assert.IsNull(rule.Validate(null, " a ", null));
            Assert.IsNull(rule.Validate(null, "A", null));
            Assert.IsNull(rule.Validate(null, " A ", null));
        }

        [Test]
        public void ValidateNoInitialValueTrimSpacesNoIgnoreCase()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, true);

            Assert.IsNotNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, string.Empty, null));
            Assert.IsNotNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "s", null));
            Assert.IsNull(rule.Validate(null, " s ", null));
            Assert.IsNull(rule.Validate(null, "a", null));
            Assert.IsNull(rule.Validate(null, " a ", null));
            Assert.IsNull(rule.Validate(null, "A", null));
            Assert.IsNull(rule.Validate(null, " A ", null));

        }

        [Test]
        public void RuleRuleInterpretation1()
        {

            RequiredStringRule rule = new RequiredStringRule(null, null, false, true);
            Assert.IsNotNull(rule.RuleInterpretation);

        }
        [Test]
        public void RuleRuleInterpretation2()
        {

            RequiredStringRule rule = new RequiredStringRule(null, null, false, false);
            Assert.IsNotNull(rule.RuleInterpretation);

        }
        [Test]
        public void RuleRuleInterpretation3()
        {

            RequiredStringRule rule = new RequiredStringRule(null, null, false, "initialValue",true, true);
            Assert.IsNotNull(rule.RuleInterpretation);

        }


        [Test]
        public void CheckTypes()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, true);
            ReflectionUtilities.SetField<Rule>(rule, new MockInfoDescriptor(typeof(string).TypeHandle, "foo"), "infoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.String' to be used for the ValidationFramework.RequiredStringRule. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            RequiredStringRule rule = new RequiredStringRule(null, null, false, true);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}