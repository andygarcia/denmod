using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class RequiredRuleTest
    {


        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";
        const int expectedInitialValue = 3;

        [Test]
        public void Construction1()
        {
            RequiredRule<int> rule = new RequiredRule<int>(expectedErrorMessage, expectedRuleSet, false);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);

        }


        [Test]
        public void Construction2()
        {
            RequiredRule<int> rule = new RequiredRule<int>(expectedErrorMessage, expectedRuleSet, false, expectedInitialValue);
            Assert.IsTrue(rule.HasInitialValue);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedInitialValue, rule.InitialValue);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);

        }


        [Test]
        public void Construction3()
        {
            RequiredRule<int> rule = new RequiredRule<int>(expectedErrorMessage);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);

        }


        [Test]
        public void Construction4()
        {
            RequiredRule<int> rule = new RequiredRule<int>();
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);

        }
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ThrowOnNoInitialValue()
        {
            RequiredRule<int> rule = new RequiredRule<int>();
            int initialValue = rule.InitialValue;
        }

        
        [Test]
        public void Equality()
        {
            RequiredRule<int> rule1 = new RequiredRule<int>(null, null, false);
            RequiredRule<int> rule2 = new RequiredRule<int>(null, null, false);
            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule1 = new RequiredRule<int>(null, null, false, 1);
            rule2 = new RequiredRule<int>(null, null, false, 1);
            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule1 = new RequiredRule<int>(null, null, false, 1);
            rule2 = new RequiredRule<int>(null, null, false, 2);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

            rule1 = new RequiredRule<int>(null, null, false);
            rule2 = new RequiredRule<int>(null, null, false, 1);
            Assert.IsFalse(rule1.IsEquivalent(rule2));
            
        }


        [Test]
        public void ErrorMessage()
        {
            RequiredRule<int> rule1 = new RequiredRule<int>(null, null, false);
            object returnValue1 = ReflectionUtilities.CallMethod<RequiredRule<int>>(rule1, "GetComputedErrorMessage", "foo", "testMemberType");
            Assert.AreEqual("The testMemberType 'foo' is required.", returnValue1);

            RequiredRule<int> rule2 = new RequiredRule<int>(null, null, false, 2);
            object returnValue2 = ReflectionUtilities.CallMethod<RequiredRule<int>>(rule2, "GetComputedErrorMessage", "foo", "testMemberType");
            Assert.AreEqual("The testMemberType 'foo' is required and cannot be '2'.", returnValue2);
        }


        [Test]
        public void RuleInterpretation()
        {
            RequiredRule<int> rule1 = new RequiredRule<int>(null, null, false);
            Assert.AreEqual("The value must not be null", rule1.RuleInterpretation);

            RequiredRule<int> rule2 = new RequiredRule<int>(null, null, false, 2);
            Assert.AreEqual("The value must not be '2'", rule2.RuleInterpretation);
        }


        [Test]
        public void ValidateNullable()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int?).TypeHandle, "foo");
            RequiredRule<int> rule1 = new RequiredRule<int>(null, null, false);
            ReflectionUtilities.SetField<Rule>(rule1, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule1.Validate(null, null, null));
            Assert.IsNull(rule1.Validate(null, 4, null));
            Assert.IsNull(rule1.Validate(null, 0, null));

            MockInfoDescriptor mockInfoDescriptor2 = new MockInfoDescriptor(typeof(int?).TypeHandle, "foo");
            RequiredRule<int> rule2 = new RequiredRule<int>(null, null, false, 2);
            ReflectionUtilities.SetField<Rule>(rule2, mockInfoDescriptor2, "infoDescriptor");
            Assert.IsNotNull(rule2.Validate(null, 2, null));
            Assert.IsNull(rule2.Validate(null, 4, null));
            Assert.IsNull(rule2.Validate(null, null, null));
            Assert.IsNull(rule2.Validate(null, 0, null));

        }


        [Test]
        public void RuleRuleInterpretationNullInitialValue()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");
            RequiredRule<int> rule = new RequiredRule<int>(null, null, false);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule.RuleInterpretation);
        }


        [Test]
        public void RuleRuleInterpretationNotNullInitialValue()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");
            RequiredRule<int> rule = new RequiredRule<int>(null, null, false, 2);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule.RuleInterpretation);
        }


        [Test]
        public void ValidateNotNullable()
        {

            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");


            RequiredRule<int> rule = new RequiredRule<int>(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, mockInfoDescriptor, "InfoDescriptor");
            Assert.IsNotNull(rule.Validate(null, default(int), null));
            Assert.IsNull(rule.Validate(null, 4, null));

            MockInfoDescriptor mockInfoDescriptor2 = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");
            RequiredRule<int> rule2 = new RequiredRule<int>(null, null, false, 2);
            ReflectionUtilities.SetProperty<Rule>(rule2, mockInfoDescriptor2, "InfoDescriptor");
            Assert.IsNotNull(rule2.Validate(null, 2, null));
            Assert.IsNull(rule2.Validate(null, 4, null));

        }


        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void NullInfoDescriptor()
        {
            RequiredRule<int> rule = new RequiredRule<int>(null, null, false);
            rule.Validate(1, default(int), null);
        }


        [Test]
        public void CheckTypes()
        {
            RequiredRule<int> rule = new RequiredRule<int>(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(Nullable<int>).TypeHandle, "foo"), "InfoDescriptor");

        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.Int32' to be used for the ValidationFramework.RequiredRule<System.Int32>. Actual Type 'System.String'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            RequiredRule<int> rule = new RequiredRule<int>(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(string).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}