using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class EnumerableDuplicateRuleTest
    {

        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";
      
        
        [Test]
        public void Constructor1()
        {
            EnumerableDuplicateRule rule = new EnumerableDuplicateRule(expectedErrorMessage, expectedRuleSet, false, StringComparer.Ordinal);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(StringComparer.Ordinal, rule.Comparer);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Constructor2()
        {
            EnumerableDuplicateRule rule = new EnumerableDuplicateRule(expectedErrorMessage);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.Comparer);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Constructor3()
        {
            EnumerableDuplicateRule rule = new EnumerableDuplicateRule();
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.Comparer);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void ValidateGeneric()
        {
            EnumerableDuplicateRule rule = new EnumerableDuplicateRule(null, null, false, null);
            List<int> list = null;
            Assert.IsNull(rule.Validate(null, list, null));

            list = new List<int>();
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));
        }


        [Test]
        public void Equality()
        {
            EnumerableDuplicateRule rule1 = new EnumerableDuplicateRule(null, null, false, null);
            EnumerableDuplicateRule rule2 = new EnumerableDuplicateRule(null, null, false, null);

            Assert.IsTrue(rule1.IsEquivalent(rule2));

        }


        [Test]
        public void RuleRuleInterpretation()
        {
            EnumerableDuplicateRule rule = new EnumerableDuplicateRule(null, null, false, null);
            Assert.IsNotNull(rule.RuleInterpretation);
        }


        [Test]
        public void ValidateNonGeneric()
        {

            EnumerableDuplicateRule rule = new EnumerableDuplicateRule(null, null, false, null);
            ArrayList list = null;
            Assert.IsNull(rule.Validate(null, list, null));

            list = new ArrayList();
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

        }


        [Test]
        public void CheckTypes()
        {
            EnumerableDuplicateRule rule = new EnumerableDuplicateRule(null, null, false, null);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(IList<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(List<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(ICollection<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(LinkedList<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(Stack<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(ArrayList).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(string).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int[]).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.Collections.IEnumerable' to be used for the ValidationFramework.EnumerableDuplicateRule. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            EnumerableDuplicateRule rule = new EnumerableDuplicateRule(null, null, false, null);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}