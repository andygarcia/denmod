using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class RegexRuleTest
    {

        private readonly Type regexRuleType = typeof(RegexRule);
        private readonly Type stringType = typeof(string);
        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";
        const string expectedRegularExpression = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
        const RegexOptions expectedRegexOptions = RegexOptions.IgnorePatternWhitespace;

        [Test]
        public void Constructor1()
        {
            RegexRule rule = new RegexRule(expectedErrorMessage, expectedRuleSet, false, expectedRegularExpression, expectedRegexOptions);
            Assert.AreEqual(expectedRegularExpression, rule.ValidationExpression);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.AreEqual(expectedRegexOptions, rule.RegexOptions);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }

        [Test]
        public void Constructor1TestRegexRange()
        {
            RegexOptions minExpectedRegexOptions = RegexOptions.None;
            RegexRule rule1 = new RegexRule(expectedErrorMessage, expectedRuleSet, false, expectedRegularExpression, minExpectedRegexOptions);
            Assert.AreEqual(minExpectedRegexOptions, rule1.RegexOptions);


            RegexOptions maxExpectedRegexOptions =
                RegexOptions.Compiled |
                RegexOptions.CultureInvariant |
                RegexOptions.ECMAScript |
                RegexOptions.ExplicitCapture |
                RegexOptions.IgnoreCase |
                RegexOptions.IgnorePatternWhitespace |
                RegexOptions.Multiline |
                RegexOptions.None |
                RegexOptions.RightToLeft |
                RegexOptions.Singleline;
            RegexRule rule2 = new RegexRule(expectedErrorMessage, expectedRuleSet, false, expectedRegularExpression, maxExpectedRegexOptions);
            Assert.AreEqual(maxExpectedRegexOptions, rule2.RegexOptions);

        }



        [Test]
        public void Construction1InvalidRegexOptions()
        {
            Exception argException = null;
            try
            {
                ConstructorInfo constructor = regexRuleType.GetConstructor(new Type[] { stringType, stringType, typeof(bool), stringType, typeof(RegexOptions) });
                constructor.Invoke(new object[] { expectedErrorMessage, expectedRuleSet, false, expectedRegularExpression, -1 });
            }
            catch (TargetInvocationException e)
            {
                argException = e.InnerException;
            }
            Assert.IsNotNull(argException);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: validationExpression")]
        public void Constructor1ValidationExpressionNull()
        {
            new RegexRule(expectedErrorMessage, expectedRuleSet, false, null, expectedRegexOptions);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: validationExpression")]
        public void Constructor1ValidationExpressionEmpty()
        {
            new RegexRule(expectedErrorMessage, expectedRuleSet, false, string.Empty, expectedRegexOptions);
        }


        [Test]
        public void Constructor2()
        {
            RegexRule rule = new RegexRule(expectedErrorMessage, expectedRegularExpression);
            Assert.AreEqual(expectedRegularExpression, rule.ValidationExpression);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.AreEqual(RegexOptions.None, rule.RegexOptions);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: validationExpression")]
        public void Constructor2ValidationExpressionNull()
        {
            new RegexRule(expectedErrorMessage, null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: validationExpression")]
        public void Constructor2ValidationExpressionEmpty()
        {
            new RegexRule(expectedErrorMessage, string.Empty);
        }


        [Test]
        public void Constructor3()
        {
            RegexRule rule = new RegexRule(expectedRegularExpression);
            Assert.AreEqual(expectedRegularExpression, rule.ValidationExpression);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.AreEqual(RegexOptions.None, rule.RegexOptions);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: validationExpression")]
        public void Constructor3ValidationExpressionNull()
        {
            new RegexRule(null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: validationExpression")]
        public void Constructor3ValidationExpressionEmpty()
        {
            new RegexRule(string.Empty);
        }


        [Test]
        public void Equality()
        {
            RegexRule rule1 = new RegexRule(null, null, false, "regex", RegexOptions.None);
            RegexRule rule2 = new RegexRule(null, null, false, "regex", RegexOptions.None);
            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule1 = new RegexRule(null, null, false, "regex", RegexOptions.None);
            rule2 = new RegexRule(null, null, false, "regex2", RegexOptions.None);
            Assert.IsFalse(rule1.IsEquivalent(rule2));
        }


        [Test]
        public void RuleRuleInterpretation()
        {
            RegexRule nullableRule = new RegexRule(null, null, false, @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", RegexOptions.None);
            Assert.IsNotNull(nullableRule.RuleInterpretation);

        }


        [Test]
        public void Validate()
        {
            RegexRule nullableRule = new RegexRule(null, null, false, @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", RegexOptions.None);

            Assert.IsNull(nullableRule.Validate(null, null, null));
            Assert.IsNull(nullableRule.Validate(null, string.Empty, null));
            Assert.IsNotNull(nullableRule.Validate(null, "aaa", null));
            Assert.IsNull(nullableRule.Validate(null, "a@b.com", null));

        }


        [Test]
        public void GetBaseValidatorDateTime()
        {
            RegexRule rule = new RegexRule(null, null, false, @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", RegexOptions.None);
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNotNull(list);
            Assert.AreEqual(1, list.Count);
        }


        [Test]
        public void CheckTypes()
        {
            RegexRule rule = new RegexRule(null, null, false, "sss", RegexOptions.None);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(string).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.String' to be used for the ValidationFramework.RegexRule. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException()
        {
            RegexRule rule = new RegexRule(null, null, false, "sss", RegexOptions.None);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}