using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class ValidatableRuleTest
    {
        public class Validatable:IValidatable
        {
            public bool IsValid
            {
                get
                {
                    return true;
                }
            }

            public IList<string> ErrorMessages
            {
                get
                {
                    return null;
                }
            }
        }

        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";
      
        
        [Test]
        public void Constructor1()
        {
            ValidatableRule rule = new ValidatableRule(expectedErrorMessage, expectedRuleSet, false);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Constructor2()
        {
            ValidatableRule rule = new ValidatableRule(expectedErrorMessage);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsNull(rule.RuleSet);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Constructor3()
        {
            ValidatableRule rule = new ValidatableRule();
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsNull(rule.RuleSet);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Equality()
        {
            ValidatableRule rule1 = new ValidatableRule(null, null, false);
            ValidatableRule rule2 = new ValidatableRule(null, null, false);

            Assert.IsTrue(rule1.IsEquivalent(rule2));
        }


        [Test]
        public void RuleRuleInterpretation()
        {
            ValidatableRule rule = new ValidatableRule(null, null, false);
            Assert.IsNotNull(rule.RuleInterpretation);
        }


        [Test]
        public void ValidateNonGeneric()
        {

            ValidatableRule rule = new ValidatableRule(null, null, false);
            Validatable list = null;
            Assert.IsNull(rule.Validate(null, list, null));

            list = new Validatable();
            Assert.IsNull(rule.Validate(null, list, null));
        }


        [Test]
        public void CheckTypes()
        {
            ValidatableRule rule = new ValidatableRule(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(Validatable).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'ValidationFramework.IValidatable' to be used for the ValidationFramework.ValidatableRule. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            ValidatableRule rule = new ValidatableRule(null, null, false);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}