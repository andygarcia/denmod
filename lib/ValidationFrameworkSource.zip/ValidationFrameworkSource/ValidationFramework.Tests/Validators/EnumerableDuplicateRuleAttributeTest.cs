using System;
using System.Collections;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class EnumerableDuplicateRuleAttributeTest
    {


        [Test]
        public void CheckValues()
        {
            EnumerableDuplicateRuleAttribute ruleAttribute = new EnumerableDuplicateRuleAttribute();

            string expectedEqualityComparerTypeName = "System.StringComparer";
            ruleAttribute.EqualityComparerTypeName = expectedEqualityComparerTypeName;
            string expectedEqualityComparerPropertyName = "InvariantCulture";
            ruleAttribute.EqualityComparerPropertyName = expectedEqualityComparerPropertyName;
            Assert.AreEqual(expectedEqualityComparerTypeName, ruleAttribute.EqualityComparerTypeName);
            Assert.AreEqual(expectedEqualityComparerPropertyName, ruleAttribute.EqualityComparerPropertyName);

            EnumerableDuplicateRule propertyRule = (EnumerableDuplicateRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<IList>("foo"));
            Assert.AreEqual(StringComparer.InvariantCulture, propertyRule.Comparer);

            EnumerableDuplicateRule parameterRule = (EnumerableDuplicateRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<IList>("foo"));
            Assert.AreEqual(StringComparer.InvariantCulture, parameterRule.Comparer);

        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<IList>(new EnumerableDuplicateRuleAttribute());
            AttributeTester.CheckNonDefaultValues<IList>(new EnumerableDuplicateRuleAttribute());
        }

    }
}