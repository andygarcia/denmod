using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
  [TestFixture]
  public class ComparePropertyRuleAttributeTest
  {

    
    [Test]
    public void CheckValues()
    {
      ComparePropertyRuleAttribute ruleAttribute = new ComparePropertyRuleAttribute("PropertyToCompare", CompareOperator.Equal);
      Assert.AreEqual("PropertyToCompare", ruleAttribute.PropertyToCompare);
      Assert.AreEqual(CompareOperator.Equal, ruleAttribute.Operator);
      ComparePropertyRule propertyRule = (ComparePropertyRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<byte>("foo"));
      ComparePropertyRule parameterRule = (ComparePropertyRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<byte>("foo"));
      Assert.AreEqual("PropertyToCompare", propertyRule.PropertyToCompare);
      Assert.AreEqual(CompareOperator.Equal, propertyRule.CompareOperator);
      Assert.AreEqual("PropertyToCompare", parameterRule.PropertyToCompare);
      Assert.AreEqual(CompareOperator.Equal, parameterRule.CompareOperator);
    }

      [Test]
      public void CallAttributeTester()
      {
          AttributeTester.CheckDefaultValues<string>(new ComparePropertyRuleAttribute("PropertyToCompare", CompareOperator.Equal));
          AttributeTester.CheckNonDefaultValues<string>(new ComparePropertyRuleAttribute("PropertyToCompare", CompareOperator.Equal));
      }

  }
}