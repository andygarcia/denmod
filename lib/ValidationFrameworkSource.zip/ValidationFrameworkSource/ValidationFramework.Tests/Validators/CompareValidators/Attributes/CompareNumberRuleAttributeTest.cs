using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class CompareNumberRuleAttributeTest
    {

        [Test]
        public void RunForAllNumberTypes()
        {
            CheckDefaultValues<byte>(2);
            CheckDefaultValues<int>(2);
            CheckDefaultValues<long>(2);
            CheckDefaultValues<double>(2);
            CheckDefaultValues<float>(2);
            CheckDefaultValues<short>(2);
            CallAttributeTester<byte>(2);
            CallAttributeTester<int>(2);
            CallAttributeTester<long>(2);
            CallAttributeTester<double>(2);
            CallAttributeTester<float>(2);
            CallAttributeTester<short>(2);
        }


        public void CheckDefaultValues<T>(T initialValue) where T : IComparable<T>
        {
            CompareRuleAttribute ruleAttribute = CreateRuleAttribute(initialValue);
            

            CompareRule<T> propertyRule = (CompareRule<T>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<byte>("foo"));
            CompareRule<T> parameterRule = (CompareRule<T>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<byte>("foo"));
            Assert.AreEqual(initialValue, TypeHelper.GetPropertyValue<T>(ruleAttribute,"ValueToCompare"));
            Assert.AreEqual(CompareOperator.Equal, ruleAttribute.Operator);
            Assert.AreEqual(CompareOperator.Equal, parameterRule.CompareOperator);
            Assert.AreEqual(initialValue, propertyRule.ValueToCompare);
            Assert.AreEqual(CompareOperator.Equal, propertyRule.CompareOperator);
            Assert.AreEqual(initialValue, parameterRule.ValueToCompare);


        }
      
        public void CallAttributeTester<T>(T initialValue) where T : IComparable<T>
        {
            AttributeTester.CheckDefaultValues<T>(CreateRuleAttribute(initialValue)); 
            AttributeTester.CheckNonDefaultValues<T>(CreateRuleAttribute(initialValue));
        }

        private static CompareRuleAttribute CreateRuleAttribute<T>(T initialValue) where T : IComparable<T>
        {
            string attributeTypeName = string.Format("ValidationFramework.Compare{0}RuleAttribute,ValidationFramework", TypeHelper.GetTypeFromKeyName<T>());
            Type attributeType = Type.GetType(attributeTypeName);
            return (CompareRuleAttribute)Activator.CreateInstance(attributeType, initialValue, CompareOperator.Equal);
        }


    
    }
}