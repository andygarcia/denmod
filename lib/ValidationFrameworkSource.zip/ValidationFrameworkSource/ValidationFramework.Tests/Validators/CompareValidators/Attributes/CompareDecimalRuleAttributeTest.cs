using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class CompareDecimalRuleAttributeTest
    {

        [Test]
        public void CheckValues()
        {
            CompareDecimalRuleAttribute ruleAttribute = new CompareDecimalRuleAttribute(2, CompareOperator.Equal);
            Assert.AreEqual(2, ruleAttribute.ValueToCompare);
            Assert.AreEqual(CompareOperator.Equal, ruleAttribute.Operator);
            CompareRule<decimal> propertyRule = (CompareRule<decimal>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<decimal>("foo"));
            CompareRule<decimal> parameterRule = (CompareRule<decimal>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<decimal>("foo"));
            Assert.AreEqual(2, propertyRule.ValueToCompare);
            Assert.AreEqual(CompareOperator.Equal, propertyRule.CompareOperator);
            Assert.AreEqual(2, parameterRule.ValueToCompare);
            Assert.AreEqual(CompareOperator.Equal, parameterRule.CompareOperator);
        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<Decimal>(new CompareDecimalRuleAttribute(2, CompareOperator.Equal));
            AttributeTester.CheckNonDefaultValues<Decimal>(new CompareDecimalRuleAttribute(2, CompareOperator.Equal));
        }

    }
}