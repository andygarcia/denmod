using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class CompareStringRuleAttributeTest
    {
      

        [Test]
        public void CheckValues()
        {
            string expectedCompareValue = "b";
            CompareOperator expectedCompareOperator = CompareOperator.GreaterThan;
            CompareStringRuleAttribute ruleAttribute = new CompareStringRuleAttribute(expectedCompareValue, expectedCompareOperator);
            Assert.AreEqual(expectedCompareValue, ruleAttribute.ValueToCompare);
            CompareRule<string> propertyRule = (CompareRule<string>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            CompareRule<string> parameterRule = (CompareRule<string>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.AreEqual(expectedCompareValue, parameterRule.ValueToCompare);
            Assert.AreEqual(expectedCompareOperator, propertyRule.CompareOperator);
            Assert.AreEqual(expectedCompareValue, propertyRule.ValueToCompare);
            Assert.AreEqual(expectedCompareOperator, propertyRule.CompareOperator);

        }



        [Test]
        public void CallAttributeTester()
        {
            string expectedCompareValue = "b";
            CompareOperator expectedCompareOperator = CompareOperator.GreaterThan;
            AttributeTester.CheckDefaultValues<string>(new CompareStringRuleAttribute(expectedCompareValue, expectedCompareOperator));
            AttributeTester.CheckNonDefaultValues<string>(new CompareStringRuleAttribute(expectedCompareValue, expectedCompareOperator));
        }

    }
}