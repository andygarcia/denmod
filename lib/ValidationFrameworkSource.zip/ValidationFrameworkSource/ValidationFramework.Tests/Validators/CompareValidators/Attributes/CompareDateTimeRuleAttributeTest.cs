using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class CompareDateTimeRuleAttributeTest
    {

        [Test]
        public void CheckDefaultValues()
        {
            string expectedInitialString = "01 Jan 2006";
            DateTime expectedDateTime = new DateTime(2006, 1, 1);
            CompareDateTimeRuleAttribute ruleAttribute = new CompareDateTimeRuleAttribute(expectedInitialString, CompareOperator.Equal);

            Assert.AreEqual(expectedInitialString, ruleAttribute.ValueToCompare);
            Assert.AreEqual(expectedDateTime, ruleAttribute.ValueToCompareDateTime);
            Assert.AreEqual(CompareOperator.Equal, ruleAttribute.Operator);
            CompareRule<DateTime> propertyRule = (CompareRule<DateTime>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<DateTime>("foo"));
            CompareRule<DateTime> parameterRule = (CompareRule<DateTime>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<DateTime>("foo"));
            Assert.AreEqual(expectedDateTime, propertyRule.ValueToCompare);
            Assert.AreEqual(CompareOperator.Equal, propertyRule.CompareOperator);
            Assert.AreEqual(expectedDateTime, parameterRule.ValueToCompare);
            Assert.AreEqual(CompareOperator.Equal, parameterRule.CompareOperator);

        }

        [Test]
        public void CallAttributeTester()
        {
            string expectedInitialString = "01 Jan 2006";
            AttributeTester.CheckDefaultValues<DateTime>(new CompareDateTimeRuleAttribute(expectedInitialString, CompareOperator.Equal));
            AttributeTester.CheckNonDefaultValues<DateTime>(new CompareDateTimeRuleAttribute(expectedInitialString, CompareOperator.Equal));
        }
    }
}
