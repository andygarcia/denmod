using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.UI.WebControls;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class CompareStructRuleTest
    {
        private readonly Type compareRuleType = typeof(CompareRule<int>);
       private  readonly Type stringType = typeof(string);
        private const string expectedErrorMessage = "expectedErrorMessage";
        private const string expectedRuleSet = "EXPECTEDRULESET";
        private const int expectedValueToCompare = 2;
        private const CompareOperator expectedCompareOperator = CompareOperator.GreaterThan;


        [Test]
        public void Construction1()
        {
            CompareRule<int> rule = new CompareRule<int>(expectedErrorMessage, expectedRuleSet, false, expectedValueToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.AreEqual(expectedValueToCompare, rule.ValueToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction1InvalidCompareOperator()
        {
            Exception argException = null;
            try
            {

            ConstructorInfo constructor = compareRuleType.GetConstructor(new Type[] {stringType, stringType, typeof (bool),typeof(int), typeof (CompareOperator)});
            constructor.Invoke(new object[] {expectedErrorMessage, expectedRuleSet, false, expectedValueToCompare, -1});
            }
            catch (TargetInvocationException e)
            {
                argException = e.InnerException;
            }
            Assert.IsNotNull(argException);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: valueToCompare")]
        public void Construction1ValueToCompareNull()
        {
            new CompareRule<string>(expectedErrorMessage, expectedRuleSet, false, null, expectedCompareOperator);
        }


        [Test]
        public void Construction2()
        {
            CompareRule<int> rule = new CompareRule<int>(expectedErrorMessage, expectedValueToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedValueToCompare, rule.ValueToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction2InvalidCompareOperator()
        {
            Exception argException = null;
            try
            {

                ConstructorInfo constructor = compareRuleType.GetConstructor(new Type[] { stringType, typeof(int), typeof(CompareOperator) });
                constructor.Invoke(new object[] { expectedErrorMessage, expectedValueToCompare, -1 });
            }
            catch (TargetInvocationException e)
            {
                argException = e.InnerException;
            }
            Assert.IsNotNull(argException);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: valueToCompare")]
        public void Construction2ValueToCompareNull()
        {
new CompareRule<string>(expectedErrorMessage, null, expectedCompareOperator);
        }


        [Test]
        public void Construction3()
        {
            CompareRule<int> rule = new CompareRule<int>(expectedValueToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedValueToCompare, rule.ValueToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction3InvalidCompareOperator()
        {
            Exception argException = null;
            try
            {
                ConstructorInfo constructor = compareRuleType.GetConstructor(new Type[] { typeof(int), typeof(CompareOperator) });
                constructor.Invoke(new object[] { expectedValueToCompare, -1 });
            }
            catch (TargetInvocationException e)
            {
                argException = e.InnerException;
            }
            Assert.IsNotNull(argException);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: valueToCompare")]
        public void Construction3ValueToCompareNull()
        {
            new CompareRule<string>(null, expectedCompareOperator);
        }


        [Test]
        public void Equality()
        {
            CompareRule<int> rule1 = new CompareRule<int>(null, null, false, 5, CompareOperator.LessThan);
            CompareRule<int> rule2 = new CompareRule<int>(null, null, false, 5, CompareOperator.LessThan);
            Assert.IsTrue(rule1.IsEquivalent(rule2));
            rule2 = new CompareRule<int>(null, null, false, 5, CompareOperator.GreaterThan);

            Assert.IsFalse(rule1.IsEquivalent(rule2));

        }


        [Test]
        public void ValidateNullable()
        {
            int expectedValueToCompare = 2;
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int?).TypeHandle, "foo");

            CompareRule<int> rule = new CompareRule<int>(null, null, false, expectedValueToCompare, CompareOperator.GreaterThan);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, 1, null));
            Assert.IsNotNull(rule.Validate(null, 2, null));
            Assert.IsNull(rule.Validate(null, 3, null));
        }


        [Test]
        public void GetBaseValidatorUnknown()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(fooStruct).TypeHandle, "foo");

            CompareRule<fooStruct> rule = new CompareRule<fooStruct>(null, null, false, new fooStruct(), CompareOperator.GreaterThan);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNull(rule.CreateWebClientValidators());
        }


        [Test]
        public void RuleInterpretation()
        {
            CompareRule<int> rule = new CompareRule<int>(null, null, false, expectedValueToCompare, CompareOperator.GreaterThan);
            Assert.IsFalse(string.IsNullOrEmpty(rule.RuleInterpretation));
        }


        [Test]
        public void ValidateNotNullable()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");
            CompareRule<int> rule = new CompareRule<int>(null, null, false, expectedValueToCompare, CompareOperator.GreaterThan);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule.Validate(null, 1, null));
            Assert.IsNotNull(rule.Validate(null, 2, null));
            Assert.IsNull(rule.Validate(null, 3, null));
        }


        [Test]
        public void GetBaseValidatorNonDateTime()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");

            CompareRule<int> rule = new CompareRule<int>(null, null, false, expectedValueToCompare, CompareOperator.GreaterThan);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNotNull(list);
            Assert.AreEqual(1, list.Count);
        }


        [Test]
        public void GetBaseValidatorDate()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(DateTime).TypeHandle, "foo");

            CompareRule<DateTime> rule = new CompareRule<DateTime>(null, null, false, new DateTime(2007, 1, 1), CompareOperator.GreaterThan);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNotNull(list);
            Assert.AreEqual(1, list.Count);
        }


        [Test]
        public void GetBaseValidatorDateTime()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(DateTime).TypeHandle, "foo");

            CompareRule<DateTime> rule = new CompareRule<DateTime>(null, null, false, new DateTime(2007, 1, 1, 2, 1, 1), CompareOperator.GreaterThan);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNull(list);
        }


        [Test]
        public void CheckTypes()
        {
            CompareRule<DateTime> rule = new CompareRule<DateTime>(null, null, false, DateTime.Now, CompareOperator.GreaterThan);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(DateTime).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(Nullable<DateTime>).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.DateTime' to be used for the ValidationFramework.CompareRule<System.DateTime>. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            CompareRule<DateTime> rule = new CompareRule<DateTime>(null, null, false, DateTime.Now, CompareOperator.GreaterThan);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }


        struct fooStruct : IComparable<fooStruct>
        {


            public int CompareTo(fooStruct other)
            {
                throw new NotImplementedException();
            }
        }
    }
}