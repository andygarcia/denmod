using System;
using NUnit.Framework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class ComparePropertyRuleTest
    {

        const string expectedPropertyToCompare = "property1";
        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";
        const CompareOperator expectedCompareOperator = CompareOperator.GreaterThan;

        [Test]
        public void Construction1()
        {
            ComparePropertyRule rule = new ComparePropertyRule(expectedPropertyToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedPropertyToCompare, rule.PropertyToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsNull(rule.RuleSet);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyToCompare")]
        public void Construction1PropertyToCompareNull()
        {
            new ComparePropertyRule(null, expectedCompareOperator);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyToCompare")]
        public void Construction1PropertyToCompareEmpty()
        {
            new ComparePropertyRule(string.Empty, expectedCompareOperator);
        }


        [Test]
        public void Construction2()
        {
            ComparePropertyRule rule = new ComparePropertyRule(expectedErrorMessage, expectedPropertyToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedPropertyToCompare, rule.PropertyToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsNull(rule.RuleSet);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyToCompare")]
        public void Construction2PropertyToCompareNull()
        {
            new ComparePropertyRule(expectedErrorMessage, null, expectedCompareOperator);
        }
        

        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyToCompare")]
        public void Construction2PropertyToCompareEmpty()
        {
            new ComparePropertyRule(expectedErrorMessage, string.Empty, expectedCompareOperator);
        }


        [Test]
        public void Construction3()
        {
            ComparePropertyRule rule = new ComparePropertyRule(expectedErrorMessage, expectedRuleSet, true, expectedPropertyToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedPropertyToCompare, rule.PropertyToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.IsTrue(rule.UseErrorMessageProvider);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyToCompare")]
        public void Construction3PropertyToCompareEmpty()
        {
            new ComparePropertyRule(expectedErrorMessage, expectedRuleSet, true, string.Empty, expectedCompareOperator);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyToCompare")]
        public void Construction3PropertyToCompareNull()
        {
            new ComparePropertyRule(expectedErrorMessage, expectedRuleSet, true, null, expectedCompareOperator);
        }


        [Test]
        public void Equality()
        {
            string expectedPropertyToCompare2 = "property2";
            ComparePropertyRule rule1 = new ComparePropertyRule(null, null, false, expectedPropertyToCompare, CompareOperator.LessThan);
            ComparePropertyRule rule2 = new ComparePropertyRule(null, null, false, expectedPropertyToCompare, CompareOperator.LessThan);
            Assert.IsTrue(rule1.IsEquivalent(rule2));
            rule2 = new ComparePropertyRule(null, null, false, expectedPropertyToCompare, CompareOperator.GreaterThan);

            Assert.IsFalse(rule1.IsEquivalent(rule2));
            rule2 = new ComparePropertyRule(null, null, false, expectedPropertyToCompare2, CompareOperator.LessThan);

            Assert.IsFalse(rule1.IsEquivalent(rule2));

        }


        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void NotFindProperty()
        {

            TypeDescriptor descriptor = TypeCache.GetType(typeof(TestClass).TypeHandle);
            Rule rule = descriptor.Properties["Property1"].Rules[0];
            TestClass testClass = new TestClass();


            testClass.Property1 = null;
            Assert.IsNotNull(rule.Validate(testClass, 0, null));

        }


        [Test]
        public void Validate()
        {

            TypeDescriptor descriptor = TypeCache.GetType(typeof(TestClass).TypeHandle);
            Rule rule = descriptor.Properties["Property2"].Rules[0];
            TestClass testClass = new TestClass();


            Assert.IsNull(rule.Validate(testClass, null, null));
            Assert.IsNull(rule.Validate(testClass, "b", null));

            testClass.Property1 = "b";
            Assert.IsNotNull(rule.Validate(testClass, "a", null));
            Assert.IsNotNull(rule.Validate(testClass, "b", null));
            Assert.IsNull(rule.Validate(testClass, "c", null));

        }


        [Test]
        public void RuleInterpretation()
        {
            ComparePropertyRule rule = new ComparePropertyRule(null, null, false, expectedPropertyToCompare, CompareOperator.GreaterThan);
            Assert.IsFalse(string.IsNullOrEmpty(rule.RuleInterpretation));
        }


        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void CheckInvalidProperty()
        {
            ComparePropertyRule rule = new ComparePropertyRule(null, null, false, "Property3", CompareOperator.GreaterThan);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockParameterDescriptor<string>("foo"), "InfoDescriptor");
        }

    }

    class TestClass
    {
        private string property1;
        private string property2;

        [ComparePropertyRule("Property1", CompareOperator.GreaterThan)]
        public string Property2
        {
            get
            {
                return property2;
            }
            set
            {
                property2 = value;
            }
        }


        [ComparePropertyRule("property3", CompareOperator.GreaterThan)]
        public string Property1
        {
            get
            {
                return property1;
            }
            set
            {
                property1 = value;
            }
        }
    }
}