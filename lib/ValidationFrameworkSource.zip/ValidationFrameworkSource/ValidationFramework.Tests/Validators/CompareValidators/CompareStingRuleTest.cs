using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class CompareStringRuleTest
    {

        const string expectedValueToCompare = "expectedValueToCompare";
        const CompareOperator expectedCompareOperator = CompareOperator.GreaterThan;
        const string expectedErrorMessage = "EXPECTEDERRORMESSAGE";
        const string expectedRuleSet = "EXPECTEDRULESET";

        [Test]
        public void Construction1()
        {
            CompareRule<string> rule = new CompareRule<string>(expectedErrorMessage, expectedRuleSet, false, expectedValueToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedValueToCompare, rule.ValueToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: valueToCompare")]
        public void Construction1ValueToCompareNull()
        {
            CompareRule<string> rule = new CompareRule<string>(expectedErrorMessage, expectedRuleSet, false, null, expectedCompareOperator);
        }


        [Test]
        public void Construction2()
        {
            CompareRule<string> rule = new CompareRule<string>(expectedErrorMessage, expectedValueToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedValueToCompare, rule.ValueToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsNull(rule.RuleSet);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: valueToCompare")]
        public void Construction2ValueToCompareNull()
        {
            CompareRule<string> rule = new CompareRule<string>(expectedErrorMessage, null, expectedCompareOperator);
        }


        [Test]
        public void Construction3()
        {
            CompareRule<string> rule = new CompareRule<string>(expectedValueToCompare, expectedCompareOperator);
            Assert.AreEqual(expectedValueToCompare, rule.ValueToCompare);
            Assert.AreEqual(expectedCompareOperator, rule.CompareOperator);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsNull(rule.RuleSet);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: valueToCompare")]
        public void Construction3ValueToCompareNull()
        {
            CompareRule<string> rule = new CompareRule<string>(null, expectedCompareOperator);
        }


        [Test]
        public void Equality()
        {
            CompareRule<string> rule1 = new CompareRule<string>(null, null, false, "aaa", CompareOperator.LessThan);
            CompareRule<string> rule2 = new CompareRule<string>(null, null, false, "aaa", CompareOperator.LessThan);

            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule1 = new CompareRule<string>(null, null, false, "aaa", CompareOperator.LessThan);
            rule2 = new CompareRule<string>(null, null, false, "aaa", CompareOperator.GreaterThanEqual);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

            rule1 = new CompareRule<string>(null, null, false, "bbb", CompareOperator.LessThan);
            rule2 = new CompareRule<string>(null, null, false, "aaa", CompareOperator.LessThanEqual);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: valueToCompare")]
        public void ArgumentNullExceptionOnConstruction()
        {
            new CompareRule<string>(null, null, false, null, CompareOperator.GreaterThan);
        }


        [Test]
        public void RuleInterpretation()
        {
            string expectedValueToCompare = "expectedValueToCompare";
            CompareRule<string> rule = new CompareRule<string>(null, null, false, expectedValueToCompare, CompareOperator.GreaterThan);
            Assert.IsFalse(string.IsNullOrEmpty(rule.RuleInterpretation));
        }


        [Test]
        public void ValidateGreaterThan()
        {
            CompareRule<string> compareStringRule = new CompareRule<string>(null, null, false, "b", CompareOperator.GreaterThan);
            Assert.IsNull(compareStringRule.Validate(null, null, null));
            Assert.IsNotNull(compareStringRule.Validate(null, string.Empty, null));
            Assert.IsNotNull(compareStringRule.Validate(null, "a", null));
            Assert.IsNotNull(compareStringRule.Validate(null, "b", null));
            Assert.IsNull(compareStringRule.Validate(null, "c", null));
        }

        [Test]
        public void ValidateEqual()
        {
            CompareRule<string> compareStringRule = new CompareRule<string>(null, null, false, "b", CompareOperator.Equal);
            Assert.IsNull(compareStringRule.Validate(null, null, null));
            Assert.IsNotNull(compareStringRule.Validate(null, string.Empty, null));
            Assert.IsNotNull(compareStringRule.Validate(null, "a", null));
            Assert.IsNull(compareStringRule.Validate(null, "b", null));
            Assert.IsNotNull(compareStringRule.Validate(null, "c", null));
        }

        [Test]
        public void ValidateGreaterThanEqual()
        {
            CompareRule<string> compareStringRule = new CompareRule<string>(null, null, false, "b", CompareOperator.GreaterThanEqual);
            Assert.IsNull(compareStringRule.Validate(null, null, null));
            Assert.IsNotNull(compareStringRule.Validate(null, string.Empty, null));
            Assert.IsNotNull(compareStringRule.Validate(null, "a", null));
            Assert.IsNull(compareStringRule.Validate(null, "b", null));
            Assert.IsNull(compareStringRule.Validate(null, "c", null));
        }

        [Test]
        public void ValidateLessThan()
        {
            CompareRule<string> compareStringRule = new CompareRule<string>(null, null, false, "b", CompareOperator.LessThan);
            Assert.IsNull(compareStringRule.Validate(null, null, null));
            Assert.IsNull(compareStringRule.Validate(null, string.Empty, null));
            Assert.IsNull(compareStringRule.Validate(null, "a", null));
            Assert.IsNotNull(compareStringRule.Validate(null, "b", null));
            Assert.IsNotNull(compareStringRule.Validate(null, "c", null));
        }

        [Test]
        public void ValidateLessThanEqual()
        {
            CompareRule<string> compareStringRule = new CompareRule<string>(null, null, false, "b", CompareOperator.LessThanEqual);
            Assert.IsNull(compareStringRule.Validate(null, null, null));
            Assert.IsNull(compareStringRule.Validate(null, string.Empty, null));
            Assert.IsNull(compareStringRule.Validate(null, "a", null));
            Assert.IsNull(compareStringRule.Validate(null, "b", null));
            Assert.IsNotNull(compareStringRule.Validate(null, "c", null));
        }

        [Test]
        public void ValidateNotEqual()
        {
            CompareRule<string> compareStringRule = new CompareRule<string>(null, null, false, "b", CompareOperator.NotEqual);
            Assert.IsNull(compareStringRule.Validate(null, null, null));
            Assert.IsNull(compareStringRule.Validate(null, string.Empty, null));
            Assert.IsNull(compareStringRule.Validate(null, "a", null));
            Assert.IsNotNull(compareStringRule.Validate(null, "b", null));
            Assert.IsNull(compareStringRule.Validate(null, "c", null));
        }


        [Test]
        public void GetBaseValidator()
        {
            string expectedValueToCompare = "expectedValueToCompare";
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(string).TypeHandle, "foo");

            CompareRule<string> rule = new CompareRule<string>(null, null, false, expectedValueToCompare, CompareOperator.GreaterThan);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNotNull(list);
            Assert.AreEqual(1, list.Count);
        }


        [Test]
        public void CheckTypes()
        {
            CompareRule<string> rule = new CompareRule<string>(null, null, false, "expectedValueToCompare", CompareOperator.GreaterThan);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(string).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.String' to be used for the ValidationFramework.CompareRule<System.String>. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            CompareRule<string> rule = new CompareRule<string>(null, null, false, "expectedValueToCompare", CompareOperator.GreaterThan);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}