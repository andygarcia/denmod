using System;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{
    internal static class TypeHelper
    {
        internal static TRule CreatePropertyRule<TRule>(RuleAttribute ruleAttribute, PropertyDescriptor propertyDescriptor) where TRule : Rule
        {
            return (TRule) ((IPropertyRuleAttribute) ruleAttribute).CreatePropertyRule(propertyDescriptor);
        }

        internal static TRule CreateParameterRule<TRule>(RuleAttribute ruleAttribute, ParameterDescriptor propertyDescriptor) where TRule : Rule 
        {
            return (TRule) ((IParameterRuleAttribute) ruleAttribute).CreateParameterRule(propertyDescriptor);
        }

        internal static PropertyType GetPropertyValue<PropertyType>(object target, string property)
        {
            object value = target.GetType().GetProperty(property).GetValue(target, null);
            return (PropertyType)value;
        }

        internal static void SetPropertyValue(object target, string property, object value)
        {
            target.GetType().GetProperty(property).SetValue(target, value, null);
        }
        internal static string GetTypeFromKeyName<T>()
        {
            Type type = typeof(T);
            if (type == typeof(Byte))
            {
                {
                    return "Byte";
                }
            }
            else if (type == typeof(int))
            {
                {
                    return "Int";
                }
            }
            else if (type == typeof(long))
            {
                {
                    return "Long";
                }
            }
            else if (type == typeof(Double))
            {
                {
                    return "Double";
                }
            }
            else if (type == typeof(float))
            {
                {
                    return "Float";
                }
            }
            else if (type == typeof(short))
            {
                {
                    return "Short";
                }
            }
            return null;
        }
        internal static string GetTypeFromShortName<T>()
        {
            Type type = typeof(T);
            if (type == typeof(Byte))
            {
                {
                    return "byte";
                }
            }
            else if (type == typeof(int))
            {
                {
                    return "int";
                }
            }
            else if (type == typeof(long))
            {
                {
                    return "long";
                }
            }
            else if (type == typeof(Double))
            {
                {
                    return "double";
                }
            }
            else if (type == typeof(float))
            {
                {
                    return "float";
                }
            }
            else if (type == typeof(short))
            {
                {
                    return "short";
                }
            }
            return null;
        }
    }
}
