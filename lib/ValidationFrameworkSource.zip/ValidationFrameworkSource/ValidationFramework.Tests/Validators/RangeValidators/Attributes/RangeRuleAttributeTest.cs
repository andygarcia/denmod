using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RangeRuleAttributeTest
    {

        [Test]
        public void CheckValues()
        {
            RangeRuleTestObjectAttribute ruleAttribute = new RangeRuleTestObjectAttribute();

            Assert.IsTrue(ruleAttribute.EqualsMaximumIsValid);
            ruleAttribute.EqualsMaximumIsValid = false;
            Assert.IsFalse(ruleAttribute.EqualsMaximumIsValid);
            ruleAttribute.EqualsMaximumIsValid = true;
            Assert.IsTrue(ruleAttribute.EqualsMaximumIsValid);


            Assert.IsTrue(ruleAttribute.EqualsMinimumIsValid);
            ruleAttribute.EqualsMinimumIsValid = false;
            Assert.IsFalse(ruleAttribute.EqualsMinimumIsValid);
            ruleAttribute.EqualsMinimumIsValid = true;
            Assert.IsTrue(ruleAttribute.EqualsMinimumIsValid);

        }

    }
}