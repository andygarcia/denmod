using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RangeStringRuleAttributeTest
    {
        const string expectedMinimum = "a";
        const string expectedMaximum = "c";

        [Test]
        public void CheckValues()
        {
            RangeStringRuleAttribute ruleAttribute = new RangeStringRuleAttribute(expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, ruleAttribute.Minimum);
            Assert.AreEqual(expectedMaximum, ruleAttribute.Maximum);
            RangeStringRule propertyRule = (RangeStringRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            RangeStringRule parameterRule = (RangeStringRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.AreEqual(expectedMinimum, parameterRule.Minimum);
            Assert.AreEqual(expectedMaximum, propertyRule.Maximum);
            Assert.AreEqual(expectedMinimum, propertyRule.Minimum);
            Assert.AreEqual(expectedMaximum, propertyRule.Maximum);

        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<string>(new RangeStringRuleAttribute(expectedMinimum, expectedMaximum));
            AttributeTester.CheckNonDefaultValues<string>(new RangeStringRuleAttribute(expectedMinimum, expectedMaximum));
        }


    }
}