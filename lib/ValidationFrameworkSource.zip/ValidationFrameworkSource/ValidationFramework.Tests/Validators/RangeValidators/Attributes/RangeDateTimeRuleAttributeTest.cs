using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RangeDateTimeRuleAttributeTest
    {

        const string expectedMinimumString = "01 Jan 2006";
        const string expectedMaximumString = "03 Jan 2006";
        readonly DateTime expectedMinimumDateTime = new DateTime(2006, 1, 1);
        readonly DateTime expectedMaximumDateTime = new DateTime(2006, 1, 3);


        [Test]
        public void CheckValues()
        {
            RangeDateTimeRuleAttribute ruleAttribute = new RangeDateTimeRuleAttribute(expectedMinimumString, expectedMaximumString);
            Assert.AreEqual(expectedMinimumString, ruleAttribute.Minimum);
            Assert.AreEqual(expectedMaximumString, ruleAttribute.Maximum);
            RangeRule<DateTime> propertyRule = (RangeRule<DateTime>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<DateTime>("foo"));
            RangeRule<DateTime> parameterRule = (RangeRule<DateTime>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<DateTime>("foo"));
            Assert.AreEqual(expectedMinimumDateTime, propertyRule.Minimum);
            Assert.AreEqual(expectedMaximumDateTime, propertyRule.Maximum);
            Assert.AreEqual(expectedMinimumDateTime, parameterRule.Minimum);
            Assert.AreEqual(expectedMaximumDateTime, parameterRule.Maximum);

        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<DateTime>(new RangeDateTimeRuleAttribute(expectedMinimumString, expectedMaximumString));
            AttributeTester.CheckNonDefaultValues<DateTime>(new RangeDateTimeRuleAttribute(expectedMinimumString, expectedMaximumString));
        }



    }
}