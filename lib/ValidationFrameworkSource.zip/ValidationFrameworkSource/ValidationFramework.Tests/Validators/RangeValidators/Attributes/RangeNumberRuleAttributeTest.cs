using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RangeByteRuleAttributeTest
    {

        [Test]
        public void RunForAllNumberTypes()
        {
            CallAttributeTester<byte>();
            CallAttributeTester<int>();
            CallAttributeTester<long>();
            CallAttributeTester<double>();
            CallAttributeTester<float>();
            CallAttributeTester<short>();
            CheckValues<byte>();
            CheckValues<int>();
            CheckValues<long>();
            CheckValues<double>();
            CheckValues<float>(); 
            CheckValues<short>();
        }

        private static RangeRuleAttribute GetRuleAttribute<T>(T minimum, T maximum)
        {
            string attributeTypeName = string.Format("ValidationFramework.Range{0}RuleAttribute,ValidationFramework", TypeHelper.GetTypeFromKeyName<T>());
            Type attributeType = Type.GetType(attributeTypeName);
            return (RangeRuleAttribute)Activator.CreateInstance(attributeType, minimum, maximum);
        }

   
        public void CheckValues<T>() where T : IComparable<T>
        {
            T expectedMinimum = (T)Convert.ChangeType(2, typeof(T));
            T expectedMaximum = (T)Convert.ChangeType(4, typeof(T));
            RangeRuleAttribute ruleAttribute = GetRuleAttribute(expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, TypeHelper.GetPropertyValue<T>(ruleAttribute,"Minimum"));
            Assert.AreEqual(expectedMaximum, TypeHelper.GetPropertyValue<T>(ruleAttribute,"Maximum"));
            RangeRule<T> propertyRule = TypeHelper.CreatePropertyRule<RangeRule<T>>(ruleAttribute, new MockPropertyDescriptor<T>("foo"));
            RangeRule<T> parameterRule = TypeHelper.CreateParameterRule<RangeRule<T>>(ruleAttribute, new MockParameterDescriptor<T>("foo"));
            Assert.AreEqual(expectedMinimum, propertyRule.Minimum);
            Assert.AreEqual(expectedMaximum, propertyRule.Maximum);
            Assert.AreEqual(expectedMinimum, parameterRule.Minimum);
            Assert.AreEqual(expectedMaximum, parameterRule.Maximum);


        }

        public void CallAttributeTester<T>() where T : IComparable<T>
        {
            T expectedMinimum = (T) Convert.ChangeType(2, typeof(T));
            T expectedMaximum = (T) Convert.ChangeType(4, typeof(T));
            AttributeTester.CheckDefaultValues<T>(GetRuleAttribute(expectedMinimum, expectedMaximum));
            AttributeTester.CheckNonDefaultValues<T>(GetRuleAttribute(expectedMinimum, expectedMaximum));
        }


    }
}