using System;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{

    public sealed class RangeRuleTestObjectAttribute : RangeRuleAttribute
    {

        public override Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            throw new NotImplementedException();
        }


        public override Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            throw new NotImplementedException();
        }


        public override Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            throw new NotImplementedException();
        }

    }
}