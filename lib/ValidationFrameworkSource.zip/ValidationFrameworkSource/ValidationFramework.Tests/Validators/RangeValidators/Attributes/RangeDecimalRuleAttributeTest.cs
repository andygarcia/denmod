using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RangeDecimalRuleAttributeTest
    {

       const double expectedMinimum = 2;
        const double expectedMaximum = 4;
        const decimal expectedMinimumDecimal = 2;
        const decimal expectedMaximumDecimal = 4;



        [Test]
        public void CheckValues()
        {
            RangeDecimalRuleAttribute ruleAttribute = new RangeDecimalRuleAttribute(expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimumDecimal, ruleAttribute.Minimum);
            Assert.AreEqual(expectedMaximumDecimal, ruleAttribute.Maximum);
            RangeRule<decimal> propertyRule = (RangeRule<decimal>)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<decimal>("foo"));
            RangeRule<decimal> parameterRule = (RangeRule<decimal>)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<decimal>("foo"));
            Assert.AreEqual(expectedMinimumDecimal, propertyRule.Minimum);
            Assert.AreEqual(expectedMaximumDecimal, propertyRule.Maximum);
            Assert.AreEqual(expectedMinimumDecimal, parameterRule.Minimum);
            Assert.AreEqual(expectedMaximumDecimal, parameterRule.Maximum);
        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<decimal>(new RangeDecimalRuleAttribute(expectedMinimum, expectedMaximum));
            AttributeTester.CheckNonDefaultValues<decimal>(new RangeDecimalRuleAttribute(expectedMinimum, expectedMaximum));
        }

    }
}