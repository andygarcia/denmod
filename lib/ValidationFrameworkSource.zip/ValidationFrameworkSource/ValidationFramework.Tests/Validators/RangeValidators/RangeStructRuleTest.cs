using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class RangeRuleTest
    {

        const int expectedMinimum = 1;
        const int expectedMaximum = 3;
        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";

        [Test]
        public void Construction1()
        {
            RangeRule<int> rule = new RangeRule<int>(expectedErrorMessage, expectedRuleSet, false, expectedMinimum, expectedMaximum, true, false);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsFalse(rule.EqualsMaximumIsValid);
            Assert.IsTrue(rule.EqualsMinimumIsValid);
        }


        [Test]
        public void Construction2()
        {
            RangeRule<int> rule = new RangeRule<int>(expectedErrorMessage, expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsTrue(rule.EqualsMaximumIsValid);
            Assert.IsTrue(rule.EqualsMinimumIsValid);
        }


        [Test]
        public void Construction3()
        {
            RangeRule<int> rule = new RangeRule<int>(expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsTrue(rule.EqualsMaximumIsValid);
            Assert.IsTrue(rule.EqualsMinimumIsValid);
        }


        [Test]
        public void Equality()
        {
            RangeRule<int> rule1 = new RangeRule<int>(null, null, false, 1, 5, true, true);
            RangeRule<int> rule2 = new RangeRule<int>(null, null, false, 1, 5, true, true);
            Assert.IsTrue(rule1.IsEquivalent(rule2));
            rule1 = new RangeRule<int>(null, null, false, 1, 5, true, true);
            rule2 = new RangeRule<int>(null, null, false, 1, 5, true, true);
            Assert.IsTrue(rule1.IsEquivalent(rule2));
            rule1 = new RangeRule<int>(null, null, false, 1, 5, false, false);
            rule2 = new RangeRule<int>(null, null, false, 1, 5, false, false);
            Assert.IsTrue(rule1.IsEquivalent(rule2));


            rule1 = new RangeRule<int>(null, null, false, 1, 5, false, false);
            rule2 = new RangeRule<int>(null, null, false, 1, 5, true, false);
            Assert.IsFalse(rule1.IsEquivalent(rule2));


            rule1 = new RangeRule<int>(null, null, false, 1, 5, false, false);
            rule2 = new RangeRule<int>(null, null, false, 1, 3, false, false);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

            RangeRule<string> stringRule1 = new RangeRule<string>(null, null, false, "a", "a", false, false);
            RangeRule<string> stringRule2 = new RangeRule<string>(null, null, false, "a", null, false, false);
            Assert.IsFalse(stringRule1.IsEquivalent(stringRule2));

            stringRule1 = new RangeRule<string>(null, null, false, "a", null, false, false);
            stringRule2 = new RangeRule<string>(null, null, false, "a", "a", false, false);
            Assert.IsFalse(stringRule1.IsEquivalent(stringRule2));

            stringRule1 = new RangeRule<string>(null, null, false, "a", null, false, false);
            stringRule2 = new RangeRule<string>(null, null, false, "a", null, false, false);
            Assert.IsTrue(stringRule1.IsEquivalent(stringRule2));


        }


        [Test]
        public void ValidateNullable()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int?).TypeHandle, "foo");

            RangeRule<int> rule = new RangeRule<int>(null, null, false, expectedMinimum, expectedMaximum, true, true);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");

            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, 0, null));
            Assert.IsNull(rule.Validate(null, 1, null));
            Assert.IsNull(rule.Validate(null, 2, null));
            Assert.IsNull(rule.Validate(null, 3, null));
            Assert.IsNotNull(rule.Validate(null, 4, null));
        }


        [Test]
        public void ValidateNullableExclusive()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int?).TypeHandle, "foo");

            RangeRule<int> rule = new RangeRule<int>(null, null, false, expectedMinimum, expectedMaximum, false, false);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");

            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, 0, null));
            Assert.IsNotNull(rule.Validate(null, 1, null));
            Assert.IsNull(rule.Validate(null, 2, null));
            Assert.IsNotNull(rule.Validate(null, 3, null));
            Assert.IsNotNull(rule.Validate(null, 4, null));
        }


        [Test]
        public void RuleRuleInterpretation()
        {
            RangeRule<int> rule1 = new RangeRule<int>(null, null, false, expectedMinimum, expectedMaximum, true, true);
            Assert.IsNotNull(rule1.RuleInterpretation);
            RangeRule<int> rule2 = new RangeRule<int>(null, null, false, expectedMinimum, expectedMaximum, false, false);
            Assert.IsNotNull(rule2.RuleInterpretation);
        }


        [Test]
        public void ValidateNotNullable()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");
            RangeRule<int> rule = new RangeRule<int>(null, null, false, expectedMinimum, expectedMaximum, true, true);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule.Validate(null, 0, null));
            Assert.IsNull(rule.Validate(null, 1, null));
            Assert.IsNull(rule.Validate(null, 2, null));
            Assert.IsNull(rule.Validate(null, 3, null));
            Assert.IsNotNull(rule.Validate(null, 4, null));
        }


        [Test]
        public void ValidateNotNullableExclusive()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");
            RangeRule<int> rule = new RangeRule<int>(null, null, false, expectedMinimum, expectedMaximum, false, false);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNotNull(rule.Validate(null, 0, null));
            Assert.IsNotNull(rule.Validate(null, 1, null));
            Assert.IsNull(rule.Validate(null, 2, null));
            Assert.IsNotNull(rule.Validate(null, 3, null));
            Assert.IsNotNull(rule.Validate(null, 4, null));
        }


        [Test]
        public void GetBaseValidatorNonDateTime()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(int).TypeHandle, "foo");

            RangeRule<int> rule = new RangeRule<int>(null, null, false, expectedMaximum, expectedMinimum, true, true);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNotNull(list);
            Assert.AreEqual(1, list.Count);
        }


        [Test]
        public void GetBaseValidatorDate()
        {
            DateTime expectedMinimum = new DateTime(2007, 1, 1);
            DateTime expectedMaximum = expectedMinimum.AddDays(1);
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(DateTime).TypeHandle, "foo");

            RangeRule<DateTime> rule = new RangeRule<DateTime>(null, null, false, expectedMinimum, expectedMaximum, true, true);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNotNull(list);
            Assert.AreEqual(1, list.Count);
        }


        [Test]
        public void GetBaseValidatorAsDateTime()
        {
            DateTime expectedMinimum = new DateTime(2007, 1, 1).AddHours(1);
            DateTime expectedMaximum = expectedMinimum.AddDays(1);
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(DateTime).TypeHandle, "foo");

            RangeRule<DateTime> rule = new RangeRule<DateTime>(null, null, false, expectedMinimum, expectedMaximum, true, true);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNull(list);
        }


        [Test]
        public void GetBaseValidatorMaxAsDateTime()
        {
            DateTime expectedMinimum = new DateTime(2007, 1, 1);
            DateTime expectedMaximum = expectedMinimum.AddDays(1).AddHours(1);
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(DateTime).TypeHandle, "foo");

            RangeRule<DateTime> rule = new RangeRule<DateTime>(null, null, false, expectedMinimum, expectedMaximum, true, true);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNull(list);
        }


        [Test]
        public void GetBaseValidatorMinAsDateTime()
        {
            DateTime expectedMinimum = new DateTime(2007, 1, 1);
            DateTime expectedMaximum = expectedMinimum.AddDays(1);
            expectedMinimum = expectedMinimum.AddHours(1);
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(DateTime).TypeHandle, "foo");

            RangeRule<DateTime> rule = new RangeRule<DateTime>(null, null, false, expectedMinimum, expectedMaximum, true, true);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNull(list);
            //Assert.AreEqual(1, list.Count);
        }


        struct fooStruct : IComparable<fooStruct>, IComparable
        {


            public int CompareTo(fooStruct other)
            {
                throw new NotImplementedException();
            }

            public int CompareTo(object obj)
            {
                throw new NotImplementedException();
            }
        }


        [Test]
        public void GetBaseValidatorUnknown()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(fooStruct).TypeHandle, "foo");

            RangeRule<fooStruct> rule = new RangeRule<fooStruct>(null, null, false, new fooStruct(), new fooStruct(), true, true);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            IList<BaseValidator> list = rule.CreateWebClientValidators();
            Assert.IsNull(list);

        }


        [Test]
        public void CheckTypes()
        {
            RangeRule<int> rule = new RangeRule<int>(null, null, false, 0, 10, true, true);

            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(Nullable<int>).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.Int32' to be used for the ValidationFramework.RangeRule<System.Int32>. Actual Type 'System.String'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            RangeRule<int> rule = new RangeRule<int>(null, null, false, 0, 10, true, true);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(string).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}