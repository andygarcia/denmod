using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class RangeStringRuleTest
    {

        const string expectedMinimum = "b";
        const string expectedMaximum = "d";
        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";


        [Test]
        public void Construction1()
        {
            RangeStringRule rule = new RangeStringRule(expectedErrorMessage, expectedRuleSet, false, expectedMinimum, expectedMaximum, false, true);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsTrue(rule.EqualsMaximumIsValid);
            Assert.IsFalse(rule.EqualsMinimumIsValid);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: minimum")]
        public void Construction1MinimumNull()
        {
            new RangeStringRule(expectedErrorMessage, expectedRuleSet, false, null, expectedMaximum, false, true);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: minimum")]
        public void Construction1MinimumEmpty()
        {
            new RangeStringRule(expectedErrorMessage, expectedRuleSet, false, string.Empty, expectedMaximum, false, true);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: maximum")]
        public void Construction1MaximumNull()
        {
            new RangeStringRule(expectedErrorMessage, expectedRuleSet, false, expectedMinimum, null, false, true);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: maximum")]
        public void Construction1MaximumEmpty()
        {
            new RangeStringRule(expectedErrorMessage, expectedRuleSet, false, expectedMinimum, string.Empty, false, true);
        }


        [Test]
        public void Construction2()
        {
            RangeStringRule rule = new RangeStringRule(expectedErrorMessage, expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsTrue(rule.EqualsMaximumIsValid);
            Assert.IsTrue(rule.EqualsMinimumIsValid);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: minimum")]
        public void Construction2MinimumNull()
        {
             new RangeStringRule(null, expectedMaximum);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: minimum")]
        public void Construction2MinimumEmpty()
        {
            new RangeStringRule(string.Empty, expectedMaximum);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: maximum")]
        public void Construction2MaximumNull()
        {
          new RangeStringRule(expectedErrorMessage, expectedMinimum, null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: maximum")]
        public void Construction2MaximumEmpty()
        {
            new RangeStringRule(expectedErrorMessage, expectedMinimum, string.Empty);
        }


        [Test]
        public void Construction3()
        {
            RangeStringRule rule = new RangeStringRule(expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.UseErrorMessageProvider);
            Assert.IsTrue(rule.EqualsMaximumIsValid);
            Assert.IsTrue(rule.EqualsMinimumIsValid);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: minimum")]
        public void Construction3MinimumNull()
        {
            new RangeStringRule(null, expectedMaximum);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: minimum")]
        public void Construction3MinimumEmpty()
        {
            new RangeStringRule(string.Empty, expectedMaximum);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: maximum")]
        public void Construction3MaximumNull()
        {
            new RangeStringRule(expectedMinimum, null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: maximum")]
        public void Construction3MaximumEmpty()
        {
            new RangeStringRule(expectedMinimum, string.Empty);
        }



        [Test]
        public void Equality()
        {
            RangeStringRule rule1 = new RangeStringRule(null, null, false, expectedMinimum, expectedMaximum, true, true);
            RangeStringRule rule2 = new RangeStringRule(null, null, false, expectedMinimum, expectedMaximum, true, true);

            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule1 = new RangeStringRule(null, null, false, "a", "d", true, true);
            rule2 = new RangeStringRule(null, null, false, "b", "d", true, true);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

            rule1 = new RangeStringRule(null, null, false, "a", "d", true, true);
            rule2 = new RangeStringRule(null, null, false, "a", "c", true, true);
            Assert.IsFalse(rule1.IsEquivalent(rule2));
        }


        [Test]
        public void RuleRuleInterpretation()
        {

            RangeStringRule rule = new RangeStringRule(null, null, false, expectedMinimum, expectedMaximum, true, true);
            Assert.IsNotNull(rule.RuleInterpretation);
        }


        [Test]
        public void Validate()
        {
            RangeStringRule rule = new RangeStringRule(null, null, false, expectedMinimum, expectedMaximum, true, true);
            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, "a", null));
            Assert.IsNull(rule.Validate(null, "b", null));
            Assert.IsNull(rule.Validate(null, "c", null));
            Assert.IsNull(rule.Validate(null, "d", null));
            Assert.IsNotNull(rule.Validate(null, "e", null));
        }


        [Test]
        public void CheckTypes()
        {
            RangeStringRule rule = new RangeStringRule(null, null, false, expectedMinimum, expectedMaximum, true, true);

            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(string).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.String' to be used for the ValidationFramework.RangeStringRule. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            RangeStringRule rule = new RangeStringRule(null, null, false, expectedMinimum, expectedMaximum, true, true);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}