using System;
using System.Collections;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class ValidatableRuleAttributeTest
    {

        [Test]
        public void CheckValues()
        {
            ValidatableRuleAttribute ruleAttribute = new ValidatableRuleAttribute();


            ruleAttribute.UseMemberErrorMessages = true;
            ValidatableRule propertyRule = (ValidatableRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<IValidatable>("foo"));
            Assert.IsNotNull(propertyRule);
            Assert.IsTrue(propertyRule.UseMemberErrorMessages);

            ValidatableRule parameterRule = (ValidatableRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<IValidatable>("foo"));
            Assert.IsNotNull(parameterRule);
            Assert.IsTrue(parameterRule.UseMemberErrorMessages);
        }


        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void CheckPropertyRuleErrorMessageUseMemberErrorMessages()
        {
            ValidatableRuleAttribute ruleAttribute = new ValidatableRuleAttribute();
            ruleAttribute.ErrorMessage = "foo";
            ruleAttribute.UseMemberErrorMessages = true;
            ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<IValidatable>("foo"));
        }


        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void CheckParameterRuleErrorMessageUseMemberErrorMessages()
        {
            ValidatableRuleAttribute ruleAttribute = new ValidatableRuleAttribute();
            ruleAttribute.ErrorMessage = "foo";
            ruleAttribute.UseMemberErrorMessages = true;
            ruleAttribute.CreateParameterRule(new MockParameterDescriptor<IValidatable>("foo"));
        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<IList>(new ValidatableRuleAttribute());
            AttributeTester.CheckNonDefaultValues<IList>(new ValidatableRuleAttribute());
        }

    }
}