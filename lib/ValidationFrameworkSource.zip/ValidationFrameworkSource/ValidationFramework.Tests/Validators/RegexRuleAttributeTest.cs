using System.Text.RegularExpressions;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class RegexRuleAttributeTest
    {

        string expectedRegEx = "aaa";


        [Test]
        public void CheckValues()
        {
            RegexOptions regexOptions = RegexOptions.Multiline;
            RegexRuleAttribute ruleAttribute = new RegexRuleAttribute(expectedRegEx);
            Assert.AreEqual(expectedRegEx, ruleAttribute.ValidationExpression);
            RegexRule propertyRule = (RegexRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            RegexRule parameterRule = (RegexRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.AreEqual(expectedRegEx, propertyRule.ValidationExpression);
            Assert.AreEqual(expectedRegEx, parameterRule.ValidationExpression);

            ruleAttribute.RegexOptions = regexOptions;
            Assert.AreEqual(regexOptions, ruleAttribute.RegexOptions);

            propertyRule = (RegexRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            parameterRule = (RegexRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.AreEqual(regexOptions, propertyRule.RegexOptions);
            Assert.AreEqual(regexOptions, parameterRule.RegexOptions);

        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<string>(new RegexRuleAttribute(expectedRegEx));
            AttributeTester.CheckNonDefaultValues<string>(new RegexRuleAttribute(expectedRegEx));
        }

    }
}