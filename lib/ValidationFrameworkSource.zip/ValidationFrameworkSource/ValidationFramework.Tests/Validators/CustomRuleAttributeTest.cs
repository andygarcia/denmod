using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class CustomRuleAttributeTest
    {

        string expectedTypeName = "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests";
        string expectedMethodName = "ValidateValid";
        string expectedRuleInterpretation = "expectedRuleInterpretation";

  
        [Test]
        public void CheckValues()
        {
            CustomRuleAttribute ruleAttribute = new CustomRuleAttribute(expectedTypeName, expectedMethodName, expectedRuleInterpretation);
            Assert.AreEqual(expectedTypeName, ruleAttribute.ValidationTypeName);
            Assert.AreEqual(expectedMethodName, ruleAttribute.ValidationMethod);
            Assert.AreEqual(expectedRuleInterpretation, ruleAttribute.RuleInterpretation);
            CustomRule propertyRule = (CustomRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<object>("foo"));
            CustomRule parameterRule = (CustomRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<object>("foo"));

            Assert.AreEqual(typeof(CustomRuleTest.ValidationClass).GetMethod("ValidateValid"), propertyRule.Handler.Method);
            Assert.AreEqual(expectedRuleInterpretation, propertyRule.RuleInterpretation);
            Assert.AreEqual(typeof(CustomRuleTest.ValidationClass).GetMethod("ValidateValid"), parameterRule.Handler.Method);
            Assert.AreEqual(expectedRuleInterpretation, parameterRule.RuleInterpretation);

        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<object>(new CustomRuleAttribute(expectedTypeName, expectedMethodName, expectedRuleInterpretation));
            AttributeTester.CheckNonDefaultValues<object>(new CustomRuleAttribute(expectedTypeName, expectedMethodName, expectedRuleInterpretation));
        }

    }
}