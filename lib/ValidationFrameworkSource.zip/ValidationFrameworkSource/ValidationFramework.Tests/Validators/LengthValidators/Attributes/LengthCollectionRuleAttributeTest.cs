using System;
using System.Collections;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class LengthCollectionRuleAttributeTest
    {

        int expectedMaximum = 3;



        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Minimum too low.\r\nParameter name: value")]
        public void MinimumTooSmall()
        {
            int expectedMinimum = -1;
            LengthCollectionRuleAttribute ruleAttribute = new LengthCollectionRuleAttribute(expectedMaximum);
            ruleAttribute.Minimum = expectedMinimum;
        }

        [Test]
        public void CheckValues()
        {
            LengthCollectionRuleAttribute ruleAttribute = new LengthCollectionRuleAttribute(expectedMaximum);
            Assert.IsFalse(ruleAttribute.ExcludeDuplicatesFromCount);
            Assert.AreEqual(expectedMaximum, ruleAttribute.Maximum);
            LengthCollectionRule propertyRule = (LengthCollectionRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<IList>("foo"));
            LengthCollectionRule parameterRule = (LengthCollectionRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<IList>("foo"));
            Assert.AreEqual(expectedMaximum, propertyRule.Maximum);
            Assert.IsFalse(propertyRule.ExcludeDuplicatesFromCount);
            Assert.IsFalse(parameterRule.ExcludeDuplicatesFromCount);
            Assert.AreEqual(expectedMaximum, parameterRule.Maximum);

            ruleAttribute.ExcludeDuplicatesFromCount = true;

        }


        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<IList>(new LengthCollectionRuleAttribute(expectedMaximum));
            AttributeTester.CheckNonDefaultValues<IList>(new LengthCollectionRuleAttribute(expectedMaximum));
        }

    }
}