using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class LengthStringRuleAttributeTest
    {

        int expectedMaximum = 3;
        int expectedMinimum = 1;
        [Test]
        public void CheckRules()
        {
            LengthStringRuleAttribute ruleAttribute = new LengthStringRuleAttribute(expectedMaximum);
            Rule propertyRule = ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            Rule parameterRule = ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.IsNotNull(propertyRule);
            Assert.IsNotNull(parameterRule);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Minimum too low.\r\nParameter name: value")]
        public void MinimumTooSmall()
        {
            LengthStringRuleAttribute ruleAttribute = new LengthStringRuleAttribute(3);
            ruleAttribute.Minimum = -1;
        }

        [Test]
        public void CheckValues()
        {
            LengthStringRuleAttribute ruleAttribute = new LengthStringRuleAttribute(expectedMaximum);
            ruleAttribute.Minimum = expectedMinimum;
            ruleAttribute.TrimWhiteSpace = false;
            Assert.IsFalse(ruleAttribute.TrimWhiteSpace);
            Assert.AreEqual(expectedMaximum, ruleAttribute.Maximum);
            Assert.AreEqual(expectedMinimum, ruleAttribute.Minimum);
            LengthStringRule propertyRule = (LengthStringRule)ruleAttribute.CreatePropertyRule(new MockPropertyDescriptor<string>("foo"));
            LengthStringRule parameterRule = (LengthStringRule)ruleAttribute.CreateParameterRule(new MockParameterDescriptor<string>("foo"));
            Assert.AreEqual(expectedMaximum, propertyRule.Maximum);
            Assert.AreEqual(expectedMinimum, propertyRule.Minimum);
            Assert.IsFalse(propertyRule.TrimWhiteSpace);
            Assert.AreEqual(expectedMaximum, parameterRule.Maximum);
            Assert.AreEqual(expectedMinimum, parameterRule.Minimum);
            Assert.IsFalse(parameterRule.TrimWhiteSpace);



        }

        [Test]
        public void CallAttributeTester()
        {
            AttributeTester.CheckDefaultValues<string>(new LengthStringRuleAttribute(expectedMaximum));
            AttributeTester.CheckNonDefaultValues<string>(new LengthStringRuleAttribute(expectedMaximum));
        }

    }
}