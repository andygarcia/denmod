using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class LengthStringRuleTest
    {

        const int expectedMinimum = 1;
       const int expectedMaximum = 3;
       const string expectedErrorMessage = "expectedErrorMessage";
       const string expectedRuleSet = "EXPECTEDRULESET";


        [Test]
        public void Construction1()
        {
            LengthStringRule rule = new LengthStringRule(expectedErrorMessage, expectedRuleSet, false, expectedMinimum, expectedMaximum, false);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.TrimWhiteSpace);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction2()
        {
            LengthStringRule rule = new LengthStringRule(expectedErrorMessage,  expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsTrue(rule.TrimWhiteSpace);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction3()
        {
            LengthStringRule rule = new LengthStringRule(expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsTrue(rule.TrimWhiteSpace);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Equality()
        {
            LengthStringRule rule1 = new LengthStringRule(null, null, false, 10, 15, true);
            LengthStringRule rule2 = new LengthStringRule(null, null, false, 10, 15, true);
            Assert.IsTrue(rule1.IsEquivalent(rule2));
        }


        [Test]
        public void ConstructionEqualMinAndMax()
        {
            new LengthStringRule(null, null, false, 1, 1, true);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Minimum must be less than or equal to Maximum.\r\nParameter name: minimum")]
        public void ArgumentExceptionOnConstructionMinGreaterThan()
        {
            new LengthStringRule(null, null, false, 2, 1, true);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Minimum must be greater than 0.\r\nParameter name: minimum")]
        public void ArgumentExceptionOnConstructionMinLessThanZero()
        {
            new LengthStringRule(null, null, false, -1, 1, true);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Minimum must be less than or equal to Maximum.\r\nParameter name: minimum")]
        public void ArgumentExceptionOnConstructionGreaterThan()
        {
            new LengthStringRule(null, null, false, 2, 1, true);
        }


        [Test]
        public void GetComputedErrorMessageSameValues()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(string).TypeHandle, "foo");

            LengthStringRule rule2 = new LengthStringRule(null, null, false, expectedMinimum, expectedMinimum, true);
            ReflectionUtilities.SetProperty<Rule>(rule2, mockInfoDescriptor, "InfoDescriptor");
            Assert.IsFalse(string.IsNullOrEmpty(rule2.ErrorMessage));
        }

        [Test]
        public void GetComputedErrorMessageDifferentValues()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(string).TypeHandle, "foo");

            LengthStringRule rule1 = new LengthStringRule(null, null, false, expectedMinimum, expectedMaximum, true);
            ReflectionUtilities.SetProperty<Rule>(rule1, mockInfoDescriptor, "InfoDescriptor");
            Assert.IsFalse(string.IsNullOrEmpty(rule1.ErrorMessage));
        }


        [Test]
        public void RuleInterpretationDifferentValues()
        {
            LengthStringRule rule = new LengthStringRule(expectedMinimum, expectedMaximum);
            Assert.IsNotNull(rule.RuleInterpretation);
        }

        [Test]
        public void RuleInterpretationSameValues()
        {
            LengthStringRule rule = new LengthStringRule(expectedMinimum, expectedMinimum);
            Assert.IsNotNull(rule.RuleInterpretation);
        }


        [Test]
        public void ValidateTrimWhiteSpace()
        {
            LengthStringRule rule = new LengthStringRule(null, null, false, expectedMinimum, expectedMaximum, true);
            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, "", null));
            Assert.IsNotNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "a", null));
            Assert.IsNull(rule.Validate(null, " a ", null));
            Assert.IsNull(rule.Validate(null, "aa", null));
            Assert.IsNull(rule.Validate(null, " aa ", null));
            Assert.IsNull(rule.Validate(null, "aaa", null));
            Assert.IsNull(rule.Validate(null, " aaa ", null));
            Assert.IsNotNull(rule.Validate(null, "aaaa", null));
            Assert.IsNotNull(rule.Validate(null, " aaaa ", null));
        }



        [Test]
        public void ValidateNoTrimWhiteSpace()
        {
            LengthStringRule rule = new LengthStringRule(null, null, false, expectedMinimum, expectedMaximum, false);
            Assert.IsNull(rule.Validate(null, null, null));
            Assert.IsNotNull(rule.Validate(null, "", null));
            Assert.IsNull(rule.Validate(null, " ", null));
            Assert.IsNull(rule.Validate(null, "a", null));
            Assert.IsNull(rule.Validate(null, " a ", null));
            Assert.IsNull(rule.Validate(null, "aa", null));
            Assert.IsNotNull(rule.Validate(null, " aa ", null));
            Assert.IsNull(rule.Validate(null, "aaa", null));
            Assert.IsNotNull(rule.Validate(null, " aaa ", null));
            Assert.IsNotNull(rule.Validate(null, "aaaa", null));
            Assert.IsNotNull(rule.Validate(null, " aaaa ", null));
        }

		[Test]
		public void ValidateEqualMinAndMax()
		{
			LengthStringRule rule = new LengthStringRule(null, null, false, 2, 2, true);
			Assert.IsNotNull(rule.Validate(null, "", null));
			Assert.IsNotNull(rule.Validate(null, " ", null));
			Assert.IsNotNull(rule.Validate(null, "a", null));
			Assert.IsNotNull(rule.Validate(null, "a ", null));
			Assert.IsNull(rule.Validate(null, "aa", null));
			Assert.IsNull(rule.Validate(null, "aa ", null));
			Assert.IsNotNull(rule.Validate(null, "aaa", null));
			Assert.IsNotNull(rule.Validate(null, "aaa ", null));
		}


    	[Test]
        public void GetBaseValidator()
        {
            LengthStringRule rule = new LengthStringRule(null, null, false, expectedMinimum, expectedMaximum, true);
            Assert.IsNotNull(rule.CreateWebClientValidators());
        }


        [Test]
        public void CheckTypes()
        {
            LengthStringRule rule = new LengthStringRule(null, null, false, expectedMinimum, expectedMaximum, true);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(string).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Member 'foo' must be a 'System.String' to be used for the ValidationFramework.LengthStringRule. Actual Type 'System.Int32'.\r\nParameter name: value")]
        public void CheckTypesException1()
        {
            LengthStringRule rule = new LengthStringRule(null, null, false, expectedMinimum, expectedMaximum, true);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}