using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public sealed class LengthCollectionRuleTest
    {
        public class MyCollection : ICollection<int>
        {
            public void CopyTo(Array array, int index)
            {
                throw new NotImplementedException();
            }

            public void Add(int item)
            {
                throw new NotImplementedException();
            }

            public void Clear()
            {
                throw new NotImplementedException();
            }

            public bool Contains(int item)
            {
                throw new NotImplementedException();
            }

            public void CopyTo(int[] array, int arrayIndex)
            {
                throw new NotImplementedException();
            }

            public bool Remove(int item)
            {
                throw new NotImplementedException();
            }

            public int Count
            {
                get
                {
                    return 5;
                }
            }

            public bool IsReadOnly
            {
                get
                {
                    throw new NotImplementedException();
                }
            }

            IEnumerator<int> IEnumerable<int>.GetEnumerator()
            {
                throw new NotImplementedException();
            }

            public IEnumerator GetEnumerator()
            {
                throw new NotImplementedException();
            }
        }

        const int expectedMinimum = 2;
        const int expectedMaximum = 4;
        const string expectedErrorMessage = "expectedErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";


        [Test]
        public void Construction1()
        {
            LengthCollectionRule rule = new LengthCollectionRule(expectedErrorMessage, expectedRuleSet, false, expectedMinimum, expectedMaximum, true, null);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMaximum, rule.Maximum);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsTrue(rule.ExcludeDuplicatesFromCount);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction2()
        {

            LengthCollectionRule rule = new LengthCollectionRule(expectedErrorMessage, expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMaximum, rule.Maximum);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedErrorMessage, rule.ErrorMessage);
            Assert.IsFalse(rule.ExcludeDuplicatesFromCount);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Construction3()
        {

            LengthCollectionRule rule = new LengthCollectionRule(expectedMinimum, expectedMaximum);
            Assert.AreEqual(expectedMinimum, rule.Minimum);
            Assert.AreEqual(expectedMaximum, rule.Maximum);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.ExcludeDuplicatesFromCount);
            Assert.IsFalse(rule.UseErrorMessageProvider);
        }


        [Test]
        public void Equality()
        {
            LengthCollectionRule rule1 = new LengthCollectionRule(null, null, false, 10, 15, true, null);
            LengthCollectionRule rule2 = new LengthCollectionRule(null, null, false, 10, 15, true, null);
            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule2 = new LengthCollectionRule(null, null, false, 10, 15, false, null);
            Assert.IsFalse(rule1.IsEquivalent(rule2));
        }

        [Test]
        public void GetComputedErrorMessageSameValues()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(ICollection).TypeHandle, "foo");

            LengthCollectionRule rule2 = new LengthCollectionRule(null, null, false, expectedMinimum, expectedMinimum, true, null);
            ReflectionUtilities.SetProperty<Rule>(rule2, mockInfoDescriptor, "InfoDescriptor");
            Assert.IsFalse(string.IsNullOrEmpty(rule2.ErrorMessage));
        }

        [Test]
        public void GetComputedErrorMessageDifferentValues()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(ICollection).TypeHandle, "foo");

            LengthCollectionRule rule1 = new LengthCollectionRule(null, null, false, expectedMinimum, expectedMaximum, true, null);
            ReflectionUtilities.SetProperty<Rule>(rule1, mockInfoDescriptor, "InfoDescriptor");
            Assert.IsFalse(string.IsNullOrEmpty(rule1.ErrorMessage));
        }

        [Test]
        public void ConstructionEqual()
        {
            new LengthCollectionRule(null, null, false, 1, 1, true, null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Minimum must be less than or equal to Maximum.\r\nParameter name: minimum")]
        public void ArgumentExceptionOnConstructionGreaterThan()
        {
            new LengthCollectionRule(null, null, false, 2, 1, true, null);
        }


        [Test]
        public void ValidateGenericIncludeDuplicates()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(IList).TypeHandle, "foo");

            LengthCollectionRule rule = new LengthCollectionRule(null, null, false, expectedMinimum, expectedMaximum, false, null);

            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");

            List<int> list = null;
            Assert.IsNull(rule.Validate(null, list, null));
            list = new List<int>();
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));
        }


        [Test]
        public void ValidateGenericExcludeDuplicates()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(ArrayList).TypeHandle, "foo");
            LengthCollectionRule rule = new LengthCollectionRule(null, null, false, expectedMinimum, expectedMaximum, true, null);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            List<int> list = null;
            Assert.IsNull(rule.Validate(null, list, null));

            list = new List<int>();
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(2);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(3);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(4);
            Assert.IsNull(rule.Validate(null, list, null));
        }


        [Test]
        public void ValidateNonICollection()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(MyCollection).TypeHandle, "foo");
            LengthCollectionRule rule = new LengthCollectionRule(null, null, false, 2, 7, false, null);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            Assert.IsNull(rule.Validate(null, new MyCollection(), null));
        }


        [Test]
        public void ValidateNonGenericIncludeDuplicates()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(ArrayList).TypeHandle, "foo");
            LengthCollectionRule rule = new LengthCollectionRule(null, null, false, expectedMinimum, expectedMaximum, false, null);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            ArrayList list = null;
            Assert.IsNull(rule.Validate(null, list, null));
            list = new ArrayList();
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));
        }


        [Test]
        public void RuleInterpretationSameValues()
        {
            LengthCollectionRule rule = new LengthCollectionRule(null, expectedMaximum, expectedMaximum);
            Assert.IsNotNull(rule.RuleInterpretation);
        }

        [Test]
        public void RuleInterpretationDifferentValues()
        {
            LengthCollectionRule rule = new LengthCollectionRule(null, expectedMinimum, expectedMaximum);
            Assert.IsNotNull(rule.RuleInterpretation);
        }


        [Test]
        public void ValidateNonGenericExcludeDuplicates()
        {
            MockInfoDescriptor mockInfoDescriptor = new MockInfoDescriptor(typeof(ArrayList).TypeHandle, "foo");

            LengthCollectionRule rule = new LengthCollectionRule(null, null, false, expectedMinimum, expectedMaximum, true, null);
            ReflectionUtilities.SetField<Rule>(rule, mockInfoDescriptor, "infoDescriptor");
            ArrayList list = null;
            Assert.IsNull(rule.Validate(null, list, null));

            list = new ArrayList();
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(1);
            Assert.IsNotNull(rule.Validate(null, list, null));

            list.Add(2);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(3);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(4);
            Assert.IsNull(rule.Validate(null, list, null));

            list.Add(5);
            Assert.IsNotNull(rule.Validate(null, list, null));
        }


        [Test]
        public void CheckTypes()
        {
            LengthCollectionRule rule = new LengthCollectionRule(null, null, false, expectedMinimum, expectedMaximum, true, null);

            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(IList<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(List<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(ICollection<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(LinkedList<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(Stack<int>).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(ArrayList).TypeHandle, "foo"), "InfoDescriptor");
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int[]).TypeHandle, "foo"), "InfoDescriptor");
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Property must be a ICollection<T> or ICollection to be used for the LengthCollectionRule.")]
        public void CheckTypesException1()
        {
            LengthCollectionRule rule = new LengthCollectionRule(null, null, false, expectedMinimum, expectedMaximum, true, null);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(int).TypeHandle, "foo"), "InfoDescriptor");
        }
    }
}