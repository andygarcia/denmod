using System;
using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class CustomRuleTest
    {


        const string expectedValidationTypeName = "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests";
        const string expectedValidationMethod = "ValidateValid";
        const string expectedRuleInterpretation = "expectedRuleInterpretation";
        const string expectedRuleErrorMessage = "expectedRuleErrorMessage";
        const string expectedMethodErrorMessage = "expectedMethodErrorMessage";
        const string expectedRuleSet = "EXPECTEDRULESET";

        [Test]
        public void Constructor1()
        {
            CustomRule rule = new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, expectedValidationTypeName, expectedValidationMethod, expectedRuleInterpretation);

            Assert.AreEqual(typeof(ValidationClass).GetMethod("ValidateValid"), rule.Handler.Method);
            Assert.AreEqual(expectedRuleInterpretation, rule.RuleInterpretation);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedRuleErrorMessage, rule.ErrorMessage);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: validationTypeName")]
        public void Constructor1ValidationTypeNameNull()
        {
            new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, null, expectedValidationMethod, expectedRuleInterpretation);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: validationTypeName")]
        public void Constructor1ValidationTypeNameEmpty()
        {
            new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, string.Empty, expectedValidationMethod, expectedRuleInterpretation);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: validationMethod")]
        public void Constructor1ValidationMethodNull()
        {
            new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, expectedValidationTypeName, null, expectedRuleInterpretation);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: validationMethod")]
        public void Constructor1ValidationMethodEmpty()
        {
            new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, expectedValidationTypeName, string.Empty, expectedRuleInterpretation);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: ruleInterpretation")]
        public void Constructor1RuleInterpretationNull()
        {
            new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, expectedValidationTypeName, expectedValidationMethod, null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleInterpretation")]
        public void Constructor1RuleInterpretationEmpty()
        {
            new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, expectedValidationTypeName, expectedValidationMethod, string.Empty);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "CustomRule could not load the validation type asdasd,ValidationFramework.Tests.\r\nParameter name: validationTypeName")]
        public void Constructor1TypeException()
        {
            new CustomRule(null, null, false, "asdasd,ValidationFramework.Tests", "ValidateValid", expectedRuleInterpretation);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "CustomRule could not load the validation method 'ValidateValid2' from type 'ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests'.\r\nParameter name: validationMethod")]
        public void Constructor1MethodException()
        {
            new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateValid2", expectedRuleInterpretation);
        }

        
        [Test]
        public void Constructor2()
        {
            CustomRule rule = new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, ValidationClass.ValidateValid, expectedRuleInterpretation);
            Assert.AreEqual(typeof(ValidationClass).GetMethod("ValidateValid"), rule.Handler.Method);
            Assert.AreEqual(expectedRuleInterpretation, rule.RuleInterpretation);
            Assert.AreEqual(expectedRuleSet, rule.RuleSet);
            Assert.AreEqual(expectedRuleErrorMessage, rule.ErrorMessage);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: ruleInterpretation")]
        public void Constructor2RuleInterpretationNull()
        {
            new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, ValidationClass.ValidateValid, null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleInterpretation")]
        public void Constructor2RuleInterpretationEmpty()
        {
            new CustomRule(expectedRuleErrorMessage, expectedRuleSet, false, ValidationClass.ValidateValid, string.Empty);
        }


        [Test]
        public void Constructor3()
        {
            CustomRule rule = new CustomRule(expectedRuleErrorMessage, expectedValidationTypeName, expectedValidationMethod, expectedRuleInterpretation);
            Assert.AreEqual(typeof(ValidationClass).GetMethod("ValidateValid"), rule.Handler.Method);
            Assert.AreEqual(expectedRuleInterpretation, rule.RuleInterpretation);
            Assert.IsNull(rule.RuleSet);
            Assert.AreEqual(expectedRuleErrorMessage, rule.ErrorMessage);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: ruleInterpretation")]
        public void Constructor3RuleInterpretationNull()
        {
            new CustomRule(expectedRuleErrorMessage, expectedValidationTypeName, expectedValidationMethod, null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleInterpretation")]
        public void Constructor3RuleInterpretationEmpty()
        {
            new CustomRule(expectedRuleErrorMessage, expectedValidationTypeName, expectedValidationMethod, string.Empty);
        }


        [Test]
        public void Constructor4()
        {
            CustomRule rule = new CustomRule(expectedValidationTypeName, expectedValidationMethod, expectedRuleInterpretation);
            Assert.AreEqual(typeof(ValidationClass).GetMethod("ValidateValid"), rule.Handler.Method);
            Assert.AreEqual(expectedRuleInterpretation, rule.RuleInterpretation);
            Assert.IsNull(rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: ruleInterpretation")]
        public void Constructor4RuleInterpretationNull()
        {
            new CustomRule(expectedValidationTypeName, expectedValidationMethod, null);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleInterpretation")]
        public void Constructor4RuleInterpretationEmpty()
        {
            new CustomRule(expectedValidationTypeName, expectedValidationMethod, string.Empty);
        }


        [Test]
        public void Equality()
        {
            CustomRule rule1 = new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateValid", expectedRuleInterpretation);
            CustomRule rule2 = new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateValid", expectedRuleInterpretation);
            Assert.IsTrue(rule1.IsEquivalent(rule2));

            rule1 = new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateValid", expectedRuleInterpretation);
            rule2 = new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateInValidNoErrorMessage", expectedRuleInterpretation);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

            rule1 = new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateValid", expectedRuleInterpretation);
            rule2 = new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass2,ValidationFramework.Tests", "ValidateValid", expectedRuleInterpretation);
            Assert.IsFalse(rule1.IsEquivalent(rule2));

        }


        [Test]
        public void ValidateValid()
        {
            CustomRule rule = new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateValid", expectedRuleInterpretation);
            Assert.IsNull(rule.Validate(null, new ValidationClass(), null));
        }


        [Test]
        public void ValidateInValidNoErrorMessage()
        {
            CustomRule rule = new CustomRule(expectedRuleErrorMessage, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateInValidNoErrorMessage", expectedRuleInterpretation);
            ValidationResult result = rule.Validate(null, new ValidationClass(), null);
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedRuleErrorMessage, result.ErrorMessage);
        }


        [Test]
        public void ValidateInValidWithErrorMessage()
        {
            CustomRule rule = new CustomRule(expectedRuleErrorMessage, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateInValidWithErrorMessage", expectedRuleInterpretation);
            ValidationResult result = rule.Validate(null, new ValidationClass(), null);
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedMethodErrorMessage, result.ErrorMessage);
        }


        [Test]
        public void ComputedErrorMessage()
        {
            CustomRule rule = new CustomRule(null, null, false, "ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests", "ValidateInValidWithErrorMessage", expectedRuleInterpretation);
            ReflectionUtilities.SetProperty<Rule>(rule, new MockInfoDescriptor(typeof(object).TypeHandle, "foo"), "InfoDescriptor");
            Assert.IsFalse(string.IsNullOrEmpty(rule.ErrorMessage));
        }

        #region class Foo (for testing)

        public class ValidationClass
        {


            public static void ValidateValid(object sender, CustomValidationEventArgs e)
            {
                ValidationClass validationClass = (ValidationClass)e.TargetObjectValue;
                e.IsValid = true;
            }


            private static void ValidateInValidNoErrorMessage(object sender, CustomValidationEventArgs e)
            {
                ValidationClass validationClass = (ValidationClass)e.TargetObjectValue;
                e.IsValid = false;
            }


            private static void ValidateInValidWithErrorMessage(object sender, CustomValidationEventArgs e)
            {
                ValidationClass validationClass = (ValidationClass)e.TargetObjectValue;
                e.IsValid = false;
                e.ErrorMessage = expectedMethodErrorMessage;
            }
        }


        public class ValidationClass2
        {
            
            private static void ValidateValid(object sender, CustomValidationEventArgs e)
            {
                ValidationClass validationClass = (ValidationClass)e.TargetObjectValue;
                e.IsValid = true;
            }


            private static void ValidateInValidNoErrorMessage(object sender, CustomValidationEventArgs e)
            {
                ValidationClass validationClass = (ValidationClass)e.TargetObjectValue;
                e.IsValid = false;
            }


            private static void ValidateInValidWithErrorMessage(object sender, CustomValidationEventArgs e)
            {
                ValidationClass validationClass = (ValidationClass)e.TargetObjectValue;
                e.IsValid = false;
                e.ErrorMessage = expectedMethodErrorMessage;
            }
        }

        #endregion
    }
}