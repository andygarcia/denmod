using System;
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;
using TypeMock;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{

    [TestFixture]
    public class ParameterValidationManagerValidateOverloadTests 
    {
             public IParameters parameters;
        Mock mock;
       public static readonly RuntimeMethodHandle handle;

        static ParameterValidationManagerValidateOverloadTests()
        {
            handle = typeof(ParameterValidationManagerValidateOverloadTests).GetMethod("MethodForHandle").MethodHandle;
        }

        public void MethodForHandle() { }


        [SetUp]
        public void SetUp()
        {
            MockManager.ClearAll();
            mock = MockManager.Mock(typeof(ParameterValidationManager));
            parameters = mock.ExpectCall("InternalValidate");
        }

        [TearDown]
        public void TearDown()
        {
            mock.Verify();
            MockManager.ClearAll();
        }

        [Test]
        public void Validate1Test()
        {
                parameters.Args(handle, "ruleSet", new object[] { "param" }, "target", null, true);
                ParameterValidationManager.Validate("target", handle, "ruleSet", new object[] { "param" });
        }
        [Test]
        public void Validate2Test()
        {
                parameters.Args(handle, "ruleSet", new object[] { "param" }, "target", "context", true);
                ParameterValidationManager.Validate("target", handle, "ruleSet", "context", new object[] { "param" });
        }

        [Test]
        public void Validate3Test()
        {
                parameters.Args(handle, null, new object[] { "param" }, "target", null, true);
                ParameterValidationManager.Validate("target", handle, new object[] { "param" });
        }

        [Test]
        public void TryValidate1Test()
        {
            parameters.Args(handle, "ruleSet", new object[] { "param" }, "target", null, false);
            ParameterValidationManager.TryValidate("target", handle, "ruleSet", new object[] { "param" });
        }

        [Test]
        public void TryValidate2Test()
        {
            parameters.Args(handle, "ruleSet", new object[] { "param" }, "target", "context", false);
            ParameterValidationManager.TryValidate("target", handle, "ruleSet", "context", new object[] { "param" });
        }

        [Test]
        public void TryValidate3Test()
        {
            parameters.Args(handle, null, new object[] { "param" }, "target", null, false);
            ParameterValidationManager.TryValidate("target", handle, new object[] { "param" });
        }

    }

  
    [TestFixture]
    public class ParameterValidationManagerThrowOverloadsTest
    {
       public IParameters parameters;
        Mock mock;
       public static readonly RuntimeMethodHandle handle;

        static ParameterValidationManagerThrowOverloadsTest()
        {
            handle = typeof(ParameterValidationManagerThrowOverloadsTest).GetMethod("MethodForHandle").MethodHandle;
        }

        public void MethodForHandle() { }


        [SetUp]
        public void SetUp()
        {
            MockManager.ClearAll();
            mock = MockManager.Mock(typeof(ParameterValidationManager));
            parameters = mock.ExpectCall("InternalThrowException");
        }

        [TearDown]
        public void TearDown()
        {
            mock.Verify();
            MockManager.ClearAll();
        }



        [Test]
        public void ThrowException1Test()
        {
            parameters.Args(handle, "ruleSet", new object[] { "param" }, "target", null, true);
            ParameterValidationManager.ThrowException("target", handle, "ruleSet", new object[] { "param" });
        }

        [Test]
        public void ThrowException2Test()
        {
            parameters.Args(handle, "ruleSet", new object[] { "param" }, "target", "context", true);
            ParameterValidationManager.ThrowException("target", handle, "ruleSet", "context", new object[] { "param" });
        }

        [Test]
        public void ThrowException3Test()
        {
            parameters.Args(handle, null, new object[] { "param" }, "target", null, true);
            ParameterValidationManager.ThrowException("target", handle, new object[] { "param" });
        }
        [Test]
        public void TryThrowException1Test()
        {
            parameters.Args(handle, "ruleSet", new object[] { "param" }, "target", null, false);
            ParameterValidationManager.TryThrowException("target", handle, "ruleSet", new object[] { "param" });
        }
        [Test]
        public void TryThrowException2Test()
        {
            parameters.Args(handle, "ruleSet", new object[] { "param" }, "target", "context", false);
            ParameterValidationManager.TryThrowException("target", handle, "ruleSet", "context", new object[] { "param" });
        }

        [Test]
        public void TryThrowException3Test()
        {
            parameters.Args(handle, null, new object[] { "param" }, "target", null, false);
            ParameterValidationManager.TryThrowException("target", handle, new object[] { "param" });
        }
    }


    public class ParameterValidationManagerTestsBase
    {
        public static readonly RuntimeMethodHandle doSomethingStaticHandle =
            typeof(ParameterValidationManagerTestsBase).GetMethod("DoSomething").MethodHandle;
        public static bool isRuleValid;

        private static readonly CustomRule customRuleWithRuleSet;
        private static readonly CustomRule customRuleWithNoRuleSet;

        public static void CheckIsNotEmpty(object sender, CustomValidationEventArgs e)
        {
            e.IsValid = isRuleValid;
        }

        static ParameterValidationManagerTestsBase()
        {
            customRuleWithRuleSet = new CustomRule(null, "foo", false, CheckIsNotEmpty, "foo");
            customRuleWithNoRuleSet = new CustomRule(null, null, false, CheckIsNotEmpty, "foo");
        }

        public static void SetRuleWithRuleSet()
        {
            GetParamDataRules().Add(customRuleWithRuleSet);
        }

        public static void SetRuleWithNoRuleSet()
        {
            GetParamDataRules().Add(customRuleWithNoRuleSet);
        }


        private static RuleCollection GetParamDataRules()
        {
            return MethodCache.GetMethod(doSomethingStaticHandle).Parameters["paramData"].Rules;
        }


        public static void DoSomething(int paramData)
        {
        }

        [SetUp]
        public void SetUp()
        {
            GetParamDataRules().Clear();
        }

        [TearDown]
        public void TearDown()
        {
            GetParamDataRules().Clear();
        }

    }


    [TestFixture]
    public class ParameterValidationManagerThrowTests : ParameterValidationManagerTestsBase
    {

        private static void CallInternalThrow(RuntimeMethodHandle runtimeMethodHandle, string ruleSet, object context, bool throwException)
        {
            BindingFlags bindingFlags = BindingFlags.Static | BindingFlags.NonPublic;
            MethodInfo internalValidateMethodInfo = typeof(ParameterValidationManager).GetMethod("InternalThrowException", bindingFlags);
            object[] methodBeingValidatedParams = new object[] { 6 };
            object[] internalThrowExceptionParams = new object[] { runtimeMethodHandle, ruleSet, methodBeingValidatedParams, null, context, throwException };

            try
            {
                internalValidateMethodInfo.Invoke(null, bindingFlags, null, internalThrowExceptionParams, null);
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }

        }


        // ruleSet = string.empty
        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void RuleSetEmpty()
        {
            SetRuleWithNoRuleSet();
            isRuleValid = false;
            CallInternalThrow(doSomethingStaticHandle, string.Empty, null, false);
        }


        // ruleSet = null, invalid parameter
        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "The parameter 'param Data' is invalid.\r\nParameter name: paramData")]
        public void RuleSetNullInvalidParameter()
        {
            SetRuleWithNoRuleSet();
            isRuleValid = false;
            CallInternalThrow(doSomethingStaticHandle, null, null, false);
        }


        // ruleSet = null, valid parameter
        [Test]
        public void RuleSetNullValidParameter()
        {
            SetRuleWithNoRuleSet();
            isRuleValid = true;
            CallInternalThrow(doSomethingStaticHandle, null, null, false);
        }


        // ruleSet != null, invalid parameter, valid ruleSet
        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "The parameter 'param Data' is invalid.\r\nParameter name: paramData")]
        public void RuleSetNotNullInvalidParameterValidRuleSet()
        {
            SetRuleWithRuleSet();
            isRuleValid = false;
            CallInternalThrow(doSomethingStaticHandle, "foo", null, false);
        }

        // ruleSet != null, valid parameter, invalid ruleSet
        [Test]
        public void RuleSetNotNullValidParameterInvalidRuleSet()
        {
            SetRuleWithRuleSet();
            isRuleValid = true;
            CallInternalThrow(doSomethingStaticHandle, "foo2", null, false);
        }


        // ruleSet != null, valid parameter, valid ruleSet
        [Test]
        public void RuleSetNotNullValidParameterValidRuleSet()
        {
            SetRuleWithRuleSet();
            isRuleValid = true;
            CallInternalThrow(doSomethingStaticHandle, "foo", null, false);
        }


        // ruleSet != null, invalid parameter, invalid ruleSet
        [Test]
        public void RuleSetNotNullInValidParameterInvalidRuleSet()
        {
            SetRuleWithRuleSet();
            isRuleValid = false;
            CallInternalThrow(doSomethingStaticHandle, "foo2", null, false);
        }


        // throwException = true, rule not found, ruleSet = null
        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No parameters could be found containing rules.")]
        public void ThrowExceptionRuleNotFoundRuleSetNull()
        {
            isRuleValid = false;
            CallInternalThrow(doSomethingStaticHandle, null, null, true);
        }


        // throwException = true, rule not found, ruleSet != null
        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No parameters could be found containing rules with the ruleSet 'FOO2'.")]
        public void ThrowExceptionRuleNotFoundRuleSetNotNull()
        {
            isRuleValid = false;
            CallInternalThrow(doSomethingStaticHandle, "foo2", null, true);
        }
    }


    [TestFixture]
    public class ParameterValidationManagerValidateTests : ParameterValidationManagerTestsBase
    {

        private static IList<ValidationResult> CallInternalValidate(RuntimeMethodHandle runtimeMethodHandle, string ruleSet, object context, bool throwException)
        {
            BindingFlags bindingFlags = BindingFlags.Static | BindingFlags.NonPublic;
            MethodInfo internalValidateMethodInfo = typeof(ParameterValidationManager).GetMethod("InternalValidate", bindingFlags);
            object[] methodBeingValidatedParams = new object[] { 6 };
            object[] internalThrowExceptionParams = new object[] { runtimeMethodHandle, ruleSet, methodBeingValidatedParams, null, context, throwException };

            try
            {
               return (IList<ValidationResult>) internalValidateMethodInfo.Invoke(null, bindingFlags, null, internalThrowExceptionParams, null);
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }

        }


        // ruleSet = string.empty
        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void RuleSetEmpty()
        {
            SetRuleWithNoRuleSet();
            isRuleValid = false;
            CallInternalValidate(doSomethingStaticHandle, string.Empty, null, false);
        }


        // ruleSet = null, invalid parameter
        [Test]
        public void RuleSetNullInvalidParameter()
        {
            SetRuleWithNoRuleSet();
            isRuleValid = false;
            IList<ValidationResult> validate = CallInternalValidate(doSomethingStaticHandle, null, null, false);
            Assert.AreEqual(1, validate.Count);
        }


        // ruleSet = null, valid parameter
        [Test]
        public void RuleSetNullValidParameter()
        {
            SetRuleWithNoRuleSet();
            isRuleValid = true;
            IList<ValidationResult> validate = CallInternalValidate(doSomethingStaticHandle, null, null, false);
            Assert.AreEqual(0, validate.Count);
        }


        // ruleSet != null, invalid parameter, valid ruleSet
        [Test]
        public void RuleSetNotNullInvalidParameterValidRuleSet()
        {
            SetRuleWithRuleSet();
            isRuleValid = false;
            IList<ValidationResult> validate = CallInternalValidate(doSomethingStaticHandle, "foo", null, false);
            Assert.AreEqual(1, validate.Count);
        }


        // ruleSet != null, valid parameter, invalid ruleSet
        [Test]
        public void RuleSetNotNullValidParameterInvalidRuleSet()
        {
            SetRuleWithRuleSet();
            isRuleValid = true;
            CallInternalValidate(doSomethingStaticHandle, "foo2", null, false);
        }


        // ruleSet != null, valid parameter, valid ruleSet
        [Test]
        public void RuleSetNotNullValidParameterValidRuleSet()
        {
            SetRuleWithRuleSet();
            isRuleValid = true;
   CallInternalValidate(doSomethingStaticHandle, "foo", null, false);
        }


        // ruleSet != null, invalid parameter, invalid ruleSet
        [Test]
        public void RuleSetNotNullInValidParameterInvalidRuleSet()
        {
            SetRuleWithRuleSet();
            isRuleValid = false;
              CallInternalValidate(doSomethingStaticHandle, "foo2", null, false);
        }


        // throwException = true, rule not found, ruleSet = null
        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No parameters could be found containing rules.")]
        public void ThrowExceptionRuleNotFoundRuleSetNull()
        {
            isRuleValid = false;
               CallInternalValidate(doSomethingStaticHandle, null, null, true);
        }


        // throwException = true, rule not found, ruleSet != null
        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No parameters could be found containing rules with the ruleSet 'FOO2'.")]
        public void ThrowExceptionRuleNotFoundRuleSetNotNull()
        {
            isRuleValid = false;
            CallInternalValidate(doSomethingStaticHandle, "foo2", null, true);
        }
    }

}