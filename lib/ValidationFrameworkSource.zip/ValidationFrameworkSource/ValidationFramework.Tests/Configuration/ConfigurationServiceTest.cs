using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests.Configuration
{
    public class BasicRuleConfigReader: IRuleConfigReader
    {
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            return new BasicRule(ruleData.ErrorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider);
        }
    }

    public class BasicRule: Rule
    {
        public BasicRule( string errorMessage, string ruleSet, bool useErrorMessageProvider) : base(typeof(string).TypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
        }

        public override string RuleInterpretation
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            throw new NotImplementedException();
        }

        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            throw new NotImplementedException();
        }

        public override bool IsEquivalent(Rule rule)
        {
            throw new NotImplementedException();
        }
    }

    public class Employee:Person
    {
        
    }
    public class Person
    {
        private static readonly RuntimeMethodHandle setTheAgeHandle =
            typeof(Person).GetMethod("SetTheAge").MethodHandle;

        private string name;
        private int age;

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }


        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }


        public void SetTheAge(int age)
        {
            ParameterValidationManager.ThrowException(this, setTheAgeHandle, age);
            this.age = age;
        }


        public void SetTheAge(long age)
        {
            ParameterValidationManager.ThrowException(this, setTheAgeHandle, age);
            this.age = (int)age;
        }


        public void SetTheAge2(int age)
        {
            ParameterValidationManager.ThrowException(this, setTheAgeHandle, age);
            this.age = age;
        }
    }


    [TestFixture]
    public class ConfigurationServiceTest
    {
        readonly string propertyXmlString = @"<?xml version='1.0' encoding='utf-8' ?>
<validationMapping xmlns='urn:validationFramework-validationDefinition-1.5'>
  <class typeName='ValidationFramework.Tests.Configuration.Person, ValidationFramework.Tests'>
    <property name='Name'>
      <rule typeName='RequiredStringRule' initialValue='aaaa'/>
    </property>
    <property name='Age'>
      <rule typeName='RangeRule' minimum='18' maximum='80' errorMessage='Age is invalid' />
    </property>
  </class>
</validationMapping>";

        readonly string methodXmlString = @"<?xml version='1.0' encoding='utf-8' ?>
<validationMapping xmlns='urn:validationFramework-validationDefinition-1.5'>
  <class typeName='ValidationFramework.Tests.Configuration.Person, ValidationFramework.Tests'>
 
    <method name='SetTheAge'>
      <overloadType typeName='System.Int32'/>
      <parameter name='age'>
        <rule typeName='RangeRule' minimum='18' maximum='80' errorMessage='Age is invalid' />
        <rule ruleSet='a' typeName='RangeRule' minimum='18' maximum='80' errorMessage='Age is invalid' />
        <rule ruleSet='b' typeName='RangeRule' minimum='18' maximum='80' errorMessage='Age is invalid' />
        <rule ruleInterpretation='This is a custom rule' ruleSet='foo' validationMethod='ValidateValid' validationTypeName='ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests' errorMessage='hello' typeName='CustomRule'/>
      </parameter>
    </method>
    <method name='SetTheAge2'>
      <parameter name='age'>
        <rule typeName='RangeRule' minimum='18' maximum='80' errorMessage='Age is invalid' />
        <rule ruleSet='a' typeName='RangeRule' minimum='18' maximum='80' errorMessage='Age is invalid' />
        <rule ruleSet='b' typeName='RangeRule' minimum='18' maximum='80' errorMessage='Age is invalid' />
        <rule ruleInterpretation='This is a custom rule' ruleSet='foo' validationMethod='ValidateValid' validationTypeName='ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests' errorMessage='hello' typeName='CustomRule'/>
      </parameter>
    </method>
  </class>
</validationMapping>";

        [SetUp]
        public void SetUp()
        {
            TypeCache.Clear();
            MethodCache.Clear();
        }

        [TearDown]
        public void TearDown()
        {

            TypeCache.Clear();
            MethodCache.Clear();
            if(File.Exists("temp.xml"))
            {
                File.Delete("temp.xml");
            }
        }

        [Test]
        public void AddAssembly()
        {
            ConfigurationService.AddAssembly(typeof(ConfigurationServiceTest).Assembly);
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties["Age"].Rules.Count);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
        }


        [Test]
        public void AddAssemblyByName()
        {
            ConfigurationService.AddAssembly("ValidationFramework.Tests");
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties["Age"].Rules.Count);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[]{typeof(int)}).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);


        }


        [Test]
        [ExpectedException(typeof(FileNotFoundException))]
        public void AddAssemblyByNameInvalid()
        {
            ConfigurationService.AddAssembly("InvalidAssemblyName");
        }


        [Test]
        public void AddClass()
        {
            Type type = typeof(Person);
            ConfigurationService.AddClass(type);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties["Age"].Rules.Count);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
        }


        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void AddXmlFileInvalid()
        {
            ConfigurationService.AddXmlFile(@"Invalid.xml");
        }

        [Test]
        public void AddXmlFileValid()
        {
            WriteXmlConfig();

            ConfigurationService.AddXmlFile(@"temp.xml");
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties["Age"].Rules.Count);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
        }

        private void WriteXmlConfig()
        {
            using (Stream stream = GetType().Assembly.GetManifestResourceStream("ValidationFramework.Tests.Configuration.Person.validation.xml"))
            {
                using (StreamReader streamReader = new StreamReader(stream))
                {
                    File.WriteAllText("temp.xml", streamReader.ReadToEnd());
                }
            }
        }

        [Test]
        public void AddUrlValid()
        {
            WriteXmlConfig();
            ConfigurationService.AddUrl(@"temp.xml");
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties["Age"].Rules.Count);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
        }


        [Test]
        public void AddUriValid()
        {
            WriteXmlConfig();
            string path = Path.GetFullPath(@"temp.xml");
            ConfigurationService.AddUrl(new Uri(path));
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties["Age"].Rules.Count);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
        }

        [Test]
        public void AddDirectory()
        {
            try
            {

                WriteXmlConfig();
                Directory.CreateDirectory("temp");
                File.Move("temp.xml", "temp/temp.validation.xml");
                ConfigurationService.AddDirectory(new DirectoryInfo(@"./"));
                Type type = typeof(Person);
                TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
                Assert.AreEqual(4, typeDescriptor.Properties["Age"].Rules.Count);

                RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
                MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
                Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

                RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
                MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
                Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
            }
            finally
            {
                if(Directory.Exists("temp"))
                {
                    if (File.Exists("temp/temp.validation.xml"))
                    {
                        File.Delete("temp/temp.validation.xml");
                        Directory.Delete("temp");
                    }
                }
            }

        }


        [Test]
        public void AddXmlStringMethod()
        {
            ConfigurationService.AddXmlString(methodXmlString);
            Type type = typeof(Person);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
        }


        [Test]
        public void AddXmlStringProperty()
        {
            ConfigurationService.AddXmlString(propertyXmlString);
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(1, typeDescriptor.Properties["Age"].Rules.Count);
        }


        [Test]
        public void AddXmlStringPropertySub()
        {
            ConfigurationService.AddXmlString(propertyXmlString);
            Type type = typeof(Employee);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(1, typeDescriptor.Properties["Age"].Rules.Count);
        }


        [Test]
        public void AddXmlDocumentMethod()
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.LoadXml(methodXmlString);
            ConfigurationService.AddDocument(xmlDocument);
            Type type = typeof(Person);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
        }


        [Test]
        public void AddXmlDocumentProperty()
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.LoadXml(propertyXmlString);
            ConfigurationService.AddDocument(xmlDocument);
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(1, typeDescriptor.Properties["Age"].Rules.Count);
        }


        [Test]
        public void AddXmlReaderProperty()
        {
            XmlTextReader xmlTextReader = new XmlTextReader(new StringReader(propertyXmlString));
            ConfigurationService.AddXmlReader(xmlTextReader);
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(1, typeDescriptor.Properties["Age"].Rules.Count);

        }


        [Test]
        public void AddXmlReaderMethod()
        {
            XmlTextReader xmlTextReader = new XmlTextReader(new StringReader(methodXmlString));
            ConfigurationService.AddXmlReader(xmlTextReader);
            Type type = typeof(Person);

            RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
            MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
            Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

            RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
            MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
            Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
        }


        [Test]
        public void AddInputStream()
        {
            using (Stream stream = GetType().Assembly.GetManifestResourceStream("ValidationFramework.Tests.Configuration.Person.validation.xml"))
            {
                ConfigurationService.AddInputStream(stream);
                Type type = typeof(Person);
                TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
                Assert.AreEqual(4, typeDescriptor.Properties["Age"].Rules.Count);

                RuntimeMethodHandle setTheAgeIntMethodHandle = type.GetMethod("SetTheAge", new Type[] { typeof(int) }).MethodHandle;
                MethodDescriptor intSetTheAgeMethodDescriptor = MethodCache.GetMethod(setTheAgeIntMethodHandle);
                Assert.AreEqual(4, intSetTheAgeMethodDescriptor.Parameters["age"].Rules.Count);

                RuntimeMethodHandle setTheAge2MethodHandle = type.GetMethod("SetTheAge2").MethodHandle;
                MethodDescriptor setTheAge2MethodDescriptor = MethodCache.GetMethod(setTheAge2MethodHandle);
                Assert.AreEqual(4, setTheAge2MethodDescriptor.Parameters["age"].Rules.Count);
            }
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "Could not load IRuleConfigReader type. Tried 'ValidationFramework.Configuration.InvalidReaderConfigReader,ValidationFramework'\r\nParameter name: runtimeTypeHandle")]
        public void GetRuleNotExist()
        {
            string validatorXml = "<rule validationExpression='aaaaa' typeName='InvalidReader'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);

        }

        [Test]
        public void GetRuleConfigReader1()
        {
            string validatorXml = "<rule validationExpression='aaaaa' errorMessage='hello' typeName='ValidationFramework.Configuration.RegexRuleConfigReader,ValidationFramework' ruleSet='foo' regexOptions='RightToLeft'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RegexRule rule = (RegexRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(RegexOptions.RightToLeft, rule.RegexOptions);
            Assert.AreEqual("aaaaa", rule.ValidationExpression);
            Assert.AreEqual("FOO", rule.RuleSet);
        }
        [Test]
        public void GetRuleConfigReader2()
        {
            string validatorXml = "<rule validationExpression='aaaaa' errorMessage='hello' typeName='RegexRuleConfigReader' ruleSet='foo' regexOptions='RightToLeft'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RegexRule rule = (RegexRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(RegexOptions.RightToLeft, rule.RegexOptions);
            Assert.AreEqual("aaaaa", rule.ValidationExpression);
            Assert.AreEqual("FOO", rule.RuleSet);
        }
        [Test]
        public void GetRuleConfigReader3()
        {
            string validatorXml = "<rule validationExpression='aaaaa' errorMessage='hello' typeName='RegexRule' ruleSet='foo' regexOptions='RightToLeft'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RegexRule rule = (RegexRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(RegexOptions.RightToLeft, rule.RegexOptions);
            Assert.AreEqual("aaaaa", rule.ValidationExpression);
            Assert.AreEqual("FOO", rule.RuleSet);
        }

        [Test]
        public void GetRuleConfigReader4()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='ValidationFramework.Tests.Configuration.BasicRule,ValidationFramework.Tests' ruleSet='foo'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            BasicRule rule = (BasicRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("FOO", rule.RuleSet);
        }
        [Test]
        public void GetRuleConfigReader5()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='ValidationFramework.Tests.Configuration.BasicRuleConfigReader,ValidationFramework.Tests' ruleSet='foo'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            BasicRule rule = (BasicRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("FOO", rule.RuleSet);
        }
        
    }


}