using System;
using System.Collections;
using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class LengthCollectionRuleConfigReaderTest
    {
        #region Methods

      [Test]
      public void ReadConfig()
      {
        string validatorXml = "<rule errorMessage='hello' excludeDuplicatesFromCount='true' ruleSet='foo' typeName='LengthCollectionRule' minimum='1' maximum='5' equalityComparerTypeName='System.StringComparer' equalityComparerPropertyName='OrdinalIgnoreCase'/>";
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
        RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
        LengthCollectionRule rule = (LengthCollectionRule)ConfigurationService.GetRule(ruleData, typeof(IList).TypeHandle);
        Assert.AreEqual("hello", rule.ErrorMessage);
        Assert.AreEqual(true, rule.ExcludeDuplicatesFromCount);
        Assert.AreEqual(1, rule.Minimum);
        Assert.AreEqual(5, rule.Maximum);
        Assert.AreEqual("FOO", rule.RuleSet);
        Assert.AreEqual(StringComparer.OrdinalIgnoreCase, rule.Comparer);


      }
      [Test]
      public void ReadConfigSimple()
      {
        string validatorXml = "<rule typeName='LengthCollectionRule' maximum='5'/>";
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
        RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
        LengthCollectionRule rule = (LengthCollectionRule)ConfigurationService.GetRule(ruleData, typeof(IList).TypeHandle);
        Assert.AreEqual(null, rule.ErrorMessage);
        Assert.AreEqual(true, rule.ExcludeDuplicatesFromCount);
        Assert.AreEqual(0, rule.Minimum);
        Assert.AreEqual(5, rule.Maximum);
        Assert.AreEqual(null, rule.RuleSet);
        Assert.AreEqual(null, rule.Comparer);


      }

        #endregion

    }
}