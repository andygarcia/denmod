using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class CustomRuleConfigReaderTest
    {

        #region Methods

        [Test]
        public void ReadConfig()
        {

            string validatorXml = "<rule ruleInterpretation='This is a custom rule' ruleSet='foo' validationMethod='ValidateValid' validationTypeName='ValidationFramework.Tests.CustomRuleTest+ValidationClass,ValidationFramework.Tests' errorMessage='hello' typeName='CustomRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            CustomRule rule = (CustomRule)ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("This is a custom rule", rule.RuleInterpretation);
            Assert.AreEqual(typeof(CustomRuleTest.ValidationClass).GetMethod("ValidateValid"), rule.Handler.Method);
            Assert.AreEqual("FOO", rule.RuleSet);
        }

        #endregion


    }
}