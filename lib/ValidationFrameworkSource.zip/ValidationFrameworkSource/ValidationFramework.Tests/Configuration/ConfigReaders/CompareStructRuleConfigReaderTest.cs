using System;
using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class CompareStructRuleConfigReaderTest
    {
        #region Methods

        [Test]
        public void ReadConfig()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='CompareRule' ruleSet='foo'  valueToCompare='1' compareOperator='Equal'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            CompareRule<int> rule = (CompareRule<int>)ConfigurationService.GetRule(ruleData, typeof(int).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(1, rule.ValueToCompare);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(CompareOperator.Equal, rule.CompareOperator);
        }


        [Test]
        public void ReadConfigNullable()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='CompareRule' ruleSet='foo'  valueToCompare='1' compareOperator='Equal'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            CompareRule<int> rule = (CompareRule<int>)ConfigurationService.GetRule(ruleData, typeof(int?).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(1, rule.ValueToCompare);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(CompareOperator.Equal, rule.CompareOperator);
        }

        [Test]
        public void ReadDateTimeConfig()
        {
            string validatorXml = "<rule errorMessage='hello' valueToCompare='10 Mar 2007' typeName='CompareRule' ruleSet='foo'   compareOperator='Equal'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            CompareRule<DateTime> rule = (CompareRule<DateTime>)ConfigurationService.GetRule(ruleData, typeof(DateTime).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(new DateTime(2007,3,10), rule.ValueToCompare);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(CompareOperator.Equal, rule.CompareOperator);
        }


        [Test]
        public void ReadDateTimeConfigNullable()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='CompareRule' ruleSet='foo' valueToCompare='10 Mar 2007' compareOperator='Equal'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            CompareRule<DateTime> rule = (CompareRule<DateTime>)ConfigurationService.GetRule(ruleData, typeof(DateTime?).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(new DateTime(2007, 3, 10), rule.ValueToCompare);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(CompareOperator.Equal, rule.CompareOperator);
        }

        #endregion


    }
}