using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class ComparePropertyRuleConfigReaderTest
    {

        #region Methods

        [Test]
        public void ReadConfig()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='ComparePropertyRule' ruleSet='foo' propertyToCompare='a' compareOperator='Equal'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            ComparePropertyRule rule = (ComparePropertyRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("a", rule.PropertyToCompare);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(CompareOperator.Equal, rule.CompareOperator);

        }

        #endregion


    }
}