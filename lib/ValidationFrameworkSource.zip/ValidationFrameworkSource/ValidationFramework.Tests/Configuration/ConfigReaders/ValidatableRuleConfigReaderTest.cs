using System;
using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class ValidatableRuleConfigReaderTest
    {

        #region Methods

        [Test]
        public void ReadConfig1()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='ValidatableRule' ruleSet='foo' />";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            ValidatableRule rule = (ValidatableRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.IsFalse(rule.UseMemberErrorMessages);
        }


        [Test]
        public void ReadConfig2()
        {
            string validatorXml = "<rule useMemberErrorMessages='true' typeName='ValidatableRule' ruleSet='foo' />";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            ValidatableRule rule = (ValidatableRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsTrue(rule.UseMemberErrorMessages);
        }



        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ReadConfig3()
        {
            string validatorXml = "<rule useMemberErrorMessages='true' errorMessage='hello' typeName='ValidatableRule' ruleSet='foo' />";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
        }

        #endregion

    }
}