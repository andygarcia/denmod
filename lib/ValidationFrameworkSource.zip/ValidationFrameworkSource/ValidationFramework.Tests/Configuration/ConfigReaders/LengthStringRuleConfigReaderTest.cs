using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class LengthStringRuleConfigReaderTest
    {

        #region Methods

      [Test]
      public void ReadConfig()
      {
        string validatorXml = "<rule errorMessage='hello' typeName='LengthStringRule' ruleSet='foo' minimum='1' maximum='5' trimWhiteSpace='false'/>";
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
        RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
        LengthStringRule rule = (LengthStringRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
        Assert.AreEqual("hello", rule.ErrorMessage);
        Assert.AreEqual(1, rule.Minimum);
        Assert.AreEqual(5, rule.Maximum);
        Assert.AreEqual("FOO", rule.RuleSet);
        Assert.IsFalse(rule.TrimWhiteSpace);

      }

      [Test]
      public void ReadConfigNoMinimum()
      {
        string validatorXml = "<rule typeName='LengthStringRule' maximum='5'/>";
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
        RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
        LengthStringRule rule = (LengthStringRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
        Assert.AreEqual(null, rule.ErrorMessage);
        Assert.AreEqual(0, rule.Minimum);
        Assert.AreEqual(5, rule.Maximum);
        Assert.AreEqual(null, rule.RuleSet);
        Assert.IsTrue(rule.TrimWhiteSpace);

      }

        #endregion


    }
}