using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class RequiredObjectRuleConfigReaderTest
    {
        [XmlRoot("person")]
        public class Person
        {
            [XmlAttribute("name")]
            public string Name
            {
                get;
                set;
            }

            [XmlAttribute("age")]
            public int Age
            {
                get;
                set;
            }

        }
        #region Methods

        [Test]
        public void ReadConfigComplex()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RequiredObjectRule' ruleSet='foo' ><person name='john' age='23'/></rule>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<Person> rule = (RequiredRule<Person>)ConfigurationService.GetRule(ruleData, typeof(Person).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Person person = rule.InitialValue;
            Assert.AreEqual("FOO", rule.RuleSet);

            Assert.AreEqual(23, person.Age);
            Assert.AreEqual("john", person.Name);

        }


        [Test]
        public void ReadConfigSimple()
        {
            string validatorXml = "<rule typeName='RequiredObjectRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<Person> rule = (RequiredRule<Person>)ConfigurationService.GetRule(ruleData, typeof(Person).TypeHandle);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.HasInitialValue);
        }
        #endregion


    }
}