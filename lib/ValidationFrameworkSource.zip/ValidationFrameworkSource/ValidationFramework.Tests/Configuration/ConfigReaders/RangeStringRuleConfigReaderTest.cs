using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class RangeStringRuleConfigReaderTest
    {

        #region Methods

        [Test]
        public void ReadConfig()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RangeStringRule' ruleSet='foo' minimum='a' maximum='c' equalsMinimumIsValid='false' equalsMaximumIsValid='false' />";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RangeStringRule rule = (RangeStringRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("a", rule.Minimum);
            Assert.AreEqual("c", rule.Maximum);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.IsFalse(rule.EqualsMinimumIsValid);
            Assert.IsFalse(rule.EqualsMaximumIsValid);

        }

        #endregion


    }
}