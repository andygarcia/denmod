using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class RequiredEnumRuleConfigReaderTest
    {
        public enum Numbers
        {
            One,
            Two,
            Three
        }
        #region Methods

        [Test]
        public void ReadConfig()
        {
            string validatorXml = "<rule errorMessage='hello' initialValue='Two' typeName='RequiredEnumRule' ruleSet='foo' />";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<Numbers> rule = (RequiredRule<Numbers>)ConfigurationService.GetRule(ruleData, typeof(Numbers).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(Numbers.Two, rule.InitialValue);


        }

        [Test]
        public void ReadConfigSimpleNotNullable()
        {
            string validatorXml = "<rule typeName='RequiredEnumRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<Numbers> rule = (RequiredRule<Numbers>)ConfigurationService.GetRule(ruleData, typeof(Numbers).TypeHandle);
            Assert.AreEqual(Numbers.One, rule.InitialValue);
            Assert.IsNull(rule.ErrorMessage);
        }


        [Test]
        public void ReadConfigSimpleNullable()
        {
            string validatorXml = "<rule typeName='RequiredEnumRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<Numbers> rule = (RequiredRule<Numbers>)ConfigurationService.GetRule(ruleData, typeof(Numbers?).TypeHandle);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsNull(rule.ErrorMessage);
        }
        [Test]
        public void ReadConfigSimpleNotNullableInitialValue()
        {
            string validatorXml = "<rule typeName='RequiredEnumRule' initialValue='Two'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<Numbers> requiredEnumRule = (RequiredRule<Numbers>)ConfigurationService.GetRule(ruleData, typeof(Numbers).TypeHandle);
            Assert.AreEqual(Numbers.Two, requiredEnumRule.InitialValue);
            Assert.IsNull(requiredEnumRule.ErrorMessage);
        }


        [Test]
        public void ReadConfigSimpleNullableInitialValue()
        {
            string validatorXml = "<rule typeName='RequiredEnumRule' initialValue='Two'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<Numbers> rule = (RequiredRule<Numbers>)ConfigurationService.GetRule(ruleData, typeof(Numbers?).TypeHandle);
            Assert.AreEqual(Numbers.Two, rule.InitialValue);
            Assert.IsNull(rule.ErrorMessage);
        }

        #endregion


    }
}