using System;
using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class RequiredRuleConfigReaderTest
    {
        #region Methods

        [Test]
        public void ReadConfig()
        {
            string validatorXml = "<rule errorMessage='hello' initialValue='10' typeName='RequiredRule' ruleSet='foo' />";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<int> rule = (RequiredRule<int>)ConfigurationService.GetRule(ruleData, typeof(int).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(10, rule.InitialValue);


        }

        [Test]
        public void ReadConfigSimple()
        {
            string validatorXml = "<rule typeName='RequiredRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<int> rule = (RequiredRule<int>)ConfigurationService.GetRule(ruleData, typeof(int).TypeHandle);
            Assert.IsFalse(rule.HasInitialValue);


        }
        [Test]
        public void ReadConfigNullable()
        {
            string validatorXml = "<rule typeName='RequiredRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<int> rule = (RequiredRule<int>)ConfigurationService.GetRule(ruleData, typeof(int?).TypeHandle);
            Assert.IsFalse(rule.HasInitialValue);


        }

        [Test]
        public void ReadConfigDateTime()
        {
            string validatorXml = "<rule errorMessage='hello' initialValue='10 Mar 2007' typeName='RequiredRule' ruleSet='foo' />";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<DateTime> rule = (RequiredRule<DateTime>)ConfigurationService.GetRule(ruleData, typeof(DateTime).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(new DateTime(2007,3,10), rule.InitialValue);


        }

        [Test]
        public void ReadConfigDateTimeSimple()
        {
            string validatorXml = "<rule typeName='RequiredRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<DateTime> rule = (RequiredRule<DateTime>)ConfigurationService.GetRule(ruleData, typeof(DateTime).TypeHandle);
            Assert.IsFalse(rule.HasInitialValue);


        }
        [Test]
        public void ReadConfigDateTimeNullable()
        {
            string validatorXml = "<rule typeName='RequiredRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredRule<DateTime> rule = (RequiredRule<DateTime>)ConfigurationService.GetRule(ruleData, typeof(DateTime?).TypeHandle);
            Assert.IsFalse(rule.HasInitialValue);


        }

        #endregion


    }
}