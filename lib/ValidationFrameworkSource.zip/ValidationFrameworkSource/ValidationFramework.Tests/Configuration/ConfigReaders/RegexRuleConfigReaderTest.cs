using System.IO;
using System.Text.RegularExpressions;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class RegexRuleConfigReaderTest
    {

        #region Methods

        [Test]
        public void ReadConfigComplex()
        {
            string validatorXml = "<rule validationExpression='aaaaa' errorMessage='hello' typeName='RegexRule' ruleSet='foo' regexOptions='RightToLeft'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RegexRule rule = (RegexRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(RegexOptions.RightToLeft, rule.RegexOptions);
            Assert.AreEqual("aaaaa", rule.ValidationExpression);
            Assert.AreEqual("FOO", rule.RuleSet);

        }


        [Test]
        public void ReadConfigSimple()
        {
            string validatorXml = "<rule validationExpression='aaaaa' typeName='RegexRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RegexRule rule = (RegexRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("aaaaa", rule.ValidationExpression);
            Assert.AreEqual(RegexOptions.None, rule.RegexOptions);
            Assert.IsNull(rule.ErrorMessage);

        }

        #endregion


    }
}