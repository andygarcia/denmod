using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class RequiredBoolRuleConfigReaderTest
    {

        #region Methods

		[Test]
		public void ReadConfig()
		{
			string validatorXml = "<rule errorMessage='hello' typeName='RequiredBoolRule'  ruleSet='foo' />";
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
			RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
			RequiredBoolRule rule = (RequiredBoolRule)ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);
			Assert.AreEqual("hello", rule.ErrorMessage);
			Assert.AreEqual("FOO", rule.RuleSet);

		}


		[Test]
		public void ReadConfigNullable()
		{
			string validatorXml = "<rule errorMessage='hello' typeName='RequiredBoolRule'  ruleSet='foo' />";
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
			RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
			RequiredBoolRule rule = (RequiredBoolRule)ConfigurationService.GetRule(ruleData, typeof(bool?).TypeHandle);
			Assert.AreEqual("hello", rule.ErrorMessage);
			Assert.AreEqual("FOO", rule.RuleSet);

		}

        #endregion


    }
}