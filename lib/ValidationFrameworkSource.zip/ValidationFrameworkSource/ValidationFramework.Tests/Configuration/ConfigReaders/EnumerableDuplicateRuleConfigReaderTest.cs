using System;
using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class EnumerableDuplicateRuleConfigReaderTest
    {

        #region Methods

        [Test]
        public void ReadConfigSimple()
        {
            string validatorXml = "<rule typeName='EnumerableDuplicateRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            EnumerableDuplicateRule rule = (EnumerableDuplicateRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual(null, rule.RuleSet);
            Assert.AreEqual(null, rule.ErrorMessage);
            Assert.IsNull(rule.Comparer);

        }

        [Test]
        public void ReadConfigComplex()
        {
          string validatorXml = "<rule errorMessage='hello' typeName='EnumerableDuplicateRule'  ruleSet='foo' equalityComparerTypeName='System.StringComparer' equalityComparerPropertyName='InvariantCulture'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            EnumerableDuplicateRule rule = (EnumerableDuplicateRule)ConfigurationService.GetRule(ruleData, typeof(string).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.AreEqual(StringComparer.InvariantCulture, rule.Comparer);

        }

        #endregion


    }
}