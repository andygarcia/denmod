
using System;
using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class RangeRuleConfigReaderTest
    {
        #region Methods

        [Test]
        public void ReadConfig()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RangeRule' minimum='1' ruleSet='foo' equalsMinimumIsValid='false' equalsMaximumIsValid='false' maximum='5'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RangeRule<int> rule = (RangeRule<int>)ConfigurationService.GetRule(ruleData, typeof(int).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(1, rule.Minimum);
            Assert.AreEqual(5, rule.Maximum);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.IsFalse(rule.EqualsMinimumIsValid);
            Assert.IsFalse(rule.EqualsMaximumIsValid);
        }



        [Test]
        public void ReadConfigNullable()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RangeRule' minimum='1' ruleSet='foo' equalsMinimumIsValid='false' equalsMaximumIsValid='false' maximum='5'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RangeRule<int> rule = (RangeRule<int>)ConfigurationService.GetRule(ruleData, typeof(int?).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(1, rule.Minimum);
            Assert.AreEqual(5, rule.Maximum);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.IsFalse(rule.EqualsMinimumIsValid);
            Assert.IsFalse(rule.EqualsMaximumIsValid);
        }

        [Test]
        public void ReadDateTimeConfig()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RangeRule' minimum='10 Mar 2007' ruleSet='foo' equalsMinimumIsValid='false' equalsMaximumIsValid='false' maximum='12 Mar 2007'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RangeRule<DateTime> rule = (RangeRule<DateTime>)ConfigurationService.GetRule(ruleData, typeof(DateTime).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(new DateTime(2007, 3, 10), rule.Minimum);
            Assert.AreEqual(new DateTime(2007, 3, 12), rule.Maximum);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.IsFalse(rule.EqualsMinimumIsValid);
            Assert.IsFalse(rule.EqualsMaximumIsValid);
        }



        [Test]
        public void ReadDateTimeConfigNullable()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RangeRule' minimum='10 Mar 2007' ruleSet='foo' equalsMinimumIsValid='false' equalsMaximumIsValid='false' maximum='12 Mar 2007'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RangeRule<DateTime> rule = (RangeRule<DateTime>)ConfigurationService.GetRule(ruleData, typeof(DateTime?).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual(new DateTime(2007, 3, 10), rule.Minimum);
            Assert.AreEqual(new DateTime(2007, 3, 12), rule.Maximum);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.IsFalse(rule.EqualsMinimumIsValid);
            Assert.IsFalse(rule.EqualsMaximumIsValid);
        }
        #endregion


    }
}