using System;
using System.IO;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class RequiredStringRuleConfigReaderTest
    {

        #region Methods

        [Test]
        public void ReadConfig()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RequiredStringRule' initialValue='hello2' ruleSet='foo' />";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredStringRule rule = (RequiredStringRule)ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.AreEqual("hello2", rule.InitialValue);
            Assert.AreEqual("FOO", rule.RuleSet);
            Assert.IsTrue(rule.TrimWhiteSpace);

        }

        [Test]
        public void ReadConfigIgnoreSpaces()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RequiredStringRule' ignoreSpaces='true'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredStringRule rule = (RequiredStringRule)ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsTrue(rule.TrimWhiteSpace);

        }

        [Test]
        public void ReadConfigIgnoreCase()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RequiredStringRule' initialValue='aa' ignoreCase='false'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredStringRule requiredStringRule = (RequiredStringRule)ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);
            Assert.AreEqual("hello", requiredStringRule.ErrorMessage);
            Assert.IsFalse(requiredStringRule.IgnoreCase.Value);

        }
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ReadConfigIgnoreCaseNoInitialValue()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RequiredStringRule' ignoreCase='false'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredStringRule requiredStringRule = (RequiredStringRule)ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);
            Assert.AreEqual("hello", requiredStringRule.ErrorMessage);
            Assert.IsFalse(requiredStringRule.IgnoreCase.Value);

        }
        [Test]
        public void ReadConfigNoTrimWhiteSpace()
        {
            string validatorXml = "<rule errorMessage='hello' typeName='RequiredStringRule' trimWhiteSpace='false'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredStringRule rule = (RequiredStringRule)ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);
            Assert.AreEqual("hello", rule.ErrorMessage);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsFalse(rule.TrimWhiteSpace);

        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: initialValue")]
        public void ReadConfigEmptyInitialValueException()
        {
            string validatorXml = "<rule typeName='RequiredStringRule'  initialValue=''/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);

        }

        [Test]
        public void ReadConfigSimple()
        {
            string validatorXml = "<rule typeName='RequiredStringRule'/>";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(RuleData));
            RuleData ruleData = (RuleData)xmlSerializer.Deserialize(new StringReader(validatorXml));
            RequiredStringRule rule = (RequiredStringRule)ConfigurationService.GetRule(ruleData, typeof(bool).TypeHandle);
            Assert.IsNull(rule.ErrorMessage);
            Assert.IsFalse(rule.HasInitialValue);
            Assert.IsTrue(rule.TrimWhiteSpace);
        }
        #endregion


    }
}