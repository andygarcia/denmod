using System;
using System.Configuration;
using System.IO;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests.Configuration
{
    [TestFixture]
    public class ValidationConfigurationSectionTest
    {
        [Test]
        public void ReadConfig()
        {
            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();

            fileMap.ExeConfigFilename = Path.Combine(Environment.CurrentDirectory, "AppConfigSample.xml");

            System.Configuration.Configuration configuration = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
            ConfigurationSection section = configuration.GetSection("validationFrameworkConfiguration");
            ValidationConfigurationSection validationConfigurationSection = (ValidationConfigurationSection) section;
            //Assert.AreEqual(validationConfigurationSection.ErrorMessageProviderType, "foo");
          
            Assert.AreEqual(validationConfigurationSection.MappingDocuments[0].Url, "map1");
            Assert.AreEqual(validationConfigurationSection.MappingDocuments[1].Url, "map2");
        }
    }
}
