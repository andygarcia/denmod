using System.Globalization;
using System.IO;
using System.Threading;
using System.Xml.Serialization;
using NUnit.Framework;
using ValidationFramework.Configuration;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class KeyedCultureErrorMessageProviderTest
    {
        [Test]
        public void ReadConfig()
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(KeyedCultureErrorMessageProvider));
            KeyedCultureErrorMessageProvider keyedCultureErrorMessageProvider = (KeyedCultureErrorMessageProvider) xmlSerializer.Deserialize(new StringReader(File.ReadAllText("KeyedCultureErrorMessageProvider.xml")));
            Assert.AreEqual(2, keyedCultureErrorMessageProvider.MessageGroups.Length);
            MessageGroup messageGroup = keyedCultureErrorMessageProvider.MessageGroups[0];
            Assert.AreEqual("AddressIsRequired", messageGroup.Key);
            Assert.AreEqual(3, messageGroup.CultureMessages.Length);
            CultureMessage cultureMessage = messageGroup.CultureMessages[0];
            Assert.AreEqual("fr", cultureMessage.CultureId);
            Assert.AreEqual("L'adresse est exig�e.", cultureMessage.Text);

            RequiredBoolRule requiredBoolRule = new RequiredBoolRule("AddressIsRequired");
            string errorMessage;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("fr-CA");
            errorMessage = keyedCultureErrorMessageProvider.RetrieveErrorMessage(requiredBoolRule, null, null, null);
            Assert.AreEqual("L'adresse est exig�e.", errorMessage);

            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-AU");
            errorMessage = keyedCultureErrorMessageProvider.RetrieveErrorMessage(requiredBoolRule, null, null, null);
            Assert.AreEqual("Address is required.", errorMessage);
        }
    }
}
