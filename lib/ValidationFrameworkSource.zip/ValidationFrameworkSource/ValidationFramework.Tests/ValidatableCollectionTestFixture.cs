using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class ValidatableCollectionTestFixture
    {
        [Test]
        public void ValidatableCollectionIsValidTest()
        {
            ValidatableCollection<NotifyValidatableBaseItem> col = new ValidatableCollection<NotifyValidatableBaseItem>();

            Assert.IsTrue(col.IsValid);
            Assert.AreEqual(col.ErrorMessages.Count, 0);
            NotifyValidatableBaseItem item = new NotifyValidatableBaseItem();
            col.Add(item);
            Assert.IsFalse(col.IsValid);
            Assert.AreEqual(col.ErrorMessages.Count, 1);
            item.StringData = "asas";
            Assert.IsTrue(col.IsValid);
            Assert.AreEqual(col.ErrorMessages.Count, 0);
        }
    }
}