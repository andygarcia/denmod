using System.Collections.Generic;
using NUnit.Framework;

namespace ValidationFramework.PropertyValidationManagerTests
{
    [TestFixture]
    public class InheritanceTests
    {

        public class BaseClass
        {

            [RequiredStringRule]
            public string Property1
            {
                get;
                set;
            }
        }

        public class InheritedClass : BaseClass
        {

            [RequiredStringRule]
            public string Property2
            {
                get;
                set;
            }
        }

        [Test]
        public void InstanceValidate()
        {
            BaseClass baseClass = new BaseClass();
            PropertyValidationManager baseClassPropertyValidationManager = new PropertyValidationManager(baseClass);
            baseClassPropertyValidationManager.ValidateAllProperties();
            Assert.AreEqual(1, baseClassPropertyValidationManager.ValidatorResultsInError.Count);

            InheritedClass inheritedClass = new InheritedClass();
            PropertyValidationManager inheritedClassPropertyValidationManager = new PropertyValidationManager(inheritedClass);
            inheritedClassPropertyValidationManager.ValidateAllProperties();
            Assert.AreEqual(2, inheritedClassPropertyValidationManager.ValidatorResultsInError.Count);
        }


        [Test]
        public void StaticValidate()
        {
            BaseClass baseClass = new BaseClass();
            IList<ValidationResult> baseClassValidationResults = PropertyValidationManager.ValidateAllProperties(baseClass, null, null);
            Assert.AreEqual(1, baseClassValidationResults.Count);

            InheritedClass inheritedClass = new InheritedClass();
            IList<ValidationResult> inheritedClassValidationResults = PropertyValidationManager.ValidateAllProperties(inheritedClass, null, null);
            Assert.AreEqual(2, inheritedClassValidationResults.Count);
        }
        [Test]
        public void InstanceTryValidate()
        {
            BaseClass baseClass = new BaseClass();
            PropertyValidationManager baseClassPropertyValidationManager = new PropertyValidationManager(baseClass);
            baseClassPropertyValidationManager.TryValidateAllProperties();
            Assert.AreEqual(1, baseClassPropertyValidationManager.ValidatorResultsInError.Count);

            InheritedClass inheritedClass = new InheritedClass();
            PropertyValidationManager inheritedClassPropertyValidationManager = new PropertyValidationManager(inheritedClass);
            inheritedClassPropertyValidationManager.TryValidateAllProperties();
            Assert.AreEqual(2, inheritedClassPropertyValidationManager.ValidatorResultsInError.Count);
        }


        [Test]
        public void StaticTryValidate()
        {
            BaseClass baseClass = new BaseClass();
            IList<ValidationResult> baseClassValidationResults = PropertyValidationManager.TryValidateAllProperties(baseClass, null, null);
            Assert.AreEqual(1, baseClassValidationResults.Count);

            InheritedClass inheritedClass = new InheritedClass();
            IList<ValidationResult> inheritedClassValidationResults = PropertyValidationManager.TryValidateAllProperties(inheritedClass, null, null);
            Assert.AreEqual(2, inheritedClassValidationResults.Count);
        }
    }
}
