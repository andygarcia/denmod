using System;
using System.Collections.Generic;
using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ValidationFramework.PropertyValidationManagerTests
{

    public interface IFoo2
    {
        int Data
        {
            get;
            set;
        }
    }


    public class Foo : IFoo2
    {

        public int Data
        {
            get;
            set;
        }
  


        //[CompareIntRule(5, CompareOperator.LessThan)]
        int IFoo2.Data
        {
            get;
            set;
        }
    }


    public static class StaticFoo
    {
        public static int Data
        {
            get;
            set;
        }
    }

    public class PropertyValidationManagerTestBase
    {

        [TearDown]
        public void TearDown()
        {
            TypeDescriptor staticTypeDescriptor = TypeCache.GetType(typeof(StaticFoo).TypeHandle);
            if (staticTypeDescriptor.Properties.ContainsKey("Data"))
            {
                staticTypeDescriptor.Properties["Data"].Rules.Clear();
            }

            TypeDescriptor instanceTypeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);
            if (instanceTypeDescriptor.Properties.ContainsKey("Data"))
            {
                instanceTypeDescriptor.Properties["Data"].Rules.Clear();
            }
            if (instanceTypeDescriptor.Properties.ContainsKey("ValidationFramework.Tests.IFoo2.Data"))
            {
                instanceTypeDescriptor.Properties["ValidationFramework.Tests.IFoo2.Data"].Rules.Clear();
            }

        }
        [SetUp]
        public void Setup()
        {
            TypeCache.Clear();
        }
    }

    [TestFixture]
    public class PropertyValidationManagerConstructorTest : PropertyValidationManagerTestBase
    {
        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: targetObject")]
        public void NullTargetTest()
        {
            new PropertyValidationManager(null);
        }
        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void EmptyRuleSetTest()
        {
            new PropertyValidationManager("foo",string.Empty);
        }

        [Test]
        public void ConstructorTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            Assert.IsFalse(manager.IsValidatingStatic);
            Assert.AreEqual(manager.Target, foo);
        }

        [Test]
        public void ConstructorStaticTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager manager = new PropertyValidationManager(handle);
            Assert.AreEqual(manager.TypeDescriptor.RuntimeTypeHandle, handle);
            Assert.AreEqual(manager.TargetHandle, handle);
            Assert.IsTrue(manager.IsValidatingStatic);
        }

    }


    [TestFixture]
    public class PropertyValidationManagerValidateTest:PropertyValidationManagerTestBase
    {
        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void ValidateNullPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.ValidateProperty(null);
        }

        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ValidateNoRulesExceptionTest()
        {
            Foo classWithNoRules = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(classWithNoRules);
            manager.ValidateAllProperties();
        }

        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void ValidateNullPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.ValidateProperty(null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void ValidateEmptyPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.ValidateProperty(string.Empty);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void ValidateEmptyPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.ValidateProperty(string.Empty);
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'aaa' could not be found containing rules.\r\nParameter name: propertyName")]
        public void ValidateInvalidPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.ValidateProperty("aaa");
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'dataC' could not be found containing rules.\r\nParameter name: propertyName")]
        public void ValidatePropertyWithNoRulesExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.ValidateProperty("dataC");
        }

        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'aaa' could not be found containing rules.\r\nParameter name: propertyName")]
        public void ValidateInvalidPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.ValidateProperty("aaa");
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'dataC' could not be found containing rules.\r\nParameter name: propertyName")]
        public void ValidatePropertyWithNoRulesExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.ValidateProperty("dataC");
        }

        [Test]
        public void PropertyValidationTest()
        {

            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            Assert.IsTrue(manager.IsValid);
            foo.Data = 6;
            manager.ValidateProperty("Data");
            Assert.IsFalse(manager.IsValid);
            foo.Data = 2;
            manager.ValidateProperty("Data");
            Assert.IsTrue(manager.IsValid);
        }

        [Test]
        public void PropertyValidationTestRuleSetA()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo, "a");
            Assert.IsTrue(manager.IsValid);
            foo.Data = 6;
            manager.ValidateAllProperties();
            Assert.IsFalse(manager.IsValid);
            foo.Data = 2;
            manager.ValidateAllProperties();
            Assert.IsTrue(manager.IsValid);
        }




        [Test]
        public void ExplicitPropertyValidationTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("ValidationFramework.PropertyValidationManagerTests.IFoo2.Data").Rules;
            rules.Add(compareIntRule);
            IFoo2 foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            Assert.IsTrue(manager.IsValid);
            foo.Data = 6;
            manager.ValidateProperty("ValidationFramework.PropertyValidationManagerTests.IFoo2.Data");
            Assert.IsFalse(manager.IsValid);
            foo.Data = 2;
            manager.ValidateProperty("ValidationFramework.PropertyValidationManagerTests.IFoo2.Data");
            Assert.IsTrue(manager.IsValid);
        }


        [Test]
        public void PropertyValidationStaticTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(handle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);
            PropertyValidationManager manager = new PropertyValidationManager(handle);
            Assert.IsTrue(manager.IsValid);
            StaticFoo.Data = 6;
            manager.ValidateProperty("Data");
            Assert.IsFalse(manager.IsValid);
            StaticFoo.Data = 2;
            manager.ValidateProperty("Data");
            Assert.IsTrue(manager.IsValid);
        }

    }

    [TestFixture]
    public class PropertyValidationManagerResultsInErrorTest: PropertyValidationManagerTestBase
    {
      [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
      public void GetResultsInErrorForPropertyNullPropertyExceptionTest()
      {
        Foo foo = new Foo();
        PropertyValidationManager manager = new PropertyValidationManager(foo);
        manager.GetResultsInErrorForProperty(null);
      }


      [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyNames")]
      public void GetResultsInErrorForPropertiesNullPropertiesExceptionTest()
      {
        Foo foo = new Foo();
        PropertyValidationManager manager = new PropertyValidationManager(foo);
        manager.GetResultsInErrorForProperties(null);
      }


      [Test]
      [ExpectedException(typeof(ArgumentOutOfRangeException), ExpectedMessage = "Specified argument was out of the range of valid values.\r\nParameter name: propertyNames")]
      public void GetResultsInErrorForPropertiesEmptyListPropertiesExceptionTest()
      {
        Foo foo = new Foo();
        PropertyValidationManager manager = new PropertyValidationManager(foo);
        manager.GetResultsInErrorForProperties(new string[]{});
      }


      [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void GetResultsInErrorForPropertyNullPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.GetResultsInErrorForProperty(null);
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void GetResultsInErrorForPropertyEmptyPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.GetResultsInErrorForProperty(string.Empty);
        }


      [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void GetResultsInErrorForPropertyEmptyPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.GetResultsInErrorForProperty(string.Empty);
        }

      [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'aaa' could not be found containing rules.\r\nParameter name: propertyName")]
        public void GetResultsInErrorForPropertyInvalidPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.GetResultsInErrorForProperty("aaa");
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'aaa' could not be found containing rules.\r\nParameter name: propertyName")]
        public void GetResultsInErrorForPropertyInvalidPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.GetResultsInErrorForProperty("aaa");
        }

        [Test]
        public void GetResultsInErrorForProperty()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);

            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);
            Foo foo = new Foo();

            PropertyValidationManager manager = new PropertyValidationManager(foo);
            foo.Data = 6;
            manager.ValidateProperty("Data");
            IList<ValidationResult> list = manager.GetResultsInErrorForProperty("Data");
            Assert.AreEqual(1, list.Count);
            foo.Data = 2;
            manager.ValidateProperty("Data");
            list = manager.GetResultsInErrorForProperty("Data");
            Assert.AreEqual(0, list.Count);
        }

    }

    [TestFixture]
    public class PropertyValidationManagerTryValidateTest : PropertyValidationManagerTestBase
    {

        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void ValidateNullPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.TryValidateProperty(null);
        }


        [Test]
        public void ValidateNoRulesExceptionTest()
        {
            Foo classWithNoRules = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(classWithNoRules);
            manager.TryValidateAllProperties();
        }



        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void ValidateNullPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.TryValidateProperty(null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void ValidateEmptyPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.TryValidateProperty(string.Empty);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void ValidateEmptyPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.TryValidateProperty(string.Empty);
        }

        [Test]
        public void ValidateInvalidPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.TryValidateProperty("aaa");
        }

        [Test]
        public void ValidatePropertyWithNoRulesExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            manager.TryValidateProperty("dataC");
        }
        [Test]
        public void ValidatePropertyWithNoRulesExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.TryValidateProperty("dataC");
        }

        [Test]
        public void ValidateInvalidPropertyExceptionStaticTest()
        {
            PropertyValidationManager manager = new PropertyValidationManager(typeof(StaticFoo).TypeHandle);
            manager.TryValidateProperty("aaa");
        }


        [Test]
        public void PropertyValidationTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            Assert.IsTrue(manager.IsValid);
            foo.Data = 6;
            manager.TryValidateProperty("Data");
            Assert.IsFalse(manager.IsValid);
            foo.Data = 2;
            manager.TryValidateProperty("Data");
            Assert.IsTrue(manager.IsValid);
        }

        [Test]
        public void PropertyValidationTestRuleSetA()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo, "a");
            Assert.IsTrue(manager.IsValid);
            foo.Data = 6;
            manager.TryValidateAllProperties();
            Assert.IsFalse(manager.IsValid);
            foo.Data = 2;
            manager.TryValidateAllProperties();
            Assert.IsTrue(manager.IsValid);
        }

   

        [Test]
        public void ExplicitPropertyValidationTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("ValidationFramework.PropertyValidationManagerTests.IFoo2.Data").Rules;
            rules.Add(compareIntRule);
            IFoo2 foo = new Foo();
            PropertyValidationManager manager = new PropertyValidationManager(foo);
            Assert.IsTrue(manager.IsValid);
            foo.Data = 6;
            manager.TryValidateProperty("ValidationFramework.PropertyValidationManagerTests.IFoo2.Data");
            Assert.IsFalse(manager.IsValid);
            foo.Data = 2;
            manager.TryValidateProperty("ValidationFramework.PropertyValidationManagerTests.IFoo2.Data");
            Assert.IsTrue(manager.IsValid);
        }


        [Test]
        public void PropertyValidationStaticTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(handle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);
            PropertyValidationManager manager = new PropertyValidationManager(handle);
            Assert.IsTrue(manager.IsValid);
            StaticFoo.Data = 6;
            manager.TryValidateProperty("Data");
            Assert.IsFalse(manager.IsValid);
            StaticFoo.Data = 2;
            manager.TryValidateProperty("Data");
            Assert.IsTrue(manager.IsValid);
        }

    }


    [TestFixture]
    public class PropertyValidationManagerStaticTryValidateTest : PropertyValidationManagerTestBase
    {

        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void ValidateNullPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.TryValidateProperty(foo, null, null, null);
        }

        [Test]
        public void ValidateNoRulesExceptionTest()
        {
            Foo classWithNoRules = new Foo();
            PropertyValidationManager.TryValidateAllProperties(classWithNoRules, null, null);
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void ValidateEmptyRuleSetExceptionTest()
        {
            Foo classWithNoRules = new Foo();
            PropertyValidationManager.TryValidateAllProperties(classWithNoRules, string.Empty, null);
        }

        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void ValidateNullPropertyExceptionStaticTest()
        {
            PropertyValidationManager.TryValidateProperty(typeof(StaticFoo).TypeHandle, null, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void ValidateEmptyPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.TryValidateProperty(foo, string.Empty, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void ValidateEmptyPropertyExceptionStaticTest()
        {
            PropertyValidationManager.TryValidateProperty(typeof(StaticFoo).TypeHandle, string.Empty, null, null);
        }

        [Test]
        public void ValidateInvalidPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.TryValidateProperty(foo, "aaa", null, null);
        }

        [Test]
        public void ValidateInvalidPropertyExceptionStaticTest()
        {
            PropertyValidationManager.TryValidateProperty(typeof(StaticFoo).TypeHandle, "aaa", null, null);
        }


        [Test]
        public void PropertyValidationTest()
        {

            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);

            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();

            Assert.AreEqual(0, PropertyValidationManager.TryValidateAllProperties(foo, null, null).Count);
            foo.Data = 6;
            Assert.AreEqual(1, PropertyValidationManager.TryValidateProperty(foo, "Data", null, null).Count);
            foo.Data = 2;
            Assert.AreEqual(0, PropertyValidationManager.TryValidateProperty(foo, "Data", null, null).Count);
        }

        [Test]
        public void PropertyValidationTestRuleSetA()
        {


            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            Assert.AreEqual(0, PropertyValidationManager.TryValidateAllProperties(foo, "a", null).Count);
            foo.Data = 6;
            Assert.AreEqual(1, PropertyValidationManager.TryValidateProperty(foo, "Data", "a", null).Count);
            foo.Data = 2;
            Assert.AreEqual(0, PropertyValidationManager.TryValidateProperty(foo, "Data", "a", null).Count);
        }

    
        [Test]
        public void ExplicitPropertyValidationTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("ValidationFramework.PropertyValidationManagerTests.IFoo2.Data").Rules;
            rules.Add(compareIntRule);

            IFoo2 foo = new Foo();
            Assert.AreEqual(0, PropertyValidationManager.TryValidateAllProperties(foo, null, null).Count);
            foo.Data = 6;
            Assert.AreEqual(1, PropertyValidationManager.TryValidateProperty(foo, "ValidationFramework.PropertyValidationManagerTests.IFoo2.Data", null, null).Count);
            foo.Data = 2;
            Assert.AreEqual(0, PropertyValidationManager.TryValidateProperty(foo, "ValidationFramework.PropertyValidationManagerTests.IFoo2.Data", null, null).Count);
        }


        [Test]
        public void PropertyValidationStaticTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
                        RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
                        rules.Add(compareIntRule);

            Assert.AreEqual(0, PropertyValidationManager.TryValidateAllProperties(handle, null, null).Count);
            StaticFoo.Data = 6;
            Assert.AreEqual(1, PropertyValidationManager.TryValidateProperty(handle, "Data", null, null).Count);
            StaticFoo.Data = 2;
            Assert.AreEqual(0, PropertyValidationManager.TryValidateProperty(handle, "Data", null, null).Count);
        }

        [Test]
        public void ValidatePropertyWithNoRulesExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.TryValidateProperty(foo, "DataC", null, null);
        }
        [Test]
        public void ValidatePropertyWithNoRulesExceptionStaticTest()
        {

            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager.TryValidateProperty(handle, "DataC", null, null);
        }

    }


    [TestFixture]
    public class PropertyValidationManagerStaticTryThrowExceptionTest : PropertyValidationManagerTestBase
    {

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "The property 'Data' must be 'Less Than' '5'.\r\nParameter name: value")]
        public void InstanceInvalidDataTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            PropertyValidationManager.TryThrowPropertyException(foo, 6, "Data", null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "The property 'Data' must be 'Less Than' '5'.\r\nParameter name: value")]
        public void StaticInvalidDataTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            PropertyValidationManager.TryThrowPropertyException(handle, 6, "Data", null, null);
        }

        [Test]
        public void InstanceValidDataTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            PropertyValidationManager.TryThrowPropertyException(foo, 3, "Data", null, null);
        }

        [Test]
        public void InstanceNoRuleTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.TryThrowPropertyException(foo, 3, "Data", null, null);
        }
        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void InstanceEmptyRuleSetTest()
        {

            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            PropertyValidationManager.TryThrowPropertyException(foo, 3, "Data", string.Empty, null);
        }


        [Test]
        public void StaticValidDataTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            PropertyValidationManager.TryThrowPropertyException(handle, 3, "Data", null, null);
        }

        [Test]
        public void StaticNoRuleTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager.TryThrowPropertyException(handle, 3, "Data", null, null);
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void StaticEmptyRuleSetTest()
        {

            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);
            PropertyValidationManager.TryThrowPropertyException(handle, 3, "Data", string.Empty, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void StaticNullPropertyNameDataTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager.TryThrowPropertyException(handle, 3, null, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void InstanceNullPropertyNameDataTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.TryThrowPropertyException(foo, 3, null, null, null);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void InstanceEmptyPropertyNameDataTest()
        {
            Foo foo = new Foo();

            PropertyValidationManager.TryThrowPropertyException(foo, 3, string.Empty, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: target")]
        public void InstanceNullTargetObjectNameDataTest()
        {
            PropertyValidationManager.TryThrowPropertyException(null, 3, "Data", null, null);
        }
    }

    [TestFixture]
    public class PropertyValidationManagerStaticThrowExceptionTest : PropertyValidationManagerTestBase
    {


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "The property 'Data' must be 'Less Than' '5'.\r\nParameter name: value")]
        public void InstanceInvalidDataTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            PropertyValidationManager.ThrowPropertyException(foo, 6, "Data", null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "The property 'Data' must be 'Less Than' '5'.\r\nParameter name: value")]
        public void StaticInvalidDataTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            PropertyValidationManager.ThrowPropertyException(handle, 6, "Data", null, null);
        }

        [Test]
        public void InstanceValidDataTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            PropertyValidationManager.ThrowPropertyException(foo, 3, "Data", null, null);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'Data' could not be found containing rules.\r\nParameter name: propertyName")]
        public void InstancePropertyRuleTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.ThrowPropertyException(foo, 3, "Data", null, null);
        }

        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No members could be found containing rules.")]
        public void InstanceNoRuleTest()
        {
        RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
        typeDescriptor.GetOrCreatePropertyDescriptor("Data");

            Foo foo = new Foo();
            PropertyValidationManager.ThrowPropertyException(foo, 3, "Data", null, null);
        }


        [Test]
        public void StaticValidDataTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            PropertyValidationManager.ThrowPropertyException(handle, 3, "Data", null, null);
        }

        [Test]
        [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No members could be found containing rules.")]
        public void StaticNoRuleTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            typeDescriptor.GetOrCreatePropertyDescriptor("Data");
            PropertyValidationManager.ThrowPropertyException(handle, 3, "Data", null, null);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'Data' could not be found containing rules.\r\nParameter name: propertyName")]
     public void StaticNoPropertyTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager.ThrowPropertyException(handle, 3, "Data", null, null);
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void StaticEmptyRuleSetTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager.ThrowPropertyException(handle, 3, "Data", string.Empty, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void StaticNullPropertyNameDataTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager.ThrowPropertyException(handle, 3, null, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void InstanceNullPropertyNameDataTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.ThrowPropertyException(foo, 3, null, null, null);
        }
        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void InstanceEmptyRuleSetDataTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.ThrowPropertyException(foo, 3, "Data", string.Empty, null);
        }

        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void InstanceEmptyPropertyNameDataTest()
        {
            Foo foo = new Foo();

            PropertyValidationManager.ThrowPropertyException(foo, 3, string.Empty, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: target")]
        public void InstanceNullTargetObjectNameDataTest()
        {
            PropertyValidationManager.ThrowPropertyException(null, 3, "Data", null, null);
        }
    }


    [TestFixture]
    public class PropertyValidationManagerStaticValidateTest : PropertyValidationManagerTestBase
    {

        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void ValidateNullPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.ValidateProperty(foo, null, null, null);
        }


        [Test]
      [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No members could be found containing rules.")]
        public void ValidateNoRulesExceptionTest()
        {
            Foo classWithNoRules = new Foo();
            PropertyValidationManager.ValidateAllProperties(classWithNoRules, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void ValidateEmptyRuleSetExceptionTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);
            Foo foo = new Foo();
            PropertyValidationManager.ValidateAllProperties(foo, string.Empty, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void ValidateNullPropertyExceptionStaticTest()
        {
            PropertyValidationManager.ValidateProperty(typeof(StaticFoo).TypeHandle, null, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void ValidateEmptyPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.ValidateProperty(foo, string.Empty, null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void ValidateEmptyPropertyExceptionStaticTest()
        {
            PropertyValidationManager.ValidateProperty(typeof(StaticFoo).TypeHandle, string.Empty, null, null);
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'aaa' could not be found containing rules.\r\nParameter name: propertyName")]
        public void ValidateInvalidPropertyExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.ValidateProperty(foo, "aaa", null, null);
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'aaa' could not be found containing rules.\r\nParameter name: propertyName")]
        public void ValidateInvalidPropertyExceptionStaticTest()
        {
            PropertyValidationManager.ValidateProperty(typeof(StaticFoo).TypeHandle, "aaa", null, null);
        }


        [Test]
        public void PropertyValidationTest()
        {

            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();

            Assert.AreEqual(0, PropertyValidationManager.ValidateAllProperties(foo, null, null).Count);
            foo.Data = 6;
            Assert.AreEqual(1, PropertyValidationManager.ValidateProperty(foo, "Data", null, null).Count);
            foo.Data = 2;
            Assert.AreEqual(0, PropertyValidationManager.ValidateProperty(foo, "Data", null, null).Count);
        }

        [Test]
        public void PropertyValidationTestRuleSetA()
        {

            CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);

            Foo foo = new Foo();
            Assert.AreEqual(0, PropertyValidationManager.ValidateAllProperties(foo, "a", null).Count);
            foo.Data = 6;
            Assert.AreEqual(1, PropertyValidationManager.ValidateProperty(foo, "Data", "a", null).Count);
            foo.Data = 2;
            Assert.AreEqual(0, PropertyValidationManager.ValidateProperty(foo, "Data", "a", null).Count);
        }


        [Test]
        public void ExplicitPropertyValidationTest()
        {
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);
            RuleCollection rules = typeDescriptor.GetOrCreatePropertyDescriptor("ValidationFramework.PropertyValidationManagerTests.IFoo2.Data").Rules;
            rules.Add(compareIntRule);
            IFoo2 foo = new Foo();
            Assert.AreEqual(0, PropertyValidationManager.ValidateAllProperties(foo, null, null).Count);
            foo.Data = 6;
            Assert.AreEqual(1, PropertyValidationManager.ValidateProperty(foo, "ValidationFramework.PropertyValidationManagerTests.IFoo2.Data", null, null).Count);
            foo.Data = 2;
            Assert.AreEqual(0, PropertyValidationManager.ValidateProperty(foo, "ValidationFramework.PropertyValidationManagerTests.IFoo2.Data", null, null).Count);
        }


        [Test]
        public void PropertyValidationStaticTest()
        {
            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
            RuleCollection rules = TypeCache.GetType(handle).GetOrCreatePropertyDescriptor("Data").Rules;
            rules.Add(compareIntRule);
            Assert.AreEqual(0, PropertyValidationManager.ValidateAllProperties(handle, null, null).Count);
            StaticFoo.Data = 6;
            Assert.AreEqual(1, PropertyValidationManager.ValidateProperty(handle, "Data", null, null).Count);
            StaticFoo.Data = 2;
            Assert.AreEqual(0, PropertyValidationManager.ValidateProperty(handle, "Data", null, null).Count);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'DataC' could not be found containing rules.\r\nParameter name: propertyName")]
        public void ValidatePropertyWithNoRulesExceptionTest()
        {
            Foo foo = new Foo();
            PropertyValidationManager.ValidateProperty(foo, "DataC", null, null);
        }


        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "A property named 'DataC' could not be found containing rules.\r\nParameter name: propertyName")]
        public void ValidatePropertyWithNoRulesExceptionStaticTest()
        {

            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager.ValidateProperty(handle, "DataC", null, null);
        }

        [Test]
      [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
        public void ValidatePropertyWithEmptyRuleSetExceptionStaticTest()
        {

            RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
            PropertyValidationManager.ValidateProperty(handle, "DataC", string.Empty, null);
        }

    }
}