
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{

    public class InfoDescriptorHelper
    {
        static ParameterDescriptor parameterDescriptor;
        private static PropertyDescriptor propertyDescriptor;
     

        [RequiredStringRule]
        public string Foo
        {
            get;
            set;
        }

        public void FooMethod([RequiredStringRule] string foo)
        {

        }

        public static ParameterDescriptor MockParameterDescriptor
        {
            get
            {
                if (parameterDescriptor == null)
                {
                    MethodDescriptor descriptor = MethodCache.GetMethod(typeof(InfoDescriptorHelper).GetMethod("FooMethod").MethodHandle);
                    parameterDescriptor = descriptor.Parameters["foo"];
                }
                return parameterDescriptor;
            }
        }


        public static PropertyDescriptor MockPropertyDescriptor
        {
            get
            {
                if (propertyDescriptor == null)
                {
                    propertyDescriptor = TypeCache.GetType(typeof(InfoDescriptorHelper).TypeHandle).GetOrCreatePropertyDescriptor("Foo");
                }
                return propertyDescriptor;
            }
        }
    }
}