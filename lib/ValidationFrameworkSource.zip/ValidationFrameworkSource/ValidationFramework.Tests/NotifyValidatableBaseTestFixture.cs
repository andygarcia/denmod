using NUnit.Framework;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class NotifyValidatableBaseTestFixture
    {
        [Test]
        public void NotifyValidatableBaseInitialInvalid()
        {
            NotifyValidatableBaseItem notifyValidatableBaseItem = new NotifyValidatableBaseItem();
            Assert.IsFalse(notifyValidatableBaseItem.IsValid);
        }


        [Test]
        public void NotifyValidatableBaseMessageCount()
        {
            NotifyValidatableBaseItem notifyValidatableBaseItem = new NotifyValidatableBaseItem();
            Assert.AreEqual(notifyValidatableBaseItem.ErrorMessages.Count, 1);
            notifyValidatableBaseItem.StringData = "aaa";
            Assert.AreEqual(notifyValidatableBaseItem.ErrorMessages.Count, 0);
        }


        [Test]
        public void NotifyValidatableBaseIsValid()
        {
            NotifyValidatableBaseItem notifyValidatableBaseItem = new NotifyValidatableBaseItem();
            Assert.IsFalse(notifyValidatableBaseItem.IsValid);
            notifyValidatableBaseItem.StringData = "aaa";
            Assert.IsTrue(notifyValidatableBaseItem.IsValid);
        }

        [Test]
        public void NotifyValidatableBaseGetAllValidationMessages()
        {
            NotifyValidatableBaseItem notifyValidatableBaseItem = new NotifyValidatableBaseItem();
            Assert.IsNotNull(notifyValidatableBaseItem.Error);
            Assert.AreNotEqual(notifyValidatableBaseItem.ErrorMessages.Count, 0);
        }
    }
}