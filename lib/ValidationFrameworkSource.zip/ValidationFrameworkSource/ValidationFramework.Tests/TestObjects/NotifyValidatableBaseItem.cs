namespace ValidationFramework.Tests
{
	public class NotifyValidatableBaseItem : NotifyValidatableBase
	{
		private string stringData;

		public NotifyValidatableBaseItem()
			: base(true)
		{
		}

		[RequiredStringRule]
		public string StringData
		{
			get
			{
				return stringData;
			}
			set
			{
				stringData = value;
				NotifyAndValidate("StringData");
			}
		}
	}
}