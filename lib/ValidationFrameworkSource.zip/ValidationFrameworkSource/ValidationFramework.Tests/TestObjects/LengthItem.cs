namespace ValidationFramework.Tests
{
    internal class InvalidLengthItem
    {
        private int intData;

        [LengthStringRule(10, Minimum = 5)]
        public int IntData
        {
            get
            {
                return intData;
            }
            set
            {
                intData = value;
            }
        }

        private string stringData;

        [LengthStringRule(10, Minimum = 5)]
        public string StringData
        {
            get
            {
                return stringData;
            }
            set
            {
                stringData = value;
            }
        }
    }
    internal class ValidLengthItem
    {

        private string stringData;

        [LengthStringRule(10, Minimum = 5)]
        public string StringData
        {
            get
            {
                return stringData;
            }
            set
            {
                stringData = value;
            }
        }
    }
}