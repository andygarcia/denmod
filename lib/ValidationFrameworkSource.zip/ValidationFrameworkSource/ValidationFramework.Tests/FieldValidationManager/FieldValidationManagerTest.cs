using System;
using System.Collections.Generic;
using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{

	public class FieldValidationManagerTests
	{

		public class Foo
		{
			public int Data;
			public int DataC;
		}

		public static class StaticFoo
		{
			public static int Data;
			public static int DataC;


		}

		public class FieldValidationManagerTestBase
		{

			[TearDown]
			public void TearDown()
			{
				TypeDescriptor staticTypeDescriptor = TypeCache.GetType(typeof(StaticFoo).TypeHandle);
				if (staticTypeDescriptor.Fields.ContainsKey("Data"))
				{
					staticTypeDescriptor.Fields["Data"].Rules.Clear();
				}

				TypeDescriptor instanceTypeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);
				if (instanceTypeDescriptor.Fields.ContainsKey("Data"))
				{
					instanceTypeDescriptor.Fields["Data"].Rules.Clear();
				}

			}
		}

		[TestFixture]
		public class Constructor : FieldValidationManagerTestBase
		{
			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: targetObject")]
			public void NullTargetTest()
			{
				new FieldValidationManager(null);
			}
			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
			public void EmptyRuleSetTest()
			{
				new FieldValidationManager("foo", string.Empty);
			}

			[Test]
			public void ConstructorTest()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				Assert.IsFalse(manager.IsValidatingStatic);
				Assert.AreEqual(manager.Target, foo);
			}

			[Test]
			public void ConstructorStaticTest()
			{
				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				FieldValidationManager manager = new FieldValidationManager(handle);
				Assert.AreEqual(manager.TypeDescriptor.RuntimeTypeHandle, handle);
				Assert.AreEqual(manager.TargetHandle, handle);
				Assert.IsTrue(manager.IsValidatingStatic);
			}

		}


		[TestFixture]
		public class ValidateField : FieldValidationManagerTestBase
		{
			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ValidateNullFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.ValidateField(null);
			}

			[Test]
			[ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No fields could be found containing rules.")]
			public void ValidateNoRulesExceptionTest()
			{
				Foo classWithNoRules = new Foo();
				FieldValidationManager manager = new FieldValidationManager(classWithNoRules);
				manager.ValidateAllFields();
			}

			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ValidateNullFieldExceptionStaticTest()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.ValidateField(null);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ValidateEmptyFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.ValidateField(string.Empty);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ValidateEmptyFieldExceptionStaticTest()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.ValidateField(string.Empty);
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'aaa' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ValidateInvalidFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.ValidateField("aaa");
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'dataC' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ValidateFieldWithNoRulesExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.ValidateField("dataC");
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'aaa' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ValidateInvalidFieldExceptionStaticTest()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.ValidateField("aaa");
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'dataC' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ValidateFieldWithNoRulesExceptionStaticTest()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.ValidateField("dataC");
			}

			[Test]
			public void FieldValidationTest()
			{

				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);

				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				Assert.IsTrue(manager.IsValid);
				foo.Data = 6;
				manager.ValidateField("Data");
				Assert.IsFalse(manager.IsValid);
				foo.Data = 2;
				manager.ValidateField("Data");
				Assert.IsTrue(manager.IsValid);
			}

			[Test]
			public void FieldValidationTestRuleSetA()
			{
				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo, "a");
				Assert.IsTrue(manager.IsValid);
				foo.Data = 6;
				manager.ValidateAllFields();
				Assert.IsFalse(manager.IsValid);
				foo.Data = 2;
				manager.ValidateAllFields();
				Assert.IsTrue(manager.IsValid);
			}







			[Test]
			public void FieldValidationStaticTest()
			{
				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(handle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);
				FieldValidationManager manager = new FieldValidationManager(handle);
				Assert.IsTrue(manager.IsValid);
				StaticFoo.Data = 6;
				manager.ValidateField("Data");
				Assert.IsFalse(manager.IsValid);
				StaticFoo.Data = 2;
				manager.ValidateField("Data");
				Assert.IsTrue(manager.IsValid);
			}

		}

		[TestFixture]
		public class GetResultsInErrorForField : FieldValidationManagerTestBase
		{
			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ExceptionNullField()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.GetResultsInErrorForField(null);
			}


			[Test]
			[ExpectedException(typeof(ArgumentOutOfRangeException), ExpectedMessage = "Specified argument was out of the range of valid values.\r\nParameter name: fieldNames")]
			public void ExceptionEmptyListNullField()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.GetResultsInErrorForFields(new string[] { });
			}


			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ExceptionNullFieldStatic()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.GetResultsInErrorForField(null);
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ExceptionFieldEmptyField()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.GetResultsInErrorForField(string.Empty);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ExceptionEmptyFieldExceptionStatic()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.GetResultsInErrorForField(string.Empty);
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'aaa' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ExceptionInvalidFieldInstance()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.GetResultsInErrorForField("aaa");
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'aaa' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ExceptionInvalidFieldStatic()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.GetResultsInErrorForField("aaa");
			}

			[Test]
			public void Simple()
			{
				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);

				RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);
				Foo foo = new Foo();

				FieldValidationManager manager = new FieldValidationManager(foo);
				foo.Data = 6;
				manager.ValidateField("Data");
				IList<ValidationResult> list = manager.GetResultsInErrorForField("Data");
				Assert.AreEqual(1, list.Count);
				foo.Data = 2;
				manager.ValidateField("Data");
				list = manager.GetResultsInErrorForField("Data");
				Assert.AreEqual(0, list.Count);
			}

		}

		[TestFixture]
		public class TryValidateField : FieldValidationManagerTestBase
		{

			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ExceptionNullField()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.TryValidateField(null);
			}


			[Test]
			public void NoRules()
			{
				Foo classWithNoRules = new Foo();
				FieldValidationManager manager = new FieldValidationManager(classWithNoRules);
				manager.TryValidateAllFields();
			}



			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ExceptionFieldStatic()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.TryValidateField(null);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ExceptionEmptyField()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.TryValidateField(string.Empty);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ExceptionEmptyFieldStatic()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.TryValidateField(string.Empty);
			}

			[Test]
			public void InvalidField()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.TryValidateField("aaa");
			}

			[Test]
			public void FieldWithNoRules()
			{
				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				manager.TryValidateField("dataC");
			}

			[Test]
			public void FieldWithNoRulesStatic()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.TryValidateField("dataC");
			}

			[Test]
			public void InvalidFieldStatic()
			{
				FieldValidationManager manager = new FieldValidationManager(typeof(StaticFoo).TypeHandle);
				manager.TryValidateField("aaa");
			}


			[Test]
			public void Simple()
			{
				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);

				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo);
				Assert.IsTrue(manager.IsValid);
				foo.Data = 6;
				manager.TryValidateField("Data");
				Assert.IsFalse(manager.IsValid);
				foo.Data = 2;
				manager.TryValidateField("Data");
				Assert.IsTrue(manager.IsValid);
			}

			[Test]
			public void FieldValidationTestRuleSetA()
			{
				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);

				Foo foo = new Foo();
				FieldValidationManager manager = new FieldValidationManager(foo, "a");
				Assert.IsTrue(manager.IsValid);
				foo.Data = 6;
				manager.TryValidateAllFields();
				Assert.IsFalse(manager.IsValid);
				foo.Data = 2;
				manager.TryValidateAllFields();
				Assert.IsTrue(manager.IsValid);
			}





			[Test]
			public void FieldValidationStaticTest()
			{
				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(handle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);
				FieldValidationManager manager = new FieldValidationManager(handle);
				Assert.IsTrue(manager.IsValid);
				StaticFoo.Data = 6;
				manager.TryValidateField("Data");
				Assert.IsFalse(manager.IsValid);
				StaticFoo.Data = 2;
				manager.TryValidateField("Data");
				Assert.IsTrue(manager.IsValid);
			}

		}


		[TestFixture]
		public class FieldValidationManagerStaticTryValidateTest : FieldValidationManagerTestBase
		{

			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ValidateNullFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager.TryValidateField(foo, null, null, null);
			}

			[Test]
			public void ValidateNoRulesExceptionTest()
			{
				Foo classWithNoRules = new Foo();
				FieldValidationManager.TryValidateAllFields(classWithNoRules, null, null);
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
			public void ValidateEmptyRuleSetExceptionTest()
			{
				Foo classWithNoRules = new Foo();
				FieldValidationManager.TryValidateAllFields(classWithNoRules, string.Empty, null);
			}

			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ValidateNullFieldExceptionStaticTest()
			{
				FieldValidationManager.TryValidateField(typeof(StaticFoo).TypeHandle, null, null, null);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ValidateEmptyFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager.TryValidateField(foo, string.Empty, null, null);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ValidateEmptyFieldExceptionStaticTest()
			{
				FieldValidationManager.TryValidateField(typeof(StaticFoo).TypeHandle, string.Empty, null, null);
			}

			[Test]
			public void ValidateInvalidFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager.TryValidateField(foo, "aaa", null, null);
			}

			[Test]
			public void ValidateInvalidFieldExceptionStaticTest()
			{
				FieldValidationManager.TryValidateField(typeof(StaticFoo).TypeHandle, "aaa", null, null);
			}


			[Test]
			public void FieldValidationTest()
			{

				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);

				RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);

				Foo foo = new Foo();

				Assert.AreEqual(0, FieldValidationManager.TryValidateAllFields(foo, null, null).Count);
				foo.Data = 6;
				Assert.AreEqual(1, FieldValidationManager.TryValidateField(foo, "Data", null, null).Count);
				foo.Data = 2;
				Assert.AreEqual(0, FieldValidationManager.TryValidateField(foo, "Data", null, null).Count);
			}

			[Test]
			public void FieldValidationTestRuleSetA()
			{


				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				TypeDescriptor typeDescriptor = TypeCache.GetType(typeof(Foo).TypeHandle);
				RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);

				Foo foo = new Foo();
				Assert.AreEqual(0, FieldValidationManager.TryValidateAllFields(foo, "a", null).Count);
				foo.Data = 6;
				Assert.AreEqual(1, FieldValidationManager.TryValidateField(foo, "Data", "a", null).Count);
				foo.Data = 2;
				Assert.AreEqual(0, FieldValidationManager.TryValidateField(foo, "Data", "a", null).Count);
			}





			[Test]
			public void FieldValidationStaticTest()
			{
				CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
				RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);

				Assert.AreEqual(0, FieldValidationManager.TryValidateAllFields(handle, null, null).Count);
				StaticFoo.Data = 6;
				Assert.AreEqual(1, FieldValidationManager.TryValidateField(handle, "Data", null, null).Count);
				StaticFoo.Data = 2;
				Assert.AreEqual(0, FieldValidationManager.TryValidateField(handle, "Data", null, null).Count);
			}

			[Test]
			public void ValidateFieldWithNoRulesExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager.TryValidateField(foo, "DataC", null, null);
			}
			[Test]
			public void ValidateFieldWithNoRulesExceptionStaticTest()
			{

				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				FieldValidationManager.TryValidateField(handle, "DataC", null, null);
			}

		}


		//[TestFixture]
		//public class FieldValidationManagerStaticTryThrowExceptionTest : FieldValidationManagerTestBase
		//{

		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
		//    public void InstanceInvalidDataTest()
		//    {
		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        Foo foo = new Foo();
		//        FieldValidationManager.TryThrowFieldException(foo, 6, "Data", null, null);
		//    }


		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
		//    public void StaticInvalidDataTest()
		//    {
		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        FieldValidationManager.TryThrowFieldException(handle, 6, "Data", null, null);
		//    }

		//    [Test]
		//    public void InstanceValidDataTest()
		//    {
		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        Foo foo = new Foo();
		//        FieldValidationManager.TryThrowFieldException(foo, 3, "Data", null, null);
		//    }

		//    [Test]
		//    public void InstanceNoRuleTest()
		//    {
		//        Foo foo = new Foo();
		//        FieldValidationManager.TryThrowFieldException(foo, 3, "Data", null, null);
		//    }
		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
		//    public void InstanceEmptyRuleSetTest()
		//    {

		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        Foo foo = new Foo();
		//        FieldValidationManager.TryThrowFieldException(foo, 3, "Data", string.Empty, null);
		//    }


		//    [Test]
		//    public void StaticValidDataTest()
		//    {
		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        FieldValidationManager.TryThrowFieldException(handle, 3, "Data", null, null);
		//    }

		//    [Test]
		//    public void StaticNoRuleTest()
		//    {
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        FieldValidationManager.TryThrowFieldException(handle, 3, "Data", null, null);
		//    }

		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
		//    public void StaticEmptyRuleSetTest()
		//    {

		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);
		//        FieldValidationManager.TryThrowFieldException(handle, 3, "Data", string.Empty, null);
		//    }


		//    [Test]
		//    [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "")]
		//    public void StaticNullFieldNameDataTest()
		//    {
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        FieldValidationManager.TryThrowFieldException(handle, 3, null, null, null);
		//    }


		//    [Test]
		//    [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "")]
		//    public void InstanceNullFieldNameDataTest()
		//    {
		//        Foo foo = new Foo();
		//        FieldValidationManager.TryThrowFieldException(foo, 3, null, null, null);
		//    }

		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty\r\nParameter name: fieldName")]
		//    public void InstanceEmptyFieldNameDataTest()
		//    {
		//        Foo foo = new Foo();

		//        FieldValidationManager.TryThrowFieldException(foo, 3, string.Empty, null, null);
		//    }


		//    [Test]
		//    [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "")]
		//    public void InstanceNullTargetObjectNameDataTest()
		//    {
		//        FieldValidationManager.TryThrowFieldException(null, 3, "Data", null, null);
		//    }
		//}
		//[TestFixture]
		//public class FieldValidationManagerStaticThrowExceptionTest : FieldValidationManagerTestBase
		//{

		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
		//    public void InstanceInvalidDataTest()
		//    {
		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        Foo foo = new Foo();
		//        FieldValidationManager.ThrowFieldException(foo, 6, "Data", null, null);
		//    }


		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
		//    public void StaticInvalidDataTest()
		//    {
		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        FieldValidationManager.ThrowFieldException(handle, 6, "Data", null, null);
		//    }

		//    [Test]
		//    public void InstanceValidDataTest()
		//    {
		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        Foo foo = new Foo();
		//        FieldValidationManager.ThrowFieldException(foo, 3, "Data", null, null);
		//    }

		//    [Test]
		//    [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No fields could be found containing rules.")]
		//    public void InstanceFieldRuleTest()
		//    {
		//        Foo foo = new Foo();
		//        FieldValidationManager.ThrowFieldException(foo, 3, "Data", null, null);
		//    }

		//    [Test]
		//    [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No fields could be found containing rules.")]
		//    public void InstanceNoRuleTest()
		//    {
		//    RuntimeTypeHandle handle = typeof(Foo).TypeHandle;
		//    TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//    typeDescriptor.GetOrCreateFieldDescriptor("Data");

		//        Foo foo = new Foo();
		//        FieldValidationManager.ThrowFieldException(foo, 3, "Data", null, null);
		//    }


		//    [Test]
		//    public void StaticValidDataTest()
		//    {
		//        CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
		//        rules.Add(compareIntRule);

		//        FieldValidationManager.ThrowFieldException(handle, 3, "Data", null, null);
		//    }

		//    [Test]
		//    [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No fields could be found containing rules.")]
		//    public void StaticNoRuleTest()
		//    {
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
		//        typeDescriptor.GetOrCreateFieldDescriptor("Data");
		//        FieldValidationManager.ThrowFieldException(handle, 3, "Data", null, null);
		//    }

		//    [Test]
		//    [ExpectedException(typeof(InvalidOperationException), ExpectedMessage = "No fields could be found containing rules.")]
		//    public void StaticNoFieldTest()
		//    {
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        FieldValidationManager.ThrowFieldException(handle, 3, "Data", null, null);
		//    }

		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
		//    public void StaticEmptyRuleSetTest()
		//    {
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        FieldValidationManager.ThrowFieldException(handle, 3, "Data", string.Empty, null);
		//    }


		//    [Test]
		//    [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "")]
		//    public void StaticNullFieldNameDataTest()
		//    {
		//        RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
		//        FieldValidationManager.ThrowFieldException(handle, 3, null, null, null);
		//    }


		//    [Test]
		//    [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "")]
		//    public void InstanceNullFieldNameDataTest()
		//    {
		//        Foo foo = new Foo();
		//        FieldValidationManager.ThrowFieldException(foo, 3, null, null, null);
		//    }
		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "")]
		//    public void InstanceEmptyRuleSetDataTest()
		//    {
		//        Foo foo = new Foo();
		//        FieldValidationManager.ThrowFieldException(foo, 3, "Data", string.Empty, null);
		//    }

		//    [Test]
		//    [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty\r\nParameter name: fieldName")]
		//    public void InstanceEmptyFieldNameDataTest()
		//    {
		//        Foo foo = new Foo();

		//        FieldValidationManager.ThrowFieldException(foo, 3, string.Empty, null, null);
		//    }


		//    [Test]
		//    [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "")]
		//    public void InstanceNullTargetObjectNameDataTest()
		//    {
		//        FieldValidationManager.ThrowFieldException(null, 3, "Data", null, null);
		//    }
		//}


		[TestFixture]
		public class FieldValidationManagerStaticValidateTest : FieldValidationManagerTestBase
		{

			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ValidateNullFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager.ValidateField(foo, null, null, null);
			}

			[Test]
			[ExpectedException(typeof(InvalidOperationException))]
			public void ValidateNoRulesExceptionTest()
			{
				Foo classWithNoRules = new Foo();
				FieldValidationManager.ValidateAllFields(classWithNoRules, null, null);
			}
			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
			public void ValidateEmptyRuleSetExceptionTest()
			{
				CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				TypeDescriptor typeDescriptor = TypeCache.GetType(handle);
				RuleCollection rules = typeDescriptor.GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);
				Foo foo = new Foo();
				FieldValidationManager.ValidateAllFields(foo, string.Empty, null);
			}

			[Test]
			[ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: fieldName")]
			public void ValidateNullFieldExceptionStaticTest()
			{
				FieldValidationManager.ValidateField(typeof(StaticFoo).TypeHandle, null, null, null);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ValidateEmptyFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager.ValidateField(foo, string.Empty, null, null);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: fieldName")]
			public void ValidateEmptyFieldExceptionStaticTest()
			{
				FieldValidationManager.ValidateField(typeof(StaticFoo).TypeHandle, string.Empty, null, null);
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'aaa' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ValidateInvalidFieldExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager.ValidateField(foo, "aaa", null, null);
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'aaa' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ValidateInvalidFieldExceptionStaticTest()
			{
				FieldValidationManager.ValidateField(typeof(StaticFoo).TypeHandle, "aaa", null, null);
			}


			[Test]
			public void FieldValidationTest()
			{

				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);

				Foo foo = new Foo();

				Assert.AreEqual(0, FieldValidationManager.ValidateAllFields(foo, null, null).Count);
				foo.Data = 6;
				Assert.AreEqual(1, FieldValidationManager.ValidateField(foo, "Data", null, null).Count);
				foo.Data = 2;
				Assert.AreEqual(0, FieldValidationManager.ValidateField(foo, "Data", null, null).Count);
			}

			[Test]
			public void FieldValidationTestRuleSetA()
			{

				CompareRule<int> compareIntRule = new CompareRule<int>(null, "a", false, 5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(typeof(Foo).TypeHandle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);

				Foo foo = new Foo();
				Assert.AreEqual(0, FieldValidationManager.ValidateAllFields(foo, "a", null).Count);
				foo.Data = 6;
				Assert.AreEqual(1, FieldValidationManager.ValidateField(foo, "Data", "a", null).Count);
				foo.Data = 2;
				Assert.AreEqual(0, FieldValidationManager.ValidateField(foo, "Data", "a", null).Count);
			}


			[Test]
			public void FieldValidationStaticTest()
			{
				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				CompareRule<int> compareIntRule = new CompareRule<int>(5, CompareOperator.LessThan);
				RuleCollection rules = TypeCache.GetType(handle).GetOrCreateFieldDescriptor("Data").Rules;
				rules.Add(compareIntRule);
				Assert.AreEqual(0, FieldValidationManager.ValidateAllFields(handle, null, null).Count);
				StaticFoo.Data = 6;
				Assert.AreEqual(1, FieldValidationManager.ValidateField(handle, "Data", null, null).Count);
				StaticFoo.Data = 2;
				Assert.AreEqual(0, FieldValidationManager.ValidateField(handle, "Data", null, null).Count);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'DataC' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ValidateFieldWithNoRulesExceptionTest()
			{
				Foo foo = new Foo();
				FieldValidationManager.ValidateField(foo, "DataC", null, null);
			}


			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "A field named 'DataC' could not be found containing rules.\r\nParameter name: fieldName")]
			public void ValidateFieldWithNoRulesExceptionStaticTest()
			{

				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				FieldValidationManager.ValidateField(handle, "DataC", null, null);
			}

			[Test]
			[ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: ruleSet")]
			public void ValidateFieldWithEmptyRuleSetExceptionStaticTest()
			{

				RuntimeTypeHandle handle = typeof(StaticFoo).TypeHandle;
				FieldValidationManager.ValidateField(handle, "DataC", string.Empty, null);
			}

		}
	}
}