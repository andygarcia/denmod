using System;
using System.Reflection;
using NUnit.Framework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests.Reflection
{

    [TestFixture]
    public class DescriptorsTest
    {
        private static int myStaticProperty;
        private int myInstanceProperty;


        [Test]
        public void InstanceProperty()
        {
            RuntimeTypeHandle runtimeTypeHandle = typeof(DescriptorsTest).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
            Assert.AreEqual(2, typeDescriptor.Properties.Count);
            Assert.AreEqual(runtimeTypeHandle, typeDescriptor.RuntimeTypeHandle);

            string propertyName = "MyInstanceProperty";
            PropertyDescriptor propertyDescriptor = typeDescriptor.Properties[propertyName];

            DescriptorsTest descriptorsTest = new DescriptorsTest();
            descriptorsTest.MyInstanceProperty = 10;
            object value = propertyDescriptor.GetValue(descriptorsTest);

            Assert.AreEqual(10, value);

            Assert.AreEqual(propertyName, propertyDescriptor.Name);
            Assert.IsFalse(propertyDescriptor.IsStatic);
            Assert.AreEqual(1, propertyDescriptor.Rules.Count);
            Assert.AreEqual(propertyDescriptor, propertyDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(typeDescriptor.Properties.TypeDescriptor, typeDescriptor);
            foreach (Rule rule in propertyDescriptor.Rules)
            {
                Assert.AreEqual(propertyDescriptor, rule.InfoDescriptor);
            }
        }


        [Test]
        public void StaticProperty()
        {
            RuntimeTypeHandle runtimeTypeHandle = typeof(DescriptorsTest).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
            Assert.AreEqual(2, typeDescriptor.Properties.Count);
            Assert.AreEqual(runtimeTypeHandle, typeDescriptor.RuntimeTypeHandle);

            string propertyName = "MyStaticProperty";
            PropertyDescriptor propertyDescriptor = typeDescriptor.Properties[propertyName];
            DescriptorsTest.MyStaticProperty = 10;
            object value = propertyDescriptor.GetValue(null);

            Assert.AreEqual(10, value);

            Assert.AreEqual(propertyName, propertyDescriptor.Name);
            Assert.IsTrue(propertyDescriptor.IsStatic);
            Assert.AreEqual(1, propertyDescriptor.Rules.Count);
            Assert.AreEqual(propertyDescriptor, propertyDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(typeDescriptor.Properties.TypeDescriptor, typeDescriptor);

            foreach (Rule rule in propertyDescriptor.Rules)
            {
                Assert.AreEqual(propertyDescriptor, rule.InfoDescriptor);
            }
        }


        [Test]
        public void InstanceMethod()
        {
            ConstructorInfo constructorInfo = typeof(MethodDescriptor).GetConstructor(BindingFlags.NonPublic | BindingFlags.Instance, null, new Type[] { typeof(RuntimeMethodHandle) }, null);
            string methodName = "MyInstanceMethod";
            RuntimeMethodHandle handle = typeof(DescriptorsTest).GetMethod(methodName).MethodHandle;
            MethodDescriptor methodDescriptor = (MethodDescriptor)constructorInfo.Invoke(new object[] { handle });
            Assert.AreEqual(1, methodDescriptor.Parameters.Count);
            Assert.AreEqual(methodName, methodDescriptor.Name);
            Assert.IsFalse(methodDescriptor.IsStatic);
            Assert.AreEqual(handle, methodDescriptor.RuntimeMethodHandle);

            string parameterName = "param1";
            ParameterDescriptor parameterDescriptor = methodDescriptor.Parameters[parameterName];
            Assert.AreEqual(parameterName, parameterDescriptor.Name);
            Assert.AreEqual(methodDescriptor, parameterDescriptor.Method);
            Assert.AreEqual(0, parameterDescriptor.Position);
            Assert.AreEqual(1, parameterDescriptor.Rules.Count);
            Assert.AreEqual(parameterDescriptor, parameterDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(methodDescriptor.Parameters.MethodDescriptor, methodDescriptor);

            foreach (Rule rule in parameterDescriptor.Rules)
            {
                Assert.AreEqual(parameterDescriptor, rule.InfoDescriptor);
            }
        }


        [Test]
        public void StaticMethod()
        {
            ConstructorInfo constructorInfo = typeof(MethodDescriptor).GetConstructor(BindingFlags.NonPublic | BindingFlags.Instance, null, new Type[] { typeof(RuntimeMethodHandle) }, null);
            string methodName = "MyStaticMethod";
            RuntimeMethodHandle handle = typeof(DescriptorsTest).GetMethod(methodName).MethodHandle;
            MethodDescriptor methodDescriptor = (MethodDescriptor)constructorInfo.Invoke(new object[] { handle });
            Assert.AreEqual(1, methodDescriptor.Parameters.Count);
            Assert.AreEqual(methodName, methodDescriptor.Name);
            Assert.IsTrue(methodDescriptor.IsStatic);
            Assert.AreEqual(handle, methodDescriptor.RuntimeMethodHandle);

            string parameterName = "param1";
            ParameterDescriptor parameterDescriptor = methodDescriptor.Parameters[parameterName];
            Assert.AreEqual(parameterName, parameterDescriptor.Name);
            Assert.AreEqual(methodDescriptor, parameterDescriptor.Method);
            Assert.AreEqual(0, parameterDescriptor.Position);
            Assert.AreEqual(1, parameterDescriptor.Rules.Count);
            Assert.AreEqual(parameterDescriptor, parameterDescriptor.Rules.InfoDescriptor);


            Assert.AreEqual(methodDescriptor.Parameters.MethodDescriptor, methodDescriptor);
            foreach (Rule rule in parameterDescriptor.Rules)
            {
                Assert.AreEqual(parameterDescriptor, rule.InfoDescriptor);
            }
        }


        public void MyInstanceMethod([RequiredIntRule]int param1)
        {

        }


        [RequiredIntRule]
        protected int MyInstanceProperty
        {
            get
            {
                return myInstanceProperty;
            }
            set
            {
                myInstanceProperty = value;
            }
        }


        [RequiredIntRule]
        public static int MyStaticProperty
        {
            get
            {
                return myStaticProperty;
            }
            set
            {
                myStaticProperty = value;
            }
        }


        public static void MyStaticMethod([RequiredIntRule]int param1)
        {

        }
    }
}