using System;
using NUnit.Framework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests.Reflection
{

    [TestFixture]
    public class FieldDescriptorTest
    {
        [RequiredIntRule]
        private static int myStaticField;
        [RequiredIntRule]
        private int myInstanceField;


        [Test]
        public void InstanceField()
        {
            RuntimeTypeHandle runtimeTypeHandle = typeof(FieldDescriptorTest).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
            Assert.AreEqual(2, typeDescriptor.Fields.Count);
            Assert.AreEqual(runtimeTypeHandle, typeDescriptor.RuntimeTypeHandle);

            string fieldName = "myInstanceField";
            FieldDescriptor fieldDescriptor = typeDescriptor.Fields[fieldName];

            FieldDescriptorTest descriptorsTest = new FieldDescriptorTest();
            descriptorsTest.myInstanceField = 10;
            object value = fieldDescriptor.GetValue(descriptorsTest);

            Assert.AreEqual(10, value);

            Assert.AreEqual(fieldName, fieldDescriptor.Name);
            Assert.IsFalse(fieldDescriptor.IsStatic);
            Assert.AreEqual(1, fieldDescriptor.Rules.Count);
            Assert.AreEqual(fieldDescriptor, fieldDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(typeDescriptor.Fields.TypeDescriptor, typeDescriptor);
            foreach (Rule rule in fieldDescriptor.Rules)
            {
                Assert.AreEqual(fieldDescriptor, rule.InfoDescriptor);
            }
        }


        [Test]
        public void StaticParameter()
        {
            RuntimeTypeHandle runtimeTypeHandle = typeof(FieldDescriptorTest).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
            Assert.AreEqual(2, typeDescriptor.Fields.Count);
            Assert.AreEqual(runtimeTypeHandle, typeDescriptor.RuntimeTypeHandle);

            string fieldName = "myStaticField";
            FieldDescriptor fieldDescriptor = typeDescriptor.Fields[fieldName];
            myStaticField = 10;
            object value = fieldDescriptor.GetValue(null);

            Assert.AreEqual(10, value);

            Assert.AreEqual(fieldName, fieldDescriptor.Name);
            Assert.IsTrue(fieldDescriptor.IsStatic);
            Assert.AreEqual(1, fieldDescriptor.Rules.Count);
            Assert.AreEqual(fieldDescriptor, fieldDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(typeDescriptor.Fields.TypeDescriptor, typeDescriptor);

            foreach (Rule rule in fieldDescriptor.Rules)
            {
                Assert.AreEqual(fieldDescriptor, rule.InfoDescriptor);
            }
        }





    }
}