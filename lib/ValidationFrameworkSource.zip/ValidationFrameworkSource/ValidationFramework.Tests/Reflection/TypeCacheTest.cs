using System;
using System.Collections.Generic;
using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{

    [TestFixture]
    public class TypeCacheTest
    {
        public class GenericFoo<T>
        {

            [RequiredObjectRule]
            public T Data
            {
                get;
                set;
            }

        }
        public class Person
        {
            [RequiredStringRule]
            [LengthStringRule(5)]
            [LengthStringRule(8)]
            public string Name
            {
                get;
                set;
            }

        }

        public class Car
        {

            //Assume for the purposes of this sample that cars can have between 2 and 5 doors.
            public int NumberOfDoors
            {
                get;
                set;
            }
        }


        [Test]
        public void NoDuplicateTest()
        {

            TypeCache.Clear();
            RuntimeTypeHandle personTypeHandle1 = typeof(Person).TypeHandle;
            RuntimeTypeHandle personTypeHandle2 = typeof(Person).TypeHandle;
            TypeDescriptor typeDescriptor1 = TypeCache.GetType(personTypeHandle1);
            TypeDescriptor typeDescriptor2 = TypeCache.GetType(personTypeHandle2);
            Assert.AreSame(typeDescriptor1, typeDescriptor2);
            TypeCache.Clear();
        }

        [Test]
        public void AddRuleProgrammatically()
        {
            TypeCache.Clear();
            Car car = new Car();

            //Create a PropertyValidationManager for Car
            PropertyValidationManager manager = new PropertyValidationManager(car);

            Assert.IsTrue(manager.IsValid);

            Type carType = typeof(Car);

            RangeRule<int> rangeRule = new RangeRule<int>(null, null, false, 2, 5, true, true);

            //create a PropertyDescriptor for NumberOfDoors and add a RangeRule to it.  
            TypeDescriptor typeDescriptor = TypeCache.GetType(carType.TypeHandle);
            PropertyDescriptor propertyDescriptor = typeDescriptor.GetOrCreatePropertyDescriptor("NumberOfDoors");
            propertyDescriptor.Rules.Add(rangeRule);

            // 0 is an invalid NumberOfDoors 
            manager.ValidateAllProperties();
            Assert.IsFalse(manager.IsValid);

            // 0 is an invalid NumberOfDoors 
            car.NumberOfDoors = 1;
            manager.ValidateAllProperties();
            Assert.IsFalse(manager.IsValid);

            // 0 is an invalid NumberOfDoors 
            car.NumberOfDoors = 2;
            manager.ValidateAllProperties();
            Assert.IsTrue(manager.IsValid);


            // 6 is an invalid NumberOfDoors 
            car.NumberOfDoors = 6;
            manager.ValidateAllProperties();
            Assert.IsFalse(manager.IsValid);

            typeDescriptor.RemovePropertyDescriptor(propertyDescriptor);


            // 6 is now a valid NumberOfDoors because the validation rule has been removed.
            //Since there are no rules will have to use TryValidate
            manager.TryValidateAllProperties();
            Assert.IsTrue(manager.IsValid);
            TypeCache.Clear();
        }


        [Test]
        public void GetRulesForProperty()
        {
            IList<LengthStringRule> list = TypeCache.GetRulesForProperty<LengthStringRule>("Name", typeof(Person).TypeHandle);
            Assert.AreEqual(2, list.Count);
            list = TypeCache.GetRulesForProperty<LengthStringRule, Person>("Name");
            Assert.AreEqual(2, list.Count);
        }


        [Test]
        public void GetRulesForPropertyGeneric()
        {
            RuntimeTypeHandle handle = typeof(GenericFoo<int>).TypeHandle;
            IList<RequiredRule<int>> list = TypeCache.GetRulesForProperty<RequiredRule<int>>("Data", handle);
            Assert.AreEqual(1, list.Count);
        }


        [Test]
        [ExpectedException(typeof(ArgumentException), ExpectedMessage = "String cannot be empty.\r\nParameter name: propertyName")]
        public void GetRulesForPropertyArgumentException()
        {
            IList<LengthStringRule> list = TypeCache.GetRulesForProperty<LengthStringRule>("", typeof(Person).TypeHandle);
        }


        [Test]
        [ExpectedException(typeof(ArgumentNullException), ExpectedMessage = "Value cannot be null.\r\nParameter name: propertyName")]
        public void GetRulesForPropertyArgumentNullException()
        {
            IList<LengthStringRule> list = TypeCache.GetRulesForProperty<LengthStringRule>(null, typeof(Person).TypeHandle);
        }

    }
}