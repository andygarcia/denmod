using System;
using System.Collections.Generic;
using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{
    public class Bike
    {
        public static readonly RuntimeMethodHandle ChangeWheelsMethodHandle = typeof(Bike).GetMethod("ChangeWheels").MethodHandle;

        //Assume for the purposes of this sample that a bike can have between 1 and 2 wheels changed at a time.
        public IList<ValidationResult> ChangeWheels(int numberOfWheels)
        {
            return ParameterValidationManager.TryValidate(this, ChangeWheelsMethodHandle, numberOfWheels);
        }
    }

    [TestFixture]
    public class MethodCacheTest
    {

        [Test]
        public void NoDuplicateTest()
        {

            MethodCache.Clear();
            RuntimeMethodHandle changeWheelsMethodHandle1 = typeof(Bike).GetMethod("ChangeWheels").MethodHandle;
            RuntimeMethodHandle changeWheelsMethodHandle2 = typeof(Bike).GetMethod("ChangeWheels").MethodHandle;
            MethodDescriptor methodDescriptor1 = MethodCache.GetMethod(changeWheelsMethodHandle1);
            MethodDescriptor methodDescriptor2 = MethodCache.GetMethod(changeWheelsMethodHandle2);
            Assert.AreSame(methodDescriptor1, methodDescriptor2);
        }


        [Test]
        public void AddRuleProgrammatically()
        {
            MethodCache.Clear();
            IList<ValidationResult> list;
            Bike bike = new Bike();
            // 0 is valid numberOfWheels because there are no validation rules yet.
            list = bike.ChangeWheels(0);
            Assert.AreEqual(0, list.Count);

            RangeRule<int> rangeRule = new RangeRule<int>(null, null, false, 1, 2, true, true);

            MethodDescriptor methodDescriptor = MethodCache.GetMethod(Bike.ChangeWheelsMethodHandle);
            ParameterDescriptor numberOfWheelsParameterDescriptor = methodDescriptor.Parameters["numberOfWheels"];
            numberOfWheelsParameterDescriptor.Rules.Add(rangeRule);


            // 0 is an invalid numberOfWheels 
            list = bike.ChangeWheels(0);
            Assert.IsNotNull(list[0]);

            // 1 and 2 are a valid numberOfWheels 
            list = bike.ChangeWheels(1);
            Assert.AreEqual(0, list.Count);
            list = bike.ChangeWheels(2);
            Assert.AreEqual(0, list.Count);

            // 3 is an invalid numberOfWheels 
            list = bike.ChangeWheels(3);
            Assert.IsNotNull(list[0]);


            numberOfWheelsParameterDescriptor.Rules.Clear();

            // 0 is valid numberOfWheels because the validation rule has been removed.
            list = bike.ChangeWheels(0);
            Assert.AreEqual(0, list.Count);
        }
    }
}