using System;
using System.Reflection;
using NUnit.Framework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests.Reflection
{

    [TestFixture]
  public class ParameterDescriptorTest
    {


        [Test]
        public void InstanceMethod()
        {
            ConstructorInfo constructorInfo = typeof(MethodDescriptor).GetConstructor(BindingFlags.NonPublic | BindingFlags.Instance, null, new Type[] { typeof(RuntimeMethodHandle) }, null);
            string methodName = "MyInstanceMethod";
            RuntimeMethodHandle handle = typeof(ParameterDescriptorTest).GetMethod(methodName).MethodHandle;
            MethodDescriptor methodDescriptor = (MethodDescriptor)constructorInfo.Invoke(new object[] { handle });
            Assert.AreEqual(1, methodDescriptor.Parameters.Count);
            Assert.AreEqual(methodName, methodDescriptor.Name);
            Assert.IsFalse(methodDescriptor.IsStatic);
            Assert.AreEqual(handle, methodDescriptor.RuntimeMethodHandle);

            string parameterName = "param1";
            ParameterDescriptor parameterDescriptor = methodDescriptor.Parameters[parameterName];
            Assert.AreEqual(parameterName, parameterDescriptor.Name);
            Assert.AreEqual(methodDescriptor, parameterDescriptor.Method);
            Assert.AreEqual(0, parameterDescriptor.Position);
            Assert.AreEqual(1, parameterDescriptor.Rules.Count);
            Assert.AreEqual(parameterDescriptor, parameterDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(methodDescriptor.Parameters.MethodDescriptor, methodDescriptor);

            foreach (Rule rule in parameterDescriptor.Rules)
            {
                Assert.AreEqual(parameterDescriptor, rule.InfoDescriptor);
            }
        }


        [Test]
        public void StaticMethod()
        {
            ConstructorInfo constructorInfo = typeof(MethodDescriptor).GetConstructor(BindingFlags.NonPublic | BindingFlags.Instance, null, new Type[] { typeof(RuntimeMethodHandle) }, null);
            string methodName = "MyStaticMethod";
            RuntimeMethodHandle handle = typeof(ParameterDescriptorTest).GetMethod(methodName).MethodHandle;
            MethodDescriptor methodDescriptor = (MethodDescriptor)constructorInfo.Invoke(new object[] { handle });
            Assert.AreEqual(1, methodDescriptor.Parameters.Count);
            Assert.AreEqual(methodName, methodDescriptor.Name);
            Assert.IsTrue(methodDescriptor.IsStatic);
            Assert.AreEqual(handle, methodDescriptor.RuntimeMethodHandle);

            string parameterName = "param1";
            ParameterDescriptor parameterDescriptor = methodDescriptor.Parameters[parameterName];
            Assert.AreEqual(parameterName, parameterDescriptor.Name);
            Assert.AreEqual(methodDescriptor, parameterDescriptor.Method);
            Assert.AreEqual(0, parameterDescriptor.Position);
            Assert.AreEqual(1, parameterDescriptor.Rules.Count);
            Assert.AreEqual(parameterDescriptor, parameterDescriptor.Rules.InfoDescriptor);


            Assert.AreEqual(methodDescriptor.Parameters.MethodDescriptor, methodDescriptor);
            foreach (Rule rule in parameterDescriptor.Rules)
            {
                Assert.AreEqual(parameterDescriptor, rule.InfoDescriptor);
            }
        }


        public void MyInstanceMethod([RequiredIntRule]int param1)
        {

        }



        public static void MyStaticMethod([RequiredIntRule]int param1)
        {

        }
    }
}