using System;
using NUnit.Framework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests.Reflection
{

    [TestFixture]
    public class PropertyDescriptorTest
    {
    	private int myPrivateGetProperty;
    	private int myPrivateSetProperty;


    	[Test]
        public void InstanceProperty()
        {
          RuntimeTypeHandle runtimeTypeHandle = typeof(PropertyDescriptorTest).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties.Count);
            Assert.AreEqual(runtimeTypeHandle, typeDescriptor.RuntimeTypeHandle);

            string propertyName = "MyInstanceProperty";
            PropertyDescriptor propertyDescriptor = typeDescriptor.Properties[propertyName];

            PropertyDescriptorTest descriptorsTest = new PropertyDescriptorTest();
            descriptorsTest.MyInstanceProperty = 10;
            object value = propertyDescriptor.GetValue(descriptorsTest);

            Assert.AreEqual(10, value);

            Assert.AreEqual(propertyName, propertyDescriptor.Name);
            Assert.IsFalse(propertyDescriptor.IsStatic);
            Assert.AreEqual(1, propertyDescriptor.Rules.Count);
            Assert.AreEqual(propertyDescriptor, propertyDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(typeDescriptor.Properties.TypeDescriptor, typeDescriptor);
            foreach (Rule rule in propertyDescriptor.Rules)
            {
                Assert.AreEqual(propertyDescriptor, rule.InfoDescriptor);
            }
        }
        [Test]
        public void PrivateGetProperty()
        {
          RuntimeTypeHandle runtimeTypeHandle = typeof(PropertyDescriptorTest).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties.Count);
            Assert.AreEqual(runtimeTypeHandle, typeDescriptor.RuntimeTypeHandle);

			string propertyName = "MyPrivateGetProperty";
            PropertyDescriptor propertyDescriptor = typeDescriptor.Properties[propertyName];

            PropertyDescriptorTest descriptorsTest = new PropertyDescriptorTest();
            descriptorsTest.MyPrivateGetProperty = 10;
            object value = propertyDescriptor.GetValue(descriptorsTest);

            Assert.AreEqual(10, value);

            Assert.AreEqual(propertyName, propertyDescriptor.Name);
            Assert.IsFalse(propertyDescriptor.IsStatic);
            Assert.AreEqual(1, propertyDescriptor.Rules.Count);
            Assert.AreEqual(propertyDescriptor, propertyDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(typeDescriptor.Properties.TypeDescriptor, typeDescriptor);
            foreach (Rule rule in propertyDescriptor.Rules)
            {
                Assert.AreEqual(propertyDescriptor, rule.InfoDescriptor);
            }
        }
        [Test]
        public void PrivateSetProperty()
        {
          RuntimeTypeHandle runtimeTypeHandle = typeof(PropertyDescriptorTest).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties.Count);
            Assert.AreEqual(runtimeTypeHandle, typeDescriptor.RuntimeTypeHandle);

			string propertyName = "MyPrivateSetProperty";
            PropertyDescriptor propertyDescriptor = typeDescriptor.Properties[propertyName];

            PropertyDescriptorTest descriptorsTest = new PropertyDescriptorTest();
            descriptorsTest.MyPrivateSetProperty = 10;
            object value = propertyDescriptor.GetValue(descriptorsTest);

            Assert.AreEqual(10, value);

            Assert.AreEqual(propertyName, propertyDescriptor.Name);
            Assert.IsFalse(propertyDescriptor.IsStatic);
            Assert.AreEqual(1, propertyDescriptor.Rules.Count);
            Assert.AreEqual(propertyDescriptor, propertyDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(typeDescriptor.Properties.TypeDescriptor, typeDescriptor);
            foreach (Rule rule in propertyDescriptor.Rules)
            {
                Assert.AreEqual(propertyDescriptor, rule.InfoDescriptor);
            }
        }


        [Test]
        public void StaticProperty()
        {
          RuntimeTypeHandle runtimeTypeHandle = typeof(PropertyDescriptorTest).TypeHandle;
            TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
            Assert.AreEqual(4, typeDescriptor.Properties.Count);
            Assert.AreEqual(runtimeTypeHandle, typeDescriptor.RuntimeTypeHandle);

            string propertyName = "MyStaticProperty";
            PropertyDescriptor propertyDescriptor = typeDescriptor.Properties[propertyName];
            MyStaticProperty = 10;
            object value = propertyDescriptor.GetValue(null);

            Assert.AreEqual(10, value);

            Assert.AreEqual(propertyName, propertyDescriptor.Name);
            Assert.IsTrue(propertyDescriptor.IsStatic);
            Assert.AreEqual(1, propertyDescriptor.Rules.Count);
            Assert.AreEqual(propertyDescriptor, propertyDescriptor.Rules.InfoDescriptor);

            Assert.AreEqual(typeDescriptor.Properties.TypeDescriptor, typeDescriptor);

            foreach (Rule rule in propertyDescriptor.Rules)
            {
                Assert.AreEqual(propertyDescriptor, rule.InfoDescriptor);
            }
        }


       


        [RequiredIntRule]
        protected int MyInstanceProperty
        {
        	get;
        	set;
        }



        [RequiredIntRule]
		public int MyPrivateGetProperty
        {
            set
            {
            	myPrivateGetProperty = value;
            }
			private get
			{
				return myPrivateGetProperty;
			}
        }



        [RequiredIntRule]
		public int MyPrivateSetProperty
        {
            private set
            {
            	myPrivateSetProperty = value;
            }
			get
			{
				return myPrivateSetProperty;
			}
        }


        [RequiredIntRule]
        public static int MyStaticProperty
        {
        	get;
        	set;
        }


    }
}