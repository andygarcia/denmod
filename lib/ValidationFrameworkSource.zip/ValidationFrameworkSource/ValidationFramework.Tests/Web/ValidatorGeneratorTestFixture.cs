
using System;
using System.Web.UI.WebControls;
using NUnit.Framework;
using ValidationFramework.Web;

namespace ValidationFramework.Tests
{
    [TestFixture]
    public class ValidatorGeneratorTestFixture
    {
        [Test]
        public void ValidatorGeneratorTest()
        {
            Panel panel = new Panel();

            TextBox myFooStringControl = new TextBox();
            myFooStringControl.ID = "myFooStringControl";
            panel.Controls.Add(myFooStringControl);

            TextBox myFooDateTimeControl = new TextBox();
            myFooDateTimeControl.ID = "myFooDateTimeControl";
            panel.Controls.Add(myFooDateTimeControl);

            TextBox myFooDecimalControl = new TextBox();
            myFooDecimalControl.ID = "myFooDecimalControl";
            panel.Controls.Add(myFooDecimalControl);

            PropertyValidatorGenerator validatorGenerator = new PropertyValidatorGenerator();
            validatorGenerator.AddAssociation(myFooStringControl, "FooString");
            validatorGenerator.AddAssociation(myFooDecimalControl, "FooDecimal");
            validatorGenerator.AddAssociation(myFooDateTimeControl, "FooDateTime");
            validatorGenerator.TypeToValidate = typeof(ValidatorGeneratorTestObject).TypeHandle;
            validatorGenerator.GenerateValidators();
            Assert.AreEqual(29, panel.Controls.Count);
        }
    }

    public class ValidatorGeneratorTestObject
    {


        [RequiredStringRule]
        [LengthStringRule(5)]
        [RangeStringRule("aaaaa", "ccccc")]
        [RegexRule("bbbbb", ErrorMessage = "fooString must be bbbbb")]
        [CompareStringRule("bbbbb", CompareOperator.Equal)]
        public string FooString
        {
            get;
            set;
        }

        [RequiredDecimalRule]
        [RequiredDecimalRule(InitialValue = 2)]
        [CompareDecimalRule(123, CompareOperator.Equal)]
        public decimal FooDecimal
        {
            get;
            set;
        }

        [CompareDateTimeRule("10 Jan 1999", CompareOperator.Equal)]
        [RequiredDateTimeRule]
        public DateTime FooDateTime
        {
            get;
            set;
        }

    }
}