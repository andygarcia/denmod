using System;
using System.Reflection;

namespace ValidationFramework.Tests
{
    public static class ReflectionUtilities
    {
        public static void SetField<TFieldOwner>(object target, object value, string fieldName)
        {
            Type type = typeof(TFieldOwner);
            FieldInfo info = type.GetField(fieldName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            info.SetValue(target, value);
        }

        public static void SetProperty<TFieldOwner>(object target, object value, string propertyName)
        {
            Type type = typeof(TFieldOwner);
            PropertyInfo info = type.GetProperty(propertyName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            try
            {
                info.SetValue(target, value, null);
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }
        public static object CallMethod<TMethodOwner>(object target, string method, params object[] values)
        {
            Type[] types = new Type[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                types[i] = values[i].GetType();
            }

            Type type = typeof(TMethodOwner);
            MethodInfo info = type.GetMethod(method, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, types, null);
            return info.Invoke(target, values);
        }
    }
}