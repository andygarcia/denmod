using System;
using System.Collections.Generic;
using System.Reflection;
using NUnit.Framework;
using ValidationFramework.Reflection;

namespace ValidationFramework.Tests
{
    /// <summary>
    ///This is a test class for ValidationFramework.RuleDescriber and is intended to contain all ValidationFramework.RuleDescriber Unit Tests
    ///</summary>
    [TestFixture]
    public class RuleDescriberTests
    {

        public class TestClass : ValidatableBase
        {
            public TestClass()
                : base(true)
            {
            }


            [RegexRule(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage = "Invalid email format.")]
            public string Email
            {
                get;
                set;
            }


            public void DoSomething([RegexRule(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage = "Invalid email format.")] string emailAddress)
            {
                
            }
        }


        [Test]
        public void GetPropertyRulesTest()
        {
            Assembly assembly = GetType().Assembly; 

            IList<TypeDescriptor> typeDescriptors = RuleDescriber.GetPropertyRules(assembly);
            TypeDescriptor testClassTypeDescriptor = null;
            RuntimeTypeHandle testClassHandle = typeof(TestClass).TypeHandle;
            foreach (TypeDescriptor typeDescriptor in typeDescriptors)
            {
                if (typeDescriptor.RuntimeTypeHandle.Equals(testClassHandle))
                {
                    testClassTypeDescriptor = typeDescriptor;
                    break;
                }
            }
            RuleCollection propertyRules = testClassTypeDescriptor.Properties["Email"].Rules;

            Assert.AreEqual(1, propertyRules.Count);
        }


        [Test]
        public void GetMethodRulesTest()
        {
            Assembly assembly = GetType().Assembly; 

            IList<MethodDescriptor> methodDescriptors = RuleDescriber.GetMethodRules(assembly);
            MethodDescriptor doSomethingMethodDescriptor = null;
            RuntimeMethodHandle doSomethingHandle = typeof(TestClass).GetMethod("DoSomething").MethodHandle;
            foreach (MethodDescriptor methodDescriptor in methodDescriptors)
            {
                if (methodDescriptor.RuntimeMethodHandle.Equals(doSomethingHandle))
                {
                    doSomethingMethodDescriptor = methodDescriptor;
                    break;
                }
            }
            RuleCollection propertyRules = doSomethingMethodDescriptor.Parameters["emailAddress"].Rules;

            Assert.AreEqual(1, propertyRules.Count);
        }

    }


}