using System;

namespace ValidationFramework
{
    /// <summary>
    /// The results of any <see cref="ValidationFramework.Rule.Validate"/> operation.
    /// </summary>
    /// <remarks>An instance is only created if the <see cref="ValidationFramework.Rule.Validate"/> operation fails.</remarks>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Reflection\GetReflectionInfoFromValidationResult.cs" title="This example shows how to get a Type or a MethodBase from a ValidationResult." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Reflection\GetReflectionInfoFromValidationResult.vb"  title="This example shows how to get a Type or a MethodBase from a ValidationResult." lang="vbnet"/>
    /// </example>
    public class ValidationResult
    {
        #region Fields

        private readonly string errorMessage;
        private readonly Rule rule;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationResult"/> class.
        /// </summary>
        /// <remarks>
        /// null is an invalid value for both <paramref name="rule"/> and <paramref name="errorMessage"/>. 
        /// Due to performance concerns <see cref="ArgumentNullException"/> will no be thrown.
        /// So just don't pass in null or an empty string.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> that this <see cref="ValidationResult"/> has been generated from.</param>
        /// <param name="errorMessage">The error message.</param>
        public ValidationResult(Rule rule, string errorMessage)
        {
            //Dont guard these. the performance hit is not worth the minor help it gives developers. 
            this.rule = rule;
            this.errorMessage = errorMessage;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the error message for the <see cref="ValidationResult"/>.
        /// </summary>
        public string ErrorMessage
        {
            get
            {
                return errorMessage;
            }
        }


        /// <summary>
        /// Gets the <see cref="Rule"/> that this <see cref="ValidationResult"/> has been generated from.
        /// </summary>
        /// <seealso cref="ValidationFramework.Rule.Validate"/>
        public Rule Rule
        {
            get
            {
                return rule;
            }
        }

        #endregion
    }
}