using System;

namespace ValidationFramework
{
    /// <summary>
    /// Base class for all <see cref="Attribute"/>s that define <see cref="Rule"/>s.
    /// </summary>
    /// <seealso cref="IRuleAttribute"/>
    /// <seealso cref="IParameterRuleAttribute"/>
    /// <seealso cref="IPropertyRuleAttribute"/>
    /// <example>
    /// <b>Extending the validation framework</b><br/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\RequiredCharacterRule.cs" title="Implementing a custom rule by inheriting from Rule" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\RequiredCharacterRule.vb" title="Implementing a custom rule by inheriting from Rule" lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\RequiredCharacterRuleAttribute.cs" title="Creating a IRuleAttribute for that Rule" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\RequiredCharacterRuleAttribute.vb" title="Creating a IRuleAttribute for that Rule" lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\RequiredCharacterRuleConfigReader.cs" title="Creating IRuleConfigReader for that Rule." lang="cs"/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\RequiredCharacterRuleConfigReaderUsage.cs" title="Using the custom ConfigReader." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\RequiredCharacterRuleConfigReader.vb" title="Creating IRuleConfigReader for that Rule." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\RequiredCharacterRuleConfigReaderUsage.vb" title="Using the custom ConfigReader." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\ClientRegularExpressionWebValidator.cs" title="A custom RegularExpressionValidator that only validates on the client side." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\ClientRegularExpressionWebValidator.vb" title="A custom RegularExpressionValidator that only validates on the client side." lang="vbnet"/>
    /// </example>
    [Serializable]
    public abstract class RuleAttribute : Attribute, IRuleAttribute
    {
   

        #region Properties



        /// <summary>
        /// Gets or sets A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.
        /// </summary>
        /// <seealso cref="Rule.RuleSet"/>
        public string RuleSet
        {
            get;
            set;
        }


        /// <seealso cref="Rule.UseErrorMessageProvider"/>
        public bool UseErrorMessageProvider
        {
            get;
            set;
        }

        #endregion

        #region IRuleAttribute Members

        /// <summary>
        /// Gets or sets the error message for <see cref="IRuleAttribute"/>.
        /// </summary>
        /// <seealso cref="Rule.ErrorMessage"/>
        public string ErrorMessage
        {
            get;
            set;
        }

        #endregion
    }
}