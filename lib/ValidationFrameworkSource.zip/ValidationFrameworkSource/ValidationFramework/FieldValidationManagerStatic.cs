using System;
using System.Collections.Generic;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ValidationFramework
{

    [Serializable]
    public partial class FieldValidationManager
    {
        #region Methods


        #region TryThrowException

        /// <summary>
        /// Performs validation when a field is being set.
        /// </summary>
        /// <remarks>
        /// <para>Should be called before the field (representing this field) is set.</para>
        /// <para>This should be used if you are not certain if the field will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ThrowFieldException(object,object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="fieldName">Field to validate. Case sensitive.</param>
        /// <param name="fieldValue">The value of the field being validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void TryThrowFieldException(object target, object fieldValue, string fieldName, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
            FieldDescriptor fieldDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            if (typeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
            {
              InternalThrowException(fieldDescriptor, fieldValue, ruleSet, context, false, target);
            }
        }


        /// <summary>
        /// Performs validation when a field is being set.
        /// </summary>
        /// <remarks>
        /// <para>Should be called before the field (representing this field) is set.</para> 
        /// <para>This should be used if you expect the field to have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryThrowFieldException(object,object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="fieldName">Field to validate. Case sensitive.</param>
        /// <param name="fieldValue">The value of the field being validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void ThrowFieldException(object target, object fieldValue, string fieldName, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
            FieldDescriptor fieldDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            if (typeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
            {
              InternalThrowException(fieldDescriptor, fieldValue, ruleSet, context, true, target);
            }
            else
            {
                throw new ArgumentException(string.Format("A field named '{0}' could not be found containing rules.", fieldName), "fieldName");
            }
        }


        /// <summary>
        /// Performs validation when a field is being set.
        /// </summary>
        /// <remarks>
        /// <para>Should be called before the field (representing this field) is set.</para>
        /// <para>This should be used if you are not certain if field will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ThrowFieldException(RuntimeTypeHandle,object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="fieldName">Field to validate. Case sensitive.</param>
        /// <param name="fieldValue">The value of the field being validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void TryThrowFieldException(RuntimeTypeHandle targetHandle, object fieldValue, string fieldName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            FieldDescriptor fieldDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            if (typeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
            {
              InternalThrowException(fieldDescriptor, fieldValue, ruleSet, context, false, null);
            }
        }


        /// <summary>
        /// Performs validation when a field is being set.
        /// </summary>
        /// <remarks>
        /// <para>Should be called before the field (representing this field) is set.</para>
        /// <para>This should be used if you expect the field to have <see cref="Rule"/>s applied to it. 
        ///  This is usually the case if you are using attributes to apply <see cref="Rule"/>s.
        ///  If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryThrowFieldException(RuntimeTypeHandle,object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="fieldName">Field to validate. Case sensitive.</param>
        /// <param name="fieldValue">The value of the field being validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void ThrowFieldException(RuntimeTypeHandle targetHandle, object fieldValue, string fieldName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            FieldDescriptor fieldDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            if (typeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
            {
              InternalThrowException(fieldDescriptor, fieldValue, ruleSet, context, true, null);
            }
            else
            {
                throw new ArgumentException(string.Format("A field named '{0}' could not be found containing rules.", fieldName), "fieldName");
            }
        }

        #endregion


        #region TryValidate

        /// <summary>
        /// Performs validation for a specific field.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you can not be certain of the field will have <see cref="Rule"/>s applied to it. 
        ///  This is usually the case if you are using code to apply <see cref="Rule"/>s.
        ///  If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ValidateField(object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="fieldName">Field to validate. Case sensitive.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
        public static IList<ValidationResult> TryValidateField(object target, string fieldName, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
            FieldDescriptor fieldDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            if (typeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
            {
                object fieldValue = fieldDescriptor.GetValue(target);
                return InternalValidateInfoDescriptor(fieldDescriptor, fieldValue, ruleSet, context, false, target);
            }
            else
            {
                return new List<ValidationResult>();
            }
        }


        /// <summary>
        /// Performs validation for a specific field.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain if field will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ValidateField(RuntimeTypeHandle,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="fieldName">Field to validate. Case sensitive.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
        public static IList<ValidationResult> TryValidateField(RuntimeTypeHandle targetHandle, string fieldName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            FieldDescriptor fieldDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            if (typeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
            {
                object fieldValue = fieldDescriptor.GetValue(null);
                return InternalValidateInfoDescriptor(fieldDescriptor, fieldValue, ruleSet, context, false, null);
            }
            else
            {
                return new List<ValidationResult>();
            }
        }


        /// <summary>
        /// Performs validation for a specific field.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain if field will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ValidateAllFields(object,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="FieldDescriptor"/>, that have the <see cref="Rule.RuleSet"/> equal to <paramref name="ruleSet"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
        public static IList<ValidationResult> TryValidateAllFields(object target, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            return InternalValidateAllInfoDescriptors(typeDescriptor, target, ruleSet, context, false);
        }


        /// <summary>
        /// Performs validation for a specific field.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain if field will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ValidateAllFields(RuntimeTypeHandle,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
        public static IList<ValidationResult> TryValidateAllFields(RuntimeTypeHandle targetHandle, string ruleSet, object context)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            return InternalValidateAllInfoDescriptors(typeDescriptor, null, ruleSet, context, false);
        }

        #endregion


        #region Validate

        /// <summary>
        /// Performs validation for an object.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are certain all fields will have <see cref="Rule"/>s applied. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidateAllFields(object,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
        public static IList<ValidationResult> ValidateAllFields(object target, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            return InternalValidateAllInfoDescriptors(typeDescriptor, target, ruleSet, context, true);
        }


        /// <summary>
        /// Performs validation for a specific field.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are certain all fields will have <see cref="Rule"/>s applied.
        ///  This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidateAllFields(RuntimeTypeHandle,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="fieldName">Field to validate. Case sensitive.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="FieldDescriptor"/>,for <paramref name="fieldName"/>, that have the <see cref="Rule.RuleSet"/> equal to <see cref="MemberValidationManager.RuleSet"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
        public static IList<ValidationResult> ValidateField(RuntimeTypeHandle targetHandle, string fieldName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            FieldDescriptor fieldDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);

          if (typeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
          {
            object fieldValue = fieldDescriptor.GetValue(null);
            return InternalValidateInfoDescriptor(fieldDescriptor, fieldValue, ruleSet, context, true, null);
          }
          else
          {
            throw new ArgumentException(string.Format("A field named '{0}' could not be found containing rules.", fieldName), "fieldName");
          }
        }


        /// <summary>
        /// Performs validation for a specific field.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain if fields will have <see cref="Rule"/>s applied.
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidateAllFields(RuntimeTypeHandle,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="FieldDescriptor"/>, that have the <see cref="Rule.RuleSet"/> equal to <paramref name="ruleSet"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
        public static IList<ValidationResult> ValidateAllFields(RuntimeTypeHandle targetHandle, string ruleSet, object context)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            return InternalValidateAllInfoDescriptors(typeDescriptor, null, ruleSet, context, true);
        }


        /// <summary>
        /// Performs validation for a specific field.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain the field will have <see cref="Rule"/>s applied. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidateField(object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="fieldName">Field to validate. Case sensitive.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="FieldDescriptor"/>,for <paramref name="fieldName"/>, that have the <see cref="Rule.RuleSet"/> equal to <see cref="MemberValidationManager.RuleSet"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
        public static IList<ValidationResult> ValidateField(object target, string fieldName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            FieldDescriptor fieldDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            if (typeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
            {
                object fieldValue = fieldDescriptor.GetValue(target);
                return InternalValidateInfoDescriptor(fieldDescriptor, fieldValue, ruleSet, context, true, target);
            }
            else
            {
                throw new ArgumentException(string.Format("A field named '{0}' could not be found containing rules.", fieldName), "fieldName");
            }
        }

        #endregion

        internal static IList<ValidationResult> InternalValidateAllInfoDescriptors(TypeDescriptor typeDescriptor, object target, string ruleSet, object context, bool throwException)
        {
            bool ruleFound = false;
            List<ValidationResult> validationResults = new List<ValidationResult>();
            foreach (FieldDescriptor fieldDescriptor in typeDescriptor.Fields)
            {
                object fieldValue = fieldDescriptor.GetValue(target);
                if (CheckValid(fieldDescriptor, fieldValue, ruleSet, context, target, validationResults))
                {
                    ruleFound = true;
                }
            }

            ThrowNoRules(ruleSet, ruleFound, throwException);
            return validationResults;
        }
        #endregion
    }
}