using System;
using System.Collections.Generic;

namespace ValidationFramework
{
    /// <summary>
    /// Base class that provides minimal validation logic.
    /// </summary>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\BusinessBaseClasses\ValidatableBaseSample.cs"  title="The following code example shows how to inherit from ValidatableBase." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\BusinessBaseClasses\ValidatableBaseSample.vb" title="The following code example shows how to inherit from ValidatableBase." lang="vbnet"/>
    /// </example>
    /// <seealso cref="NotifyValidatableBase"/>
    /// <seealso cref="DataErrorInfoValidatableBase"/>
    /// <seealso cref="IValidatable"/>
    [Serializable]
    public abstract class ValidatableBase : IValidatable
    {
        #region Fields

        private readonly bool validateOnConstruction;

        [NonSerialized]
        private PropertyValidationManager propertyValidationManager;
        private readonly bool ignoreNoRules;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableBase"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        protected ValidatableBase(bool validateOnConstruction)
            : this(validateOnConstruction, null)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableBase"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        protected ValidatableBase(bool validateOnConstruction, string ruleSet)
            : this(validateOnConstruction, ruleSet, null)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableBase"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        protected ValidatableBase(bool validateOnConstruction, string ruleSet, object context)
        {
            this.validateOnConstruction = validateOnConstruction;
            propertyValidationManager = new PropertyValidationManager(this, ruleSet, context);
            if (validateOnConstruction)
            {
                propertyValidationManager.ValidateAllProperties();
            }
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableBase"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
     /// <param name="ignoreNoRules">Set to <c>true</c> to ignore the fact that no <see cref="Rule"/>s exists on the current type.</param>
        protected ValidatableBase(bool validateOnConstruction, string ruleSet, object context, bool ignoreNoRules)
        {
            this.validateOnConstruction = validateOnConstruction;
            this.ignoreNoRules = ignoreNoRules;
            propertyValidationManager = new PropertyValidationManager(this, ruleSet, context);
            if (validateOnConstruction)
            {
                propertyValidationManager.ValidateAllProperties();
            }
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableBase"/> class.
        /// </summary>
        /// <remarks><see cref="ValidatableBase.ValidateOnConstruction"/> will default to <see langword="false"/>.</remarks>
        protected ValidatableBase()
            : this(false)
        {
        }

        #endregion


        #region Properties

        /// <summary>
        /// An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. The default is null.
        /// </summary>
        public object Context
        {
            get
            {
                return propertyValidationManager.Context;
            }
        }

        /// <summary>
        /// Gets the the rule set to validate.
        /// </summary>
        /// <remarks>Will be a null to validate all <see cref="Rule"/>s.</remarks>
        public string RuleSet
        {
            get
            {
                return propertyValidationManager.RuleSet;
            }
        }


        /// <summary>
        /// Gets a <see cref="IList{T}"/> containing all <see cref="ValidationResult"/> in error.
        /// </summary>
        public virtual IList<ValidationResult> ValidatorResultsInError
        {
            get
            {
                return propertyValidationManager.ValidatorResultsInError;
            }
        }


        /// <summary>
        /// Gets the <see cref="ValidationFramework.PropertyValidationManager"/>.
        /// </summary>
        /// <remarks>
        /// This is exposed as 'public' for advanced usage scenarios. In general it should only be used by inherited classes.
        /// </remarks>
        public PropertyValidationManager PropertyValidationManager
        {
            get
            {
                return propertyValidationManager;
            }
        }


        /// <summary>
        /// Gets a <see langword="bool"/> indicating if the <see cref="ValidatableBase"/> has been validated on construction.
        /// </summary>
        public bool ValidateOnConstruction
        {
            get
            {
                return validateOnConstruction;
            }
        }


        /// <summary>
        /// Gets a value indicating that, if no <see cref="Rule"/>s exists, it will be ignored.
        /// </summary>
        public bool IgnoreNoRules
        {
            get
            {
                return ignoreNoRules;
            }
        }


        /// <summary>
        /// Gets a <see lanword="bool"/> indicating if the current state is valid.
        /// </summary>
        /// <remarks>
        /// Base behavior is to validate all properties and return boolean value.
        /// Sub-class can override this if, for example, they are validating on the fly.
        /// </remarks>
        public virtual bool IsValid
        {
            get
            {
                if (ignoreNoRules)
                {
                    propertyValidationManager.TryValidateAllProperties();
                }
                else
                {
                    propertyValidationManager.ValidateAllProperties();
                }
                return propertyValidationManager.IsValid;
            }
        }


        /// <summary>
        /// Gets a <see see="IList{T}"/> of <see langword="string"/>s that contain all the error messages.
        /// </summary>
        public virtual IList<string> ErrorMessages
        {
            get
            {
                return ResultFormatter.GetErrorMessages(propertyValidationManager.ValidatorResultsInError);
            }
        }

        #endregion
    }
}