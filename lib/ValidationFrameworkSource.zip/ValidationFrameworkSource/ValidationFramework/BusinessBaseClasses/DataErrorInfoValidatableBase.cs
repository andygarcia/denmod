using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ValidationFramework
{
    /// <summary>
    /// Provides base class that developer can inherit from to provide <see cref="INotifyPropertyChanged"/> and <see cref="IDataErrorInfo"/> functionality for all sub-classes.
    /// </summary>
    /// <remarks>This ideal for windows forms applications to get immediate validation feedback on dataBound controls.</remarks>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\BusinessBaseClasses\DataErrorInfoValidatableBaseSample.cs" title="The following example shows how to inherit from DataErrorInfoValidatableBase." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\BusinessBaseClasses\DataErrorInfoValidatableBaseSample.vb" title="The following example shows how to inherit from DataErrorInfoValidatableBase." lang="vbnet"/>
    /// </example>
    /// <seealso cref="NotifyValidatableBase"/>
    /// <seealso cref="IValidatable"/>
    /// <seealso cref="ValidatableBase"/>
    [Serializable]
    public abstract class DataErrorInfoValidatableBase : ValidatableBase, IDataErrorInfo
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="DataErrorInfoValidatableBase"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        protected DataErrorInfoValidatableBase(bool validateOnConstruction)
            : base(validateOnConstruction, null)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="DataErrorInfoValidatableBase"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        protected DataErrorInfoValidatableBase(bool validateOnConstruction, string ruleSet)
            : base(validateOnConstruction, ruleSet)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="DataErrorInfoValidatableBase"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        protected DataErrorInfoValidatableBase(bool validateOnConstruction, string ruleSet, object context)
            : base(validateOnConstruction, ruleSet, context)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DataErrorInfoValidatableBase"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <param name="ignoreNoRules">Set to <c>true</c> to ignore the fact that no <see cref="Rule"/>s exists on the current type.</param>
        protected DataErrorInfoValidatableBase(bool validateOnConstruction, string ruleSet, object context, bool ignoreNoRules)
            : base(validateOnConstruction, ruleSet, context, ignoreNoRules)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="DataErrorInfoValidatableBase"/> class.
        /// </summary>
        /// <remarks><see cref="ValidatableBase.ValidateOnConstruction"/> will default to <see langword="false"/>.</remarks>
        protected DataErrorInfoValidatableBase()
            : base(false, null)
        {
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a <see lanword="bool"/> indicating if the current state is valid.
        /// </summary>
        /// <remarks>
        /// Since properties are validated when set, calling this property does not validate all properties.
        /// </remarks>
        public override bool IsValid
        {
            get
            {
                return PropertyValidationManager.IsValid;
            }
        }

        /// <summary>
        /// Gets an error message indicating what is wrong with this object. 
        /// </summary>
        /// <remarks>The uses <see cref="ResultFormatter.GetConcatenatedErrorMessages(ICollection{ValidationResult})"/> to merge the <see cref="ValidationResult.ErrorMessage"/>s of <see cref="ValidatableBase.ValidatorResultsInError"/>.</remarks>
        public virtual string Error
        {
            get
            {
                return ResultFormatter.GetConcatenatedErrorMessages(ValidatorResultsInError);
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Gets the error message for the property with the given name. 
        /// </summary>
        /// <param name="columnName">The name of the property whose error message to get.  The parameter is case sensitive.</param>
        /// <returns>The error message for the property. The default is an <see cref="string.Empty"/>.</returns>
        public virtual string this[string columnName]
        {
            get
            {
                IList<ValidationResult> property;
                if (PropertyValidationManager.TryGetResultsInErrorForProperty(columnName, out property))
                {
                    StringBuilder errors = new StringBuilder();
                    for (int propertyIndex = 0; propertyIndex < property.Count; propertyIndex++)
                    {
                        ValidationResult validationResult = property[propertyIndex];
                        errors.AppendLine(validationResult.ErrorMessage);
                    }

                    return errors.ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }


        /// <summary>
        /// Perform validation for specified property.
        /// </summary>
        /// <param name="propertyName">The name of the property to validate. The parameter is case sensitive.</param>
        protected void ValidateProperty(string propertyName)
        {
            if (IgnoreNoRules)
            {
                PropertyValidationManager.TryValidateProperty(propertyName);
            }
            else
            {
                PropertyValidationManager.ValidateProperty(propertyName);
            }
        }

        #endregion
    }
}