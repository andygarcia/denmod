using System;
using System.Text.RegularExpressions;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="RegexRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="RegexRuleConfigReader"/>
    /// <seealso cref="RegexRule"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\RegexRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\RegexRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class RegexRuleAttribute : RuleAttribute, IPropertyRuleAttribute, IParameterRuleAttribute, IFieldRuleAttribute
    {
        #region Fields

        private readonly string validationExpression;
        private RegexOptions regexOptions = RegexOptions.None;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RegexRuleAttribute"/> class.
        /// </summary>
        /// <param name="validationExpression">The regular expression pattern to match.</param>
        public RegexRuleAttribute(string validationExpression)
        {
            this.validationExpression = validationExpression;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the regular expression pattern to match.  
        /// </summary>
        /// <seealso cref="RegexRule.ValidationExpression"/>
        public string ValidationExpression
        {
            get
            {
                return validationExpression;
            }
        }

        /// <summary>
        /// A bitwise OR combination of <see cref="System.Text.RegularExpressions.RegexOptions"/> enumeration values.
        /// </summary>
        /// <seealso cref="RegexRule.RegexOptions"/>
        public RegexOptions RegexOptions
        {
            get
            {
                return regexOptions;
            }
            set
            {
                regexOptions = value;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }

        #endregion


        private RegexRule CreateRule()
        {
            return new RegexRule(ErrorMessage, RuleSet, UseErrorMessageProvider, validationExpression, regexOptions);
        }

        #endregion
    }
}