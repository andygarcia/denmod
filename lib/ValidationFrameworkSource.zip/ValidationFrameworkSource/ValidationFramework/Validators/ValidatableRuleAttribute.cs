using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="ValidatableRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="ValidatableRuleConfigReader"/>
    /// <seealso cref="ValidatableRule"/>
    ///// <example>
    ///// <code source="Examples\ExampleLibraryCSharp\Validators\ValidatableRuleAttributeSample.cs" lang="cs"/>
    ///// <code source="Examples\ExampleLibraryVB\Validators\ValidatableRuleAttributeSample.vb" lang="vbnet"/>
    ///// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class ValidatableRuleAttribute : RuleAttribute, IPropertyRuleAttribute, IParameterRuleAttribute, IFieldRuleAttribute
    {

        #region Fields

        private  bool useMemberErrorMessages;

        #endregion

        #region Properties


        /// <summary>
        /// Gets or sets a value indicating if <see cref="IValidatable.ErrorMessages"/> should be use as the <see cref="Rule.ErrorMessage"/>.  
        /// </summary>
        public bool UseMemberErrorMessages
        {
            get
            {
                return useMemberErrorMessages;
            }
            set
            {
                useMemberErrorMessages = value;
            }
        }

        #endregion

        #region Methods

        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        /// <exception cref="InvalidOperationException"><see cref="UseMemberErrorMessages"/> is true and <see cref="RuleAttribute.ErrorMessage"/> is not null.</exception>
        public Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        /// <exception cref="InvalidOperationException"><see cref="UseMemberErrorMessages"/> is true and <see cref="RuleAttribute.ErrorMessage"/> is not null.</exception>
        public Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        /// <exception cref="InvalidOperationException"><see cref="UseMemberErrorMessages"/> is true and <see cref="RuleAttribute.ErrorMessage"/> is not null.</exception>
        public Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }

        #endregion


        private ValidatableRule CreateRule()
        {
            if (useMemberErrorMessages)
            {
                if (ErrorMessage == null)
                {
                    return new ValidatableRule(true, RuleSet, UseErrorMessageProvider);
                }
                else
                {
                    throw new InvalidOperationException("Cannot use 'useMemberErrorMessages'");
                }
            }
            else
            {
                return new ValidatableRule(ErrorMessage, RuleSet, UseErrorMessageProvider); 
            }
        }

        #endregion
    }
}