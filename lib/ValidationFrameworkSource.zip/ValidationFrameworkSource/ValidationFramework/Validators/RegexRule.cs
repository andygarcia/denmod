using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;
using ValidationFramework.Web;

namespace ValidationFramework
{
    //public static class StandardRegularExpressions
    //{
    //  //Source from http://regexlib.com/REDetails.aspx?regexp_id=599
    //  public const string EmailAddress = @"^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@(([0-9a-zA-Z])+([-\w]*[0-9a-zA-Z])*\.)+[a-zA-Z]{2,9})$";
    //}
    /// <summary>
    /// Performs a Regular Expression validation.
    /// </summary>
    /// <remarks>If the value being validated is null the rule will evaluate to true.</remarks>
    /// <seealso cref="RegexRuleConfigReader"/>
    /// <seealso cref="RegexRuleAttribute"/>
    [Serializable]
    public class RegexRule : Rule, ISupportWebClientValidation
    {
        #region Fields

        private static readonly RuntimeTypeHandle runtimeTypeHandle = Type.GetTypeHandle(string.Empty);
        private readonly RegexOptions regexOptions;
        private readonly string validationExpression;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RegexRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// <item>
        /// <see cref="RegexOptions"/> to the <see cref="System.Text.RegularExpressions.RegexOptions.None"/>.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="validationExpression">The regular expression pattern to match.</param>
        /// <exception cref="ArgumentNullException"><paramref name="validationExpression"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationExpression"/> is <see cref="string.Empty"/>.</exception>
        public RegexRule(string validationExpression)
            : this(null, null, false, validationExpression, RegexOptions.None)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RegexRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// Sets <see cref="RegexOptions"/> to the <see cref="System.Text.RegularExpressions.RegexOptions.None"/>.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="validationExpression">The regular expression pattern to match.</param>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="validationExpression"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationExpression"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RegexRule(string errorMessage, string validationExpression)
            : this(errorMessage, null, false, validationExpression, RegexOptions.None)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RegexRule"/> class.
        /// </summary>
        /// <param name="validationExpression">The regular expression pattern to match.</param>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="regexOptions">A bitwise OR combination of <see cref="System.Text.RegularExpressions.RegexOptions"/> enumeration values.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentNullException"><paramref name="validationExpression"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationExpression"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentOutOfRangeException"><paramref name="regexOptions"/> is out of the accepted range.</exception>
        public RegexRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, string validationExpression, RegexOptions regexOptions)
            : base(runtimeTypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
            Guard.ArgumentNotNullOrEmptyString(validationExpression, "validationExpression");
            if ((regexOptions < RegexOptions.None) || ((((int)regexOptions) >> 10) != 0))
            {
                throw new ArgumentOutOfRangeException("regexOptions");
            }



            this.validationExpression = validationExpression;
            this.regexOptions = regexOptions;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the regular expression pattern to match.  
        /// </summary>
        public string ValidationExpression
        {
            get
            {
                return validationExpression;
            }
        }

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                return string.Format("The value must match the regular expression '{0}'.", validationExpression);
            }
        }

        ///<summary>
        /// Gets A bitwise OR combination of <see cref="System.Text.RegularExpressions.RegexOptions"/> enumeration values.
        ///</summary>
        public RegexOptions RegexOptions
        {
            get
            {
                return regexOptions;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Get a <see cref="BaseValidator"/> to perform the client side validation.
        /// </summary>
        /// <returns>The <see cref="BaseValidator"/> to perform the client side validation.</returns>
        public IList<BaseValidator> CreateWebClientValidators()
        {
            RegularExpressionWebValidatorEx webValidator = new RegularExpressionWebValidatorEx();
            webValidator.ValidationExpression = validationExpression;
            BaseValidator[] array = new BaseValidator[1];
            array[0] = webValidator;
            return array;
        }


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            bool isValid;
            if (targetMemberValue == null)
            {
                isValid = true;
            }
            else
            {
                string s = (string) targetMemberValue;
                if (s.Length == 0)
                {
                    return null;
                }
                else
                {
                    Match m = Regex.Match(s, validationExpression, regexOptions);
                    isValid = (m.Success && (m.Index == 0) && (m.Length == s.Length));
                }
            }

            if (isValid)
            {
                return null;
            }
            else
            {
                return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
            }
        }


        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            return string.Format("The {0} '{1}' is an invalid format.", descriptorType, tokenizedMemberName);
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            RegexRule regexRule = (RegexRule) rule;
            return regexRule.regexOptions == regexOptions && regexRule.validationExpression == validationExpression;
        }

        #endregion
    }
}