using System;
using System.Reflection;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// For comparing two properties.
    /// </summary>
    /// <seealso cref="ComparePropertyRuleAttribute"/>
    /// <seealso cref="ComparePropertyRuleConfigReader"/>
    [Serializable]
    public class ComparePropertyRule : Rule
    {
        #region Fields

        private const string errorMessageFormat = "The property '{0}' must be '{1}' the property '{2}'.";
        private readonly string propertyToCompare;
        private readonly CompareOperator compareOperator;
        private FastInvokeHandler propertyToCompareHandler;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ComparePropertyRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="operator">The comparison operation to perform.</param>
        /// <param name="propertyToCompare">The name of the property to compare with.</param> 
        /// <exception cref="ArgumentNullException"><paramref name="propertyToCompare"/> is null.</exception>
        public ComparePropertyRule(string propertyToCompare, CompareOperator @operator)
            : this(null, null, false, propertyToCompare, @operator)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ComparePropertyRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="operator">The comparison operation to perform.</param>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="propertyToCompare">The name of the property to compare with.</param> 
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="propertyToCompare"/> is null.</exception>
        public ComparePropertyRule(string errorMessage, string propertyToCompare, CompareOperator @operator)
            : this(errorMessage, null, false, propertyToCompare, @operator)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ComparePropertyRule"/> class.
        /// </summary>
        /// <param name="operator">The comparison operation to perform.</param>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="propertyToCompare">The name of the property to compare with.</param> 
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyToCompare"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="propertyToCompare"/> is null.</exception>
        public ComparePropertyRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, string propertyToCompare, CompareOperator @operator)
            : base(null, errorMessage, ruleSet, useErrorMessageProvider)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyToCompare, "propertyToCompare");
            this.propertyToCompare = propertyToCompare;
            compareOperator = @operator;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the comparison operation to perform. 
        /// </summary>
        public CompareOperator CompareOperator
        {
            get
            {
                return compareOperator;
            }
        }

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                return string.Format("The value must be '{0}' the value of the property '{1}'", EnumUserFriendlyNameConverter.Convert(compareOperator), propertyToCompare);
            }
        }


        /// <summary>
        /// Gets the name of the property to compare with.
        /// </summary>
        public string PropertyToCompare
        {
            get
            {
                return propertyToCompare;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            return
                string.Format(errorMessageFormat, tokenizedMemberName, EnumUserFriendlyNameConverter.Convert(compareOperator),
                              propertyToCompare);
        }


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            if (targetMemberValue != null)
            {
                if (propertyToCompareHandler == null)
                {
                    PropertyInfo propertyInfo = targetObjectValue.GetType().GetProperty(propertyToCompare, TypeDescriptor.PropertyFlags);
                    if (propertyInfo == null)
                    {
                        throw new InvalidOperationException(string.Format("Could not find the property '{0}'", propertyToCompare));
                    }
                    MethodInfo getMethodInfo = propertyInfo.GetGetMethod(true);

                    propertyToCompareHandler = MethodInvokerCreator.GetMethodInvoker(getMethodInfo);
                }
                object propertyToCompareValue = propertyToCompareHandler(targetObjectValue);

                if ((propertyToCompareValue != null) && !CompareValidationHelper.Compare(targetMemberValue, propertyToCompareValue, compareOperator))
                {
                    return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
                }
            }
            return null;
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            ComparePropertyRule comparePropertyRule = (ComparePropertyRule) rule;
            return ((comparePropertyRule.propertyToCompare == propertyToCompare) && (compareOperator == comparePropertyRule.compareOperator));
        }


        /// <summary>
        /// Check that the <see cref="RuntimeTypeHandle"/> is valid.
        /// </summary>
        /// <exception cref="ArgumentException"><paramref name="targetMemberRuntimeTypeHandle"/> is not of a valid type.</exception>
        /// <remarks>
        /// Called after <see cref="InfoDescriptor"/> is set. Should throw <see cref="ArgumentException"/> if <paramref name="targetMemberRuntimeTypeHandle"/> is of the wrong type.
        /// </remarks>
        /// <param name="targetMemberRuntimeTypeHandle">The <see cref="RuntimeTypeHandle"/> that this <see cref="Rule"/> is applied to.</param>
        protected override void CheckType(RuntimeTypeHandle targetMemberRuntimeTypeHandle)
        {
            base.CheckType(targetMemberRuntimeTypeHandle);
            if (InfoDescriptor is ParameterDescriptor)
            {
                throw new InvalidOperationException("ComparePropertyRule cannot be applied to a parameter.");
            }
        }

        #endregion
    }
}