using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;
using ValidationFramework.Web;

namespace ValidationFramework
{
    /// <summary>
    /// Base class for all <see cref="Rule"/>s that performs comparison validation.
    /// </summary>
    /// <seealso cref="CompareRuleConfigReader"/>
    /// <seealso cref="CompareByteRuleAttribute"/>
    /// <seealso cref="CompareDateTimeRuleAttribute"/>
    /// <seealso cref="CompareDecimalRuleAttribute"/>
    /// <seealso cref="CompareDoubleRuleAttribute"/>
    /// <seealso cref="CompareFloatRuleAttribute"/>
    /// <seealso cref="CompareIntRuleAttribute"/>
    /// <seealso cref="CompareLongRuleAttribute"/>
    /// <seealso cref="CompareShortRuleAttribute"/>
    /// <seealso cref="CompareStringRuleAttribute"/>
    [Serializable]
    public class CompareRule<T> : Rule, ISupportWebClientValidation where T : IComparable<T>
    {
        #region Fields

        private const string errorMessageFormat = "The {0} '{1}' must be '{2}' '{3}'.";
        private static readonly RuntimeTypeHandle runtimeTypeHandle = typeof (T).TypeHandle;
        private readonly T valueToCompare;
        private readonly CompareOperator compareOperator;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CompareRule{T}"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="operator">The comparison operation to perform.</param>
        /// <param name="valueToCompare">The value to compare with.</param> 
        /// <exception cref="ArgumentNullException"><paramref name="valueToCompare"/> is null.</exception>
        public CompareRule(T valueToCompare, CompareOperator @operator)
            : this(null, null, false, valueToCompare, @operator)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="CompareRule{T}"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="operator">The comparison operation to perform.</param>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="valueToCompare">The value to compare with.</param> 
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="valueToCompare"/> is null.</exception>
        public CompareRule(string errorMessage, T valueToCompare, CompareOperator @operator)
            : this(errorMessage, null, false, valueToCompare, @operator)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="CompareRule{T}"/> class.
        /// </summary>
        /// <param name="compareOperator">The comparison operation to perform.</param>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="valueToCompare">The value to compare with.</param> 
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="valueToCompare"/> is null.</exception>
        /// <exception cref="ArgumentOutOfRangeException"><paramref name="compareOperator"/> is out of the accepted range.</exception>
        public CompareRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, T valueToCompare, CompareOperator compareOperator)
            : base(runtimeTypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
            Guard.ArgumentNotNull(valueToCompare, "valueToCompare");
            if ((compareOperator < ValidationFramework.CompareOperator.Equal) || (compareOperator > ValidationFramework.CompareOperator.NotEqual))
            {
                throw new ArgumentOutOfRangeException("compareOperator");
            }
            this.valueToCompare = valueToCompare;
            this.compareOperator = compareOperator;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the comparison operation to perform. 
        /// </summary>
        public CompareOperator CompareOperator
        {
            get
            {
                return compareOperator;
            }
        }

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                return
                    string.Format("The value must be '{0}' '{1}'", EnumUserFriendlyNameConverter.Convert(compareOperator),
                                  valueToCompare);
            }
        }


        /// <summary>
        /// Gets the value to compare with.
        /// </summary>
        public T ValueToCompare
        {
            get
            {
                return valueToCompare;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Get a list of <see cref="BaseValidator"/>s to perform the client side validation.
        /// </summary>
        /// <remarks>The <see cref="BaseValidator"/>s returned should only perform client validation.</remarks>
        /// <returns>The<see cref="IList{T}"/> of <see cref="BaseValidator"/>s to perform the client side validation.</returns>
        public IList<BaseValidator> CreateWebClientValidators()
        {
            ValidationDataType? validationDataType = ValidatorCreatorHelper.GetValidationDataType(InfoDescriptor.RuntimeTypeHandle);
            if (validationDataType == null)
            {
                return null;
            }
            else
            {
                CompareWebValidatorEx webValidator = new CompareWebValidatorEx();
                webValidator.Operator = ValidatorCreatorHelper.GetOperator(compareOperator);
                webValidator.Type = validationDataType.Value;
                if (webValidator.Type == ValidationDataType.Date)
                {
                    DateTime initialValueAsDateTime = (DateTime) (object) valueToCompare;
                    if (initialValueAsDateTime.TimeOfDay == TimeSpan.Zero)
                    {
                        webValidator.ValueToCompare = initialValueAsDateTime.ToString("yyyy-MM-dd");
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    webValidator.ValueToCompare = valueToCompare.ToString();
                }
                return new BaseValidator[] {webValidator};
            }
        }


        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            return
                string.Format(errorMessageFormat, descriptorType, tokenizedMemberName, EnumUserFriendlyNameConverter.Convert(compareOperator),
                              valueToCompare);
        }


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            if (targetMemberValue != null)
            {
                if (!CompareValidationHelper.Compare(targetMemberValue, valueToCompare, compareOperator))
                {
                    return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
                }
            }
            return null;
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            CompareRule<T> compareRule = (CompareRule<T>) rule;
            return compareRule.valueToCompare.Equals(valueToCompare) && compareOperator == compareRule.compareOperator;
        }

        #endregion
    }
}