using System;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a comparison operation should be applied to the program element.
    /// </summary>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public abstract class CompareRuleAttribute : RuleAttribute, IPropertyRuleAttribute, IParameterRuleAttribute, IFieldRuleAttribute
    {
        #region Fields

        private readonly CompareOperator compareOperator;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CompareRuleAttribute"/> class.
        /// </summary>
        /// <param name="operator">The comparison operation to perform.</param>
        protected CompareRuleAttribute(CompareOperator @operator)
        {
            compareOperator = @operator;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the comparison operation to perform. 
        /// </summary>
        /// <seealso cref="CompareRule{T}.CompareOperator"/>
        public CompareOperator Operator
        {
            get
            {
                return compareOperator;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreateParameterRule(ParameterDescriptor parameterDescriptor);

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor);

        #endregion

        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreateFieldRule(FieldDescriptor propertyDescriptor);

        #endregion


        #endregion

        #region IFieldRuleAttribute Members

        Rule IFieldRuleAttribute.CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region IRuleAttribute Members

        string IRuleAttribute.ErrorMessage
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        #endregion
    }
}