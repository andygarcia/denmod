using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="CompareRule{T}"/>, that will compare a <see cref="byte"/>, should be applied to the program element.
    /// </summary>
    /// <seealso cref="CompareRule{T}"/>
    /// <seealso cref="CompareRuleConfigReader"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\CompareValidators\CompareByteRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\CompareValidators\CompareByteRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class CompareByteRuleAttribute : CompareRuleAttribute
    {
        #region Fields

        private readonly byte valueToCompare;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CompareByteRuleAttribute"/> class.
        /// </summary>
        /// <param name="operator">The comparison operation to perform.</param>
        /// <param name="valueToCompare">The value to compare with.</param>
        public CompareByteRuleAttribute(byte valueToCompare, CompareOperator @operator)
            : base(@operator)
        {
            this.valueToCompare = valueToCompare;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the value to compare.
        /// </summary>
        /// <seealso cref="CompareRule{T}.ValueToCompare"/>
        public byte ValueToCompare
        {
            get
            {
                return valueToCompare;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public override Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public override Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }
        


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public override Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }


        private CompareRule<byte> CreateRule()
        {
            return new CompareRule<byte>(ErrorMessage, RuleSet, UseErrorMessageProvider, valueToCompare, Operator);
        }

        #endregion
    }
}