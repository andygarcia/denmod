using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="ComparePropertyRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="ComparePropertyRule"/>
    /// <seealso cref="ComparePropertyRuleConfigReader"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\CompareValidators\ComparePropertyRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\CompareValidators\ComparePropertyRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true, Inherited = true)]
    public sealed class ComparePropertyRuleAttribute : CompareRuleAttribute
    {
        #region Fields

        private readonly string propertyToCompare;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CompareByteRuleAttribute"/> class.
        /// </summary>
        /// <param name="operator">The comparison operation to perform.</param>
        /// <param name="propertyToCompare">The property to compare with.</param>
        public ComparePropertyRuleAttribute(string propertyToCompare, CompareOperator @operator)
            : base(@operator)
        {
            this.propertyToCompare = propertyToCompare;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the value to compare.
        /// </summary>
        /// <seealso cref="ComparePropertyRule.PropertyToCompare"/>
        public string PropertyToCompare
        {
            get
            {
                return propertyToCompare;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public override Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public override Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public override Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }


        private ComparePropertyRule CreateRule()
        {
            return new ComparePropertyRule(ErrorMessage, RuleSet, UseErrorMessageProvider, propertyToCompare, Operator);
        }

        #endregion
    }
}