using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="LengthStringRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="LengthStringRule"/>
    /// <seealso cref="LengthStringRuleConfigReader"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\LengthValidators\LengthStringRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\LengthValidators\LengthStringRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class LengthStringRuleAttribute : LengthRuleAttribute
    {
        #region Fields

        private bool trimWhiteSpace = true;

        #endregion


        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LengthStringRuleAttribute"/> class.
        /// </summary>
        /// <param name="maximum">The maximum length allowed.</param>
        public LengthStringRuleAttribute(int maximum)
            : base(maximum)
        {
        }

        #endregion


        #region Methods

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public override Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public override Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public override Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }


        private LengthStringRule CreateRule()
        {
            return new LengthStringRule(ErrorMessage, RuleSet, UseErrorMessageProvider, Minimum, Maximum, trimWhiteSpace);
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets a <see cref="bool"/> to indicate if whitespace should be trimmed from the value being validated.
        /// </summary>
        /// <seealso cref="LengthStringRule.TrimWhiteSpace"/>
        public bool TrimWhiteSpace
        {
            get
            {
                return trimWhiteSpace;
            }
            set
            {
                trimWhiteSpace = value;
            }
        }

        #endregion
    }
}