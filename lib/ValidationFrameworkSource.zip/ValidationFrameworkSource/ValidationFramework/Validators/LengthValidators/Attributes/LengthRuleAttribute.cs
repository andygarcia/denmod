using System;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="LengthRule"/> should be applied to the program element.
    /// </summary>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public abstract class LengthRuleAttribute : RuleAttribute, IPropertyRuleAttribute, IParameterRuleAttribute, IFieldRuleAttribute
    {
        #region Fields

        private readonly int maximum;
        private int minimum = 0;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="LengthRuleAttribute"/> class.
        /// </summary>
        /// <param name="maximum">The maximum length.</param>
        protected LengthRuleAttribute(int maximum)
        {
            this.maximum = maximum;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the maximum length.
        /// </summary>
        /// <seealso cref="LengthRule.Maximum"/>
        public int Maximum
        {
            get
            {
                return maximum;
            }
        }


        /// <summary>
        /// Gets the minimum length.
        /// </summary>
        /// <exception cref="ArgumentException">Value is less than 0.</exception>
        /// <seealso cref="LengthRule.Minimum"/>
        public int Minimum
        {
            get
            {
                return minimum;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Minimum too low.", "value");
                }
                minimum = value;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreateParameterRule(ParameterDescriptor parameterDescriptor);

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor);

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreateFieldRule(FieldDescriptor fieldDescriptor);

        #endregion


        #endregion
    }
}