using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="LengthCollectionRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="LengthCollectionRule"/>
    /// <seealso cref="LengthCollectionRuleConfigReader"/>
    /// <remarks>If <see cref="ExcludeDuplicatesFromCount"/> is true then <see cref="object.GetHashCode"/> is used to discard duplicates from the count. If the collection is null <see langword="true"/> will be returned. To validate for nulls use a <see cref="RequiredObjectRuleAttribute"/>.</remarks>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class LengthCollectionRuleAttribute : LengthRuleAttribute
    {
        #region Fields

        private bool excludeDuplicatesFromCount = false;

        #endregion


        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="LengthCollectionRuleAttribute"/> class.
        /// </summary>
        /// <param name="maximum">The maximum length allowed.</param>
        public LengthCollectionRuleAttribute(int maximum)
            : base(maximum)
        {
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets whether to exclude duplicates when calculating the length.
        /// </summary>
        /// <remarks>Setting this to <see langword="true"/> will decrease the performance of <see cref="Rule.Validate"/></remarks>
        /// <seealso cref="LengthCollectionRule.ExcludeDuplicatesFromCount"/>
        public bool ExcludeDuplicatesFromCount
        {
            get
            {
                return excludeDuplicatesFromCount;
            }
            set
            {
                excludeDuplicatesFromCount = value;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public override Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public override Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public override Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }


        private LengthCollectionRule CreateRule()
        {
            //TOOO: populate the comparer
            //IEqualityComparer equalityComparer;
            //IDictionary<string, string> attributesAsDictionary = RuleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes);
            //equalityComparer = (IEqualityComparer)ReflectionUtilities.GetStaticProperty(attributesAsDictionary["equalityComparerTypeName"], attributesAsDictionary["equalityComparerPropertyName"]);

            return new LengthCollectionRule(ErrorMessage, RuleSet, UseErrorMessageProvider, Minimum, Maximum, excludeDuplicatesFromCount, null);
        }

        #endregion
    }
}