using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Performs a length validation.
    /// </summary>
    /// <seealso cref="LengthCollectionRule"/>
    /// <seealso cref="LengthStringRule"/>
    [Serializable]
    public abstract class LengthRule : Rule
    {
        #region Fields

        private readonly int maximum;
        private readonly int minimum;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="LengthRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="propertyTypeHandle">The <see cref="RuntimeTypeHandle"/> that this <see cref="LengthRule"/> can be applied to. Use <see langword="null"/> to indicate it can be applied to any property type.</param>
        /// <param name="maximum">The maximum length allowed.</param>
        /// <param name="minimum">The minimum length allowed.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is less than 0.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is not greater than or equal to <paramref name="minimum"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        protected LengthRule(RuntimeTypeHandle? propertyTypeHandle, string errorMessage, string ruleSet, bool useErrorMessageProvider, int minimum, int maximum)
            : base(propertyTypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
            if (minimum < 0)
            {
                throw new ArgumentException("Minimum must be greater than 0.", "minimum");
            }
            if (minimum > maximum)
            {
                throw new ArgumentException("Minimum must be less than or equal to Maximum.", "minimum");
            }
            this.minimum = minimum;
            this.maximum = maximum;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the maximum length.
        /// </summary>
        public int Maximum
        {
            get
            {
                return maximum;
            }
        }


        /// <summary>
        /// Gets or sets the minimum length.
        /// </summary>
        public int Minimum
        {
            get
            {
                return minimum;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            LengthRule lengthRule = (LengthRule) rule;
            return lengthRule.maximum == maximum && lengthRule.minimum == minimum;
        }

        #endregion
    }
}