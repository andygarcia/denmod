using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;
using ValidationFramework.Web;

namespace ValidationFramework
{
    /// <summary>
    /// Performs a string length validation.
    /// </summary>
    /// <seealso cref="LengthStringRuleConfigReader"/>
    /// <seealso cref="LengthStringRuleAttribute"/>
    [Serializable]
    public class LengthStringRule : LengthRule, ISupportWebClientValidation
    {
        #region Fields

        private static readonly RuntimeTypeHandle runtimeTypeHandle = Type.GetTypeHandle(string.Empty);
        private readonly bool trimWhiteSpace;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="LengthStringRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// <item>
        /// <see cref="TrimWhiteSpace"/> to true.
        /// </item>
        /// </list>
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is not greater than or equal to <paramref name="minimum"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is less than 0.</exception>
        /// <param name="maximum">The maximum length allowed.</param>
        /// <param name="minimum">The minimum length allowed.</param>
        public LengthStringRule(int minimum, int maximum)
            : this(null, null, false, minimum, maximum, true)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="LengthStringRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="TrimWhiteSpace"/> to true.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="maximum">The maximum length allowed.</param>
        /// <param name="minimum">The minimum length allowed.</param>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is less than 0.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public LengthStringRule(string errorMessage, int minimum, int maximum)
            : this(errorMessage, null, false, minimum, maximum, true)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="LengthStringRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="maximum">The maximum length allowed.</param>
        /// <param name="minimum">The minimum length allowed.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="trimWhiteSpace">A <see cref="bool"/> to indicate if whitespace should be trimmed from the value being validated.</param>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is less than 0.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is not greater than or equal to <paramref name="minimum"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public LengthStringRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, int minimum, int maximum, bool trimWhiteSpace)
            : base(runtimeTypeHandle, errorMessage, ruleSet, useErrorMessageProvider, minimum, maximum)
        {
            this.trimWhiteSpace = trimWhiteSpace;
        }

        #endregion


        #region Methods

        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            if (targetMemberValue != null)
            {
                string valueAsString = (string) targetMemberValue;
                if (trimWhiteSpace)
                {
                    valueAsString = valueAsString.Trim();
                }
                if (!(LengthValidationHelper.IsLengthValid(valueAsString.Length, Minimum, Maximum)))
                {
                    return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
                }
            }
            return null;
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            return (base.IsEquivalent(rule) && ((LengthStringRule) rule).trimWhiteSpace == trimWhiteSpace);
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a <see cref="bool"/> to indicate if whitespace should be trimmed from the value being validated.
        /// </summary>
        public bool TrimWhiteSpace
        {
            get
            {
                return trimWhiteSpace;
            }
        }


        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                if (string.Equals(Minimum, Maximum))
                {
                    return string.Format("The value must be {0} characters in length.", Minimum);
                }
                else
                {
                    return string.Format("The value must be between {0} and {1} characters in length.", Minimum, Maximum);
                }
            }
        }


        /// <summary>
        /// Get a list of <see cref="BaseValidator"/>s to perform the client side validation.
        /// </summary>
        /// <remarks>The <see cref="BaseValidator"/>s returned should only perform client validation.</remarks>
        /// <returns>The<see cref="IList{T}"/> of <see cref="BaseValidator"/>s to perform the client side validation.</returns>
        public IList<BaseValidator> CreateWebClientValidators()
        {
            RegularExpressionWebValidatorEx webValidator = new RegularExpressionWebValidatorEx();
            string format = string.Format("(.|\n|\r){{{0},{1}}}", Minimum, Maximum);
            webValidator.ValidationExpression = format;
            BaseValidator[] list = new BaseValidator[1];
            list[0] = webValidator;
            return list;
        }


        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
          if (string.Equals(Minimum, Maximum))
            {
                return string.Format("The {0} '{1}' must be {2} characters in length.", descriptorType, tokenizedMemberName, Minimum);
            }
            else
            {
                return string.Format("The {0} '{1}' must be between {2} and {3} characters in length.", descriptorType, tokenizedMemberName, Minimum, Maximum);
            }
        }

        #endregion
    }
}