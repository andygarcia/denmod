using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Performs a length validation in <see cref="ICollection"/>s.
    /// </summary>
    /// <remarks>If the value being validated is null the rule will evaluate to true.</remarks>
    /// <remarks>If <see cref="ExcludeDuplicatesFromCount"/> is true then <see cref="object.GetHashCode"/> is used to discard duplicates from the count. If the collection is null <see langword="true"/> will be returned. To validate for nulls use a <see cref="RequiredObjectRuleAttribute"/>.</remarks>
    /// <seealso cref="LengthCollectionRuleConfigReader"/>
    /// <seealso cref="LengthCollectionRuleAttribute"/>
    [Serializable]
    public class LengthCollectionRule : LengthRule
    {
        #region Fields

        private static readonly Type collectionType = typeof (ICollection);
        private static readonly Type genericCollectionType = typeof (ICollection<>);
        private readonly IEqualityComparer comparer;
        private readonly bool excludeDuplicatesFromCount = false;

        #endregion


        #region Constructor

        /// <summary>
        /// Initializes a new, empty instance of the <see cref="EnumerableDuplicateRule"/> class using the specified <see cref="IEqualityComparer"/> object. 
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// <item>
        /// <see cref="Comparer"/> to null.
        /// </item>
        /// <item>
        /// <see cref="ExcludeDuplicatesFromCount"/> to false.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="maximum">The maximum length allowed.</param>
        /// <param name="minimum">The minimum length allowed.</param>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is less than 0.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is not greater than or equal to <paramref name="minimum"/>.</exception>
        public LengthCollectionRule(int minimum, int maximum)
            : this(null, null, false, minimum, maximum, false, null)
        {
        }


        /// <summary>
        /// Initializes a new, empty instance of the <see cref="EnumerableDuplicateRule"/> class using the specified <see cref="IEqualityComparer"/> object. 
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Comparer"/> to null.
        /// </item>
        /// <item>
        /// <see cref="ExcludeDuplicatesFromCount"/> to false.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="maximum">The maximum length allowed.</param>
        /// <param name="minimum">The minimum length allowed.</param>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is less than 0.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is not greater than or equal to <paramref name="minimum"/>.</exception>
        public LengthCollectionRule(string errorMessage, int minimum, int maximum)
            : this(errorMessage, null, false, minimum, maximum, false, null)
        {
        }


        /// <summary>
        /// Initializes a new, empty instance of the <see cref="EnumerableDuplicateRule"/> class using the specified <see cref="IEqualityComparer"/> object. 
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="maximum">The maximum length allowed.</param>
        /// <param name="minimum">The minimum length allowed.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="excludeDuplicatesFromCount">Indicates whether to exclude duplicate items from the count. Setting this to <see langword="true"/> will decrease the performance of <see cref="Validate"/></param>
        /// <param name="comparer">The <see cref="IEqualityComparer"/> object that defines how to compare objects for equality.
        /// -or- 
        /// a null reference to use the default hash code provider and the default comparer. The default comparer is each item's implementation of Object.Equals. 
        /// </param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is less than 0.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is not greater than or equal to <paramref name="minimum"/>.</exception>
        public LengthCollectionRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, int minimum, int maximum, bool excludeDuplicatesFromCount, IEqualityComparer comparer)
            : base(null, errorMessage, ruleSet, useErrorMessageProvider, minimum, maximum)
        {
            this.excludeDuplicatesFromCount = excludeDuplicatesFromCount;
            this.comparer = comparer;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                if (Minimum == Maximum)
                {
                    return string.Format("The collection must contain {0}.", Maximum);
                }
                else
                {
                    return string.Format("The collection must contain between {0} and {1} items.", Minimum, Maximum);
                }
            }
        }

        /// <summary>
        /// Gets whether to exclude duplicates when calculating the length.
        /// </summary>
        public bool ExcludeDuplicatesFromCount
        {
            get
            {
                return excludeDuplicatesFromCount;
            }
        }


        /// <summary>
        /// Gets the <see cref="IEqualityComparer"/> for the <see cref="LengthCollectionRule"/>.
        /// </summary>
        public IEqualityComparer Comparer
        {
            get
            {
                return comparer;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Check that the <see cref="RuntimeTypeHandle"/> is valid.
        /// </summary>
        /// <remarks>
        /// Called after <see cref="InfoDescriptor"/> is set. Should throw <see cref="ArgumentException"/> if <paramref name="targetMemberRuntimeTypeHandle"/> is of the wrong type.
        /// </remarks>
        /// <param name="targetMemberRuntimeTypeHandle">The <see cref="RuntimeTypeHandle"/> that this <see cref="Rule"/> is applied to.</param>
        protected override void CheckType(RuntimeTypeHandle targetMemberRuntimeTypeHandle)
        {
            Type typeToCheck = Type.GetTypeFromHandle(targetMemberRuntimeTypeHandle);
            bool isGenericICollection = ReflectionUtilities.IsSubclassOf(typeToCheck, genericCollectionType);
            bool isICollection = ReflectionUtilities.IsSubclassOf(typeToCheck, collectionType);
            if (!isICollection && !isGenericICollection)
            {
                throw new ArgumentException("Property must be a ICollection<T> or ICollection to be used for the LengthCollectionRule.");
            }
        }


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            if (targetMemberValue != null)
            {
                int count;
                if (excludeDuplicatesFromCount)
                {
                    count = GetCountExcludeDuplicates(targetMemberValue);
                }
                else
                {
                    count = GetCount(targetMemberValue);
                }
                if (!LengthValidationHelper.IsLengthValid(count, Minimum, Maximum))
                {
                    return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
                }
            }

            return null;
        }


        private static int GetCount(object targetMemberValue)
        {
            //You cant do this till you have a not null value.
            ICollection iCollection = targetMemberValue as ICollection;
            if (iCollection == null)
            {
                //Dont cache countPropertyInfo as most classes that implement ICollection<> also implement ICollection so it should usually not get here
                PropertyInfo countPropertyInfo = targetMemberValue.GetType().GetProperty("Count");
                return (int) countPropertyInfo.GetValue(targetMemberValue, null);
            }
            else
            {
                return iCollection.Count;
            }
        }


        private int GetCountExcludeDuplicates(object targetMemberValue)
        {
            IEnumerable enumerable = (IEnumerable) targetMemberValue;
            Hashtable hashTable = new Hashtable(Comparer);
            foreach (object item in enumerable)
            {
                if (!hashTable.ContainsKey(item))
                {
                    hashTable.Add(item, null);
                }
            }
            return hashTable.Count;
        }


        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            if (Minimum == Maximum)
            {
                return string.Format("The number of items in {0} '{1}' must be {2}.", descriptorType, tokenizedMemberName, Minimum);
            }
            else
            {
                return string.Format("The number of items in {0} '{1}' must be between {2} and {3}.", descriptorType, tokenizedMemberName, Minimum, Maximum);
            }
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            LengthCollectionRule lengthCollectionRule = (LengthCollectionRule) rule;
            return lengthCollectionRule.excludeDuplicatesFromCount == excludeDuplicatesFromCount && lengthCollectionRule.comparer == comparer;
        }

        #endregion
    }
}