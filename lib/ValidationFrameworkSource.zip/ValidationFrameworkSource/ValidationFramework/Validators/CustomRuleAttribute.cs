using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="CustomRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="CustomRule"/>
    /// <seealso cref="CustomRuleConfigReader"/>
    /// <seealso cref="CustomValidationEventArgs"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\CustomRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\CustomRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    [Serializable]
    public sealed class CustomRuleAttribute : RuleAttribute, IPropertyRuleAttribute, IParameterRuleAttribute, IFieldRuleAttribute
    {
        #region Fields

        private readonly string ruleInterpretation;
        private readonly string validationMethod;
        private readonly string validationTypeName;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomRuleAttribute"/> class.
        /// </summary>
        /// <param name="validationTypeName">The name of the <see cref="Type"/> that the <see cref="ValidationMethod"/> exists on.</param>
        /// <param name="validationMethod">The name of the method to use when running <see cref="Rule.Validate"/>.</param>
        /// <param name="ruleInterpretation">The business interpretation of the <see cref="CustomRuleAttribute"/>.</param>
        /// <exception cref="ArgumentNullException"><paramref name="ruleInterpretation"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleInterpretation"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="validationTypeName"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationTypeName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="validationMethod"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationMethod"/> is <see cref="string.Empty"/>.</exception>
        public CustomRuleAttribute(string validationTypeName, string validationMethod, string ruleInterpretation)
        {
            Guard.ArgumentNotNullOrEmptyString(validationTypeName, "validationTypeName");
            Guard.ArgumentNotNullOrEmptyString(validationMethod, "validationMethod");
            Guard.ArgumentNotNullOrEmptyString(ruleInterpretation, "ruleInterpretation");
            this.validationTypeName = validationTypeName;
            this.validationMethod = validationMethod;
            this.ruleInterpretation = ruleInterpretation;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the name of the method to use when running <see cref="Rule.Validate"/>.
        /// </summary>
        public string ValidationMethod
        {
            get
            {
                return validationMethod;
            }
        }

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public string RuleInterpretation
        {
            get
            {
                return ruleInterpretation;
            }
        }


        /// <summary>
        /// Gets the name of the <see cref="Type"/> that the <see cref="ValidationMethod"/> exists on.
        /// </summary>
        public string ValidationTypeName
        {
            get
            {
                return validationTypeName;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }

        #endregion


        private CustomRule CreateRule()
        {
            return new CustomRule(ErrorMessage, RuleSet, UseErrorMessageProvider, ValidationTypeName, validationMethod, ruleInterpretation);
        }

        #endregion
    }
}