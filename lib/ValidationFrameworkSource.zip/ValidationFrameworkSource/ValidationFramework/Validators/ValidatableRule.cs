using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{

    /// <summary>
    /// Validates a member that implements <see cref="IValidatable"/>.
    /// </summary>
    /// <remarks>
    /// Allow hierarchical validation of objects. 
    /// If <see cref="IValidatable.IsValid"/> returns <c>false</c> then <see cref="Validate"/> will return a <see cref="ValidationResult"/> with <see cref="ValidationResult.ErrorMessage"/> populated with the concatenated value of <see cref="IValidatable.ErrorMessages"/>.
    /// </remarks>
    /// <seealso cref="ValidatableRuleConfigReader"/>
    /// <seealso cref="ValidatableRuleAttribute"/>
    [Serializable]
    public class ValidatableRule: Rule
    {
        #region Fields

        private static readonly RuntimeTypeHandle runtimeTypeHandle = typeof(IValidatable).TypeHandle;
        private readonly bool useMemberErrorMessages;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// </list>
        /// </remarks>
        public ValidatableRule()
            : this(null, null, false)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// </list>
        /// </remarks>
        public ValidatableRule(bool useMemberErrorMessages)
            : this(useMemberErrorMessages, null, false)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public ValidatableRule(string errorMessage)
            : this(errorMessage, null, false)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public ValidatableRule(string errorMessage, string ruleSet, bool useErrorMessageProvider)
            : base(runtimeTypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidatableRule"/> class.
        /// </summary>
        /// <param name="useMemberErrorMessages"><c>true</c> to use the <see cref="IValidatable.ErrorMessages"/> of the member this <see cref="Rule"/> is applied to; otherwise <c>false</c>.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public ValidatableRule(bool useMemberErrorMessages, string ruleSet, bool useErrorMessageProvider)
            : base(runtimeTypeHandle, null, ruleSet, useErrorMessageProvider)
        {
            this.useMemberErrorMessages = useMemberErrorMessages;
        }

        #endregion


        #region Properties


        /// <summary>
        /// Gets a value indicating if <see cref="IValidatable.ErrorMessages"/> should be use as the <see cref="Rule.ErrorMessage"/>.  
        /// </summary>
        public  bool UseMemberErrorMessages
        {
            get
            {
                return useMemberErrorMessages;
            }
        }


        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                return string.Format("The value must return true for IValidatable.IsValid. See Rules for the Type of this member.");
            }
        }


        #endregion


        #region Methods


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            if (targetMemberValue != null)
            {
                IValidatable validatable = (IValidatable)targetMemberValue;
                if (!validatable.IsValid)
                {
                    if (UseErrorMessageProvider)
                    {
                        return new ValidationResult(this, ConfigurationService.ErrorMessageProvider.RetrieveErrorMessage(this, targetObjectValue, targetMemberValue, context));
                    }
                    else if (useMemberErrorMessages)
                    {
                        return new ValidationResult(this, ResultFormatter.GetConcatenatedErrorMessages(validatable.ErrorMessages));
                    }
                    else
                    {
                        return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
                    }
                }
            }
            return null;

        }


        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            if (useMemberErrorMessages)
            {
                return null;
            }
            else
            {
                return string.Format("The {0} '{1}' is invalid.", descriptorType, tokenizedMemberName);
            }
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            return true;
        }

        #endregion
    }
}