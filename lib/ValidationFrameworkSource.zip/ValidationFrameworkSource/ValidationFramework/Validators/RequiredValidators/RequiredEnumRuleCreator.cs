using System;

namespace ValidationFramework
{
    internal static class RequiredEnumRuleCreator
    {
        #region Methods

        public static Rule ReadConfig(string initialValue, string errorMessage, string ruleSet, bool useErrorMessageProvider, RuntimeTypeHandle runtimeTypeHandle)
        {
            Type genericRequiredRuleType = typeof (RequiredRule<>);
            Type targetMemberType = Type.GetTypeFromHandle(runtimeTypeHandle);
            Type underlyingType = Nullable.GetUnderlyingType(targetMemberType);
            bool targetMemberIsNullable = underlyingType != null;
            Type constructedRequiredRuleType;
            if (targetMemberIsNullable)
            {
                constructedRequiredRuleType = genericRequiredRuleType.MakeGenericType(underlyingType);
            }
            else
            {
                constructedRequiredRuleType = genericRequiredRuleType.MakeGenericType(targetMemberType);
            }


            object enumInitialValue = null;
            if (initialValue != null)
            {
                if (targetMemberIsNullable)
                {
                    enumInitialValue = Enum.Parse(underlyingType, initialValue);
                }
                else
                {
                    enumInitialValue = Enum.Parse(targetMemberType, initialValue);
                }
            }

            object initialValueObject;
            if (targetMemberIsNullable || enumInitialValue != null)
            {
                initialValueObject = enumInitialValue;
            }
            else
            {
                initialValueObject = Enum.GetValues(targetMemberType).GetValue(0);
            }
            if (initialValueObject == null)
            {
                return (Rule) Activator.CreateInstance(constructedRequiredRuleType, errorMessage, ruleSet, useErrorMessageProvider);
            }
            else
            {
                return (Rule) Activator.CreateInstance(constructedRequiredRuleType, errorMessage, ruleSet, useErrorMessageProvider, initialValueObject);
            }
        }

        #endregion
    }
}