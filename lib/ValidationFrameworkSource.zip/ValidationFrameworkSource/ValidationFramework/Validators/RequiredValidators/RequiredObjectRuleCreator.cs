using System;
using System.Xml;
using System.Xml.Serialization;

namespace ValidationFramework
{
    internal static class RequiredObjectRuleCreator
    {
        #region Methods

        public static Rule ReadConfig(string errorMessage, string ruleSet, bool useErrorMessageProvider, XmlReader initialValueXmlReader, RuntimeTypeHandle runtimeTypeHandle)
        {
            Type genericRequiredRuleType = typeof (RequiredRule<>);
            Type targetMemberType = Type.GetTypeFromHandle(runtimeTypeHandle);
            Type constructedRequiredRuleType = genericRequiredRuleType.MakeGenericType(targetMemberType);

            if (initialValueXmlReader != null)
            {
                Type objectType = Type.GetTypeFromHandle(runtimeTypeHandle);
                XmlSerializer xmlSerializer = new XmlSerializer(objectType);

                object initialValue = xmlSerializer.Deserialize(initialValueXmlReader);
                return (Rule) Activator.CreateInstance(constructedRequiredRuleType, errorMessage, ruleSet, useErrorMessageProvider, initialValue);
            }
            else
            {
                return (Rule) Activator.CreateInstance(constructedRequiredRuleType, errorMessage, ruleSet, useErrorMessageProvider);
            }
        }

        #endregion
    }
}