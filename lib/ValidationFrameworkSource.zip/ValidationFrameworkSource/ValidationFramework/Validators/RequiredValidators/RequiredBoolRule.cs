using System;
using ValidationFramework.Configuration;

namespace ValidationFramework
{
    /// <summary>
    /// Performs a required field validation on a <see langword="bool"/>.
    /// </summary>
    /// <seealso cref="RequiredBoolRuleConfigReader"/>
    /// <seealso cref="RequiredBoolRuleAttribute"/>
    [Serializable]
    public class RequiredBoolRule : RequiredRule<bool>
    {
        #region Constructors

        /// <summary>
        /// Initialises a new instance of the <see cref="RequiredBoolRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// </list>	
        /// </remarks>
        public RequiredBoolRule()
            : this(null, null, false)
        {
        }


        /// <summary>
        /// Initialises a new instance of the <see cref="RequiredBoolRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// </list>	
        /// </remarks>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RequiredBoolRule(string errorMessage)
            : this(errorMessage, null, false)
        {
        }


        /// <summary>
        /// Initialises a new instance of the <see cref="RequiredBoolRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RequiredBoolRule(string errorMessage, string ruleSet, bool useErrorMessageProvider)
            : base(errorMessage, ruleSet, useErrorMessageProvider)
        {
        }

        #endregion


        #region Methods

        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <returns><see langword="true"/> if the member is valid; otherwise <see langword="false"/>.</returns>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            if (targetMemberValue == null)
            {
                return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
            }
            else
            {
                return null;
            }
        }

        #endregion
    }
}