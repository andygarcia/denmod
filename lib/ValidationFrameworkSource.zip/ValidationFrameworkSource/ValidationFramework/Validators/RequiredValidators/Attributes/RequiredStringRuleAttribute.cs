using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="RequiredStringRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="RequiredStringRule"/>
    /// <seealso cref="RequiredRuleConfigReader"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\RequiredValidators\RequiredStringRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\RequiredValidators\RequiredStringRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class RequiredStringRuleAttribute : RuleAttribute, IPropertyRuleAttribute, IParameterRuleAttribute, IFieldRuleAttribute
    {
        #region Fields

        private bool ignoreCase = true;
        private string initialValue;
        private bool trimWhiteSpace = true;

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets the initial and invalid value.
        /// </summary>
        /// <seealso cref="RequiredRule{T}.InitialValue"/>
        public string InitialValue
        {
            get
            {
                return initialValue;
            }
            set
            {
                initialValue = value;
            }
        }

        /// <summary>
        /// Gets or sets a <see cref="bool"/> to indicate if whitespace should be trimmed from the value being validated.
        /// </summary>
        /// <seealso cref="RequiredStringRule.TrimWhiteSpace"/>
        public bool TrimWhiteSpace
        {
            get
            {
                return trimWhiteSpace;
            }
            set
            {
                trimWhiteSpace = value;
            }
        }

        /// <summary>
        /// Gets or sets a <see cref="bool"/> to indicate if case should be ignored.
        /// </summary>
        /// <seealso cref="RequiredStringRule.IgnoreCase"/>
        public bool IgnoreCase
        {
            get
            {
                return ignoreCase;
            }
            set
            {
                ignoreCase = value;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }

        #endregion


        private RequiredStringRule CreateRule()
        {
            if (initialValue == null)
            {
                return new RequiredStringRule(ErrorMessage, RuleSet, UseErrorMessageProvider, trimWhiteSpace);
            }
            else
            {
                return new RequiredStringRule(ErrorMessage, RuleSet, UseErrorMessageProvider, initialValue, trimWhiteSpace, ignoreCase);
            }
        }

        #endregion
    }
}