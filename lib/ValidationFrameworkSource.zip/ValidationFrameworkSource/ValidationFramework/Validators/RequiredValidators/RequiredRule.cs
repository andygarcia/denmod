using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;
using ValidationFramework.Web;

namespace ValidationFramework
{
    /// <summary>
    /// Base class for performing a required validation.
    /// </summary>
    [Serializable]
    public class RequiredRule<T> : Rule, ISupportWebClientValidation
    {
        #region Fields

        private static readonly RuntimeTypeHandle runtimeTypeHandle = typeof (T).TypeHandle;
        private bool hasInitialValue;
        private readonly T initialValue;
        private bool isNullable;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredRule{T}"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// </list>
        /// </remarks>
        public RequiredRule()
            : this(null, null, false)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredRule{T}"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RequiredRule(string errorMessage)
            : this(errorMessage, null, false)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredRule{T}"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="initialValue">The initial and invalid value.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RequiredRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, T initialValue)
            : base(runtimeTypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
            Guard.ArgumentNotNull(initialValue, "initialValue");
            this.initialValue = initialValue;
            hasInitialValue = true;

            //TODO: should throw an exception if T is a string???
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredRule{T}"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RequiredRule(string errorMessage, string ruleSet, bool useErrorMessageProvider)
            : base(runtimeTypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
        }

        #endregion


        #region Properties

        /// <summary>
        /// Get a value indicating if the <see cref="InitialValue"/> has been set
        /// </summary>
        public bool HasInitialValue
        {
            get
            {
                return hasInitialValue;
            }
        }

        /// <summary>
        /// Gets or sets the initial and invalid value.
        /// </summary>
        public T InitialValue
        {
            get
            {
                if (!hasInitialValue)
                {
                    throw new InvalidOperationException("Initial value has not bee set. Use SetInitialValue first.");
                }
                return initialValue;
            }
        }

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                if (hasInitialValue)
                {
                    return string.Format("The value must not be '{0}'", initialValue);
                }
                else
                {
                    return string.Format("The value must not be null");
                }
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Get a list of <see cref="BaseValidator"/>s to perform the client side validation.
        /// </summary>
        /// <remarks>The <see cref="BaseValidator"/>s returned should only perform client validation.</remarks>
        /// <returns>The<see cref="IList{T}"/> of <see cref="BaseValidator"/>s to perform the client side validation.</returns>
        public virtual IList<BaseValidator> CreateWebClientValidators()
        {
            List<BaseValidator> list = new List<BaseValidator>();
            RequiredFieldWebValidatorEx webValidator = new RequiredFieldWebValidatorEx();

            if (hasInitialValue)
            {
                if (initialValue is DateTime)
                {
                    DateTime initialValueAsDateTime = (DateTime) (object) initialValue;
                    if (initialValueAsDateTime.TimeOfDay == TimeSpan.Zero)
                    {
                        webValidator.InitialValue = initialValueAsDateTime.ToString("yyyy-MM-dd");
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    webValidator.InitialValue = initialValue.ToString();
                }
                list.Add(webValidator);

                if (!isNullable)
                {
                    RequiredFieldWebValidatorEx notNullableWebValidator = new RequiredFieldWebValidatorEx();
                    list.Add(notNullableWebValidator);
                }
            }
            else
            {
                list.Add(webValidator);
            }
            ValidationDataType? validationDataType = ValidatorCreatorHelper.GetValidationDataType(InfoDescriptor.RuntimeTypeHandle);
            if (validationDataType.HasValue)
            {
                ValidationDataType validationDataTypeValue = validationDataType.Value;
                if (validationDataTypeValue != ValidationDataType.String)
                {
                    CompareValidator compareValidator = new CompareValidator();
                    compareValidator.Operator = ValidationCompareOperator.DataTypeCheck;
                    compareValidator.Type = validationDataTypeValue;
                    list.Add(compareValidator);
                }
            }
            return list;
        }


        /// <summary>
        /// Check that the <see cref="RuntimeTypeHandle"/> is valid.
        /// </summary>
        /// <remarks>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set. Should throw <see cref="ArgumentException"/> if <paramref name="targetMemberRuntimeTypeHandle"/> is of the wrong type.
        /// </remarks>
        /// <param name="targetMemberRuntimeTypeHandle">The <see cref="RuntimeTypeHandle"/> that this <see cref="Rule"/> is applied to.</param>
        protected override void CheckType(RuntimeTypeHandle targetMemberRuntimeTypeHandle)
        {
            base.CheckType(targetMemberRuntimeTypeHandle);


            Type targetMemberType = Type.GetTypeFromHandle(targetMemberRuntimeTypeHandle);

            if (targetMemberType.IsGenericType && (targetMemberType.GetGenericTypeDefinition().TypeHandle.Equals(TypePointers.NullableTypeHandle)))
            {
                isNullable = true;
            }
            Type valueType = typeof (ValueType);
            if (targetMemberType.BaseType == valueType)
            {
                if (!hasInitialValue && !isNullable)
                {
                    hasInitialValue = true;
                }
            }
        }


        /// <summary>
        /// Validate the value of the member this <see cref="RequiredRule{T}"/> is applied to.
        /// </summary>
        /// <returns><see langword="true"/> if the value is valid; otherwise <see langwordcref="false"/>.</returns>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            bool isValid;
            if (InfoDescriptor == null)
            {
                throw new InvalidOperationException("InfoDescriptor must be set before calling Validate. Adding a IRule to a RuleCollection will achieve this.");
            }

            if ((targetMemberValue == null) && (!hasInitialValue))
            {
                isValid = false;
            }
            else if ((targetMemberValue == null) && (hasInitialValue))
            {
                isValid = true;
            }
            else if ((targetMemberValue != null) && (!hasInitialValue))
            {
                isValid = true;
            }
            else
            {
                T targetMemberValueT = (T) targetMemberValue;
                isValid = !targetMemberValueT.Equals(initialValue);
            }

            if (isValid)
            {
                return null;
            }
            else
            {
                return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
            }
        }


        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            if (hasInitialValue)
            {
                return string.Format("The {0} '{1}' is required and cannot be '{2}'.", descriptorType, tokenizedMemberName, initialValue);
            }
            else
            {
                return string.Format("The {0} '{1}' is required.", descriptorType, tokenizedMemberName);
            }
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            RequiredRule<T> requiredRule = (RequiredRule<T>) rule;

            if (hasInitialValue && requiredRule.hasInitialValue)
            {
                return initialValue.Equals(requiredRule.initialValue);
            }
            else
            {
                return hasInitialValue == requiredRule.hasInitialValue;
            }
        }

        #endregion
    }
}