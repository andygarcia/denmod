using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;
using ValidationFramework.Web;

namespace ValidationFramework
{
    /// <summary>
    /// Performs a required field validation on a <see cref="string"/>.
    /// </summary>
    /// <seealso cref="RequiredStringRuleConfigReader"/>
    /// <seealso cref="RequiredStringRuleAttribute"/>
    [Serializable]
    public class RequiredStringRule : RequiredRule<string>, ISupportWebClientValidation
    {
        #region Fields

        private readonly bool? ignoreCase;
        private readonly bool trimWhiteSpace;
        private StringComparison? stringComparison = null;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredStringRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="TrimWhiteSpace"/> to true.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// </list>
        /// </remarks>
        public RequiredStringRule()
            : this(null, null, false, true)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredStringRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="TrimWhiteSpace"/> to true.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        public RequiredStringRule(string errorMessage)
            : this(errorMessage, null, false, true)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredStringRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="initialValue">The initial and invalid value.</param>
        /// <param name="trimWhiteSpace">A <see cref="bool"/> to indicate if whitespace should be trimmed from <paramref name="initialValue"/> and the value being validated.</param>
        /// <param name="ignoreCase">A <see cref="bool"/> to indicate if case should be ignored.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <exception cref="NullReferenceException"><paramref name="initialValue"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RequiredStringRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, string initialValue, bool trimWhiteSpace,
                                  bool ignoreCase)
            : base(errorMessage, ruleSet, useErrorMessageProvider, trimWhiteSpace ? initialValue.Trim() : initialValue)
        {
            this.trimWhiteSpace = trimWhiteSpace;
            if (trimWhiteSpace)
            {
                initialValue = initialValue.Trim();
            }
            Guard.ArgumentNotNullOrEmptyString(initialValue, "initialValue");

            this.ignoreCase = ignoreCase;
            if (ignoreCase)
            {
                stringComparison = StringComparison.OrdinalIgnoreCase;
            }
            else
            {
                stringComparison = StringComparison.Ordinal;
            }
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredStringRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="trimWhiteSpace">A <see cref="bool"/> to indicate if whitespace should be trimmed from the value being validated.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public RequiredStringRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, bool trimWhiteSpace)
            : base(errorMessage, ruleSet, useErrorMessageProvider)
        {
            this.trimWhiteSpace = trimWhiteSpace;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                if (HasInitialValue)
                {
                    return string.Format("The value must not be {0}", InitialValue);
                }
                else
                {
                    if (trimWhiteSpace)
                    {
                        return string.Format("The value must not be null or an empty string. All spaces are ignored.");
                    }
                    else
                    {
                        return string.Format("The value must not be null or an empty string.");
                    }
                }
            }
        }

        /// <summary>
        /// Gets a <see cref="bool"/> to indicate if whitespace should be trimmed from the value being validated.
        /// </summary>
        public bool TrimWhiteSpace
        {
            get
            {
                return trimWhiteSpace;
            }
        }

        /// <summary>
        /// Gets a <see cref="bool"/> to indicate if case should be ignored.
        /// </summary>
        public bool? IgnoreCase
        {
            get
            {
                return ignoreCase;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Get a list of <see cref="BaseValidator"/>s to perform the client side validation.
        /// </summary>
        /// <remarks>The <see cref="BaseValidator"/>s returned should only perform client validation.</remarks>
        /// <returns>The<see cref="IList{T}"/> of <see cref="BaseValidator"/>s to perform the client side validation.</returns>
        public override IList<BaseValidator> CreateWebClientValidators()
        {
            ExtendedRequiredFieldValidator validator = new ExtendedRequiredFieldValidator();
            if (HasInitialValue)
            {
                validator.InitialValue = InitialValue;
            }
            validator.IgnoreCase = ignoreCase;
            validator.TrimWhiteSpace = trimWhiteSpace;

            return new BaseValidator[] {validator};
        }


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <returns><see langword="true"/> if the member is valid; otherwise <see langword="false"/>.</returns>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        ///// <exception cref="InvalidCastException"><paramref name="targetMemberValue"/> is not a <see cref="String"/>.</exception>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            //Since String can be null or empty, need to do an explicit check
            //Always check for null before casting.
            bool isValid;
            if (HasInitialValue)
            {
                if (targetMemberValue == null)
                {
                    isValid = true;
                }
                else
                {
                    string propertyValueString = (string) targetMemberValue;
                    if (trimWhiteSpace)
                    {
                        propertyValueString = propertyValueString.Trim();
                    }
                    isValid = !String.Equals(propertyValueString, InitialValue, stringComparison.Value);
                }
            }
            else
            {
                if (targetMemberValue == null)
                {
                    isValid = false;
                }
                else
                {
                    string propertyValueString = (string) targetMemberValue;
                    if (trimWhiteSpace)
                    {
                        propertyValueString = propertyValueString.Trim();
                    }
                    isValid = (propertyValueString.Length > 0);
                }
            }
            if (!isValid)
            {
                return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            RequiredStringRule requiredStringRule = (RequiredStringRule) rule;
            return
                base.IsEquivalent(rule) && requiredStringRule.trimWhiteSpace == trimWhiteSpace &&
                requiredStringRule.ignoreCase == ignoreCase;
        }

        #endregion
    }
}