using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;
using ValidationFramework.Web;

namespace ValidationFramework
{
    /// <summary>
    /// Base class for performing a range validation.
    /// </summary>
    /// <seealso cref="RangeRuleConfigReader"/>
    /// <seealso cref="RangeByteRuleAttribute"/>
    /// <seealso cref="RangeDateTimeRuleAttribute"/>
    /// <seealso cref="RangeDoubleRuleAttribute"/>
    /// <seealso cref="RangeFloatRuleAttribute"/>
    /// <seealso cref="RangeIntRuleAttribute"/>
    /// <seealso cref="RangeLongRuleAttribute"/>
    /// <seealso cref="RangeShortRuleAttribute"/>
    [Serializable]
    public class RangeRule<T> : Rule, ISupportWebClientValidation where T : IComparable<T>
    {
        #region Fields

        private const string errorMessageFormat = "The {0} '{1}' must be '{2}' {3} and '{4}' {5}.";
        private const string ruleInterpretationFormat = "The value must be '{0}' {1} and '{2}' {3}.";
        private static readonly RuntimeTypeHandle runtimeTypeHandle = typeof (T).TypeHandle;
        private readonly bool equalsMaximumIsValid = true;
        private readonly bool equalsMinimumIsValid = true;
        private readonly T maximum;
        private readonly T minimum;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RangeRule{T}"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// <item>
        /// <see cref="EqualsMaximumIsValid"/> to true.
        /// </item>
        /// <item> 
        /// <see cref="EqualsMinimumIsValid"/> to true.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="minimum">The minimum valid value</param>
        /// <param name="maximum">The maximum valid value</param>
        public RangeRule(T minimum, T maximum)
            : this(null, null, false, minimum, maximum, true, true)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RangeRule{T}"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="EqualsMaximumIsValid"/> to true.
        /// </item>
        /// <item>Sets 
        /// <see cref="EqualsMinimumIsValid"/> to true.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="minimum">The minimum valid value</param>
        /// <param name="maximum">The maximum valid value</param>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RangeRule(string errorMessage, T minimum, T maximum)
            : this(errorMessage, null, false, minimum, maximum, true, true)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="RangeRule{T}"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="minimum">The minimum valid value</param>
        /// <param name="maximum">The maximum valid value</param>
        /// <param name="equalsMinimumIsValid"><see langword="true"/> to indicate that the minimum value is valid; otherwise <see langworg="false"/>.</param>
        /// <param name="equalsMaximumIsValid"><see langword="true"/> to indicate that the maximum value is valid; otherwise <see langworg="false"/>.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RangeRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, T minimum, T maximum, bool equalsMinimumIsValid, bool equalsMaximumIsValid)
            : base(runtimeTypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
            this.minimum = minimum;
            this.maximum = maximum;
            this.equalsMinimumIsValid = equalsMinimumIsValid;
            this.equalsMaximumIsValid = equalsMaximumIsValid;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the minimum valid value
        /// </summary>
        public T Minimum
        {
            get
            {
                return minimum;
            }
        }

        /// <summary>
        /// Gets the maximum valid value
        /// </summary>
        public T Maximum
        {
            get
            {
                return maximum;
            }
        }

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                CompareOperator minCompareOperator;
                CompareOperator maxCompareOperator;
                GetCompareOperators(out maxCompareOperator, out minCompareOperator);
                return string.Format(ruleInterpretationFormat, EnumUserFriendlyNameConverter.Convert(minCompareOperator), minimum, EnumUserFriendlyNameConverter.Convert(maxCompareOperator), maximum);
            }
        }

        /// <summary>
        /// Get a value indicating if the minimum value is valid.
        /// </summary>
        public bool EqualsMinimumIsValid
        {
            get
            {
                return equalsMinimumIsValid;
            }
        }

        /// <summary>
        /// Get a value indicating if the maximum value is valid.
        /// </summary>
        public bool EqualsMaximumIsValid
        {
            get
            {
                return equalsMaximumIsValid;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Get a list of <see cref="BaseValidator"/>s to perform the client side validation.
        /// </summary>
        /// <remarks>The <see cref="BaseValidator"/>s returned should only perform client validation.</remarks>
        /// <returns>The<see cref="IList{T}"/> of <see cref="BaseValidator"/>s to perform the client side validation.</returns>
        public IList<BaseValidator> CreateWebClientValidators()
        {
            if (equalsMinimumIsValid && equalsMaximumIsValid)
            {
                ValidationDataType? validationDataType = ValidatorCreatorHelper.GetValidationDataType(InfoDescriptor.RuntimeTypeHandle);
                if (validationDataType.HasValue)
                {
                    RangeWebValidatorEx rangeWebValidatorEx = new RangeWebValidatorEx();
                    ValidationDataType validationDataTypeValue = validationDataType.Value;
                    rangeWebValidatorEx.Type = validationDataType.Value;

                    if (validationDataTypeValue == ValidationDataType.Date)
                    {
                        DateTime minimumAsDateTime = (DateTime) (object) minimum;
                        DateTime maximumAsDateTime = (DateTime) (object) maximum;
                        if (minimumAsDateTime.TimeOfDay != TimeSpan.Zero || maximumAsDateTime.TimeOfDay != TimeSpan.Zero)
                        {
                            return null;
                        }
                        else
                        {
                            rangeWebValidatorEx.MinimumValue = minimumAsDateTime.ToString("yyyy-MM-dd");
                            rangeWebValidatorEx.MaximumValue = maximumAsDateTime.ToString("yyyy-MM-dd");
                        }
                    }
                    else
                    {
                        rangeWebValidatorEx.MinimumValue = minimum.ToString();
                        rangeWebValidatorEx.MaximumValue = maximum.ToString();
                    }

                    List<BaseValidator> list = new List<BaseValidator>();
                    list.Add(rangeWebValidatorEx);
                    return list;
                }
            }
            return null;
        }


        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            CompareOperator minCompareOperator;
            CompareOperator maxCompareOperator;
            GetCompareOperators(out maxCompareOperator, out minCompareOperator);
            return string.Format(errorMessageFormat, descriptorType, tokenizedMemberName, EnumUserFriendlyNameConverter.Convert(minCompareOperator), minimum, EnumUserFriendlyNameConverter.Convert(maxCompareOperator), maximum);
        }


        private void GetCompareOperators(out CompareOperator maxCompareOperator, out CompareOperator minCompareOperator)
        {
            if (equalsMaximumIsValid)
            {
                maxCompareOperator = CompareOperator.LessThanEqual;
            }
            else
            {
                maxCompareOperator = CompareOperator.LessThan;
            }
            if (equalsMinimumIsValid)
            {
                minCompareOperator = CompareOperator.GreaterThanEqual;
            }
            else
            {
                minCompareOperator = CompareOperator.GreaterThan;
            }
        }


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            if (targetMemberValue != null)
            {
                if (!RangeValidationHelper.IsRangeValid((T) targetMemberValue, Minimum, Maximum, EqualsMinimumIsValid, EqualsMaximumIsValid))
                {
                    return CreateValidationResult(targetObjectValue, targetMemberValue, context);
                }
            }
            return null;
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            RangeRule<T> rangeRule = (RangeRule<T>) rule;
            return (rangeRule.equalsMaximumIsValid == equalsMaximumIsValid) &&
                   (rangeRule.equalsMinimumIsValid == equalsMinimumIsValid) &&
                   CompareT(minimum, rangeRule.minimum) &&
                   CompareT(maximum, rangeRule.maximum);
        }


        private static bool CompareT(T left, T right)
        {
            if (left == null && right != null)
            {
                return false;
            }
            else if (left != null && right == null)
            {
                return false;
            }
            else if (left == null && right == null)
            {
                return true;
            }
            else
            {
                return left.Equals(right);
            }
        }

        #endregion
    }
}