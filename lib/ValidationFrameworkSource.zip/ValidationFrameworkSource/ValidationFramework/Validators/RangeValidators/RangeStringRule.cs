using System;
using ValidationFramework.Configuration;

namespace ValidationFramework
{
    /// <summary>
    /// Performs a range validation on a <see cref="string"/>.
    /// </summary>
    /// <remarks>If the value being validated is null the rule will evaluate to true.</remarks>
    /// <seealso cref="RangeStringRuleConfigReader"/>
    /// <seealso cref="RangeStringRuleAttribute"/>
    [Serializable]
    public class RangeStringRule : RangeRule<string>
    {
        #region Constructors

        /// <summary>
        /// Initialises a new instance of the <see cref="RangeStringRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// <item>
        /// <see cref="RangeRule{T}.EqualsMaximumIsValid"/> to true.
        /// </item>
        /// <item>
        /// <see cref="RangeRule{T}.EqualsMinimumIsValid"/> to true.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="minimum">The minimum value.</param>
        /// <param name="maximum">The maximum value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="minimum"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="maximum"/> is <see cref="string.Empty"/>.</exception>
        public RangeStringRule(string minimum, string maximum)
            : this(null, null, false, minimum, maximum, true, true)
        {
        }


        /// <summary>
        /// Initialises a new instance of the <see cref="RangeStringRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="RangeRule{T}.EqualsMaximumIsValid"/> to true.
        /// </item>
        /// <item>
        /// <see cref="RangeRule{T}.EqualsMinimumIsValid"/> to true.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="minimum">The minimum value.</param>
        /// <param name="maximum">The maximum value.</param>
        /// <param name="errorMessage">The error message for this rule.</param>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="minimum"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="maximum"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RangeStringRule(string errorMessage, string minimum, string maximum)
            : this(errorMessage, null, false, minimum, maximum, true, true)
        {
        }


        /// <summary>
        /// Initialises a new instance of the <see cref="RangeStringRule"/> class.
        /// </summary>
        /// <param name="minimum">The minimum value.</param>
        /// <param name="maximum">The maximum value.</param>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="equalsMinimumIsValid"><see langword="true"/> to indicate that the minimum value is valid; otherwise <see langworg="false"/>.</param>
        /// <param name="equalsMaximumIsValid"><see langword="true"/> to indicate that the maximum value is valid; otherwise <see langworg="false"/>.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="minimum"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="maximum"/> is <see cref="string.Empty"/>.</exception>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public RangeStringRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, string minimum, string maximum, bool equalsMinimumIsValid, bool equalsMaximumIsValid)
            : base(errorMessage, ruleSet, useErrorMessageProvider, minimum, maximum, equalsMinimumIsValid, equalsMaximumIsValid)
        {
            Guard.ArgumentNotNullOrEmptyString(minimum, "minimum");
            Guard.ArgumentNotNullOrEmptyString(maximum, "maximum");
        }

        #endregion


        #region Methods

        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            if (targetMemberValue != null)
            {
                if (!RangeValidationHelper.IsRangeValid((string) targetMemberValue, Minimum, Maximum, EqualsMinimumIsValid, EqualsMaximumIsValid))
                {
                    return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
                }
            }
            return null;
        }

        #endregion
    }
}