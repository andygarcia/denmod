using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="RangeRule{T}"/>, that will check the range of a <see cref="byte"/>, should be applied to the program element.
    /// </summary>
    /// <seealso cref="RangeRule{T}"/>
    /// <seealso cref="RangeRuleConfigReader"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\RangeValidators\RangeByteRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\RangeValidators\RangeByteRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public abstract class RangeRuleAttribute : RuleAttribute, IPropertyRuleAttribute, IParameterRuleAttribute, IFieldRuleAttribute
    {
        #region Fields

        private bool equalsMaximumIsValid = true;
        private bool equalsMinimumIsValid = true;

        #endregion


        #region Properties

        /// <summary>
        /// Get or sets a value indicating if the minimum value is valid.
        /// </summary>
        public bool EqualsMinimumIsValid
        {
            get
            {
                return equalsMinimumIsValid;
            }
            set
            {
                equalsMinimumIsValid = value;
            }
        }


        /// <summary>
        /// Get or sets a value indicating if the maximum value is valid.
        /// </summary>
        public bool EqualsMaximumIsValid
        {
            get
            {
                return equalsMaximumIsValid;
            }
            set
            {
                equalsMaximumIsValid = value;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreateParameterRule(ParameterDescriptor parameterDescriptor);

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor);

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public abstract Rule CreateFieldRule(FieldDescriptor fieldDescriptor);

        #endregion


        #endregion
    }
}