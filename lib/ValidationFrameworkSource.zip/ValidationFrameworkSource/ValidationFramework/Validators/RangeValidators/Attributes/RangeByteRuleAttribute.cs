using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="RangeRule{T}"/>, that will check the range of a <see cref="byte"/>, should be applied to the program element.
    /// </summary>
    /// <seealso cref="RangeRule{T}"/>
    /// <seealso cref="RangeRuleConfigReader"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\RangeValidators\RangeByteRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\RangeValidators\RangeByteRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class RangeByteRuleAttribute : RangeRuleAttribute
    {
        #region Fields

        private readonly byte maximum;
        private readonly byte minimum;

        #endregion


        #region Constructors

        /// <summary>
        /// Initialises a new instance of the <see cref="RangeByteRuleAttribute"/> class.
        /// </summary>
        /// <param name="minimum">The minimum value.</param>
        /// <param name="maximum">The maximum value.</param>
        public RangeByteRuleAttribute(byte minimum, byte maximum)
        {
            this.minimum = minimum;
            this.maximum = maximum;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the minimum value.
        /// </summary>
        /// <seealso cref="RangeRule{T}.Minimum"/>
        public byte Minimum
        {
            get
            {
                return minimum;
            }
        }

        /// <summary>
        /// Gets the maximum value.
        /// </summary>
        /// <seealso cref="RangeRule{T}.Maximum"/>
        public byte Maximum
        {
            get
            {
                return maximum;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public override Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public override Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public override Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }

        #endregion


        private RangeRule<byte> CreateRule()
        {
            return new RangeRule<byte>(ErrorMessage, RuleSet, UseErrorMessageProvider, minimum, maximum, EqualsMinimumIsValid, EqualsMaximumIsValid);
        }

        #endregion
    }
}