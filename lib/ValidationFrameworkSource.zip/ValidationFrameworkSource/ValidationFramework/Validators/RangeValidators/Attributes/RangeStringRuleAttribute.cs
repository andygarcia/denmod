using System;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="RangeStringRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="RangeStringRule"/>
    /// <seealso cref="RangeRuleConfigReader"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\RangeValidators\RangeStringRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\RangeValidators\RangeStringRuleAttributeSample.vb" lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class RangeStringRuleAttribute : RangeRuleAttribute
    {
        #region Fields

        private readonly string maximum;
        private readonly string minimum;

        #endregion


        #region Constructors

        /// <summary>
        /// Initialises a new instance of the <see cref="RangeStringRuleAttribute"/> class.
        /// </summary>
        /// <param name="minimum">The minimum value.</param>
        /// <param name="maximum">The maximum value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="minimum"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="minimum"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="maximum"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="maximum"/> is <see cref="string.Empty"/>.</exception>
        public RangeStringRuleAttribute(string minimum, string maximum)
        {
            Guard.ArgumentNotNullOrEmptyString(minimum, "minimum");
            Guard.ArgumentNotNullOrEmptyString(maximum, "maximum");
            this.minimum = minimum;
            this.maximum = maximum;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the minimum value.
        /// </summary>
        /// <seealso cref="RangeRule{T}.Minimum"/>
        public string Minimum
        {
            get
            {
                return minimum;
            }
        }

        /// <summary>
        /// Gets the maximum value.
        /// </summary>
        /// <seealso cref="RangeRule{T}.Maximum"/>
        public string Maximum
        {
            get
            {
                return maximum;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public override Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public override Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public override Rule CreateFieldRule(FieldDescriptor FieldDescriptor)
        {
            return CreateRule();
        }

        #endregion


        private RangeStringRule CreateRule()
        {
            return new RangeStringRule(ErrorMessage, RuleSet, UseErrorMessageProvider, minimum, maximum, EqualsMinimumIsValid, EqualsMaximumIsValid);
        }

        #endregion
    }
}