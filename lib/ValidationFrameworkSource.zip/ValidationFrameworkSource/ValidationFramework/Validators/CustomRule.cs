using System;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Represents the method that defines a custom validation. 
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">An <see cref="CustomValidationEventArgs"/> that contains the event data.</param>
    /// <seealso cref="CustomRule"/>
    [SuppressMessage("Microsoft.Design", "CA1003:UseGenericEventHandlerInstances")]
    public delegate void CustomValidationHandler(object sender, CustomValidationEventArgs e);

    /// <summary>
    /// Performs a custom validation via an defined method.
    /// </summary>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\CustomRuleAttributeSample.cs" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\CustomRuleAttributeSample.vb" lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\Reflection\AddCustomRuleWithTypeCacheSample.cs" lang="cs" title="This example shows how to progromatically add a CustomRule to a property."/>
    /// <code source="Examples\ExampleLibraryVB\Reflection\AddCustomRuleWithTypeCacheSample.vb" lang="vbnet" title="This example shows how to progromatically add a CustomRule to a property."/>
    /// </example>
    /// <seealso cref="CustomRuleConfigReader"/>
    /// <seealso cref="CustomRuleAttribute"/>
    /// <seealso cref="CustomValidationEventArgs"/>
    [Serializable]
    public class CustomRule : Rule
    {
        #region Fields

        private const string errorMessageFormat = "The {0} '{1}' is invalid.";
        private readonly CustomValidationHandler handler;
        private readonly string ruleInterpretation;
        private readonly long uniqueHash;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// <item>
        /// <see cref="Rule.ErrorMessage"/> to the default error message.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="validationTypeName">The name of the type to get the validation method from.</param>
        /// <param name="validationMethod">The method on the current object to use for the validation.</param>
        /// <param name="ruleInterpretation">The business interpretation of the <see cref="CustomRuleAttribute"/>.</param>
        /// <exception cref="ArgumentNullException"><paramref name="validationTypeName"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationTypeName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="validationMethod"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationMethod"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="ruleInterpretation"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleInterpretation"/> is <see cref="string.Empty"/>.</exception>
        public CustomRule(string validationTypeName, string validationMethod, string ruleInterpretation)
            : this(null, null, false, validationTypeName, validationMethod, ruleInterpretation)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="CustomRule"/> class.
        /// </summary>
        /// <remarks>
        /// The following are defaulted
        /// <list type="bullet">
        /// <item>
        /// <see cref="Rule.RuleSet"/> to null.
        /// </item>
        /// </list>
        /// </remarks>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="validationTypeName">The name of the type to get the validation method from.</param>
        /// <param name="validationMethod">The method on the current object to use for the validation.</param>
        /// <param name="ruleInterpretation">The business interpretation of the <see cref="CustomRuleAttribute"/>.</param>
        /// <exception cref="ArgumentNullException"><paramref name="validationTypeName"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationTypeName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="validationMethod"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationMethod"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="ruleInterpretation"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleInterpretation"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public CustomRule(string errorMessage, string validationTypeName, string validationMethod, string ruleInterpretation)
            : this(errorMessage, null, false, validationTypeName, validationMethod, ruleInterpretation)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="CustomRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="validationTypeName">The name of the type to get the validation method from.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="validationMethod">The method on the current object to use for the validation.</param>
        /// <param name="ruleInterpretation">The business interpretation of the <see cref="CustomRuleAttribute"/>.</param>
        /// <exception cref="ArgumentNullException"><paramref name="validationTypeName"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationMethod"/> could not be found on the <see cref="Type"/> <paramref name="validationTypeName"/>.</exception>
        /// <exception cref="ArgumentException">The <see cref="Type"/> defined by <paramref name="validationTypeName"/> can not be loaded.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationTypeName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="validationMethod"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="validationMethod"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="ruleInterpretation"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleInterpretation"/> is <see cref="string.Empty"/>.</exception>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public CustomRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, string validationTypeName, string validationMethod, string ruleInterpretation)
            : base(null, errorMessage, ruleSet, useErrorMessageProvider)
        {
            Guard.ArgumentNotNullOrEmptyString(validationTypeName, "validationTypeName");
            Guard.ArgumentNotNullOrEmptyString(validationMethod, "validationMethod");
            Guard.ArgumentNotNullOrEmptyString(ruleInterpretation, "ruleInterpretation");
            this.ruleInterpretation = ruleInterpretation;
            Type validationType;
            try
            {
                validationType = Type.GetType(validationTypeName, true);
            }
            catch (Exception exception)
            {
                throw new ArgumentException(string.Format("CustomRule could not load the validation type {0}.", validationTypeName), "validationTypeName", exception);
            }
            MethodInfo validationMethodInfo = validationType.GetMethod(validationMethod, BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
            if (validationMethodInfo == null)
            {
                throw new ArgumentException(string.Format("CustomRule could not load the validation method '{0}' from type '{1}'.", validationMethod, validationTypeName), "validationMethod");
            }
            uniqueHash = validationMethodInfo.MethodHandle.Value.ToInt64();
            handler = Delegate.CreateDelegate(typeof(CustomValidationHandler), null, validationMethodInfo, true) as CustomValidationHandler;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="CustomRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="eventHandler">The <see cref="CustomValidationHandler"/> that represents the method to validate this <see cref="CustomRule"/>.</param>
        /// <param name="ruleInterpretation">The business interpretation of the <see cref="CustomRuleAttribute"/>.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.</param>
        /// <exception cref="ArgumentNullException"><paramref name="ruleInterpretation"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleInterpretation"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        public CustomRule(string errorMessage, string ruleSet, bool useErrorMessageProvider, CustomValidationHandler eventHandler, string ruleInterpretation)
            : base(null, errorMessage, ruleSet, useErrorMessageProvider)
        {
            Guard.ArgumentNotNullOrEmptyString(ruleInterpretation, "ruleInterpretation");
            this.ruleInterpretation = ruleInterpretation;
            handler = eventHandler;
            //TODO: ensure method is static????
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s area applied to.
        /// </remarks>
        public override string RuleInterpretation
        {
            get
            {
                return ruleInterpretation;
            }
        }


        /// <summary>
        /// Gets the <see cref="CustomValidationHandler"/> that represents the method to validate this <see cref="CustomRule"/>.
        /// </summary>
        public CustomValidationHandler Handler
        {
            get
            {
                return handler;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public override ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context)
        {
            CustomValidationEventArgs args = new CustomValidationEventArgs(this, targetObjectValue, targetMemberValue, context);
            Handler(this, args);


            if (args.IsValid)
            {
                return null;
            }
            else
            {
                if (string.IsNullOrEmpty(args.ErrorMessage))
                {
                    return base.CreateValidationResult(targetObjectValue, targetMemberValue, context);
                }
                else
                {
                    return new ValidationResult(this, args.ErrorMessage);
                }
            }
        }


        /// <summary>
        /// Called after <see cref="Rule.InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            return string.Format(errorMessageFormat, descriptorType, tokenizedMemberName);
        }


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            CustomRule customRule = (CustomRule)rule;
            return uniqueHash == customRule.uniqueHash;
        }

        #endregion
    }
}