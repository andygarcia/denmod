using System;
using System.Collections;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies that a <see cref="EnumerableDuplicateRule"/> should be applied to the program element.
    /// </summary>
    /// <seealso cref="EnumerableDuplicateRule"/>  
    /// <seealso cref="EnumerableDuplicateRuleConfigReader"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Validators\EnumerableDuplicateRuleAttributeSample.cs"  lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Validators\EnumerableDuplicateRuleAttributeSample.vb"  lang="vbnet"/>
    /// </example>
    [Serializable]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Parameter | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
    public sealed class EnumerableDuplicateRuleAttribute : RuleAttribute, IPropertyRuleAttribute, IParameterRuleAttribute, IFieldRuleAttribute
    {
        #region Fields

        private string equalityComparerPropertyName;
        private string equalityComparerTypeName;

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets the type name for the type to get <see cref="IEqualityComparer"/> from.
        /// </summary>
        /// <seealso cref="EnumerableDuplicateRule.Comparer"/>
        public string EqualityComparerTypeName
        {
            get
            {
                return equalityComparerTypeName;
            }
            set
            {
                equalityComparerTypeName = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of the static property to get <see cref="IEqualityComparer"/> from. 
        /// </summary>
        /// <seealso cref="EnumerableDuplicateRule.Comparer"/>
        public string EqualityComparerPropertyName
        {
            get
            {
                return equalityComparerPropertyName;
            }
            set
            {
                equalityComparerPropertyName = value;
            }
        }

        #endregion


        #region Methods


        #region IParameterRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IPropertyRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }

        #endregion


        #region IFieldRuleAttribute Members

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }

        #endregion


        private EnumerableDuplicateRule CreateRule()
        {
            IEqualityComparer equalityComparer = (IEqualityComparer) ReflectionUtilities.GetStaticProperty(equalityComparerTypeName, equalityComparerPropertyName);
            return new EnumerableDuplicateRule(ErrorMessage, RuleSet, UseErrorMessageProvider, equalityComparer);
        }

        #endregion
    }
}