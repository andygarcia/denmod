using System;

namespace ValidationFramework.Reflection
{
    /// <summary>
    /// A <see cref="AutoKeyDictionary{TKey,TItem}"/> of <see cref="ParameterDescriptor"/>s.
    /// </summary>
    [Serializable]
    public class ParameterCollection : AutoKeyDictionary<string, ParameterDescriptor>
    {
        #region Fields

        private readonly MethodDescriptor methodDescriptor;

        #endregion


        #region Constructors

        /// <summary>
        /// Initialize a new instance of the <see cref="ParameterCollection"/> class.
        /// </summary>
        /// <param name="methodDescriptor">The <see cref="Reflection.MethodDescriptor"/> for this <see cref="ParameterCollection"/>.</param>
        internal ParameterCollection(MethodDescriptor methodDescriptor)
        {
            this.methodDescriptor = methodDescriptor;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the <see cref="Reflection.MethodDescriptor"/> for this <see cref="ParameterCollection"/>.
        /// </summary>
        public MethodDescriptor MethodDescriptor
        {
            get
            {
                return methodDescriptor;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Extracts the key from the <see cref="ParameterDescriptor"/> element.
        /// </summary>
        /// <returns>The key for the specified element.</returns>
        /// <param name="item">The element from which to extract the key.</param>
        /// <exception cref="ArgumentNullException"><paramref name="item"/> is null.</exception>
        protected override string GetKeyForItem(ParameterDescriptor item)
        {
            Guard.ArgumentNotNull(item, "item");
            return item.Name;
        }

        #endregion
    }
}