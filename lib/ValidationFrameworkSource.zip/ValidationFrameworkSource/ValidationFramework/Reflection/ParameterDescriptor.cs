using System;
using System.Reflection;

namespace ValidationFramework.Reflection
{
    /// <summary>
    /// A light-weight wrapper for <see cref="ParameterInfo"/>.
    /// </summary>
    [Serializable]
    public class ParameterDescriptor : InfoDescriptor
    {
        #region Fields

        private static readonly Type parameterRuleAttributeType = typeof (IParameterRuleAttribute);
        private readonly MethodDescriptor method;
        private readonly int position;

        #endregion


        #region Constructors

        /// <summary>
        /// For testing purposes
        /// </summary>
        /// <exclude/>
        protected ParameterDescriptor(RuntimeTypeHandle runtimeTypeHandle, string name)
            : base(runtimeTypeHandle, name)
        {
        }


        /// <summary>
        /// Initialize a new instance of the <see cref="ParameterDescriptor"/> class.
        /// </summary>
        /// <param name="methodDescriptor">The parent <see cref="MethodDescriptor"/>.</param>
        /// <param name="parameterInfo">The <see cref="ParameterInfo"/> to wrap.</param>
        ///// <exception cref="ArgumentNullException"><paramref name="methodDescriptor"/> is null.</exception>
        ///// <exception cref="ArgumentNullException"><paramref name="parameterInfo"/> is null.</exception>
        internal ParameterDescriptor(MethodDescriptor methodDescriptor, ParameterInfo parameterInfo)
            : base(parameterInfo.ParameterType.TypeHandle, parameterInfo.Name)
        {
            //TODO: dont think we need these null checks
            //Guard.ArgumentNotNull(parameterInfo, "parameterInfo");
            //Guard.ArgumentNotNull(methodDescriptor, "methodDescriptor");
            position = parameterInfo.Position;
            method = methodDescriptor;
            object[] parameterAttributes = parameterInfo.GetCustomAttributes(parameterRuleAttributeType, true);
            for (int parameterRuleIndex = 0; parameterRuleIndex < parameterAttributes.Length; parameterRuleIndex++)
            {
                IParameterRuleAttribute parameterRuleAttribute = (IParameterRuleAttribute) parameterAttributes[parameterRuleIndex];
                Rule parameterRule = parameterRuleAttribute.CreateParameterRule(this);
                Rules.Add(parameterRule);
            }
        }

        #endregion


        #region Properties

        /// <summary>
        /// The parent <see cref="MethodDescriptor"/>.
        /// </summary>
        public MethodDescriptor Method
        {
            get
            {
                return method;
            }
        }


        /// <summary>
        /// The position of the <see cref="ParameterDescriptor"/> in the methods signature.
        /// </summary>
        public int Position
        {
            get
            {
                return position;
            }
        }

        #endregion

        #region Methods

        public override object GetValue(object target)
      {
        throw new NotImplementedException();
      }

        #endregion
    }
}