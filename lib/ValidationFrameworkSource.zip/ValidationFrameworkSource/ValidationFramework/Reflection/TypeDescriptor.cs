using System;
using System.Reflection;

namespace ValidationFramework.Reflection
{
    //Design aims
    //-only one instance of TypeDescriptor should exists for each type
    /// <summary>
    /// A light-weight wrapper for <see cref="Type"/>.
    /// </summary>
    [Serializable]
    public class TypeDescriptor
    {
        #region Fields

        internal const BindingFlags PropertyFlags = BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.NonPublic;
        private readonly PropertyCollection properties;
        private readonly FieldCollection fields;
        private readonly RuntimeTypeHandle runtimeTypeHandle;

        #endregion


        #region Constructors

        /// <summary>
        /// Initialize a new instance of the <see cref="TypeDescriptor"/> class.
        /// </summary>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> to wrap.</param>
        /// <exception cref="ArgumentNullException"><paramref name="runtimeTypeHandle"/> is null.</exception>
        internal TypeDescriptor(RuntimeTypeHandle runtimeTypeHandle)
        {
          Type currentType = Type.GetTypeFromHandle(runtimeTypeHandle);

          properties = new PropertyCollection(this);
          properties.SetToReadOnly();
          this.runtimeTypeHandle = runtimeTypeHandle;
          FieldInfo[] fieldInfos = currentType.GetFields(PropertyFlags);
          PropertyInfo[] propertyInfos = currentType.GetProperties(PropertyFlags);
          for (int index = 0; index < propertyInfos.Length; index++)
          {
            PropertyInfo propertyInfo = propertyInfos[index];
            if (!propertyInfo.PropertyType.IsGenericParameter && propertyInfo.CanRead)
            {
              PropertyDescriptor propertyDescriptor = new PropertyDescriptor(this, propertyInfo);
              if (propertyDescriptor.Rules.Count > 0)
              {
                properties.InternalAdd(propertyDescriptor);
              }
            }
          }
            Type baseType = currentType.BaseType;
            //TODO: should not reflect over system types.
            if (baseType != null)
            {
              TypeDescriptor baseTypeDescriptor = TypeCache.GetType(baseType.TypeHandle);
              foreach (PropertyDescriptor propertyDescriptor in baseTypeDescriptor.Properties)
              {
                properties.InternalAdd(propertyDescriptor);
              }
            }

          fields = new FieldCollection(this);
          fields.SetToReadOnly();
          for (int index = 0; index < fieldInfos.Length; index++)
          {
            FieldInfo fieldInfo = fieldInfos[index];
            if (!fieldInfo.FieldType.IsGenericParameter)
            {
              FieldDescriptor fieldDescriptor = new FieldDescriptor(this, fieldInfo);
              if (fieldDescriptor.Rules.Count > 0)
              {
                fields.InternalAdd(fieldDescriptor);
              }
            }
        }
        //TODO: should not reflect over system types.
          if (baseType != null)
          {
            TypeDescriptor baseTypeDescriptor = TypeCache.GetType(baseType.TypeHandle);
            foreach (FieldDescriptor fieldDescriptor in baseTypeDescriptor.Fields)
            {
              fields.InternalAdd(fieldDescriptor);
            }
          }
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> this <see cref="TypeDescriptor"/> wraps.
        /// </summary>
        public RuntimeTypeHandle RuntimeTypeHandle
        {
            get
            {
                return runtimeTypeHandle;
            }
        }

        /// <summary>
        /// Get all the <see cref="PropertyDescriptor"/>s for this <see cref="TypeDescriptor"/>.
        /// </summary>
        public PropertyCollection Properties
        {
          get
          {
            return properties;
          }
        }


        /// <summary>
        /// Get all the <see cref="FieldDescriptor"/>s for this <see cref="TypeDescriptor"/>.
        /// </summary>
        public FieldCollection Fields
        {
          get
          {
            return fields;
          }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Get or create a <see cref="PropertyDescriptor"/> for this <see cref="TypeDescriptor"/>
        /// </summary>
        /// <remarks>If the <see cref="PropertyDescriptor"/> exists in <see cref="Properties"/> it will be returned; otherwise a new <see cref="PropertyDescriptor"/> will be created, added to <see cref="Properties"/>, and returned.</remarks>
        /// <param name="name">The name of the <see cref="PropertyDescriptor"/> to get or create.</param>
        /// <returns>The existing <see cref="PropertyDescriptor"/>, if it exists in <see cref="Properties"/>; otherwise a new <see cref="PropertyDescriptor"/>, that has been created and added to <see cref="Properties"/>.</returns>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="name"/> is <see cref="string.Empty"/>.</exception>
        public PropertyDescriptor GetOrCreatePropertyDescriptor(string name)
        {
          Guard.ArgumentNotNullOrEmptyString(name, "name");
          PropertyDescriptor propertyDescriptor;
          if (!properties.TryGetValue(name, out propertyDescriptor))
          {
            PropertyInfo propertyInfo = Type.GetTypeFromHandle(runtimeTypeHandle).GetProperty(name, PropertyFlags);
            propertyDescriptor = new PropertyDescriptor(this, propertyInfo);
            properties.InternalAdd(propertyDescriptor);
          }
          return propertyDescriptor;
        }


        /// <summary>
        /// Remove a <see cref="PropertyDescriptor"/> from <see cref="Properties"/>.
        /// </summary>
        /// <returns>true if the <see cref="PropertyDescriptor"/> is successfully found and removed; otherwise, false.</returns>
        /// <param name="name">The name of the <see cref="PropertyDescriptor"/> to remove.</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="name"/> is <see cref="string.Empty"/>.</exception>
        public bool RemovePropertyDescriptor(string name)
        {
          Guard.ArgumentNotNullOrEmptyString(name, "name");
          return properties.InternalRemove(name);
        }


        /// <summary>
        /// Remove a <see cref="PropertyDescriptor"/> from <see cref="Properties"/>.
        /// </summary>
        /// <returns>true if the <see cref="PropertyDescriptor"/> is successfully found and removed; otherwise, false.</returns>
        /// <param name="propertyDescriptor">The <see cref="PropertyDescriptor"/> to remove.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyDescriptor"/> is null.</exception>
        public bool RemovePropertyDescriptor(PropertyDescriptor propertyDescriptor)
        {
          return properties.InternalRemove(propertyDescriptor);
        }


        /// <summary>
        /// Get or create a <see cref="FieldDescriptor"/> for this <see cref="TypeDescriptor"/>
        /// </summary>
        /// <remarks>If the <see cref="FieldDescriptor"/> exists in <see cref="Fields"/> it will be returned; otherwise a new <see cref="FieldDescriptor"/> will be created, added to <see cref="Fields"/>, and returned.</remarks>
        /// <param name="name">The name of the <see cref="FieldDescriptor"/> to get or create.</param>
        /// <returns>The existing <see cref="FieldDescriptor"/>, if it exists in <see cref="Fields"/>; otherwise a new <see cref="FieldDescriptor"/>, that has been created and added to <see cref="Fields"/>.</returns>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="name"/> is <see cref="string.Empty"/>.</exception>
        public FieldDescriptor GetOrCreateFieldDescriptor(string name)
        {
          Guard.ArgumentNotNullOrEmptyString(name, "name");
          FieldDescriptor fieldDescriptor;
          if (!fields.TryGetValue(name, out fieldDescriptor))
          {
            FieldInfo fieldInfo = Type.GetTypeFromHandle(runtimeTypeHandle).GetField(name, PropertyFlags);
            fieldDescriptor = new FieldDescriptor(this, fieldInfo);
            fields.InternalAdd(fieldDescriptor);
          }
          return fieldDescriptor;
        }


        /// <summary>
        /// Remove a <see cref="FieldDescriptor"/> from <see cref="Fields"/>.
        /// </summary>
        /// <returns>true if the <see cref="FieldDescriptor"/> is successfully found and removed; otherwise, false.</returns>
        /// <param name="name">The name of the <see cref="FieldDescriptor"/> to remove.</param>
        /// <exception cref="ArgumentNullException"><paramref name="name"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="name"/> is <see cref="string.Empty"/>.</exception>
        public bool RemoveFieldDescriptor(string name)
        {
          Guard.ArgumentNotNullOrEmptyString(name, "name");
          return fields.InternalRemove(name);
        }


        /// <summary>
        /// Remove a <see cref="FieldDescriptor"/> from <see cref="Fields"/>.
        /// </summary>
        /// <returns>true if the <see cref="FieldDescriptor"/> is successfully found and removed; otherwise, false.</returns>
        /// <param name="fieldDescriptor">The <see cref="FieldDescriptor"/> to remove.</param>
        /// <exception cref="ArgumentNullException"><paramref name="fieldDescriptor"/> is null.</exception>
        public bool RemoveFieldDescriptor(FieldDescriptor fieldDescriptor)
        {
          return fields.InternalRemove(fieldDescriptor);
        }

        #endregion
    }
}