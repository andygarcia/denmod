using System;
using System.Reflection;

namespace ValidationFramework.Reflection
{
    /// <summary>
    /// A light-weight wrapper for <see cref="MethodBase"/>.
    /// </summary>
    [Serializable]
    public class MethodDescriptor
    {
        #region Fields

        private readonly bool isStatic;
        private readonly string name;
        private readonly ParameterCollection parameters;
        private readonly RuntimeMethodHandle runtimeMethodHandle;

        #endregion


        #region Constructors

        /// <summary>
        /// Initialize a new instance of <see cref="MethodDescriptor"/> class.
        /// </summary>
        /// <param name="runtimeMethodHandle">The <see cref="System.RuntimeMethodHandle"/> of the <see cref="MethodBase"/> to wrap.</param>
        internal MethodDescriptor(RuntimeMethodHandle runtimeMethodHandle)
        {
            MethodBase methodBase = MethodInfo.GetMethodFromHandle(runtimeMethodHandle);
            if (ReflectionUtilities.IsPropertyMethod(methodBase))
            {
                throw new ArgumentException("Creating a MethodDescriptor for a property is not supported.", "runtimeMethodHandle");
            }
            parameters = new ParameterCollection(this);
            this.runtimeMethodHandle = methodBase.MethodHandle;
            name = methodBase.Name;

            isStatic = methodBase.IsStatic;
            ParameterInfo[] parameterInfos = methodBase.GetParameters();

            for (int index = 0; index < parameterInfos.Length; index++)
            {
                ParameterInfo parameterInfo = parameterInfos[index];
                parameters.Add(new ParameterDescriptor(this, parameterInfo));
            }
            parameters.SetToReadOnly();
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the name of the <see cref="MethodDescriptor"/>.
        /// </summary>
        public string Name
        {
            get
            {
                return name;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the <see cref="MethodDescriptor"/> is static. 
        /// </summary>
        public bool IsStatic
        {
            get
            {
                return isStatic;
            }
        }

        /// <summary>
        /// Gets a <see cref="ParameterCollection"/> containing all <see cref="ParameterDescriptor"/>s for the <see cref="MethodDescriptor"/>.
        /// </summary>
        /// <remarks>This <see cref="ParameterCollection"/> is set to readonly. <see cref="AutoKeyDictionary{TKey,TValue}.IsReadOnly"/></remarks>
        public ParameterCollection Parameters
        {
            get
            {
                return parameters;
            }
        }


        /// <summary>
        /// Gets the <see cref="System.RuntimeMethodHandle"/> that represents the <see cref="MethodInfo"/> that this <see cref="MethodDescriptor"/> returns.
        /// </summary>
        public RuntimeMethodHandle RuntimeMethodHandle
        {
            get
            {
                return runtimeMethodHandle;
            }
        }

        #endregion
    }
}