using System;
using System.Collections.Generic;

namespace ValidationFramework.Reflection
{
    /// <summary>
    /// Provides an in memory cache of <see cref="MethodDescriptor"/>s.
    /// </summary>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Reflection\MethodCacheSample.cs" title="The following example shows how to programmatically add validation Rules to a method." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Reflection\MethodCacheSample.vb" title="The following example shows how to programmatically add validation Rules to a method." lang="vbnet"/>
    /// </example>
    public static class MethodCache
    {
        #region Fields

        private static readonly Dictionary<RuntimeMethodHandle, MethodDescriptor> methodCache = new Dictionary<RuntimeMethodHandle, MethodDescriptor>();
        private static readonly object methodCacheDictionaryLock = new object();

        #endregion


        #region Methods

        /// <summary>
        /// Clear all <see cref="MethodDescriptor"/>s from <see cref="MethodCache"/>.
        /// </summary>
        public static void Clear()
        {
            methodCache.Clear();
        }


        /// <summary>
        /// Get a <see cref="MethodDescriptor"/> for a <see cref="RuntimeTypeHandle"/>.
        /// </summary>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeTypeHandle"/> for which to get the <see cref="MethodDescriptor"/>.</param>
        /// <returns>A <see cref="MethodDescriptor"/> corresponding to <paramref name="runtimeMethodHandle"/>.</returns>
        public static MethodDescriptor GetMethod(RuntimeMethodHandle runtimeMethodHandle)
        {
            MethodDescriptor methodDescriptor;
            bool success = methodCache.TryGetValue(runtimeMethodHandle, out methodDescriptor);
            if (!success)
            {
                lock (methodCacheDictionaryLock)
                {
                    if (!methodCache.TryGetValue(runtimeMethodHandle, out methodDescriptor))
                    {
                        MethodDescriptor tempMethodDescriptor = new MethodDescriptor(runtimeMethodHandle);
                        methodCache.Add(runtimeMethodHandle, tempMethodDescriptor);
                        methodDescriptor = tempMethodDescriptor;
                    }
                }
            }
            return methodDescriptor;
        }

        #endregion
    }
}