using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace ValidationFramework.Reflection
{
    /// <summary>
    /// Provides an in memory cache of <see cref="TypeDescriptor"/>s.
    /// </summary>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Reflection\TypeCacheSample.cs" title="The following example shows how to programmatically add validation Rules to a property." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\Reflection\TypeCacheSample.vb" title="The following example shows how to programmatically add validation Rules to a property." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\Reflection\AddCustomRuleWithTypeCacheSample.cs" lang="cs" title="This example shows how to progromatically add a CustomRule to a property."/>
    /// <code source="Examples\ExampleLibraryVB\Reflection\AddCustomRuleWithTypeCacheSample.vb" lang="vbnet" title="This example shows how to progromatically add a CustomRule to a property."/>
    /// </example>
    public static class TypeCache
    {
        #region Fields

        private static readonly Dictionary<RuntimeTypeHandle, TypeDescriptor> typeDescriptorDictionary = new Dictionary<RuntimeTypeHandle, TypeDescriptor>();
        private static readonly object typeDescriptorDictionaryLock = new object();

        #endregion


        #region Methods

        /// <summary>
        /// Clear all <see cref="TypeDescriptor"/>s from <see cref="TypeCache"/>.
        /// </summary>
        public static void Clear()
        {
            typeDescriptorDictionary.Clear();
        }


        /// <summary>
        /// Get, and adds to the cache, a <see cref="TypeDescriptor"/> for a <see cref="RuntimeTypeHandle"/>. 
        /// </summary>
        /// <param name="runtimeTypeHandle">The <see cref="RuntimeTypeHandle"/> for which to get the <see cref="TypeDescriptor"/>.</param>
        /// <returns>A <see cref="TypeDescriptor"/> corresponding  to <paramref name="runtimeTypeHandle"/>.</returns>
        public static TypeDescriptor GetType(RuntimeTypeHandle runtimeTypeHandle)
        {
            //no need to check for null as RuntimeTypeHandle is a struct
            TypeDescriptor typeDescriptor;

            if (!typeDescriptorDictionary.TryGetValue(runtimeTypeHandle, out typeDescriptor))
            {
                lock (typeDescriptorDictionaryLock)
                {
                    if (!typeDescriptorDictionary.TryGetValue(runtimeTypeHandle, out typeDescriptor))
                    {
                        typeDescriptor = new TypeDescriptor(runtimeTypeHandle);
                        typeDescriptorDictionary.Add(runtimeTypeHandle, typeDescriptor);
                    }
                }
            }
            return typeDescriptor;
        }


        /// <summary>
        /// A helper method that gets all <see cref="Rule"/>s of a specific type for a property on an object.
        /// </summary>
        /// <remarks>
        /// If performance is a concern it is better to call <see cref="GetRulesForProperty{TRule}(string,RuntimeTypeHandle)"/>.
        /// </remarks>
        /// <typeparam name="TRule">The type of <see cref="Rule"/> to retrieve.</typeparam>
        /// <typeparam name="TTarget">The target type to to retrieve attributes from.</typeparam>
        /// <param name="propertyName">The name of the property to get the <see cref="Rule"/>s from.</param>
        /// <returns>A <see cref="IList{T}"/> containing all <see cref="Rule"/>s for the specified property.</returns>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is a <see cref="string.Empty"/>.</exception>
        [SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter"), SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
        public static IList<TRule> GetRulesForProperty<TRule, TTarget>(string propertyName) where TRule : Rule
        {
            return GetRulesForProperty<TRule>(propertyName, typeof (TTarget).TypeHandle);
        }


        /// <summary>
        /// A helper method that gets all <see cref="Rule"/>s for a property on an object.
        /// </summary>
        /// <typeparam name="TRule">The type of <see cref="Rule"/> to retrieve.</typeparam>
        /// <param name="propertyName">The name of the property to get the <see cref="Rule"/>s from.</param>
        /// <param name="runtimeTypeHandle">The <see cref="RuntimeTypeHandle"/> representing the type to get the <see cref="Rule"/>s from.</param>
        /// <returns>A <see cref="IList{T}"/> containing all <see cref="Rule"/>s for the specified property.</returns>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is a <see cref="string.Empty"/>.</exception>
        public static IList<TRule> GetRulesForProperty<TRule>(string propertyName, RuntimeTypeHandle runtimeTypeHandle) where TRule : Rule
        {
            //no need to check for null as RuntimeTypeHandle is a struct
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            IList<TRule> list = new List<TRule>();
            TypeDescriptor typeDescriptor = GetType(runtimeTypeHandle);
            RuleCollection ruleCollection = typeDescriptor.Properties[propertyName].Rules;
            for (int index = 0; index < ruleCollection.Count; index++)
            {
                Rule propertyRule = ruleCollection[index];
                TRule attribute = propertyRule as TRule;
                if (attribute != null)
                {
                    list.Add(attribute);
                }
            }
            return list;
        }


        ///// <summary>
        ///// A helper method that gets all <see cref="Rule"/>s for a property on an object.
        ///// </summary>
        ///// <typeparam name="TRule">The type of <see cref="Rule"/> to retrieve.</typeparam>
        ///// <param name="runtimePropertyHandle">The <see cref="RuntimeMethodHandle"/> representing the property to get the <see cref="Rule"/>s from.</param>
        ///// <returns>A <see cref="IList{T}"/> containing all <see cref="Rule"/>s for the specified property.</returns>
        //public static IList<TRule> GetRulesForProperty<TRule>(RuntimeMethodHandle runtimePropertyHandle) where TRule : Rule
        //{
        //    MethodBase methodFromHandle = MethodBase.GetMethodFromHandle(runtimePropertyHandle);

        //    return GetRulesForProperty<TRule>(methodFromHandle.Name, methodFromHandle.DeclaringType.TypeHandle);
        //}

        #endregion
    }
}