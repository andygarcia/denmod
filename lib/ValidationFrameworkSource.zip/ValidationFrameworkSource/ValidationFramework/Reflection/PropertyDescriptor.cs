using System;
using System.Reflection;

namespace ValidationFramework.Reflection
{
    /// <summary>
    /// A light-weight wrapper for <see cref="PropertyInfo"/>.
    /// </summary>
    [Serializable]
    public class PropertyDescriptor : InfoDescriptor
    {
        #region Fields

        private static readonly Type propertyRuleAttributeType = typeof (IPropertyRuleAttribute);
        private readonly FastInvokeHandler invoker;
        private readonly bool isStatic;
        private readonly TypeDescriptor typeDescriptor;

        #endregion


        #region Constructors

        /// <summary>
        /// For testing purposes
        /// </summary>
        /// <exclude/>
        protected PropertyDescriptor(RuntimeTypeHandle runtimeTypeHandle, string name)
            : base(runtimeTypeHandle, name)
        {
        }


        /// <summary>
        /// Initialize a new instance of <see cref="PropertyDescriptor"/>.
        /// </summary>
        /// <param name="propertyInfo">The <see cref="PropertyInfo"/> to wrap.</param>
        /// <param name="typeDescriptor">The <see cref="Reflection.TypeDescriptor"/> this <see cref="PropertyDescriptor"/> belongs to.</param>
        /// <exception cref="NullReferenceException"><paramref name="propertyInfo"/> is null.</exception>
        internal PropertyDescriptor(TypeDescriptor typeDescriptor, PropertyInfo propertyInfo)
            : base(propertyInfo.GetGetMethod(true).ReturnType.TypeHandle, propertyInfo.Name)
        {
            if (propertyInfo.PropertyType.IsGenericParameter)
            {
                throw new ArgumentException("propertyInfo cannot be a genetic type.", "propertyInfo");
            }
            this.typeDescriptor = typeDescriptor;
            MethodInfo getMethodInfo = propertyInfo.GetGetMethod(true);
			if (getMethodInfo == null)
			{
				throw new ArgumentException("Property must have a get. Private gets are allowed.", "propertyInfo");
			}
            isStatic = getMethodInfo.IsStatic;
            invoker = MethodInvokerCreator.GetMethodInvoker(getMethodInfo);
            IPropertyRuleAttribute[] attributes = (IPropertyRuleAttribute[]) propertyInfo.GetCustomAttributes(propertyRuleAttributeType, true);
            for (int index = 0; index < attributes.Length; index++)
            {
                IPropertyRuleAttribute propertyRuleAttribute = attributes[index];
                //Make sure each attribute is "aware" of the propertyInfo it's validating
                Rule rule = propertyRuleAttribute.CreatePropertyRule(this);
                Rules.Add(rule);
            }
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a value indicating whether the <see cref="PropertyDescriptor"/> is static. 
        /// </summary>
        public bool IsStatic
        {
            get
            {
                return isStatic;
            }
        }

        /// <summary>
        /// Gets the <see cref="Reflection.TypeDescriptor"/> for this <see cref="PropertyDescriptor"/>.
        /// </summary>
        public TypeDescriptor TypeDescriptor
        {
            get
            {
                return typeDescriptor;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Get the value for this <see cref="PropertyDescriptor"/>.
        /// </summary>
        /// <param name="target">The object on which to extract the property value. If a <see cref="PropertyDescriptor"/> is static, this argument is ignored.</param>
        /// <returns>The value for the property.</returns>
        public override object GetValue(object target)
        {
            return invoker(target);
        }

        #endregion
    }
}