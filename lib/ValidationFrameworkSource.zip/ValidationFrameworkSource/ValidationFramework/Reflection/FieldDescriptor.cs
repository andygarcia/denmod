using System;
using System.Reflection;
using System.Reflection.Emit;

namespace ValidationFramework.Reflection
{
    /// <summary>
    /// A light-weight wrapper for <see cref="FieldInfo"/>.
    /// </summary>
    [Serializable]
    public class FieldDescriptor : InfoDescriptor
    {
        #region Fields

        private static readonly Type fieldRuleAttributeType = typeof (IFieldRuleAttribute);
        //private readonly FieldGetHandler invoker;
        private readonly bool isStatic;
        private readonly TypeDescriptor typeDescriptor;
        private readonly FieldInfo fieldInfo;

        #endregion


        #region Constructors

        /// <summary>
        /// For testing purposes
        /// </summary>
        /// <exclude/>
        protected FieldDescriptor(RuntimeTypeHandle runtimeTypeHandle, string name)
            : base(runtimeTypeHandle, name)
        {
        }


        /// <summary>
        /// Initialize a new instance of <see cref="FieldDescriptor"/>.
        /// </summary>
        /// <param name="fieldInfo">The <see cref="FieldInfo"/> to wrap.</param>
        /// <param name="typeDescriptor">The <see cref="Reflection.TypeDescriptor"/> this <see cref="FieldDescriptor"/> belongs to.</param>
        /// <exception cref="NullReferenceException"><paramref name="fieldInfo"/> is null.</exception>
        internal FieldDescriptor(TypeDescriptor typeDescriptor, FieldInfo fieldInfo)
            : base(fieldInfo.FieldType.TypeHandle, fieldInfo.Name)
        {
            if (fieldInfo.FieldType.IsGenericParameter)
            {
                throw new ArgumentException("fieldInfo cannot be a genetic type.", "fieldInfo");
            }
            //TODO: Use Dynamic method instead
            this.fieldInfo = fieldInfo;
            this.typeDescriptor = typeDescriptor;
            isStatic = fieldInfo.IsStatic;
//            invoker = MethodInvokerCreator.GetFieldGetInvoker(Type.GetTypeFromHandle(typeDescriptor.RuntimeTypeHandle), fieldInfo);
            IFieldRuleAttribute[] attributes = (IFieldRuleAttribute[]) fieldInfo.GetCustomAttributes(fieldRuleAttributeType, true);
            for (int index = 0; index < attributes.Length; index++)
            {
                IFieldRuleAttribute fieldRuleAttribute = attributes[index];
                //Make sure each attribute is "aware" of the fieldInfo it's validating
                Rule rule = fieldRuleAttribute.CreateFieldRule(this);
                Rules.Add(rule);
            }
        }




        #endregion


        #region Properties

        /// <summary>
        /// Gets a value indicating whether the <see cref="FieldDescriptor"/> is static. 
        /// </summary>
        public bool IsStatic
        {
            get
            {
                return isStatic;
            }
        }

        /// <summary>
        /// Gets the <see cref="Reflection.TypeDescriptor"/> for this <see cref="FieldDescriptor"/>.
        /// </summary>
        public TypeDescriptor TypeDescriptor
        {
            get
            {
                return typeDescriptor;
            }
        }

        #endregion


        #region Methods

          /// <summary>
          /// Get the value for this <see cref="FieldDescriptor"/>.
          /// </summary>
          /// <param name="target">The object on which to extract the field value. If a <see cref="FieldDescriptor"/> is static, this argument is ignored.</param>
          /// <returns>The value for the field.</returns>
          public override object GetValue(object target)
          {
             return fieldInfo.GetValue(target);
              //return invoker(target);
          }

        #endregion
    }
}