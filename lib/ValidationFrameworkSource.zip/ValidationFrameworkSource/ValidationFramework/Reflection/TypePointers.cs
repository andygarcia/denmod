using System;

namespace ValidationFramework.Reflection
{
  internal static class TypePointers
  {
    internal static readonly RuntimeTypeHandle DateTimeTypeHandle = typeof (DateTime).TypeHandle;
    internal static readonly RuntimeTypeHandle NullableTypeHandle = typeof (Nullable<>).TypeHandle;
  }
}
