using System;
using System.Collections.ObjectModel;

namespace ValidationFramework.Reflection
{
    /// <summary>
    /// A <see cref="AutoKeyDictionary{TKey,TItem}"/>  of <see cref="Rule"/>s.
    /// </summary>
    [Serializable]
    public sealed class RuleCollection : Collection<Rule>
    {
        #region Fields

        private readonly InfoDescriptor infoDescriptor;

        #endregion


        #region Constructors

        /// <summary>
        /// Initialize a new instance of the <see cref="RuleCollection"/> class.
        /// </summary>
        /// <param name="infoDescriptor">The <see cref="InfoDescriptor"/> this <see cref="RuleCollection"/> belongs to.</param>
        internal RuleCollection(InfoDescriptor infoDescriptor)
        {
            this.infoDescriptor = infoDescriptor;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the <see cref="InfoDescriptor"/> this <see cref="RuleCollection"/> belongs to.
        /// </summary>
        public InfoDescriptor InfoDescriptor
        {
            get
            {
                return infoDescriptor;
            }
        }

        #endregion


        #region Methods

        /// <exception cref="ArgumentNullException"><paramref name="item"/> is null.</exception> 
        /// <exception cref="ArgumentException">An element with the same key already exists in the <see cref="AutoKeyDictionary{TKey,TItem}"/>.</exception>
        protected override void SetItem(int index, Rule item)
        {
            Guard.ArgumentNotNull(item, "item");
            Rule ruleAtIndex = this[index];
            if (ruleAtIndex != item && !ruleAtIndex.IsEquivalent(item))
            {
                CheckForDuplicate(item);
            }
            base.SetItem(index, item);
        }


        /// <exception cref="ArgumentNullException"><paramref name="item"/> is null.</exception> 
        /// <exception cref="ArgumentException">An element with the same key already exists in the <see cref="AutoKeyDictionary{TKey,TItem}"/>.</exception>
        protected override void InsertItem(int index, Rule item)
        {
            Guard.ArgumentNotNull(item, "item");
            CheckForDuplicate(item);
            base.InsertItem(index, item);
        }


        private void CheckForDuplicate(Rule rule)
        {
          //Store temp values for the new ruleset and Type to save them being accessed for each iteration of the loop.
            Type ruleType = rule.GetType();
            string tempRuleSet = rule.RuleSet;
            for (int ruleIndex = 0; ruleIndex < Count; ruleIndex++)
            {
                Rule existingRule = this[ruleIndex];
                if ((existingRule == rule) || ((existingRule.GetType() == ruleType) && (string.Equals(existingRule.RuleSet, tempRuleSet))))
                {
                    if (existingRule.IsEquivalent(rule))
                    {
                      throw new ArgumentException(string.Format("An equivalent rule already exists in collection. RuleInterpretation : '{0}'", rule.RuleInterpretation), "rule");
                    }
                }
            }
            rule.InfoDescriptor = infoDescriptor;
        }

        #endregion
    }
}