using System;
using System.Diagnostics.CodeAnalysis;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Base class for all Rules.
    /// </summary>
    /// <remarks>
    /// All <see cref="Rule"/>s must be immutable i.e. its state cannot be modified after it is created. This requirement is for performance reasons. 
    /// </remarks>
    /// <example>
    /// <b>Extending the validation framework</b><br/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\RequiredCharacterRule.cs" title="Implementing a custom rule by inheriting from Rule" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\RequiredCharacterRule.vb" title="Implementing a custom rule by inheriting from Rule" lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\RequiredCharacterRuleAttribute.cs" title="Creating a IRuleAttribute for that Rule" lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\RequiredCharacterRuleAttribute.vb" title="Creating a IRuleAttribute for that Rule" lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\RequiredCharacterRuleConfigReader.cs" title="Creating IRuleConfigReader for that Rule." lang="cs"/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\RequiredCharacterRuleConfigReaderUsage.cs" title="Using the custom ConfigReader." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\RequiredCharacterRuleConfigReader.vb" title="Creating IRuleConfigReader for that Rule." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\RequiredCharacterRuleConfigReaderUsage.vb" title="Using the custom ConfigReader." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\NewRule\ClientRegularExpressionWebValidator.cs" title="A custom RegularExpressionValidator that only validates on the client side." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\NewRule\ClientRegularExpressionWebValidator.vb" title="A custom RegularExpressionValidator that only validates on the client side." lang="vbnet"/>
    /// </example>
    [Serializable]
    public abstract class Rule
    {
        #region Fields

        private const string invalidTypeFormat = "Member '{0}' must be a '{1}' to be used for the {2}. Actual Type '{3}'.";
        private readonly string ruleSet;
        private readonly RuntimeTypeHandle? runtimeTypeHandle;
        private readonly bool useErrorMessageProvider;
        private string errorMessage;
        private InfoDescriptor infoDescriptor;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Rule"/> class.
        /// </summary>
        /// <param name="runtimeTypeHandle">The <see cref="RuntimeTypeHandle"/> that this <see cref="Rule"/> can be applied to. Use <see langword="null"/> to indicate it can be applied to any member type.</param>
        /// <param name="errorMessage">The error message for this rule. Pass a null to use the the default value.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping. Is converted to uppercase.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="errorMessage"/> is a <see cref="string.Empty"/>.</exception>
        protected Rule(RuntimeTypeHandle? runtimeTypeHandle, string errorMessage, string ruleSet, bool useErrorMessageProvider)
        {
            if (errorMessage != null)
            {
                if (errorMessage.Length == 0)
                {
                    throw new ArgumentException("Error message cannot be string.Empty", "errorMessage");
                }
            }

            this.ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
            this.runtimeTypeHandle = runtimeTypeHandle;
            this.useErrorMessageProvider = useErrorMessageProvider;
            this.errorMessage = errorMessage;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Used as a helper to document the API that <see cref="Rule"/>s are applied to.
        /// The code for this property must not use the <see cref="InfoDescriptor"/> property as it may not be set.
        /// </remarks>
        public abstract string RuleInterpretation
        {
            get;
        }


        /// <summary>
        /// Gets the error message for this <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// In the case of an application with a user interface this property would often be displayed to the user. So it should contain proper grammar and punctuation.
        /// </remarks>
        public string ErrorMessage
        {
            get
            {
                return errorMessage;
            }
        }


        /// <summary>
        /// Gets the <see cref="RuntimeTypeHandle"/> that this <see cref="Rule"/> can be applied to. A <see langword="null"/> is returned if it can be applied to any member type.
        /// </summary>
        public RuntimeTypeHandle? RuntimeTypeHandle
        {
            get
            {
                return runtimeTypeHandle;
            }
        }


        /// <summary>
        /// Gets the <see cref="InfoDescriptor"/> that represents the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <exception cref="ArgumentNullException"><paramref name="value"/> is null.</exception>
        /// <exception cref="ArgumentException"><see cref="RuntimeTypeHandle"/> has a value and <see cref="Reflection.InfoDescriptor.RuntimeTypeHandle"/> does not inherit from <see cref="RuntimeTypeHandle"/>.</exception>
        public InfoDescriptor InfoDescriptor
        {
            get
            {
                return infoDescriptor;
            }
            internal set
            {
                infoDescriptor = value;
                CheckType(infoDescriptor.RuntimeTypeHandle);
                SetDefaultErrorMessage();
            }
        }


        /// <summary>
        /// Gets A <see cref="string"/> used to group <see cref="Rule"/>s. Use a null to indicate no grouping.
        /// </summary>
        /// <remarks>
        /// Will be a null to indicate no rule set.<br/>
        /// Case insensitive so this will always return a uppercase string no matter what is passed into the constructor.
        /// </remarks>
        public string RuleSet
        {
            get
            {
                return ruleSet;
            }
        }


        /// <summary>
        /// Get a <see cref="bool"/> indicating if <see cref="ConfigurationService.ErrorMessageProvider"/> should be used when determining the error message for this <see cref="Rule"/>.
        /// </summary>
        public bool UseErrorMessageProvider
        {
            get
            {
                return useErrorMessageProvider;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Called after <see cref="InfoDescriptor"/> is set but only when <see cref="ErrorMessage"/> is null.
        /// </summary>
        /// <remarks>
        /// Used by inheritors to provide a customized default <see cref="ErrorMessage"/>.
        /// </remarks>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected abstract string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType);


        /// <summary>
        /// A helper method for creating <see cref="ValidationResult"/>s.
        /// </summary>
        /// <remarks>
        /// If <see cref="UseErrorMessageProvider"/> is <c>true</c> then <see cref="ConfigurationService.ErrorMessageProvider"/> will be called to get the error message. Otherwise the <see cref="ErrorMessage"/> will be used.
        /// </remarks>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate.</param>
        /// <returns>A constructed <see cref="ValidationResult"/>.</returns>
        [SuppressMessage("Microsoft.Naming", "CA1720:AvoidTypeNamesInParameters", MessageId = "0#")]
        protected virtual ValidationResult CreateValidationResult(object targetObjectValue, object targetMemberValue, object context)
        {
            if (useErrorMessageProvider)
            {
                return new ValidationResult(this, ConfigurationService.ErrorMessageProvider.RetrieveErrorMessage(this, targetObjectValue, targetMemberValue, context));
            }
            else
            {
                return new ValidationResult(this, errorMessage);
            }
        }


        /// <summary>
        /// Check that the <see cref="RuntimeTypeHandle"/> is valid.
        /// </summary>
        /// <exception cref="ArgumentException"><paramref name="targetMemberRuntimeTypeHandle"/> is not of a valid type.</exception>
        /// <remarks>
        /// Called after <see cref="InfoDescriptor"/> is set.
        /// </remarks>
        /// <param name="targetMemberRuntimeTypeHandle">The <see cref="RuntimeTypeHandle"/> that this <see cref="Rule"/> is applied to.</param>
        /// <exception cref="ArgumentException">If <paramref name="targetMemberRuntimeTypeHandle"/> is of the wrong type.</exception>
        protected virtual void CheckType(RuntimeTypeHandle targetMemberRuntimeTypeHandle)
        {
            //Validate that the attribute is applied to the correct type of property
            if (runtimeTypeHandle != null)
            {
                Type targetMemberRuntimeType = Type.GetTypeFromHandle(targetMemberRuntimeTypeHandle);
                Type requiredMemberType = Type.GetTypeFromHandle(runtimeTypeHandle.Value);

                Type underlyingType = Nullable.GetUnderlyingType(targetMemberRuntimeType);
                if ((underlyingType == null) || (underlyingType != requiredMemberType))
                {
                    if (!ReflectionUtilities.IsSubclassOf(targetMemberRuntimeType, requiredMemberType))
                    {
                      string friendlyRuleTypeName = ReflectionUtilities.GetFriendlyTypeName(GetType());
                      string friendlyTargetMemberTypeName = ReflectionUtilities.GetFriendlyTypeName(targetMemberRuntimeType);
                      string friendlyRequiredMemberTypeName = ReflectionUtilities.GetFriendlyTypeName(requiredMemberType);
                      string exceptionMessage = string.Format(invalidTypeFormat, infoDescriptor.Name, friendlyRequiredMemberTypeName, friendlyRuleTypeName, friendlyTargetMemberTypeName);
                        throw new ArgumentException(exceptionMessage, "value");
                    }
                }
            }
        }


        private void SetDefaultErrorMessage()
        {
            //if the error message has not been set by the user ask the inheritor 
            if (!useErrorMessageProvider && (errorMessage == null))
            {
                string tokenizedParameterName = StringUtilities.GetTokenizedValue(infoDescriptor.Name);
                if (infoDescriptor is PropertyDescriptor)
                {
                    errorMessage = GetComputedErrorMessage(tokenizedParameterName, "property");
                }
                else if (infoDescriptor is ParameterDescriptor)
                {
                    errorMessage = GetComputedErrorMessage(tokenizedParameterName, "parameter");
                }
                else
                {
                    //Fail over to "member" for unit testing purposes
                    errorMessage = GetComputedErrorMessage(tokenizedParameterName, "member");
                }
            }
        }


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <returns><see langword="true"/> if the member is valid; otherwise <see langword="false"/>.</returns>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate. The default is null.</param>
        public abstract ValidationResult Validate(object targetObjectValue, object targetMemberValue, object context);


        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new <see cref="Rule"/> is added. This method is only called when both the existing <see cref="Rule"/> and the <see cref="Rule"/> being are of the same <see cref="Type"/> and have the same <see cref="RuleSet"/>. So it is safe to directly cast <paramref name="rule"/> to the current type. All properties in <paramref name="rule"/> should be compared to the propeties of the current <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public abstract bool IsEquivalent(Rule rule);

        #endregion
    }
}