using System;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Converts an <see cref="Enum"/> to a user friendly representation that can be displayed on a user interface.
    /// </summary>
    /// <seealso cref="EnumUserFriendlyNameAttribute"/>
    public static class EnumUserFriendlyNameConverter
    {
        #region Methods

        /// <summary>
        /// Converts an <see cref="Enum"/> to a user friendly representation that can be displayed on a user interface. 
        /// </summary>
        /// <param name="enumItem">The <see cref="Enum"/> to convert.</param>
        /// <returns>A user friendly string representing the <paramref name="enumItem"/>.</returns>
        /// <remarks>
        /// Uses the <see cref="EnumUserFriendlyNameAttribute"/> on each item in the <see cref="Enum"/> to determine the string returned.
        /// If no <see cref="EnumUserFriendlyNameAttribute"/> is specified it will use <see cref="StringUtilities.GetTokenizedValue"/> for the return value.
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="enumItem"/> is a null reference.</exception>
        [SuppressMessage("Microsoft.Design", "CA1062:ValidateArgumentsOfPublicMethods")]
        public static string Convert(Enum enumItem)
        {
            Guard.ArgumentNotNull(enumItem, "enumItem");
            Type type = enumItem.GetType();
            string enumItemValue = enumItem.ToString();
            MemberInfo[] memInfo = type.GetMember(enumItemValue);
            object[] attributes = memInfo[0].GetCustomAttributes(typeof(EnumUserFriendlyNameAttribute), false);
            if (attributes.Length == 1)
            {
                EnumUserFriendlyNameAttribute attribute = (EnumUserFriendlyNameAttribute)attributes[0];
                return attribute.UserFriendlyName;
            }
            else
            {
                return StringUtilities.GetTokenizedValue(enumItemValue);
            }
        }
        #endregion
    }
}