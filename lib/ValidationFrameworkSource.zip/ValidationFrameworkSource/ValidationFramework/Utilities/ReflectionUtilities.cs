using System;
using System.Reflection;
using System.Text;

namespace ValidationFramework
{
    /// <summary>
    /// Methods to help with reflection.
    /// </summary>
    public static class ReflectionUtilities
    {

        #region Contructors
        
        static ReflectionUtilities()
        {
            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.AssemblyResolve += currentDomain_AssemblyResolve;
        }

        #endregion


        #region Methods

      public static string GetFriendlyTypeName(Type type)
      {
        StringBuilder stringBuilder = new StringBuilder(TrimGenericText(type));
        Type[] arguments = type.GetGenericArguments();
        if (arguments.Length > 0)
        {
          stringBuilder.Append("<");
          foreach (Type genericArgument in arguments)
          {
            stringBuilder.Append(GetFriendlyTypeName(genericArgument));
            stringBuilder.Append(",");
          }
          stringBuilder.Remove(stringBuilder.Length-1,1);
          stringBuilder.Append(">");
        }
        return stringBuilder.ToString();
      }


      private static string TrimGenericText(Type type)
      {
        if (type.FullName != null)
        {
          string fullName = type.FullName;
          int indexOfQuote = fullName.IndexOf("`");
          if (indexOfQuote > 0)
          {
            fullName = fullName.Remove(indexOfQuote); 
          }
          return fullName;
        }
        else
        {
          return type.Name;
        }
      }


      private static Assembly currentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            foreach (Assembly assembly in assemblies)
            {
                if (string.Equals(assembly.FullName, args.Name) || string.Equals(assembly.GetName().Name, args.Name))
                {
                    return assembly;
                }
            }
            return null;
        }


        /// <summary>
        /// Determines whether the <see cref="Type"/> represented by the <paramref name="typeToCheck"/> derives from the <see cref="Type"/> represented by the <paramref name="baseType"/>. 
        /// </summary>
        /// <param name="typeToCheck">The child <see cref="Type"/> to check for.</param>
        /// <param name="baseType">The base <see cref="Type"/> to check for.</param>
        /// <exception cref="ArgumentNullException"><paramref name="typeToCheck"/> is null.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="baseType"/> is null.</exception>
        /// <returns>true if the <paramref name="typeToCheck"/> derives from <paramref name="baseType"/> or if they are the same type; otherwise, false.</returns>
        public static bool IsSubclassOf(Type typeToCheck, Type baseType)
        {
            //return baseType.IsAssignableFrom(typeToCheck);
            Guard.ArgumentNotNull(typeToCheck, "typeToCheck");
            Guard.ArgumentNotNull(baseType, "baseType");
            for (int index = 0; index < typeToCheck.GetInterfaces().Length; index++)
            {
                Type interfaceType = typeToCheck.GetInterfaces()[index];
                if (interfaceType == baseType)
                {
                    return true;
                }
                if (interfaceType.IsGenericType && (interfaceType.GetGenericTypeDefinition() == baseType))
                {
                    return true;
                }
            }
            while (typeToCheck != null)
            {
                if (typeToCheck == baseType)
                {
                    return true;
                }
                if (typeToCheck.IsGenericType && (typeToCheck.GetGenericTypeDefinition() == baseType))
                {
                    return true;
                }
                typeToCheck = typeToCheck.BaseType;
            }

            return false;
        }


        internal static object GetStaticProperty(string typeName, string propertyName)
        {
            if (!string.IsNullOrEmpty(propertyName) && !string.IsNullOrEmpty(typeName))
            {
                Type equalityComparerType = Type.GetType(typeName, true);
                PropertyInfo propertyInfo = equalityComparerType.GetProperty(propertyName, BindingFlags.Static | BindingFlags.GetProperty | BindingFlags.Public);
                return propertyInfo.GetValue(null, null);
            }
            else
            {
                return null;
            }
        }


        //internal static Type GetType(string typeName)
        //{
        //    return Type.GetType(typeName, true);
        //}


        //internal static bool TryGetType(string typeName, out Type type)
        //{
        //    type = Type.GetType(typeName, false);
        //    if (type == null)
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        return true;
        //    }
        //}


        /// <summary>
        /// Determine if a <see cref="MethodBase"/> represents a 'get' or 'set' method.
        /// </summary>
        /// <param name="methodBase">The <see cref="MethodBase"/> to check.</param>
        /// <returns><c>true</c> if <see cref="MethodBase"/> represents a 'get' or 'set' method; otherwise <c>false</c></returns>
        internal static bool IsPropertyMethod(MethodBase methodBase)
        {
            if (methodBase.Name.StartsWith("set_") || methodBase.Name.StartsWith("get_"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }
}