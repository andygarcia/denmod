using System;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies the user friendly name of an <see cref="Enum"/>s <see langword="field"/>.
    /// </summary>
    /// <seealso cref="EnumUserFriendlyNameConverter"/>
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
    public sealed class EnumUserFriendlyNameAttribute : Attribute
    {
        #region Fields

        private readonly string userFriendlyName;

        #endregion


        #region Constructors

        /// <summary>
        /// Initialises a new instance of the <see cref="EnumUserFriendlyNameAttribute"/> class.
        /// </summary>
        /// <param name="userFriendlyName">The user friendly name.</param>
        public EnumUserFriendlyNameAttribute(string userFriendlyName)
        {
            this.userFriendlyName = userFriendlyName;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a value indicating the user friendly name of the <see langword="field"/>.
        /// </summary>
        public string UserFriendlyName
        {
            get
            {
                return userFriendlyName;
            }
        }

        #endregion
    }
}