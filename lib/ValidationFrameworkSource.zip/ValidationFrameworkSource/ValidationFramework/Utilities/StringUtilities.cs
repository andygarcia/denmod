using System;
using System.Text;

namespace ValidationFramework
{
    /// <summary>
    /// String helper methods
    /// </summary>
    public class StringUtilities
    {
        /// <summary>
        /// Splits Pascal cased string name into a readable string.
        /// </summary>
        /// <param name="value">The string to split.</param>
        /// <returns>A modified <see cref="string"/> with spaces inserted in front of every, excluding the first, upper-cased character.</returns>
        /// <exception cref="ArgumentNullException"><paramref name="value"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="value"/> is <see cref="string.Empty"/>.</exception>
        public static string GetTokenizedValue(string value)
        {
            Guard.ArgumentNotNullOrEmptyString(value, "value");
            StringBuilder stringBuilder = new StringBuilder(value.Length);
            stringBuilder.Append(value[0]);
            for (int index = 1; index < value.Length; index++)
            {
                char c = value[index];
                if (Char.IsUpper(c))
                {
                    stringBuilder.Append(" ");
                }
                stringBuilder.Append(c);
            }
            return stringBuilder.ToString();
        }

    }
}
