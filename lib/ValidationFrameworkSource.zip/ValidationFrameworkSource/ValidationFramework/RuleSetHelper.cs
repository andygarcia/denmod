using System;

namespace ValidationFramework
{
    internal static class RuleSetHelper
    {
        internal static string ConvertToUpper(string ruleSet)
        {
            if (ruleSet != null)
            {
                ruleSet = ruleSet.ToUpperInvariant();
            }
            return ruleSet;
        }
    }
}   