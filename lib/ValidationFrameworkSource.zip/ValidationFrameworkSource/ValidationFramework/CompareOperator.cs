using System.Diagnostics.CodeAnalysis;

namespace ValidationFramework
{
    /// <summary>
    /// Specifies the validation comparison operators used <see cref="CompareRule{T}"/>s. 
    /// </summary>
    /// <seealso cref="CompareRule{T}"/>
    [SuppressMessage("Microsoft.Design", "CA1008:EnumsShouldHaveZeroValue"), SuppressMessage("Microsoft.Design", "CA1008:EnumsShouldHaveZeroValue", MessageId = "No zero value required. If it was then Nullable<CompareOperator> would be used.")]
    public enum CompareOperator
    {
        /// <summary>
        /// A comparison for equality.  
        /// </summary>
        [EnumUserFriendlyNameAttribute("Equal To")] 
        Equal = 1,
        /// <summary>
        /// A comparison for greater than.  
        /// </summary>
        GreaterThan = 2,
        /// <summary>
        /// A comparison for greater than or equal to. 
        /// </summary>
        [EnumUserFriendlyNameAttribute("Greater Than Or Equal To")] 
        GreaterThanEqual = 3,
        /// <summary>
        /// A comparison for less than.  
        /// </summary>
        LessThan = 4,
        /// <summary>
        /// A comparison for less than or equal to.  
        /// </summary>
        [EnumUserFriendlyNameAttribute("Less Than Or Equal To")] 
        LessThanEqual = 5,
        /// <summary>
        /// A comparison for inequality.  
        /// </summary>
        [EnumUserFriendlyNameAttribute("Not Equal To")] 
        NotEqual = 6
    }
}