using System;
using System.Collections.Generic;

namespace ValidationFramework
{
	/// <summary>
	/// Helps in the formatting of <see cref="ValidationResult"/>s.
	/// </summary>
	public static class ResultFormatter
	{
		#region Methods

		/// <summary>
		/// Gets a <see see="ICollection{T}"/> of <see langword="string"/>s that contain all the <see cref="ValidationResult.ErrorMessage"/>s for all the <see cref="ValidationResult"/>s in <paramref name="validationResults"/>.
		/// </summary>
		/// <param name="validationResults">A <see cref="ICollection{T}"/> if <see cref="ValidationResult"/>s to extract the <see cref="ValidationResult.ErrorMessage"/>s from.</param>
		public static IList<string> GetErrorMessages(ICollection<ValidationResult> validationResults)
		{
			List<string> errors = new List<string>();
			foreach (ValidationResult validationResult in validationResults)
			{
				errors.Add(validationResult.ErrorMessage);
			}
			return errors;
		}



		/// <summary>
		/// Gets a <see see="ICollection{T}"/> of <see langword="string"/>s that contain all the <see cref="ValidationResult.ErrorMessage"/>s for all the <see cref="ValidationResult"/>s in <paramref name="validationResults"/>.
		/// </summary>
		/// <param name="splitMessagesOnNewLine"><c>true</c> to split any <see cref="ValidationResult.ErrorMessage"/> that contains <see cref="Environment.NewLine"/> into multiple entries.</param>
		/// <param name="validationResults">A <see cref="ICollection{T}"/> if <see cref="ValidationResult"/>s to extract the <see cref="ValidationResult.ErrorMessage"/>s from.</param>
		public static IList<string> GetErrorMessages(ICollection<ValidationResult> validationResults, bool splitMessagesOnNewLine)
		{
			List<string> errors = new List<string>();
			foreach (ValidationResult validationResult in validationResults)
			{
				if (validationResult.ErrorMessage.Contains(Environment.NewLine))
				{
					string[] split = validationResult.ErrorMessage.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
					foreach (string errorMessage in split)
					{

						errors.Add(errorMessage);
					}
				}
				else
				{
					errors.Add(validationResult.ErrorMessage);
				}
			}
			return errors;
		}


		/// <summary>
		/// Concatenate a <see cref="ICollection{T}"/> of <see cref="ValidationResult"/>.
		/// </summary>
		/// <remarks>Use a <see cref="Environment.NewLine"/> a the separator.</remarks>
		/// <param name="validationResults">The <see cref="ValidationResult"/>s to concatenate.</param>
		/// <returns>A concatenated string of all <see cref="ValidationResult.ErrorMessage"/>s.</returns>
		public static string GetConcatenatedErrorMessages(ICollection<ValidationResult> validationResults)
		{
			return GetConcatenatedErrorMessages(Environment.NewLine, validationResults);
		}


		//TODO: there is some refactoring to be done here
		/// <summary>
		/// Concatenate a <see cref="ICollection{T}"/> of <see cref="ValidationResult"/>.
		/// </summary>
		/// <param name="separator">The separator to use between each validation message.</param>
		/// <param name="validationResults">The <see cref="ValidationResult"/>s to concatenate.</param>
		/// <returns>A concatenated string of all <see cref="ValidationResult.ErrorMessage"/>s.</returns>
		public static string GetConcatenatedErrorMessages(string separator, ICollection<ValidationResult> validationResults)
		{
			ICollection<string> strings = GetErrorMessages(validationResults);
			string[] destinationArray = new string[strings.Count];
			strings.CopyTo(destinationArray, 0);
			return string.Join(separator, destinationArray);
		}


		/// <summary>
		/// Concatenate a <see cref="ICollection{T}"/> of <see cref="ValidationResult"/>.
		/// </summary>
		/// <param name="separator">The separator to use between each validation message.</param>
		/// <param name="errorMessages">The <see cref="ValidationResult"/>s to concatenate.</param>
		/// <returns>A concatenated string of all <see cref="ValidationResult.ErrorMessage"/>s.</returns>
		public static string GetConcatenatedErrorMessages(string separator, ICollection<string> errorMessages)
		{
			string[] destinationArray = new string[errorMessages.Count];
			errorMessages.CopyTo(destinationArray, 0);
			return string.Join(separator, destinationArray);
		}


		/// <summary>
		/// Concatenate a <see cref="ICollection{T}"/> of <see cref="ValidationResult"/>.
		/// </summary>
		/// <param name="errorMessages">The <see cref="ValidationResult"/>s to concatenate.</param>
		/// <returns>A concatenated string of all <see cref="ValidationResult.ErrorMessage"/>s.</returns>
		public static string GetConcatenatedErrorMessages(ICollection<string> errorMessages)
		{
			return GetConcatenatedErrorMessages(Environment.NewLine, errorMessages);
		}

		#endregion
	}
}