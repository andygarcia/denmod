using System;
using System.Collections.Generic;
using System.Reflection;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Provides access to all <see cref="TypeDescriptor"/>s for an <see cref="Assembly"/>.
    /// </summary>
    public static class RuleDescriber
    {
        /// <summary>
        /// Read all the <see cref="TypeDescriptor"/>s for an <see cref="Assembly"/>.
        /// </summary>
        /// <param name="assembly">The <see cref="Assembly"/> to read attributes from.</param>
        /// <returns>All the <see cref="TypeDescriptor"/>s for an <see cref="Assembly"/>.</returns>
        public static IList<TypeDescriptor> GetPropertyRules(Assembly assembly)
        {
            List<TypeDescriptor> list = new List<TypeDescriptor>();

            Type[] types = assembly.GetTypes();
            for (int typeIndex = 0; typeIndex < types.Length; typeIndex++)
            {
                Type type = types[typeIndex];
                //we only care about classes.
                if (type.IsClass)
                {
                    TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
                    if (typeDescriptor != null)
                    {
                        foreach (PropertyDescriptor propertyDescriptor in typeDescriptor.Properties)
                        {
                            if (propertyDescriptor.Rules.Count > 0)
                            {
                                list.Add(typeDescriptor);
                                break;
                            }
                        }
                    }
                }
            }
            return list;
        }


        /// <summary>
        /// Read all the <see cref="MethodDescriptor"/>s for an <see cref="Assembly"/>.
        /// </summary>
        /// <param name="assembly">The <see cref="Assembly"/> to read attributes from.</param>
        /// <returns>All the <see cref="MethodDescriptor"/>s for an <see cref="Assembly"/>.</returns>
        public static IList<MethodDescriptor> GetMethodRules(Assembly assembly)
        {
            List<MethodDescriptor> list = new List<MethodDescriptor>();

            for (int typeIndex = 0; typeIndex < assembly.GetTypes().Length; typeIndex++)
            {
                Type type = assembly.GetTypes()[typeIndex];
                //we only care about classes and interfaces.
                if (type.IsClass || type.IsInterface)
                {
                    foreach (MethodInfo methodInfo in type.GetMethods(BindingFlags.Public | BindingFlags.DeclaredOnly | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance))
                    {
                        //TODO: support generic methods
                        if (!ReflectionUtilities.IsPropertyMethod(methodInfo) && !methodInfo.ContainsGenericParameters)
                        {
                            MethodDescriptor descriptor = MethodCache.GetMethod(methodInfo.MethodHandle);
                            foreach (ParameterDescriptor parameter in descriptor.Parameters)
                            {
                                if (parameter.Rules.Count > 0)
                                {
                                    list.Add(descriptor);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            return list;
        }
    }
}