using System.Collections.Generic;
using System.Web.UI;

namespace ValidationFramework.Web
{
    /// <summary>
    /// Provides data for the <see cref="ParameterValidatorGenerator.ParametersRequired"/> event.
    /// </summary>
    public class ParametersRequiredEventArgs : TargetObjectRequiredEventArgs
    {
        #region Fields

        private readonly Dictionary<string, object> parameters;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ParametersRequiredEventArgs"/>.
        /// </summary>
        /// <param name="controlsToValidate">The <see cref="Control"/>s to validate.</param>
        public ParametersRequiredEventArgs(ICollection<Control> controlsToValidate) : base(controlsToValidate)
        {
            parameters = new Dictionary<string, object>();
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a <see cref="Dictionary{TKey,TValue}"/> for storing parameters.
        /// </summary>
        public Dictionary<string, object> Parameters
        {
            get
            {
                return parameters;
            }
        }

        #endregion

    }
}