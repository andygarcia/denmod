using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;
using ValidationFramework;
using ValidationFramework.Reflection;
using PropertyDescriptor=ValidationFramework.Reflection.PropertyDescriptor;
using TypeDescriptor=ValidationFramework.Reflection.TypeDescriptor;

namespace ValidationFramework.Web
{
  /// <summary>
  /// Adds <see cref="BaseValidator"/>s to <see cref="Control"/>s based on the <see cref="Rule"/>s on a <see cref="Type"/>.
  /// </summary>
  /// <remarks>
  /// The following <see cref="Rule"/>s are supported for front end javascript validation.
  /// <list type="bullet">
  ///  <item>
  ///		<see cref="CompareRule{T}"/>
  ///	 </item>
  ///  <item>
  ///		<see cref="CompareRule{T}"/>. But only for the following types <see cref="short"/>, <see cref="int"/>, <see cref="long"/>, <see cref="decimal"/>, <see cref="double"/>, <see cref="DateTime"/><br/>
  ///   Note: see <B>Note on <see cref="DateTime"/>s</B> 
  ///	 </item>
  ///  <item>
  ///		<see cref="LengthStringRule"/>
  ///	 </item>
  ///  <item>
  ///		<see cref="RangeStringRule"/>
  ///	 </item>
  ///  <item>
  ///		<see cref="RangeRule{T}"/>. But only for the following types <see cref="short"/>, <see cref="int"/>, <see cref="long"/>, <see cref="decimal"/>, <see cref="double"/>, <see cref="DateTime"/><br/>
  ///   Note: see <B>Note on <see cref="DateTime"/>s</B> <br/>
  ///   Note: is either <see cref="RangeRule{T}.EqualsMaximumIsValid"/> or <see cref="RangeRule{T}.EqualsMinimumIsValid"/> are set to false no <see cref="BaseValidator"/>s will be generated. This is due to extensibility restrictions of the MS web validators and will be fixed in future versions.
  ///	 </item>
  ///  <item>
  ///		<see cref="RegexRule"/>
  ///	 </item>
  ///  <item>
  ///		<see cref="RequiredStringRule"/>
  ///	 </item>
  ///  <item>
  ///		<see cref="RequiredRule{T}"/>. Note: see <B>Note on <see cref="DateTime"/>s</B> 
  ///	 </item>
  /// </list>
  /// All <see cref="Rule"/>s, including those listed above, will be validated server side. <br/>
  /// 
  /// <B>Note on <see cref="DateTime"/>s</B>: <see cref="DateTime"/>s will only work if the <see cref="RequiredRule{T}.InitialValue"/>, <see cref="CompareRule{T}.ValueToCompare"/>, <see cref="RangeRule{T}.Minimum"/> and <see cref="RangeRule{T}.Maximum"/> is a <see cref="DateTime"/> with no time component. This is due to the limitation of both the <see cref="RequiredFieldValidator"/> and <see cref="CompareValidator"/>, since they only support "yyyy-MM-dd". Note that if a <see cref="RequiredRule{T}"/> is applied to a <see cref="DateTime"/> property that is <b>not</b> <see cref="Nullable{T}"/> <see cref="DateTime.MinValue"/> will be used as the <see cref="RequiredRule{T}.InitialValue"/>.
  /// </remarks>
  /// <seealso cref="AddAssociation(Control,string)"/>
  /// <seealso cref="AddAssociation(Control,string, Control)"/>
  /// <seealso cref="GenerateValidators"/>
  public class ValidatorGenerator : Control
  {
    #region Fields

    private string typeToValidate;
    private Mode mode = Mode.ClientServer;
    private string validationGroup;
    private ValidationAssociationCollection validationAssociations;
    private ValidatorDisplay display = ValidatorDisplay.Dynamic;

    #endregion


    #region Constructor(s)

    /// <summary>
    /// Initialize a new instance of the <see cref="ValidatorGenerator"/> class.
    /// </summary>
    public ValidatorGenerator()
    {
      validationAssociations = new ValidationAssociationCollection();
    }

    #endregion


    #region Properties

    /// <summary>
    /// Gets or sets a <see cref="ValidationAssociationCollection"/> containing all the <see cref="ValidationAssociation"/>s for this <see cref="ValidatorGenerator"/>.
    /// </summary>
    public ValidationAssociationCollection ValidationAssociations
    {
      get
      {
        return validationAssociations;
      }
      set
      {
        validationAssociations = value;
      }
    }


    /// <summary>
    /// Gets or sets a the type of validators that will be generated. Client Server or both.
    /// </summary>
    /// <remarks>If <see cref="Mode"/> is set to <see cref="Web.Mode.Client"/> it is not necessary to attach to the <see cref="TargetObjectRequired"/> event. Not all <see cref="Rule"/>s can be validated on the client side so your business layer will be responsible for doing a validation of the object on the server side and displaying the message to the user.</remarks>
    [Description("Type of validators that will be generated. Client Server or both.")]
    public Mode Mode
    {
      get
      {
        object validationModeViewState = ViewState["ValidationMode"];
        if (validationModeViewState == null)
        {
          return mode;
        }
        else
        {
          return (Mode) validationModeViewState;
        }
      }
      set
      {
        mode = value;
        ViewState["ValidationMode"] = value;
      }
    }


    /// <summary>
    /// Gets or sets the fully qualified name of the target <see cref="Type"/> to validate.
    /// </summary>
    [Description("The fully qualified name of the target Type to validate.")]
    public string TypeToValidate
    {
      get
      {
        object viewStateTypeToValidate = ViewState["TypeToValidate"];
        if (viewStateTypeToValidate == null)
        {
          return typeToValidate;
        }
        else
        {
          return (string) viewStateTypeToValidate;
        }
      }
      set
      {
        typeToValidate = value;
        ViewState["TypeToValidate"] = value;
      }
    }


    /// <summary>
    /// Gets or sets the name of the validation group to which all the <see cref="BaseValidator.ValidationGroup"/>s will default to. 
    /// </summary>
    [Description("The name of the validation group to which all the BaseValidators will default to.")]
    public virtual string ValidationGroup
    {
      get
      {
        object viewStateValidationGroup = ViewState["ValidationGroup"];
        if (viewStateValidationGroup == null)
        {
          return validationGroup;
        }
        else
        {
          return (string) viewStateValidationGroup;
        }
      }
      set
      {
        validationGroup = value;
        ViewState["ValidationGroup"] = value;
      }
    }

    /// <summary>
    /// Gets or sets the display behavior of the error message to which all the <see cref="BaseValidator.Display"/>s will default to. The default value is <see cref="ValidatorDisplay.Dynamic"/>. 
    /// </summary>
    [Description("The display behavior of the error message to which all the BaseValidators will default to.")]
    public ValidatorDisplay Display
    {
      get
      {
        object validatorDisplay = ViewState["Display"];
        if (validatorDisplay == null)
        {
          return display;
        }
        else
        {
          return (ValidatorDisplay) validatorDisplay;
        }
      }
      set
      {
        display = value;
        ViewState["Display"] = value;
      }
    }

    #endregion


    #region Events

    /// <summary>
    /// Occurs when the <see cref="ValidatorGenerator"/> requires a target object for validation. 
    /// </summary>
    public event EventHandler<TargetObjectRequiredEventArgs> TargetObjectRequired;

    #endregion


    #region Methods

    private ValidationResult ServerValidateHandler(Rule propertyRule)
    {
      List<Control> controls = new List<Control>();
      foreach (ValidationAssociation association in validationAssociations)
      {
        controls.Add(association.ControlToValidate);
      }
			TargetObjectRequiredEventArgs targetObjectRequiredEventArgs = new TargetObjectRequiredEventArgs(controls);
			object targetObject = OnTargetObjectRequired(targetObjectRequiredEventArgs);

      if (targetObject == null)
      {
        throw new InvalidOperationException("No target object could be found to validate. You must attach to ValidatorGenerator.TargetObjectRequired to provide a target object for server validates.");
      }
      ValidationResult result = propertyRule.Validate(targetObject, ((PropertyDescriptor) propertyRule.InfoDescriptor).GetValue(targetObject), null);
      return result;
    }


    /// <summary>
    /// Raises the <see cref="TargetObjectRequired"/> event. 
    /// </summary>
    /// <param name="objectRequiredEventArgs">A <see cref="TargetObjectRequiredEventArgs"/> that contains the event data.</param>
    /// <returns>The target object to be validated.</returns>
    protected virtual object OnTargetObjectRequired(TargetObjectRequiredEventArgs objectRequiredEventArgs)
    {
      if (TargetObjectRequired == null)
      {
        return null;
      }
      else
      {
        TargetObjectRequired(this, objectRequiredEventArgs);
        return objectRequiredEventArgs.TargetObject;
      }
    }


    /// <summary>
    /// A shortcut method to add a new <see cref="ValidationAssociation"/> to <see cref="ValidationAssociations"/>.
    /// </summary>
    /// <param name="controlToValidate">The <see cref="Control"/> to validate.</param>
    /// <param name="propertyName">The name of the property to validate.</param>
    /// <param name="containerControl">A <see cref="Control"/> to use to locate where the <see cref="BaseValidator"/> will be rendered. Null is accepted.</param>
    /// <returns>The <see cref="ValidationAssociation"/> that has been added to <see cref="ValidationAssociations"/>.</returns>
    /// <exception cref="ArgumentNullException"><paramref name="controlToValidate"/> is a null reference.</exception>
    /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is a null reference.</exception>
    /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
    public ValidationAssociation AddAssociation(Control controlToValidate, string propertyName, Control containerControl)
    {
      Guard.ArgumentNotNull(controlToValidate, "controlToValidate");
      Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
      ValidationAssociation association = new ValidationAssociation(controlToValidate, propertyName, containerControl);
      validationAssociations.Add(association);
      return association;
    }


    /// <summary>
    /// A shortcut method to add a new <see cref="ValidationAssociation"/> to <see cref="ValidationAssociations"/>.
    /// </summary>
    /// <param name="controlToValidate">The <see cref="Control"/> to validate.</param>
    /// <param name="propertyName">The name of the property to validate.</param>
    /// <returns>The <see cref="ValidationAssociation"/> that has been added to <see cref="ValidationAssociations"/>.</returns>
    /// <exception cref="ArgumentNullException"><paramref name="controlToValidate"/> is a null reference.</exception>
    /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is a null reference.</exception>
    /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
    public ValidationAssociation AddAssociation(Control controlToValidate, string propertyName)
    {
      return AddAssociation(controlToValidate, propertyName, null);
    }


    /// <summary>
    /// Go through all the <see cref="ValidationAssociations"/> and add <see cref="BaseValidator"/>s to each.
    /// </summary>
    public IList<BaseValidator> GenerateValidators()
    {
      TypeDescriptor targetTypeDescriptor = TypeCache.GetType(Type.GetType(TypeToValidate).TypeHandle);
      List<BaseValidator> baseValidators = new List<BaseValidator>();
      foreach (ValidationAssociation association in validationAssociations)
      {
        if (targetTypeDescriptor.Properties.Contains(association.PropertyName))
        {
        	PropertyDescriptor propertyDescriptor = targetTypeDescriptor.Properties[association.PropertyName];
        	for (int ruleIndex = 0; ruleIndex < propertyDescriptor.Rules.Count; ruleIndex++)
        	{
        		Rule propertyRule = propertyDescriptor.Rules[ruleIndex];
        		if (Mode != Mode.Client)
        		{
        			CreateServerValidator(association, baseValidators, propertyRule);
        		}

        		if (Mode != Mode.Server)
        		{
        			CreateClientValidator(association, baseValidators, propertyRule);
        		}
        	}
        }
        else
        {
          throw new InvalidOperationException(string.Format("The member '{0}' could not be found or does not contain any validation rules.", association.PropertyName));
        }
      }
      return baseValidators;
    }


    private void CreateServerValidator(ValidationAssociation association, List<BaseValidator> baseValidators, Rule propertyRule)
    {
      ServerWebValidator serverWebValidator = new ServerWebValidator(propertyRule, new ServerWebValidator.ServerValidateDelegate(ServerValidateHandler));
      baseValidators.Add(serverWebValidator);
      AddValidator(association, serverWebValidator);
    }


    private void CreateClientValidator(ValidationAssociation association, List<BaseValidator> baseValidators, Rule propertyRule)
    {
      ISupportWebClientValidation supportWebClientValidation = propertyRule as ISupportWebClientValidation;
      if (supportWebClientValidation != null)
      {
        IList<BaseValidator> clientBaseValidators = supportWebClientValidation.CreateWebClientValidators();
        if (clientBaseValidators != null)
        {
        	for (int baseValidatorIndex = 0; baseValidatorIndex < clientBaseValidators.Count; baseValidatorIndex++)
        	{
        		BaseValidator clientBaseValidator = clientBaseValidators[baseValidatorIndex];
        		clientBaseValidator.ErrorMessage = propertyRule.ErrorMessage;
        		baseValidators.Add(clientBaseValidator);
        		AddValidator(association, clientBaseValidator);
        	}
        }
      }
    }


    private void AddValidator(ValidationAssociation association, BaseValidator baseValidator)
    {
      baseValidator.ControlToValidate = association.ControlToValidate.ID;
      baseValidator.ValidationGroup = ValidationGroup;
      baseValidator.Display = Display;
      if (association.ContainerControl == null)
      {
        Control parent = association.ControlToValidate.Parent;
        int indexOf = parent.Controls.IndexOf(association.ControlToValidate);
        parent.Controls.AddAt(indexOf + 1, baseValidator);
      }
      else
      {
        association.ContainerControl.Controls.Add(baseValidator);
      }
    }

    #endregion
  }
}