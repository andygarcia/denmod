using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ValidationFramework.Web
{
    /// <summary>
    /// Specifies that this <see cref="Rule"/> supports a client side (javascript) validation.
    /// </summary>
    public interface ISupportWebClientValidation
    {
        #region Methods

        /// <summary>
        /// Get a list of <see cref="BaseValidator"/>s to perform the client side validation.
        /// </summary>
        /// <remarks>The <see cref="BaseValidator"/>s returned should only perform client validation.</remarks>
        /// <returns>The<see cref="IList{T}"/> of <see cref="BaseValidator"/>s to perform the client side validation.</returns>
        IList<BaseValidator> CreateWebClientValidators();

        #endregion
    }
}