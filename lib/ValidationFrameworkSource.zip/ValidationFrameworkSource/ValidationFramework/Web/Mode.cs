using System;

namespace ValidationFramework.Web
{
    /// <summary>
    /// Specifies the type of validators that will be created.
    /// </summary>
    [Flags]
    public enum Mode
    {
        /// <summary>
        /// Create only client side validators.
        /// </summary>
        Client = 1,
        /// <summary>
        /// Create only server side validators.
        /// </summary>
        Server = 2,
        /// <summary>
        /// Create both client and server side validators.
        /// </summary>
        ClientServer = Client + Server
    }
}