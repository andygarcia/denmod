using System.Web.UI.WebControls;

namespace ValidationFramework.Web
{
    internal class ServerWebValidator : BaseValidator
    {
        #region Fields

        private readonly Rule propertyRule;
        private readonly ServerValidateDelegate serverValidate;

        internal delegate ValidationResult ServerValidateDelegate(Rule propertyRule);

        #endregion


        #region Constructors

        internal ServerWebValidator(Rule propertyRule, ServerValidateDelegate serverValidate)
        {
            this.propertyRule = propertyRule;
            this.serverValidate = serverValidate;
            EnableClientScript = false;
        }

        #endregion


        #region Methods

        protected override bool EvaluateIsValid()
        {
            ValidationResult result = serverValidate(propertyRule);
            if (result == null)
            {
                return true;
            }
            else
            {
                ErrorMessage = result.ErrorMessage;
                Text = result.ErrorMessage;
                return false;
            }
        }

        #endregion
    }
}