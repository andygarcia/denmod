using System.Web.UI.WebControls;

namespace ValidationFramework.Web
{
    /// <summary>
    /// A custom <see cref="RegularExpressionValidator"/> that does not perform any server validation.
    /// </summary>
    internal class RegularExpressionWebValidatorEx : RegularExpressionValidator
    {
        #region Methods

        /// <summary>
        /// Overrides <see cref="RegularExpressionValidator.EvaluateIsValid"/> to always return <see langword="true"/>.
        /// </summary>
        /// <returns><see langword="true"/></returns>
        protected override bool EvaluateIsValid()
        {
            return true;
        }

        #endregion
    }
}