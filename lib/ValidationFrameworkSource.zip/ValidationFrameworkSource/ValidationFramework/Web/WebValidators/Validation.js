<script type="text/javascript">

function RequiredValidatorEvaluateIsValid2(val)
{
    var valueToValidate = ValidatorGetValue2(val.controltovalidate);
    if (val.ignoreCase == "True")
    {
    valueToValidate = valueToValidate.toLowerCase();
    }
    if (val.trimWhiteSpace == "True") 
    {
	    valueToValidate = ValidatorTrim2(valueToValidate);
    } 
	  return (valueToValidate  != val.initialValue);
}

function ValidatorTrim2(s) {
    var m = s.match(/^\s*(\S+(\s+\S+)*)\s*$/);
    return (m == null) ? "" : m[1];
}

function ValidatorGetValue2(id) {
    var control;
    control = document.getElementById(id);
    if (typeof(control.value) == "string") {
        return control.value;
    }
    return ValidatorGetValueRecursive2(control);
}
function ValidatorGetValueRecursive2(control)
{
    if (typeof(control.value) == "string" && (control.type != "radio" || control.checked == true)) {
        return control.value;
    }
    var i, val;
    for (i = 0; i<control.childNodes.length; i++) {
        val = ValidatorGetValueRecursive2(control.childNodes[i]);
        if (val != "") return val;
    }
    return "";
}
</script>