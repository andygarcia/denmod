using System.Web.UI.WebControls;

namespace ValidationFramework.Web
{
    /// <summary>
    /// A custom <see cref="RequiredFieldValidator"/> that does not perform any server validation.
    /// </summary>
    internal class RequiredFieldWebValidatorEx : RequiredFieldValidator
    {
        #region Methods

        /// <summary>
        /// Overrides <see cref="CompareValidator.EvaluateIsValid"/> to always return <see langword="true"/>.
        /// </summary>
        /// <returns><see langword="true"/></returns>
        protected override bool EvaluateIsValid()
        {
            return true;
        }

        #endregion
    }
}