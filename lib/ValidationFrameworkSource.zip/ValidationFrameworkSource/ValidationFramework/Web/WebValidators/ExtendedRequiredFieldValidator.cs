using System;
using System.IO;
using System.Reflection;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ValidationFramework.Web
{
    internal class ExtendedRequiredFieldValidator : BaseValidator
    {
        #region Fields

        private static readonly Type extendedRequiredFieldValidatorType = typeof (ExtendedRequiredFieldValidator);
        private bool trimWhiteSpace;

        #endregion


        #region Methods

        /// <summary>
        /// Right before the control is going to render, I add my client-side validation script if the browser is capable of handling it.
        /// </summary>		
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            if (RenderUplevel)
            {
                if (!Page.ClientScript.IsClientScriptBlockRegistered(extendedRequiredFieldValidatorType, "ExtendedRequiredFieldValidatorMethod"))
                {
                    using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ValidationFramework.Web.WebValidators.Validation.js"))
                    {
                        using (StreamReader streamReader = new StreamReader(stream))
                        {
                            string script = streamReader.ReadToEnd();
                            Page.ClientScript.RegisterClientScriptBlock(extendedRequiredFieldValidatorType, "ExtendedRequiredFieldValidatorMethod", script);
                        }
                    }
                }
            }
        }


        /// <summary>
        /// Add extra attributes to the client-side html of the control if client-side validation is going to happen.
        /// </summary>		
        protected override void AddAttributesToRender(HtmlTextWriter writer)
        {
            base.AddAttributesToRender(writer);

            if (RenderUplevel)
            {
                //this attribute is needed by the RequiredFieldValidator's validation method.
                Page.ClientScript.RegisterExpandoAttribute(base.ClientID, "initialValue", InitialValue);
                //this is the method that asp.net calls when validating on the client-side
                Page.ClientScript.RegisterExpandoAttribute(base.ClientID, "evaluationfunction", "RequiredValidatorEvaluateIsValid2");
                Page.ClientScript.RegisterExpandoAttribute(base.ClientID, "trimWhiteSpace", TrimWhiteSpace.ToString());
                Page.ClientScript.RegisterExpandoAttribute(base.ClientID, "ignoreCase", IgnoreCase.ToString());
            }
        }


        /// <summary>
        /// Override the server validation so it always returns <see langword="true"/>.
        /// </summary>
        /// <returns><see langword="true"/></returns>
        protected override bool EvaluateIsValid()
        {
            return true;
        }

        #endregion


        #region Properties

        /// <summary>
        /// This is the equivalent of the RequiredFieldValidator's InitialValue
        /// property.
        /// </summary>
        public string InitialValue
        {
            get
            {
                string temp = (string) ViewState["InitialValue"];

                if (temp != null)
                {
                    return temp;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                ViewState["InitialValue"] = value;
            }
        }

        public bool TrimWhiteSpace
        {
            get
            {
                object viewStateTrimWhiteSpace = ViewState["TrimWhiteSpace"];
                if (viewStateTrimWhiteSpace == null)
                {
                    return trimWhiteSpace;
                }
                else
                {
                    return (bool) viewStateTrimWhiteSpace;
                }
            }
            set
            {
                trimWhiteSpace = value;
                ViewState["TrimWhiteSpace"] = value;
            }
        }

        public bool? IgnoreCase
        {
            get
            {
                return (bool?) ViewState["IgnoreCase"];
            }
            set
            {
                ViewState["IgnoreCase"] = value;
            }
        }

        #endregion
    }
}