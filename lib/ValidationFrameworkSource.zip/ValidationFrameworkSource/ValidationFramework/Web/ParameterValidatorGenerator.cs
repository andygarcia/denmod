using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Web.UI;
using System.Web.UI.WebControls;
using ValidationFramework.Reflection;

namespace ValidationFramework.Web
{
    /// <summary>
    /// Adds <see cref="BaseValidator"/>s to <see cref="Control"/>s based on the <see cref="Rule"/>s on a <see cref="Type"/>.
    /// </summary>
    /// <remarks>
    /// The following <see cref="Rule"/>s are supported for front end javascript validation.
    /// <list type="bullet">
    ///  <item>
    ///		<see cref="CompareRule{T}"/>
    ///	 </item>
    ///  <item>
    ///		<see cref="CompareRule{T}"/>. But only for the following types <see cref="short"/>, <see cref="int"/>, <see cref="long"/>, <see cref="decimal"/>, <see cref="double"/>, <see cref="DateTime"/><br/>
    ///   Note: see <B>Note on <see cref="DateTime"/>s</B> 
    ///	 </item>
    ///  <item>
    ///		<see cref="LengthStringRule"/>
    ///	 </item>
    ///  <item>
    ///		<see cref="RangeStringRule"/>
    ///	 </item>
    ///  <item>
    ///		<see cref="RangeRule{T}"/>. But only for the following types <see cref="short"/>, <see cref="int"/>, <see cref="long"/>, <see cref="decimal"/>, <see cref="double"/>, <see cref="DateTime"/><br/>
    ///   Note: see <B>Note on <see cref="DateTime"/>s</B> <br/>
    ///   Note: is either <see cref="RangeRule{T}.EqualsMaximumIsValid"/> or <see cref="RangeRule{T}.EqualsMinimumIsValid"/> are set to false no <see cref="BaseValidator"/>s will be generated. This is due to extensibility restrictions of the MS web validators and will be fixed in future versions.
    ///	 </item>
    ///  <item>
    ///		<see cref="RegexRule"/>
    ///	 </item>
    ///  <item>
    ///		<see cref="RequiredStringRule"/>
    ///	 </item>
    ///  <item>
    ///		<see cref="RequiredRule{T}"/>. Note: see <B>Note on <see cref="DateTime"/>s</B> 
    ///	 </item>
    /// </list>
    /// All <see cref="Rule"/>s, including those listed above, will be validated server side. <br/>
    /// 
    /// <B>Note on <see cref="DateTime"/>s</B>: <see cref="DateTime"/>s will only work if the <see cref="RequiredRule{T}.InitialValue"/>, <see cref="CompareRule{T}.ValueToCompare"/>, <see cref="RangeRule{T}.Minimum"/> and <see cref="RangeRule{T}.Maximum"/> is a <see cref="DateTime"/> with no time component. This is due to the limitation of both the <see cref="RequiredFieldValidator"/> and <see cref="CompareValidator"/>, since they only support "yyyy-MM-dd". Note that if a <see cref="RequiredRule{T}"/> is applied to a <see cref="DateTime"/> property that is <b>not</b> <see cref="Nullable{T}"/> <see cref="DateTime.MinValue"/> will be used as the <see cref="RequiredRule{T}.InitialValue"/>.
    /// </remarks>
    public class ParameterValidatorGenerator : BaseValidatorGenerator
    {
        #region Fields

        private EventHandler<ParametersRequiredEventArgs> parametersRequired;

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets the fully qualified name of the target <see cref="Type"/> to validate.
        /// </summary>
        [Description("The fully qualified name of the target Type to validate.")]
        public RuntimeMethodHandle MethodToValidate
        {
            get;
            set;
        }

        #endregion


        #region Events

        /// <summary>
        /// Occurs when the <see cref="ParameterValidatorGenerator"/> requires a target object for validation. 
        /// </summary>
        public EventHandler<ParametersRequiredEventArgs> ParametersRequired
        {
            get
            {
                return parametersRequired;
            }
            set
            {
                parametersRequired = value;
            }
        }

        #endregion


        #region Methods

        private ValidationResult ServerValidateHandler(Rule rule)
        {
            List<Control> controls = new List<Control>();
            foreach (ValidationAssociation association in ValidationAssociations)
            {
                controls.Add(association.ControlToValidate);
            }
            ParametersRequiredEventArgs targetObjectRequiredEventArgs = new ParametersRequiredEventArgs(controls);
            OnParametersRequired(targetObjectRequiredEventArgs);

            ParameterDescriptor parameterDescriptor = (ParameterDescriptor) rule.InfoDescriptor;

            ValidationResult result = rule.Validate(targetObjectRequiredEventArgs.TargetObject, targetObjectRequiredEventArgs.Parameters[parameterDescriptor.Name], Context);
            return result;
        }


        /// <summary>
        /// Raises the <see cref="ParametersRequired"/> event. 
        /// </summary>
        /// <param name="parametersRequiredEventArgs">A <see cref="TargetObjectRequiredEventArgs"/> that contains the event data.</param>
        /// <returns>The target object to be validated.</returns>
        protected virtual void OnParametersRequired(ParametersRequiredEventArgs parametersRequiredEventArgs)
        {
            parametersRequired(this, parametersRequiredEventArgs);
        }


        /// <summary>
        /// Get the <see cref="InfoDescriptor"/> for a specified member name.
        /// </summary>
        /// <param name="memberName">The member name to find get the <see cref="InfoDescriptor"/> for.</param>
        /// <returns>The <see cref="InfoDescriptor"/> for a specified member name.</returns>
        protected override InfoDescriptor GetInfoDescriptor(string memberName)
        {
            MethodDescriptor methodDescriptor = MethodCache.GetMethod(MethodToValidate);
            ParameterDescriptor parameterDescriptor;
            methodDescriptor.Parameters.TryGetValue(memberName, out parameterDescriptor);
            return parameterDescriptor;
        }


        [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
        protected override void CreateServerValidator(ValidationAssociation association, IList<BaseValidator> validators, Rule rule)
        {
            ServerWebValidator serverWebValidator = new ServerWebValidator(rule, ServerValidateHandler);
            validators.Add(serverWebValidator);
            AddValidator(association, serverWebValidator);
        }

        #endregion


    }
}