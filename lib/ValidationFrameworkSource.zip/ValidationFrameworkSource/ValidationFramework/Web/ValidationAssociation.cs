using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ValidationFramework.Web
{
    /// <summary>
    /// Defines an association between a <see cref="Control"/>, the property to validate and (optionally) the location <see cref="Control"/>.
    /// </summary>
    public class ValidationAssociation
    {
        #region Fields

        private Control containerControl;
        private Control controlToValidate;
        private string memberName;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationAssociation"/> class.
        /// </summary>
        /// <param name="controlToValidate">The <see cref="Control"/> to validate.</param>
        /// <param name="propertyName">The name of the property to validate.</param>
        /// <param name="containerControl">A <see cref="Control"/> to use to locate where the <see cref="BaseValidator"/> will be rendered. Null is accepted.</param>
        /// <exception cref="ArgumentNullException"><paramref name="controlToValidate"/> is a null reference.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        public ValidationAssociation(Control controlToValidate, string propertyName, Control containerControl)
        {
            Guard.ArgumentNotNull(controlToValidate, "controlToValidate");
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            this.controlToValidate = controlToValidate;
            memberName = propertyName;
            this.containerControl = containerControl;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationAssociation"/> class.
        /// </summary>
        /// <param name="controlToValidate">The <see cref="Control"/> to validate.</param>
        /// <param name="propertyName">The name of the property to validate.</param>
        /// <exception cref="ArgumentNullException"><paramref name="controlToValidate"/> is a null reference.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        public ValidationAssociation(Control controlToValidate, string propertyName)
            : this(controlToValidate, propertyName, null)
        {
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets the <see cref="Control"/> to validate.
        /// </summary>
        /// <exception cref="ArgumentNullException"><paramref name="value"/> is a null reference.</exception>
        public Control ControlToValidate
        {
            get
            {
                return controlToValidate;
            }
            set
            {
                Guard.ArgumentNotNull(value, "value");
                controlToValidate = value;
            }
        }

        /// <summary>
        /// Gets or sets the name of the property to validate.
        /// </summary>
        /// <exception cref="ArgumentNullException"><paramref name="value"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="value"/> is <see cref="string.Empty"/>.</exception>
        public string MemberName
        {
            get
            {
                return memberName;
            }
            set
            {
                Guard.ArgumentNotNullOrEmptyString(value, "value");
                memberName = value;
            }
        }

        /// <summary>
        /// Gets or sets the <see cref="Control"/> to use to locate where the <see cref="BaseValidator"/> will be rendered.
        /// </summary>
        public Control ContainerControl
        {
            get
            {
                return containerControl;
            }
            set
            {
                containerControl = value;
            }
        }

        #endregion
    }
}