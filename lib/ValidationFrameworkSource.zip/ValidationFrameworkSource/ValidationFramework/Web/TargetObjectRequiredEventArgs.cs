using System;
using System.Collections.Generic;
using System.Web.UI;

namespace ValidationFramework.Web
{
    /// <summary>
    /// Provides data for the <see cref="ValidatorGenerator.TargetObjectRequired"/> event.
    /// </summary>
    public class TargetObjectRequiredEventArgs : EventArgs
    {
        #region Fields

        private readonly ICollection<Control> controlsToValidate;
    

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TargetObjectRequiredEventArgs"/> class. 
        /// </summary>
        /// <param name="controlsToValidate">The <see cref="Control"/>s to validate.</param>
        public TargetObjectRequiredEventArgs(ICollection<Control> controlsToValidate)
        {
            this.controlsToValidate = controlsToValidate;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets the target object.
        /// </summary>
        public object TargetObject
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the controls that are being validated.
        /// </summary>
        public ICollection<Control> ControlsToValidate
        {
            get
            {
                return controlsToValidate;
            }
        }

        #endregion
    }
}