using System;
using System.Web.UI;

namespace ValidationFramework.Web
{
    /// <summary>
    /// A <see cref="AutoKeyDictionary{TKey,TItem}"/> of <see cref="ValidationAssociation"/>s.
    /// </summary>
    [Serializable]
    public class ValidationAssociationCollection : AutoKeyDictionary<Control, ValidationAssociation>
    {
        #region Methods

        /// <summary>
        /// Extracts the key from the <see cref="ValidationAssociation"/> element.
        /// </summary>
        /// <returns>The key for the specified element.</returns>
        /// <param name="item">The element from which to extract the key.</param>
        /// <exception cref="ArgumentNullException"><paramref name="item"/> is null.</exception>
        protected override Control GetKeyForItem(ValidationAssociation item)
        {
            Guard.ArgumentNotNull(item, "item");
            return item.ControlToValidate;
        }

        #endregion
    }
}