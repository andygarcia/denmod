using System;
using System.Web.UI.WebControls;

namespace ValidationFramework.Web
{
    internal static class ValidatorCreatorHelper
    {
        #region Fields

        private static readonly RuntimeTypeHandle dateTimeRuntimeTypeHandle = Type.GetTypeHandle(DateTime.MinValue);
        private static readonly RuntimeTypeHandle decimalRuntimeTypeHandle = Type.GetTypeHandle(decimal.MinValue);
        private static readonly RuntimeTypeHandle doubleRuntimeTypeHandle = Type.GetTypeHandle(double.MinValue);
        private static readonly RuntimeTypeHandle intRuntimeTypeHandle = Type.GetTypeHandle(int.MinValue);
        private static readonly RuntimeTypeHandle stringRuntimeTypeHandle = Type.GetTypeHandle(string.Empty);

        #endregion


        #region Methods

        internal static ValidationCompareOperator GetOperator(CompareOperator compareOperator)
        {
            switch (compareOperator)
            {
                case CompareOperator.Equal:
                    {
                        return ValidationCompareOperator.Equal;
                    }
                case CompareOperator.NotEqual:
                    {
                        return ValidationCompareOperator.NotEqual;
                    }
                case CompareOperator.GreaterThan:
                    {
                        return ValidationCompareOperator.GreaterThan;
                    }
                case CompareOperator.GreaterThanEqual:
                    {
                        return ValidationCompareOperator.GreaterThanEqual;
                    }
                case CompareOperator.LessThan:
                    {
                        return ValidationCompareOperator.LessThan;
                    }
                case CompareOperator.LessThanEqual:
                    {
                        return ValidationCompareOperator.LessThanEqual;
                    }
                default:
                    {
                        throw new NotImplementedException();
                    }
            }
        }


        internal static ValidationDataType? GetValidationDataType(RuntimeTypeHandle returnTypeHandle)
        {
            if (returnTypeHandle.Equals(stringRuntimeTypeHandle))
            {
                return ValidationDataType.String;
            }
            else if (returnTypeHandle.Equals(intRuntimeTypeHandle))
            {
                return ValidationDataType.Integer;
            }
            else if (returnTypeHandle.Equals(decimalRuntimeTypeHandle))
            {
                return ValidationDataType.Currency;
            }
            else if (returnTypeHandle.Equals(dateTimeRuntimeTypeHandle))
            {
                return ValidationDataType.Date;
            }
            else if (returnTypeHandle.Equals(doubleRuntimeTypeHandle))
            {
                return ValidationDataType.Double;
            }
            else
            {
                return null;
            }
        }

        #endregion
    }
}