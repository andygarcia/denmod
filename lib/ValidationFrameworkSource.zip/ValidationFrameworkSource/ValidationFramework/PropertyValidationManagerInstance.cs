using System;
using System.Collections.Generic;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// This is the primary class that will be utilized by the consumer when validating properties. This class responsible for exposing a simple public API to the consumer while handling the internals of invoking all <see cref="Rule"/>s properly.
    /// </summary>
    /// <seealso cref="NotifyValidatableBase"/>
    /// <seealso cref="DataErrorInfoValidatableBase"/>
    /// <seealso cref="ValidatableBase"/>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\PropertyValidationManager\CustomClassSample.cs" title="This example shows how to create your own custom class without using any of the base classes (e.g. ValidatableBase)." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\PropertyValidationManager\CustomClassSample.vb" title="This example shows how to create your own custom class without using any of the base classes (e.g. ValidatableBase)." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\PropertyValidationManager\ExternalSample.cs" title="This example shows how to validate a class from external code." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\PropertyValidationManager\ExternalSample.vb" title="This example shows how to validate a class from external code." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\PropertyValidationManager\ExternalExplicitSample.cs" title="This example shows how to validate a class that implements an interface explicitly." lang="cs"/>
    /// </example>
  public partial class PropertyValidationManager : MemberValidationManager
    {
   
        #region Constructors

        /// <summary>
      /// Initializes a new instance of the <see cref="PropertyValidationManager"/> class.
        /// </summary>
        /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="PropertyValidationManager(RuntimeTypeHandle)"/>.</remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        public PropertyValidationManager(object target) : base(target)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyValidationManager"/> class.
        /// </summary>
        /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="PropertyValidationManager(RuntimeTypeHandle)"/>.</remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public PropertyValidationManager(object target, string ruleSet) : base(target, ruleSet)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyValidationManager"/> class.
        /// </summary>
        /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="PropertyValidationManager(RuntimeTypeHandle)"/>.</remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public PropertyValidationManager(object target, string ruleSet, object context) : base(target, ruleSet, context)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyValidationManager"/> class.
        /// </summary>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="PropertyValidationManager(object)"/>.</remarks>
    public PropertyValidationManager(RuntimeTypeHandle targetHandle): base(targetHandle)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyValidationManager"/> class.
        /// </summary>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="PropertyValidationManager(object)"/>.</remarks>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public PropertyValidationManager(RuntimeTypeHandle targetHandle, string ruleSet) : base(targetHandle, ruleSet)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyValidationManager"/> class.
        /// </summary>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="PropertyValidationManager(object)"/>.</remarks>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
    public PropertyValidationManager(RuntimeTypeHandle targetHandle, string ruleSet, object context) : base(targetHandle, ruleSet, context)
        {
        }

        #endregion



        #region Methods


        #region Validate

        /// <summary>
        /// Validates all properties.
        /// </summary>
        /// <exception cref="InvalidOperationException">No <see cref="Rule"/>s can be found.</exception>
        public void ValidateAllProperties()
        {
            TypeDescriptor typeDescriptor = TypeDescriptor;
            errorDictionary.Clear();
            bool found = false;
            foreach (PropertyDescriptor propertyDescriptor in typeDescriptor.Properties)
            {
                object propertyValue = propertyDescriptor.GetValue(target);
                if (CheckValidMember(propertyDescriptor, propertyValue))
                {
                    found = true;
                }
            }
            if (!found)
            {
                if (ruleSet == null)
                {
                    throw new InvalidOperationException("No properties could be found containing rules.");  
                }
                else
                {   throw new InvalidOperationException(string.Format("No properties could be found containing rules with the ruleSet '{0}'.", ruleSet));
               
                }
            }
        }


        /// <summary>
        /// Validates the specified property.
        /// </summary>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="PropertyDescriptor"/>,for <paramref name="propertyName"/>, that have the <see cref="Rule.RuleSet"/> equal to <see cref="MemberValidationManager.RuleSet"/>.</exception>
        public void ValidateProperty(string propertyName)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            PropertyDescriptor propertyDescriptor;
            if (TypeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
                object propertyValue = propertyDescriptor.GetValue(target);
                if (!CheckValidMember(propertyDescriptor, propertyValue))
                {
                    throw new ArgumentException(string.Format("A property named '{0}' could not be found containing rules with the ruleSet '{1}'.", propertyName, ruleSet), "propertyName");
                }
            }
            else
            {
                throw new ArgumentException(string.Format("A property named '{0}' could not be found containing rules.", propertyName), "propertyName");
            }
        }

        #endregion


        #region TryValidate

        /// <summary>
        /// Validates all properties.
        /// </summary>
        public void TryValidateAllProperties()
        {
            TypeDescriptor typeDescriptor = TypeDescriptor;
            errorDictionary.Clear();
            foreach (PropertyDescriptor propertyDescriptor in typeDescriptor.Properties)
            {
                object propertyValue = propertyDescriptor.GetValue(target);
                CheckValidMember(propertyDescriptor, propertyValue);
            }
        }


        /// <summary>
        /// Validates only the specified property. 
        /// </summary>
        /// <remarks>No exception is thrown if the property is not found.</remarks>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is a null reference.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        public bool TryValidateProperty(string propertyName)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");

            PropertyDescriptor propertyDescriptor;
            if (TypeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
                object propertyValue = propertyDescriptor.GetValue(target);
                CheckValidMember(propertyDescriptor, propertyValue);
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion


        /// <summary>
        /// Get a <see cref="IList{T}"/> of all <see cref="ValidationResult"/>s for a list of properties.
        /// </summary>
        /// <remarks>Use <see cref="ResultFormatter"/> for some basic formatting conversions of <see cref="ValidationResult"/>s.</remarks>
        /// <param name="propertyNames">The names of the properties to retrieve error messages for. Case sensitive.</param>
        /// <returns>All <see cref="ValidationResult"/>s for the list of properties.</returns>
        /// <exception cref="ArgumentNullException"><paramref name="propertyNames"/> is null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Length of <paramref name="propertyNames"/> is 0.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found any single property <paramref name="propertyNames"/>.</exception>
        public IList<ValidationResult> GetResultsInErrorForProperties(params string[] propertyNames)
        {
          Guard.ArgumentNotNull(propertyNames, "propertyNames");

          if (propertyNames.Length == 0)
          {
            throw new ArgumentOutOfRangeException("propertyNames");
          }

          List<ValidationResult> validationResults = new List<ValidationResult>();
          foreach (string propertyName in propertyNames)
          {
            validationResults.AddRange(GetResultsInErrorForProperty(propertyName));
          }
          return validationResults;
        }


        /// <summary>
        /// Get a <see cref="IList{T}"/> of all <see cref="ValidationResult"/>s for a given property.
        /// </summary>
        /// <remarks>Use <see cref="ResultFormatter"/> for some basic formatting conversions of <see cref="ValidationResult"/>s.</remarks>
        /// <param name="propertyName">Property to retrieve error message for. Case sensitive.</param>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        public IList<ValidationResult> GetResultsInErrorForProperty(string propertyName)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            if (TypeDescriptor.Properties.ContainsKey(propertyName))
            {
                return GetResultsInErrorForMember(propertyName);
            }
            else
            {
                throw new ArgumentException(string.Format("A property named '{0}' could not be found containing rules.", propertyName), "propertyName");
            }
        }


        /// <summary>
        /// Get a <see cref="IList{T}"/> of all <see cref="ValidationResult"/>s for a given property. No exception is thrown if the property is not found.
        /// </summary>
        /// <remarks>Use <see cref="ResultFormatter"/> for some basic formatting conversions of <see cref="ValidationResult"/>s.</remarks>
        /// <param name="propertyName">Property to retrieve error message for. Case sensitive.</param>
        /// <param name="validationResults">When this method returns, if the property exists and contains <see cref="Rule"/>s, contains a <see cref="IList{T}"/> of <see cref="ValidationResult"/> for the property being validated; otherwise null.</param>
        /// <return><see langword="true"/> if the property exists and has <see cref="Rule"/>s; otherwise <see langword="false"/>.</return>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        public bool TryGetResultsInErrorForProperty(string propertyName, out IList<ValidationResult> validationResults)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            if (TypeDescriptor.Properties.ContainsKey(propertyName))
            {
                validationResults = GetResultsInErrorForMember(propertyName);
                return true;
            }
            else
            {
                validationResults = null;
                return false;
            }
        }

        #endregion
    }
}