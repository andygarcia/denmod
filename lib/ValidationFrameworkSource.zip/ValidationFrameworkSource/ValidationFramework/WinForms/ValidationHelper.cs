using System.Windows.Forms;

namespace ValidationFramework.WinForms
{
	/// <summary>
	/// Not finished yet. do not use.
	/// </summary>
	public static class ValidationHelper
	{
		public static bool ForceValidation(ContainerControl control)
		{
			bool valid = true;
			SetCausesValidation(control, true);
			if (!control.Validate())
			{
				valid = false;
			}
			if (!control.ValidateChildren())
			{
				valid = false;
			}
			SetCausesValidation(control, false);
			return valid;
		}


		internal static void SetCausesValidation(Control control, bool enabled)
		{
			control.CausesValidation = enabled;
			foreach (Control childControl in control.Controls)
			{
				SetCausesValidation(childControl, enabled);
			}
		}
	}
}