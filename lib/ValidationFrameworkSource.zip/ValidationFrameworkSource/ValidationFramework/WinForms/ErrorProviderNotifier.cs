using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ValidationFramework.WinForms
{
    /// <summary>
    /// Not finished yet. do not use.
    /// </summary>
    public class ErrorProviderNotifier
    {
        private ErrorProvider errorProvider;
        IList<Control> controls;
        BindingCompleteEventHandler handler;

        public ErrorProviderNotifier(ErrorProvider errorProvider)
        {
            controls = new List<Control>();
            handler = new BindingCompleteEventHandler(binding_BindingComplete);
            this.errorProvider = errorProvider;
        }

        public void Add(Control control)
        {
            if (controls.Contains(control))
            {
                throw new ArgumentException("Control already added", "control");
            }
            controls.Add(control);
            WireEvents(control);
        }

        private void WireEvents(Control control)
        {
            foreach (Binding binding in control.DataBindings)
            {
                if (!binding.FormattingEnabled)
                {
                    throw new InvalidOperationException("All Bindings must have FormattingEnabled set to true.");
                }
                binding.BindingComplete += handler;
            }
        }

        private void UnWireEvents(Control control)
        {
            foreach (Binding binding in control.DataBindings)
            {
                binding.BindingComplete -= handler;
            }
        }
        public void Remove(Control control)
        {
            if (!controls.Contains(control))
            {
                throw new ArgumentException("Control does not exist", "control");
            }
            controls.Remove(control);
            UnWireEvents(control);
        }

        void binding_BindingComplete(object sender, BindingCompleteEventArgs e)
        {
            if (e.Binding.IsBinding && e.BindingCompleteContext == BindingCompleteContext.DataSourceUpdate)
            {
                errorProvider.SetError(((Binding)sender).Control, e.ErrorText);
            }
        }
    }
}