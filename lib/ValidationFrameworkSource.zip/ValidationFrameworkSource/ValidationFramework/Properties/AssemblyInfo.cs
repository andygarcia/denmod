using System;
using System.Reflection;
using System.Runtime.InteropServices;
[assembly : CLSCompliant(true)]
[assembly : AssemblyTitle("ValidationFramework")]
[assembly : AssemblyDescription("")]
[assembly : AssemblyConfiguration("")]
[assembly : AssemblyProduct("ValidationFramework")]
[assembly : AssemblyTrademark("")]
[assembly : AssemblyCopyright("http://www.codeplex.com/ValidationFramework/Project/License.aspx")]
[assembly : AssemblyCulture("")]
[assembly : ComVisible(false)]
[assembly : Guid("22e91b03-19ea-4fb0-a0d9-1e03519874ef")]
[assembly : AssemblyVersion("1.12.0.0")]
[assembly : AssemblyFileVersion("1.12.0.0")]