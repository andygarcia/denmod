using System;
using System.Collections.Generic;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    /// <summary>
    /// Handles the validation of method parameters.
    /// </summary>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\BasicSample.cs" title="This example shows how to validate the parameters of a method." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\ParameterValidationManager\BasicSample.vb" title="This example shows how to validate the parameters of a method." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\ExplicitSample.cs" title="This example shows how to validate the parameters of a that is an explicit implementation of an interface." lang="cs"/>
    /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\InheritedFromInterfaceSample.cs" title="This example shows how to validate the parameters of a method by using attributes applied to an interface." lang="cs"/>
    /// <code source="Examples\ExampleLibraryVB\ParameterValidationManager\InheritedFromInterfaceSample.vb" title="This example shows how to validate the parameters of a method by using attributes applied to an interface." lang="vbnet"/>
    /// </example>
    [Serializable]
    public static class ParameterValidationManager
    {

        #region Methods

        /// <summary>
        /// Validate the parameters of a method. An <see cref="ArgumentException"/> will be thrown on the first invalid parameter.
        /// </summary>
        /// <remarks>
        /// This should be used if you expect at lease one parameter to have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryThrowException(object,RuntimeMethodHandle,string,object,object[])"/> 
        /// </remarks>
        /// <exception cref="ArgumentException">If any of the <paramref name="parameters"/> is invalid.</exception>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <example>
        /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\BasicSample.cs" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle." lang="cs"/>
        /// <code source="Examples\ExampleLibraryVB\ParameterValidationManager\BasicSample.vb" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle" lang="vbnet"/>
        /// </example>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void ThrowException(object target, RuntimeMethodHandle runtimeMethodHandle, string ruleSet, params object[] parameters)
        {
            InternalThrowException(runtimeMethodHandle, ruleSet, parameters, target, null, true);
        }


        /// <summary>
        /// Validate the parameters of a method. An <see cref="ArgumentException"/> will be thrown on the first invalid parameter.
        /// </summary>
        /// <remarks>
        /// This should be used if you are not certain if the parameters will have <see cref="Rule"/>s applied to them. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ThrowException(object,RuntimeMethodHandle,string,object,object[])"/> 
        /// </remarks>
        /// <exception cref="ArgumentException">If any of the <paramref name="parameters"/> is invalid.</exception>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <example>
        /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\BasicSample.cs" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle." lang="cs"/>
        /// <code source="Examples\ExampleLibraryVB\ParameterValidationManager\BasicSample.vb" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle" lang="vbnet"/>
        /// </example>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void TryThrowException(object target, RuntimeMethodHandle runtimeMethodHandle, string ruleSet, params object[] parameters)
        {
            InternalThrowException(runtimeMethodHandle, ruleSet, parameters, target, null, false);
        }


        /// <summary>
        /// Validate the parameters of a method. An <see cref="ArgumentException"/> will be thrown on the first invalid parameter.
        /// </summary>
        /// <remarks>
        /// This should be used if you expect at lease one parameter to have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryThrowException(object,RuntimeMethodHandle,string,object,object[])"/> 
        /// </remarks>
        /// <exception cref="ArgumentException">If any of the <paramref name="parameters"/> is invalid.</exception>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <example>
        /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\BasicSample.cs" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle." lang="cs"/>
        /// <code source="Examples\ExampleLibraryVB\ParameterValidationManager\BasicSample.vb" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle" lang="vbnet"/>
        /// </example>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void ThrowException(object target, RuntimeMethodHandle runtimeMethodHandle, string ruleSet, object context, params object[] parameters)
        {
            InternalThrowException(runtimeMethodHandle, ruleSet, parameters, target, context, true);
        }


        /// <summary>
        /// Validate the parameters of a method. An <see cref="ArgumentException"/> will be thrown on the first invalid parameter.
        /// </summary>
        /// <remarks>
        /// This should be used if you are not certain if the parameters will have <see cref="Rule"/>s applied to them. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ThrowException(object,RuntimeMethodHandle,string,object,object[])"/>
        /// </remarks>
        /// <exception cref="ArgumentException">If any of the <paramref name="parameters"/> is invalid.</exception>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <example>
        /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\BasicSample.cs" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle." lang="cs"/>
        /// <code source="Examples\ExampleLibraryVB\ParameterValidationManager\BasicSample.vb" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle" lang="vbnet"/>
        /// </example>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void TryThrowException(object target, RuntimeMethodHandle runtimeMethodHandle, string ruleSet, object context, params object[] parameters)
        {
            InternalThrowException(runtimeMethodHandle, ruleSet, parameters, target, context, false);
        }


        private static void InternalThrowException(RuntimeMethodHandle runtimeMethodHandle, string ruleSet, object[] parameters, object target, object context, bool throwException)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            bool ruleFound = false;
            ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
            MethodDescriptor methodDescriptor = MethodCache.GetMethod(runtimeMethodHandle);

            if (ruleSet == null)
            {
                foreach (ParameterDescriptor parameter in methodDescriptor.Parameters)
                {
                    object parameterValue = parameters[parameter.Position];
                    for (int ruleIndex = 0; ruleIndex < parameter.Rules.Count; ruleIndex++)
                    {
                        Rule rule = parameter.Rules[ruleIndex];
                        ruleFound = true;
                        if (rule.Validate(target, parameterValue, context) != null)
                        {
                            throw new ArgumentException(rule.ErrorMessage, rule.InfoDescriptor.Name);
                        }
                    }
                }
            }
            else
            {
                ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
                foreach (ParameterDescriptor parameter in methodDescriptor.Parameters)
                {
                    object parameterValue = parameters[parameter.Position];
                    for (int ruleIndex = 0; ruleIndex < parameter.Rules.Count; ruleIndex++)
                    {
                        Rule rule = parameter.Rules[ruleIndex];
                        ruleFound = true;
                        if ((string.Equals(rule.RuleSet, ruleSet)) && (rule.Validate(target, parameterValue, context) != null))
                        {
                            throw new ArgumentException(rule.ErrorMessage, rule.InfoDescriptor.Name);
                        }
                    }
                }
            }

            if (!ruleFound && throwException)
            {
                if (ruleSet == null)
                {
                    throw new InvalidOperationException("No parameters could be found containing rules.");
                }
                else
                {
                    throw new InvalidOperationException(string.Format("No parameters could be found containing rules with the ruleSet '{0}'.", ruleSet));
                }
            }
        }


        /// <summary>
        /// Validate the parameters of a method. An <see cref="ArgumentException"/> will be thrown on the first invalid parameter.
        /// </summary>
        /// <remarks>
        /// This should be used if you expect at lease one parameter to have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryThrowException(object,RuntimeMethodHandle,object[])"/> 
        /// </remarks>
        /// <exception cref="ArgumentException">If any of the <paramref name="parameters"/> is invalid.</exception>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <example>
        /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\BasicSample.cs" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle." lang="cs"/>
        /// <code source="Examples\ExampleLibraryVB\ParameterValidationManager\BasicSample.vb" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle" lang="vbnet"/>
        /// </example>
        public static void ThrowException(object target, RuntimeMethodHandle runtimeMethodHandle, params object[] parameters)
        {
            InternalThrowException(runtimeMethodHandle, null, parameters,target, null, true);
        }


        /// <summary>
        /// Validate the parameters of a method. An <see cref="ArgumentException"/> will be thrown on the first invalid parameter.
        /// </summary>
        /// <remarks>
        /// This should be used if you are not certain if the parameters will have <see cref="Rule"/>s applied to them. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ThrowException(object,RuntimeMethodHandle,object[])"/> 
        /// </remarks>
        /// <exception cref="ArgumentException">If any of the <paramref name="parameters"/> is invalid.</exception>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <example>
        /// <code source="Examples\ExampleLibraryCSharp\ParameterValidationManager\BasicSample.cs" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle." lang="cs"/>
        /// <code source="Examples\ExampleLibraryVB\ParameterValidationManager\BasicSample.vb" title="This example shows how to validate the parameters of a method using a RuntimeMethodHandle" lang="vbnet"/>
        /// </example>
        public static void TryThrowException(object target, RuntimeMethodHandle runtimeMethodHandle, params object[] parameters)
        {
            InternalThrowException(runtimeMethodHandle, null, parameters, target, null, false);
        }


        /// <summary>
        /// Validate the parameters of a method.
        /// </summary>
        /// <remarks>
        /// This should be used if you expect at lease one parameter to have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidate(object,RuntimeMethodHandle,string,object,object[])"/> 
        /// </remarks>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <returns>A <see cref="IList{T}"/> containing all <see cref="ValidationResult"/>s for invalid parameters.</returns>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static IList<ValidationResult> Validate(object target, RuntimeMethodHandle runtimeMethodHandle, string ruleSet, params object[] parameters)
        {
            return InternalValidate(runtimeMethodHandle, ruleSet, parameters, target, null, true);
        }


        /// <summary>
        /// Validate the parameters of a method.
        /// </summary>
        /// <remarks>
        /// This should be used if you are not certain if the parameters will have <see cref="Rule"/>s applied to them. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="Validate(object,RuntimeMethodHandle,string,object,object[])"/>
        /// </remarks>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <returns>A <see cref="IList{T}"/> containing all <see cref="ValidationResult"/>s for invalid parameters.</returns>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static IList<ValidationResult> TryValidate(object target, RuntimeMethodHandle runtimeMethodHandle, string ruleSet, params object[] parameters)
        {
            return InternalValidate(runtimeMethodHandle, ruleSet, parameters, target, null, false);
        }


        /// <summary>
        /// Validate the parameters of a method.
        /// </summary>
        /// <remarks>
        /// This should be used if you expect at lease one parameter to have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidate(object,RuntimeMethodHandle,string,object,object[])"/> 
        /// </remarks>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <returns>A <see cref="IList{T}"/> containing all <see cref="ValidationResult"/>s for invalid parameters.</returns>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static IList<ValidationResult> Validate(object target, RuntimeMethodHandle runtimeMethodHandle, string ruleSet, object context, params object[] parameters)
        {
            return InternalValidate(runtimeMethodHandle, ruleSet, parameters, target, context, true);
        }


        /// <summary>
        /// Validate the parameters of a method.
        /// </summary>
        /// <remarks>
        /// This should be used if you are not certain if the parameters will have <see cref="Rule"/>s applied to them. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="Validate(object,RuntimeMethodHandle,string,object,object[])"/> 
        /// </remarks>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <returns>A <see cref="IList{T}"/> containing all <see cref="ValidationResult"/>s for invalid parameters.</returns>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static IList<ValidationResult> TryValidate(object target, RuntimeMethodHandle runtimeMethodHandle, string ruleSet, object context, params object[] parameters)
        {
            return InternalValidate(runtimeMethodHandle, ruleSet, parameters, target, context, false);
        }


        private static IList<ValidationResult> InternalValidate(RuntimeMethodHandle runtimeMethodHandle, string ruleSet, object[] parameters, object target, object context, bool throwException)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            bool ruleFound = false;
            ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
            List<ValidationResult> list = new List<ValidationResult>();
            MethodDescriptor methodDescriptor = MethodCache.GetMethod(runtimeMethodHandle);
            if (ruleSet == null)
            {
                foreach (ParameterDescriptor parameter in methodDescriptor.Parameters)
                {
                    object parameterValue = parameters[parameter.Position];
                    RuleCollection ruleCollection = parameter.Rules;
                    for (int ruleIndex = 0; ruleIndex < ruleCollection.Count; ruleIndex++)
                    {
                        ruleFound = true;
                        Rule rule = ruleCollection[ruleIndex];
                        ValidationResult validationResult = rule.Validate(target, parameterValue, context);
                        if (validationResult != null)
                        {
                            list.Add(validationResult);
                        }
                    }
                }
            }
            else
            {
                ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
                foreach (ParameterDescriptor parameter in methodDescriptor.Parameters)
                {
                    object parameterValue = parameters[parameter.Position];
                    RuleCollection ruleCollection = parameter.Rules;
                    for (int ruleIndex = 0; ruleIndex < ruleCollection.Count; ruleIndex++)
                    {
                        Rule rule = ruleCollection[ruleIndex];
                        if (string.Equals(rule.RuleSet, ruleSet))
                        {
                        ruleFound = true;
                            ValidationResult validationResult = rule.Validate(target, parameterValue, context);
                            if (validationResult != null)
                            {
                                list.Add(validationResult);
                            }
                        }
                    }
                }
            }

            if (!ruleFound && throwException)
            {
                if (ruleSet == null)
                {
                    throw new InvalidOperationException("No parameters could be found containing rules.");
                }
                else
                {
                    throw new InvalidOperationException(string.Format("No parameters could be found containing rules with the ruleSet '{0}'.", ruleSet));
                }
            }
            return list;
        }


        /// <summary>
        /// Validate the parameters of a method.
        /// </summary>
        /// <remarks>
        /// This should be used if you expect at lease one parameter to have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidate(object,RuntimeMethodHandle,object[])"/> 
        /// </remarks>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <returns>A <see cref="IList{T}"/> containing all <see cref="ValidationResult"/>s for invalid parameters.</returns>
        public static IList<ValidationResult> Validate(object target, RuntimeMethodHandle runtimeMethodHandle, params object[] parameters)
        {
            return InternalValidate(runtimeMethodHandle, null, parameters, target, null, true);
        }


        /// <summary>
        /// Validate the parameters of a method.
        /// </summary>
        /// <remarks>
        /// This should be used if you are not certain if the parameters will have <see cref="Rule"/>s applied to them. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="Validate(object,RuntimeMethodHandle,object[])"/>
        /// </remarks>
        /// <param name="target">The instance that the method exists on. Null for static types.</param>
        /// <param name="parameters">The values of the parameters to validate. In the same order as they appear in the methods signature.</param>
        /// <param name="runtimeMethodHandle">The <see cref="RuntimeMethodHandle"/> that represents the method to be validated.</param>
        /// <returns>A <see cref="IList{T}"/> containing all <see cref="ValidationResult"/>s for invalid parameters.</returns>
        public static IList<ValidationResult> TryValidate(object target, RuntimeMethodHandle runtimeMethodHandle, params object[] parameters)
        {
            return InternalValidate( runtimeMethodHandle, null, parameters, target, null, false);
        }

        #endregion
    }
}