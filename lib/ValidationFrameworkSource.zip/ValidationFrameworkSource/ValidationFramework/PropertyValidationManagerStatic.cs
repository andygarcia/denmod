using System;
using System.Collections.Generic;
using ValidationFramework.Reflection;

namespace ValidationFramework
{

    [Serializable]
    public partial class PropertyValidationManager
    {
        #region Methods


        #region TryThrowException

        /// <summary>
        /// Performs validation when a property is being set.
        /// </summary>
        /// <remarks>
        /// <para>Should be called before the field (representing this property) is set.</para>
        /// <para>This should be used if you are not certain if the property will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ThrowPropertyException(object,object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <param name="propertyValue">The value of the property being validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void TryThrowPropertyException(object target, object propertyValue, string propertyName, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            PropertyDescriptor propertyDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            if (typeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
              InternalThrowException(propertyDescriptor, propertyValue, ruleSet, context, false, target);
            }
        }


        /// <summary>
        /// Performs validation when a property is being set.
        /// </summary>
        /// <remarks>
        /// <para>Should be called before the field (representing this property) is set.</para> 
        /// <para>This should be used if you expect the property to have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryThrowPropertyException(object,object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <param name="propertyValue">The value of the property being validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void ThrowPropertyException(object target, object propertyValue, string propertyName, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            PropertyDescriptor propertyDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            if (typeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
              InternalThrowException(propertyDescriptor, propertyValue, ruleSet, context, true, target);
            }
            else
            {
                throw new ArgumentException(string.Format("A property named '{0}' could not be found containing rules.", propertyName), "propertyName");
            }
        }


        /// <summary>
        /// Performs validation when a property is being set.
        /// </summary>
        /// <remarks>
        /// <para>Should be called before the field (representing this property) is set.</para>
        /// <para>This should be used if you are not certain if property will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ThrowPropertyException(RuntimeTypeHandle,object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <param name="propertyValue">The value of the property being validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void TryThrowPropertyException(RuntimeTypeHandle targetHandle, object propertyValue, string propertyName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            PropertyDescriptor propertyDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            if (typeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
              InternalThrowException(propertyDescriptor, propertyValue, ruleSet, context, false, null);
            }
        }


        /// <summary>
        /// Performs validation when a property is being set.
        /// </summary>
        /// <remarks>
        /// <para>Should be called before the field (representing this property) is set.</para>
        /// <para>This should be used if you expect the property to have <see cref="Rule"/>s applied to it. 
        ///  This is usually the case if you are using attributes to apply <see cref="Rule"/>s.
        ///  If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryThrowPropertyException(RuntimeTypeHandle,object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <param name="propertyValue">The value of the property being validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public static void ThrowPropertyException(RuntimeTypeHandle targetHandle, object propertyValue, string propertyName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            PropertyDescriptor propertyDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            if (typeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
              InternalThrowException(propertyDescriptor, propertyValue, ruleSet, context, true, null);
            }
            else
            {
                throw new ArgumentException(string.Format("A property named '{0}' could not be found containing rules.", propertyName), "propertyName");
            }
        }

        #endregion


        #region TryValidate

        /// <summary>
        /// Performs validation for a specific property.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you can not be certain of the property will have <see cref="Rule"/>s applied to it. 
        ///  This is usually the case if you are using code to apply <see cref="Rule"/>s.
        ///  If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ValidateProperty(object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        public static IList<ValidationResult> TryValidateProperty(object target, string propertyName, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            PropertyDescriptor propertyDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            if (typeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
                object propertyValue = propertyDescriptor.GetValue(target);
                return InternalValidateInfoDescriptor(propertyDescriptor, propertyValue, ruleSet, context, false, target);
            }
            else
            {
                return new List<ValidationResult>();
            }
        }


        /// <summary>
        /// Performs validation for a specific property.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain if property will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ValidateProperty(RuntimeTypeHandle,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        public static IList<ValidationResult> TryValidateProperty(RuntimeTypeHandle targetHandle, string propertyName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            PropertyDescriptor propertyDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            if (typeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
                object propertyValue = propertyDescriptor.GetValue(null);
                return InternalValidateInfoDescriptor(propertyDescriptor, propertyValue, ruleSet, context, false, null);
            }
            else
            {
                return new List<ValidationResult>();
            }
        }


        /// <summary>
        /// Performs validation for a specific property.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain if property will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ValidateAllProperties(object,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="PropertyDescriptor"/>, that have the <see cref="Rule.RuleSet"/> equal to <paramref name="ruleSet"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        public static IList<ValidationResult> TryValidateAllProperties(object target, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet,"ruleSet");
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            return InternalValidateAllInfoDescriptors(typeDescriptor, target, ruleSet, context, false);
        }


        /// <summary>
        /// Performs validation for a specific property.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain if property will have <see cref="Rule"/>s applied to it. 
        /// This is usually the case if you are using code to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using attributes it may be more appropriate to call <see cref="ValidateAllProperties(RuntimeTypeHandle,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        public static IList<ValidationResult> TryValidateAllProperties(RuntimeTypeHandle targetHandle, string ruleSet, object context)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            return InternalValidateAllInfoDescriptors(typeDescriptor, null, ruleSet, context, false);
        }

        #endregion


        #region Validate

        /// <summary>
        /// Performs validation for an object.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are certain all properties will have <see cref="Rule"/>s applied. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidateAllProperties(object,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        public static IList<ValidationResult> ValidateAllProperties(object target, string ruleSet, object context)
        {
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            return InternalValidateAllInfoDescriptors(typeDescriptor, target, ruleSet, context, true);
        }


        /// <summary>
        /// Performs validation for a specific property.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are certain all properties will have <see cref="Rule"/>s applied.
        ///  This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidateAllProperties(RuntimeTypeHandle,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="PropertyDescriptor"/>,for <paramref name="propertyName"/>, that have the <see cref="Rule.RuleSet"/> equal to <see cref="MemberValidationManager.RuleSet"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        public static IList<ValidationResult> ValidateProperty(RuntimeTypeHandle targetHandle, string propertyName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            PropertyDescriptor propertyDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);

          if (typeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
          {
            object propertyValue = propertyDescriptor.GetValue(null);
            return InternalValidateInfoDescriptor(propertyDescriptor, propertyValue, ruleSet, context, true, null);
          }
          else
          {
            throw new ArgumentException(string.Format("A property named '{0}' could not be found containing rules.", propertyName), "propertyName");
          }
        }


        /// <summary>
        /// Performs validation for a specific property.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain if properties will have <see cref="Rule"/>s applied.
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidateAllProperties(RuntimeTypeHandle,string,object)"/></para> 
        /// </remarks>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="PropertyDescriptor"/>, that have the <see cref="Rule.RuleSet"/> equal to <paramref name="ruleSet"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        public static IList<ValidationResult> ValidateAllProperties(RuntimeTypeHandle targetHandle, string ruleSet, object context)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            TypeDescriptor typeDescriptor = TypeCache.GetType(targetHandle);
            return InternalValidateAllInfoDescriptors(typeDescriptor, null, ruleSet, context, true);
        }


        /// <summary>
        /// Performs validation for a specific property.
        /// </summary>
        /// <remarks>
        /// <para>This should be used if you are not certain the property will have <see cref="Rule"/>s applied. 
        /// This is usually the case if you are using attributes to apply <see cref="Rule"/>s. 
        /// If <see cref="Rule"/>s are being assigned using code it may be more appropriate to call <see cref="TryValidateProperty(object,string,string,object)"/></para> 
        /// </remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="propertyName">Property to validate. Case sensitive.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <exception cref="ArgumentNullException"><paramref name="propertyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="propertyName"/> is <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="PropertyDescriptor"/> could be found named <paramref name="propertyName"/>.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="PropertyDescriptor"/>,for <paramref name="propertyName"/>, that have the <see cref="Rule.RuleSet"/> equal to <see cref="MemberValidationManager.RuleSet"/>.</exception>
        /// <returns>All <see cref="ValidationResult"/>s for a given property.</returns>
        public static IList<ValidationResult> ValidateProperty(object target, string propertyName, string ruleSet, object context)
        {
            Guard.ArgumentNotNullOrEmptyString(propertyName, "propertyName");
            Guard.ArgumentNotNull(target, "target");
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            PropertyDescriptor propertyDescriptor;
            TypeDescriptor typeDescriptor = TypeCache.GetType(target.GetType().TypeHandle);
            if (typeDescriptor.Properties.TryGetValue(propertyName, out propertyDescriptor))
            {
                object propertyValue = propertyDescriptor.GetValue(target);
                return InternalValidateInfoDescriptor(propertyDescriptor, propertyValue, ruleSet, context, true, target);
            }
            else
            {
                throw new ArgumentException(string.Format("A property named '{0}' could not be found containing rules.", propertyName), "propertyName");
            }
        }

        internal static IList<ValidationResult> InternalValidateAllInfoDescriptors(TypeDescriptor typeDescriptor, object target, string ruleSet, object context, bool throwException)
        {
            bool ruleFound = false;
            List<ValidationResult> validationResults = new List<ValidationResult>();
            foreach (PropertyDescriptor propertyDescriptor in typeDescriptor.Properties)
            {
                object propertyValue = propertyDescriptor.GetValue(target);
                if (CheckValid(propertyDescriptor, propertyValue, ruleSet, context, target, validationResults))
                {
                    ruleFound = true;
                }
            }

            ThrowNoRules(ruleSet, ruleFound, throwException);
            return validationResults;
        }

        #endregion


        #endregion
    }
}