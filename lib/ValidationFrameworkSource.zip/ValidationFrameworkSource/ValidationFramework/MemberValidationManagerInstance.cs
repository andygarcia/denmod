using System;
using System.Collections.Generic;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
  public abstract partial class MemberValidationManager
  {
      #region Fields

        private readonly object context;
    protected readonly Dictionary<Rule, ValidationResult> errorDictionary = new Dictionary<Rule, ValidationResult>();
        private readonly bool isValidatingStatic = false;
    protected readonly string ruleSet;
    protected readonly object target;
        private readonly RuntimeTypeHandle targetHandle;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MemberValidationManager"/> class.
        /// </summary>
        /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="PropertyValidationManager(RuntimeTypeHandle)"/>.</remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        public MemberValidationManager(object target)
        {
            Guard.ArgumentNotNull(target, "targetObject");
            this.target = target;
            targetHandle = Type.GetTypeHandle(target);
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="MemberValidationManager"/> class.
        /// </summary>
        /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="PropertyValidationManager(RuntimeTypeHandle)"/>.</remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public MemberValidationManager(object target, string ruleSet)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            this.ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
            Guard.ArgumentNotNull(target, "targetObject");
            this.target = target;
            targetHandle = Type.GetTypeHandle(target);
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="MemberValidationManager"/> class.
        /// </summary>
        /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="PropertyValidationManager(RuntimeTypeHandle)"/>.</remarks>
        /// <param name="target">An instance of the object to be validated.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public MemberValidationManager(object target, string ruleSet, object context)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            Guard.ArgumentNotNull(target, "targetObject");
            this.ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
            this.target = target;
            this.context = context;
            targetHandle = Type.GetTypeHandle(target);
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="MemberValidationManager"/> class.
        /// </summary>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="PropertyValidationManager(object)"/>.</remarks>
        public MemberValidationManager(RuntimeTypeHandle targetHandle)
        {
            this.targetHandle = targetHandle;
            isValidatingStatic = true;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="MemberValidationManager"/> class.
        /// </summary>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="PropertyValidationManager(object)"/>.</remarks>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
        public MemberValidationManager(RuntimeTypeHandle targetHandle, string ruleSet)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            this.ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
            this.targetHandle = targetHandle;
            isValidatingStatic = true;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="MemberValidationManager"/> class.
        /// </summary>
        /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="PropertyValidationManager(object)"/>.</remarks>
        /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
    public MemberValidationManager(RuntimeTypeHandle targetHandle, string ruleSet, object context)
        {
            Guard.ArgumentNotEmptyString(ruleSet, "ruleSet");
            this.ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
            this.targetHandle = targetHandle;
            this.context = context;
            isValidatingStatic = true;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets a value indicating if all properties are valid.
        /// </summary>
        /// <remarks>Calling this property does not perform a validation it only checks the current state. To perform a full validation call <see cref="ValidateAllProperties()"/> or, to validate an individual property, call <see cref="ValidateProperty(string)"/>.</remarks>
        public bool IsValid
        {
            get
            {
                return (errorDictionary.Count == 0);
            }
        }

        /// <summary>
        /// Gets the <see cref="Reflection.TypeDescriptor"/> for the <see cref="Type"/> that this <see cref="PropertyValidationManager"/> is validating.
        /// </summary>
        public TypeDescriptor TypeDescriptor
        {
            get
            {
                //get this from the cache each time. this will allow the removal of types from the cache in the future to save on memory.
                return TypeCache.GetType(targetHandle);
            }
        }


        /// <summary>
        /// Gets the instance of the object that this <see cref="PropertyValidationManager"/> is handling.
        /// </summary>
        /// <remarks>Will return a null if validating a static type.</remarks>
        public Object Target
        {
            get
            {
                return target;
            }
        }


        /// <summary>
        /// Gets a <see cref="IList{T}"/> containing all <see cref="ValidationResult"/> in error.
        /// </summary>
        /// <remarks>This is a copy of the actual list of <see cref="ValidationResult"/>s.</remarks>
        public IList<ValidationResult> ValidatorResultsInError
        {
            get
            {
                return new List<ValidationResult>(errorDictionary.Values);
            }
        }


        /// <summary>
        /// Gets a value indicating if the <see cref="PropertyValidationManager"/> is being used to validate a static type.
        /// </summary>
        public bool IsValidatingStatic
        {
            get
            {
                return isValidatingStatic;
            }
        }

        /// <summary>
        /// Gets the <see cref="RuntimeTypeHandle"/> for the <see cref="Type"/> being validated.
        /// </summary>
        public RuntimeTypeHandle TargetHandle
        {
            get
            {
                return targetHandle;
            }
        }


        /// <summary>
        /// Gets the the rule set to validate.
        /// </summary>
        /// <remarks>
        /// Will be a null to validate all <see cref="Rule"/>s.<br/>
        /// Case insensitive so this will always return a upper case string no matter what is passed into the constructor.
        /// </remarks>
        public string RuleSet
        {
            get
            {
                return ruleSet;
            }
        }

        /// <summary>
        /// An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. The default is null.
        /// </summary>
        public object Context
        {
            get
            {
                return context;
            }
        }

        #endregion




        protected IList<ValidationResult> GetResultsInErrorForMember(string memberName)
        {
            List<ValidationResult> errors = new List<ValidationResult>();

            foreach (ValidationResult validator in errorDictionary.Values)
            {
                if (string.Equals(validator.Rule.InfoDescriptor.Name, memberName))
                {
                    errors.Add(validator);
                }
            }
            return errors;
        }


        protected bool CheckValidMember(InfoDescriptor infoDescriptor, object memberValue)
        {
            bool ruleFound = false;

            if (ruleSet == null)
            {
                for (int index = 0; index < infoDescriptor.Rules.Count; index++)
                {
                    Rule propertyRule = infoDescriptor.Rules[index];
                    ruleFound = true;
                    ValidationResult validationResult = propertyRule.Validate(target, memberValue, context);
                    errorDictionary.Remove(propertyRule);
                    if (validationResult != null)
                    {
                        errorDictionary.Add(propertyRule, validationResult);
                    }
                }
            }
            else
            {
                for (int index = 0; index < infoDescriptor.Rules.Count; index++)
                {
                    Rule propertyRule = infoDescriptor.Rules[index];
                    if (string.Equals(propertyRule.RuleSet, ruleSet))
                    {
                        ruleFound = true;
                        ValidationResult validationResult = propertyRule.Validate(target, memberValue, context);
                        errorDictionary.Remove(propertyRule);
                        if (validationResult != null)
                        {
                            errorDictionary.Add(propertyRule, validationResult);
                        }
                    }
                }
            }

            return ruleFound;
        }
    }
}