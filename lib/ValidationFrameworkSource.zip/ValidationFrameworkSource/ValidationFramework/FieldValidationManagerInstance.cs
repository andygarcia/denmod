using System;
using System.Collections.Generic;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
  /// <summary>
  /// This is the primary class that will be utilized by the consumer when validating properties. This class responsible for exposing a simple public API to the consumer while handling the internals of invoking all <see cref="Rule"/>s properly.
  /// </summary>
  /// <seealso cref="NotifyValidatableBase"/>
  /// <seealso cref="DataErrorInfoValidatableBase"/>
  /// <seealso cref="ValidatableBase"/>
  /// <example>
  /// <code source="Examples\ExampleLibraryCSharp\FieldValidationManager\CustomClassSample.cs" title="This example shows how to create your own custom class without using any of the base classes (e.g. ValidatableBase)." lang="cs"/>
  /// <code source="Examples\ExampleLibraryVB\FieldValidationManager\CustomClassSample.vb" title="This example shows how to create your own custom class without using any of the base classes (e.g. ValidatableBase)." lang="vbnet"/>
  /// <code source="Examples\ExampleLibraryCSharp\FieldValidationManager\ExternalSample.cs" title="This example shows how to validate a class from external code." lang="cs"/>
  /// <code source="Examples\ExampleLibraryVB\FieldValidationManager\ExternalSample.vb" title="This example shows how to validate a class from external code." lang="vbnet"/>
  /// </example>
  public partial class FieldValidationManager : MemberValidationManager
  {

    #region Constructors

    /// <summary>
    /// Initializes a new instance of the <see cref="FieldValidationManager"/> class.
    /// </summary>
    /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="FieldValidationManager(RuntimeTypeHandle)"/>.</remarks>
    /// <param name="target">An instance of the object to be validated.</param>
    /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
    public FieldValidationManager(object target)
      : base(target)
    {
    }


    /// <summary>
    /// Initializes a new instance of the <see cref="FieldValidationManager"/> class.
    /// </summary>
    /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="FieldValidationManager(RuntimeTypeHandle)"/>.</remarks>
    /// <param name="target">An instance of the object to be validated.</param>
    /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
    /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
    /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
    public FieldValidationManager(object target, string ruleSet)
      : base(target, ruleSet)
    {
    }


    /// <summary>
    /// Initializes a new instance of the <see cref="FieldValidationManager"/> class.
    /// </summary>
    /// <remarks>Use this constructor if an instance of an object is being validated. If there is no instance, i.e. it is a static class or only static properties are being validated, use <see cref="FieldValidationManager(RuntimeTypeHandle)"/>.</remarks>
    /// <param name="target">An instance of the object to be validated.</param>
    /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
    /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
    /// <exception cref="ArgumentNullException"><paramref name="target"/> is null.</exception>
    /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
    public FieldValidationManager(object target, string ruleSet, object context)
      : base(target, ruleSet, context)
    {
    }


    /// <summary>
    /// Initializes a new instance of the <see cref="FieldValidationManager"/> class.
    /// </summary>
    /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
    /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="FieldValidationManager(object)"/>.</remarks>
    public FieldValidationManager(RuntimeTypeHandle targetHandle)
      : base(targetHandle)
    {
    }


    /// <summary>
    /// Initializes a new instance of the <see cref="FieldValidationManager"/> class.
    /// </summary>
    /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
    /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
    /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="FieldValidationManager(object)"/>.</remarks>
    /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
    public FieldValidationManager(RuntimeTypeHandle targetHandle, string ruleSet)
      : base(targetHandle, ruleSet)
    {
    }


    /// <summary>
    /// Initializes a new instance of the <see cref="FieldValidationManager"/> class.
    /// </summary>
    /// <param name="targetHandle">A <see cref="RuntimeTypeHandle"/> representing the static <see cref="Type"/> to validate.</param>
    /// <param name="ruleSet">The rule set to validate. Use null to validate all rules. Is converted to uppercase.</param>
    /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
    /// <remarks>Use this constructor if there is no instance, i.e. it is a static class or only static properties are being validated. If an instance of an object needs to be validated use <see cref="FieldValidationManager(object)"/>.</remarks>
    /// <exception cref="ArgumentException"><paramref name="ruleSet"/> is a <see cref="string.Empty"/>.</exception>
    public FieldValidationManager(RuntimeTypeHandle targetHandle, string ruleSet, object context)
      : base(targetHandle, ruleSet, context)
    {
    }

    #endregion



    #region Methods


    #region Validate

    /// <summary>
    /// Validates all properties.
    /// </summary>
    /// <exception cref="InvalidOperationException">No <see cref="Rule"/>s can be found.</exception>
    public void ValidateAllFields()
    {
      TypeDescriptor typeDescriptor = TypeDescriptor;
      errorDictionary.Clear();
      bool found = false;
      foreach (FieldDescriptor fieldDescriptor in typeDescriptor.Fields)
      {
        object fieldValue = fieldDescriptor.GetValue(target);
        if (CheckValidMember(fieldDescriptor, fieldValue))
        {
          found = true;
        }
      }
      if (!found)
      {
        if (ruleSet == null)
        {
          throw new InvalidOperationException("No fields could be found containing rules.");
        }
        else
        {
            throw new InvalidOperationException(string.Format("No fields could be found containing rules with the ruleSet '{0}'.", ruleSet));

        }
      }
    }


    /// <summary>
    /// Validates the specified field.
    /// </summary>
    /// <param name="fieldName">Field to validate. Case sensitive.</param>
    /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is a null reference.</exception>
    /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
    /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
    /// <exception cref="ArgumentException">No <see cref="Rule"/>s could be found on the <see cref="FieldDescriptor"/>,for <paramref name="fieldName"/>, that have the <see cref="Rule.RuleSet"/> equal to <see cref="MemberValidationManager.RuleSet"/>.</exception>
    public void ValidateField(string fieldName)
    {
      Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
      FieldDescriptor fieldDescriptor;
      if (TypeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
      {
        object fieldValue = fieldDescriptor.GetValue(target);
        if (!CheckValidMember(fieldDescriptor, fieldValue))
        {
          throw new ArgumentException(string.Format("A field named '{0}' could not be found containing rules with the ruleSet '{1}'.", fieldName, ruleSet), "fieldName");
        }
      }
      else
      {
        throw new ArgumentException(string.Format("A field named '{0}' could not be found containing rules.", fieldName), "fieldName");
      }
    }

    #endregion


    #region TryValidate

    /// <summary>
    /// Validates all properties.
    /// </summary>
    public void TryValidateAllFields()
    {
      TypeDescriptor typeDescriptor = TypeDescriptor;
      errorDictionary.Clear();
      foreach (FieldDescriptor fieldDescriptor in typeDescriptor.Fields)
      {
        object fieldValue = fieldDescriptor.GetValue(target);
        CheckValidMember(fieldDescriptor, fieldValue);
      }
    }


    /// <summary>
    /// Validates only the specified field. 
    /// </summary>
    /// <remarks>No exception is thrown if the field is not found.</remarks>
    /// <param name="fieldName">Field to validate. Case sensitive.</param>
    /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is a null reference.</exception>
    /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
    public bool TryValidateField(string fieldName)
    {
      Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");

      FieldDescriptor fieldDescriptor;
      if (TypeDescriptor.Fields.TryGetValue(fieldName, out fieldDescriptor))
      {
        object fieldValue = fieldDescriptor.GetValue(target);
        CheckValidMember(fieldDescriptor, fieldValue);
        return true;
      }
      else
      {
        return false;
      }
    }

    #endregion


    /// <summary>
    /// Get a <see cref="IList{T}"/> of all <see cref="ValidationResult"/>s for a list of properties.
    /// </summary>
    /// <remarks>Use <see cref="ResultFormatter"/> for some basic formatting conversions of <see cref="ValidationResult"/>s.</remarks>
    /// <param name="fieldNames">The names of the properties to retrieve error messages for. Case sensitive.</param>
    /// <returns>All <see cref="ValidationResult"/>s for the list of properties.</returns>
    /// <exception cref="ArgumentNullException"><paramref name="fieldNames"/> is null.</exception>
    /// <exception cref="ArgumentOutOfRangeException">Length of <paramref name="fieldNames"/> is 0.</exception>
    /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found any single field <paramref name="fieldNames"/>.</exception>
    public IList<ValidationResult> GetResultsInErrorForFields(params string[] fieldNames)
    {
      Guard.ArgumentNotNull(fieldNames, "fieldNames");

      if (fieldNames.Length == 0)
      {
        throw new ArgumentOutOfRangeException("fieldNames");
      }

      List<ValidationResult> validationResults = new List<ValidationResult>();
      foreach (string fieldName in fieldNames)
      {
        validationResults.AddRange(GetResultsInErrorForField(fieldName));
      }
      return validationResults;
    }


    /// <summary>
    /// Get a <see cref="IList{T}"/> of all <see cref="ValidationResult"/>s for a given field.
    /// </summary>
    /// <remarks>Use <see cref="ResultFormatter"/> for some basic formatting conversions of <see cref="ValidationResult"/>s.</remarks>
    /// <param name="fieldName">Field to retrieve error message for. Case sensitive.</param>
    /// <returns>All <see cref="ValidationResult"/>s for a given field.</returns>
    /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
    /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
    /// <exception cref="ArgumentException">No <see cref="FieldDescriptor"/> could be found named <paramref name="fieldName"/>.</exception>
    public IList<ValidationResult> GetResultsInErrorForField(string fieldName)
    {
      Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
      if (TypeDescriptor.Fields.ContainsKey(fieldName))
      {
        return GetResultsInErrorForMember(fieldName);
      }
      else
      {
        throw new ArgumentException(string.Format("A field named '{0}' could not be found containing rules.", fieldName), "fieldName");
      }
    }


    /// <summary>
    /// Get a <see cref="IList{T}"/> of all <see cref="ValidationResult"/>s for a given field. No exception is thrown if the field is not found.
    /// </summary>
    /// <remarks>Use <see cref="ResultFormatter"/> for some basic formatting conversions of <see cref="ValidationResult"/>s.</remarks>
    /// <param name="fieldName">Field to retrieve error message for. Case sensitive.</param>
    /// <param name="validationResults">When this method returns, if the field exists and contains <see cref="Rule"/>s, contains a <see cref="IList{T}"/> of <see cref="ValidationResult"/> for the field being validated; otherwise null.</param>
    /// <return><see langword="true"/> if the field exists and has <see cref="Rule"/>s; otherwise <see langword="false"/>.</return>
    /// <exception cref="ArgumentNullException"><paramref name="fieldName"/> is null.</exception>
    /// <exception cref="ArgumentException"><paramref name="fieldName"/> is <see cref="string.Empty"/>.</exception>
    public bool TryGetResultsInErrorForField(string fieldName, out IList<ValidationResult> validationResults)
    {
      Guard.ArgumentNotNullOrEmptyString(fieldName, "fieldName");
      if (TypeDescriptor.Fields.ContainsKey(fieldName))
      {
        validationResults = GetResultsInErrorForMember(fieldName);
        return true;
      }
      else
      {
        validationResults = null;
        return false;
      }
    }

    #endregion
  }
}