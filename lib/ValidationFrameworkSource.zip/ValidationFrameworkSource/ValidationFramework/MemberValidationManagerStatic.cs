using System;
using System.Collections.Generic;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ValidationFramework
{
    public abstract partial class MemberValidationManager
    {
        internal static bool CheckValid(InfoDescriptor descriptor, object value, string ruleSet, object context, object target, List<ValidationResult> validationResults)
        {
            bool ruleFound = false;
            if (ruleSet == null)
            {
                for (int index = 0; index < descriptor.Rules.Count; index++)
                {
                    Rule fieldRule = descriptor.Rules[index];
                    ruleFound = true;
                    ValidationResult validationResult = fieldRule.Validate(target, value, context);
                    if (validationResult != null)
                    {
                        validationResults.Add(validationResult);
                    }
                }
            }
            else
            {
                ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
                for (int index = 0; index < descriptor.Rules.Count; index++)
                {
                    Rule rule = descriptor.Rules[index];
                    if (string.Equals(rule.RuleSet, ruleSet))
                    {
                        ruleFound = true;
                        ValidationResult validationResult = rule.Validate(target, value, context);
                        if (validationResult != null)
                        {
                            validationResults.Add(validationResult);
                        }
                    }
                }
            }
            return ruleFound;
        }

        internal static void InternalThrowException(InfoDescriptor infoDescriptor, object value, string ruleSet, object context, bool throwException, object target)
        {
            bool ruleFound = false;
            if (ruleSet == null)
            {
                for (int index = 0; index < infoDescriptor.Rules.Count; index++)
                {
                    ruleFound = true;
                    Rule fieldRule = infoDescriptor.Rules[index];
                    ValidationResult tempValidationResult = fieldRule.Validate(target, value, context);
                    if (tempValidationResult != null)
                    {
                        throw new ArgumentException(tempValidationResult.ErrorMessage, "value");
                    }
                }
            }
            else
            {
                ruleSet = RuleSetHelper.ConvertToUpper(ruleSet);
                for (int index = 0; index < infoDescriptor.Rules.Count; index++)
                {
                    Rule fieldRule = infoDescriptor.Rules[index];
                    if (string.Equals(fieldRule.RuleSet, ruleSet))
                    {
                        ruleFound = true;
                        ValidationResult tempValidationResult = fieldRule.Validate(target, value, context);
                        if (tempValidationResult != null)
                        {
                            throw new ArgumentException(tempValidationResult.ErrorMessage, "value");
                        }
                    }
                }
            }

            ThrowNoRules(ruleSet, ruleFound, throwException);
        }

        protected static void ThrowNoRules(string ruleSet, bool ruleFound, bool throwException)
        {
            if (!ruleFound && throwException)
            {
                if (ruleSet == null)
                {
                    throw new InvalidOperationException("No members could be found containing rules.");
                }
                else
                {
                    throw new InvalidOperationException(string.Format("No members could be found containing rules with the ruleSet '{0}'.", ruleSet));
                }
            }
        }

   


        internal static IList<ValidationResult> InternalValidateInfoDescriptor(InfoDescriptor infoDescriptor, object value, string ruleSet, object context, bool throwException, object target)
        {
            List<ValidationResult> validationResults = new List<ValidationResult>();
            if (!CheckValid(infoDescriptor, value, ruleSet, context, target, validationResults))
            {
                if (throwException)
                {
                    throw new ArgumentException(string.Format("A member named '{0}' could not be found containing rules with the ruleSet '{1}'.", infoDescriptor.Name, ruleSet), "propertyName");
                }
            }
            return validationResults;
        }

    }
}

