using System.Collections.Generic;
using System.Xml.Serialization;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// An object representation of the validation configuration for a group classes.
    /// </summary>
    /// <seealso cref="ConfigurationService"/>
    /// <exclude/>
    [XmlRoot("validationMapping", Namespace = "urn:validationFramework-validationDefinition-1.5")]
    public sealed class ValidationMappingData
    {

        #region Properties

        /// <summary>
        /// Gets or sets a <see cref="List{T}"/> of <see cref="ClassData"/>s that represent the classes to be validate.
        /// </summary>
        [XmlElement("class", Type = typeof (ClassData))]
        public ClassData[] ClassDatas
        {
            get;
            set;
        }

        #endregion
    }
}