using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;

namespace ValidationFramework.Configuration
{
    //TODO: should this be a struct???
    /// <summary>
    /// An object representation of the validation configuration.
    /// </summary>
    /// <remarks>Will be converted to a <see cref="Rule"/> by the <see cref="Type"/> refined by <see cref="RuleData.TypeName"/>.</remarks>
    /// <seealso cref="ConfigurationService"/>
    [XmlRoot("rule")]
    public sealed class RuleData
    {

        #region Properties

        /// <summary>
        /// Gets or sets the name of the <see cref="Type"/> that this <see cref="RuleData"/> represents.
        /// </summary>
        /// <remarks>This <see cref="Type"/> must implement <see cref="IRuleConfigReader"/>.</remarks>
        [XmlAttribute("typeName")]
        public string TypeName
        {
            get;
            set;
        }


        /// <summary>
        /// Gets or sets the error message for this <see cref="RuleData"/>.
        /// </summary>
        [XmlAttribute("errorMessage")]
        public string ErrorMessage
        {
            get;
            set;
        }


        /// <summary>
        /// Gets or sets a <see cref="bool"/> indicating is <see cref="ConfigurationService.ErrorMessageProvider"/> should be used.
        /// </summary>
        [XmlAttribute("useErrorMessageProvider")]
        public bool UseErrorMessageProvider
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets an array of leftover <see cref="XmlAttribute"/>s after xml has been deserialized from xml.
        /// </summary>
        [XmlAnyAttribute]
        public XmlAttribute[] XmlAttributes
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets an array of leftover <see cref="XmlElement"/>s after xml has been deserialized from xml.
        /// </summary>
        [XmlAnyElement]
        public XmlElement[] XmlElements
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the rule set for this <see cref="RuleData"/>.
        /// </summary>
        [XmlAttribute("ruleSet")]
        public string RuleSet
        {
            get;
            set;
        }

        #endregion


        #region Methods

        /// <summary>
        /// Convert an array of <see cref="XmlAttribute"/>s to an <see cref="IDictionary{TKey,TValue}"/>.
        /// </summary>
        /// <param name="xmlAttributes">The array of <see cref="XmlAttribute"/>s to convert.</param>
        /// <returns>An <see cref="IDictionary{TKey,TValue}"/> that contains all the key value pairs of the <see cref="XmlAttribute"/>s in <paramref name="xmlAttributes"/>.</returns>
        public static IDictionary<string, string> ConvertExtraAttributesAsDictionary(XmlAttribute[] xmlAttributes)
        {
            Guard.ArgumentNotNull(xmlAttributes, "xmlAttributes");
            Dictionary<string, string> attributeDictionary = new Dictionary<string, string>();
            for (int attributeIndex = 0; attributeIndex < xmlAttributes.Length; attributeIndex++)
            {
                XmlAttribute attribute = xmlAttributes[attributeIndex];
                attributeDictionary.Add(attribute.Name, attribute.Value);
            }
            return attributeDictionary;
        }

        #endregion
    }
}