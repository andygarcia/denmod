using System;
using System.Xml.Serialization;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// An object representation of the validation configuration for an overload type.
    /// </summary>
    /// <remarks>Used to identify methods that have overloads.</remarks>
    /// <exclude/>
    /// <seealso cref="ConfigurationService"/>
    [XmlRoot("type")]
    public sealed class TypeData
    {

        #region Properties

        /// <summary>
        /// Gets or sets the name of the <see cref="Type"/> that this <see cref="TypeData"/> represents.
        /// </summary>
        [XmlAttribute("typeName")]
        public string TypeName
        {
            get;
            set;
        }

        #endregion
    }
}