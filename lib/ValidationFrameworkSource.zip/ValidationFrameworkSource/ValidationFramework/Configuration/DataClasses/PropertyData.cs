using System.Collections.Generic;
using System.Xml.Serialization;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// An object representation of the validation configuration for a property.
    /// </summary>
    /// <seealso cref="ConfigurationService"/>
    /// <exclude/>
    public sealed class PropertyData
    {

        #region Properties

        /// <summary>
        /// Gets or sets a <see cref="List{T}"/> of <see cref="RuleData"/> that represents the <see cref="Rule"/>s for this <see cref="PropertyData"/>.
        /// </summary>
        [XmlElement("rule", Type = typeof (RuleData))]
        public RuleData[] RuleDatas
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the name of the property.
        /// </summary>
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }

        #endregion
    }
}