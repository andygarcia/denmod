using System;
using System.Xml.Serialization;
using ValidationFramework.Reflection;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// An object representation of the validation configuration for a class.
    /// </summary>
    /// <exclude/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class ClassData
    {


        #region Properties

        /// <summary>
        /// Gets or sets the name of the <see cref="Type"/> that this <see cref="ClassData"/> represents.
        /// </summary>
        [XmlAttribute("typeName")]
        public string TypeName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets an array of <see cref="PropertyData"/>s that represent the properties to be validate.
        /// </summary>
        /// <remarks>The <see cref="PropertyData"/>s will be converted to <see cref="PropertyDescriptor"/>s.</remarks>
        [XmlElement("property", Type = typeof (PropertyData))]
        public PropertyData[] Properties
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets an array of <see cref="MethodData"/>s that represent the methods to be validate.
        /// </summary>
        /// <remarks>The <see cref="MethodData"/>s will be converted to <see cref="MethodDescriptor"/>s.</remarks>
        [XmlElement("method", Type = typeof (MethodData))]
        public MethodData[] Methods
        {
            get;
            set;
        }

        #endregion
    }
}