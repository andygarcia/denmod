using System.Collections.Generic;
using System.Xml.Serialization;
using ValidationFramework.Reflection;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// An object representation of the validation configuration for a method.
    /// </summary>
    /// <exclude/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class MethodData
    {


        #region Properties

        /// <summary>
        /// Gets or sets name of the method this <see cref="MethodData"/> represents.
        /// </summary>
        [XmlAttribute("name")]
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a <see cref="List{T}"/> of <see cref="ParameterData"/>s that represent the parameters to be validate.
        /// </summary>
        /// <remarks>The <see cref="ParameterData"/>s will be converted to <see cref="ParameterDescriptor"/>s.</remarks>
        [XmlElement("parameter", Type = typeof (ParameterData))]
        public ParameterData[] Parameters
        {
            get;
            set;
        }


        /// <summary>
        /// Gets or sets a <see cref="List{T}"/> of <see cref="TypeData"/>s that are used to uniquely identify overloads of a method.
        /// </summary>
        [XmlElement("overloadType", Type = typeof (TypeData))]
        public TypeData[] OverloadTypes
        {
            get;
            set;
        }

        #endregion
    }
}