using System.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A custom <see cref="ConfigurationElement"/> to hold the urls of mapping documents.
    /// </summary>
    public sealed class MappingDocumentElement : ConfigurationElement
    {

        #region Properties

        /// <summary>
        /// Gets or sets the url for the <see cref="MappingDocumentElement"/>.
        /// </summary>
        [SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings"), ConfigurationProperty("url", IsKey = true, IsRequired = true)]
        public string Url
        {
            get
            {
                return (string) base["url"];
            }
            set
            {
                base["url"] = value;
            }
        }

        #endregion

    }
}