using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml.Serialization;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// An <see cref="IErrorMessageProvider"/> that uses the current culture to determine error messages.
    /// </summary>
    [XmlRoot("keyedCultureErrorMessageProvider")]
    public class KeyedCultureErrorMessageProvider : IErrorMessageProvider
    {
        #region Fields

        private Dictionary<string, MessageGroup> messageDictionary;
        private MessageGroup[] messageGroups;

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets the array of <see cref="MessageGroup"/>s for the <see cref="KeyedCultureErrorMessageProvider"/>.
        /// </summary>
        [XmlElement("messageGroup", Type = typeof (MessageGroup))]
        public MessageGroup[] MessageGroups
        {
            get
            {
                return messageGroups;
            }
            set
            {
                messageGroups = value;
                messageDictionary = new Dictionary<string, MessageGroup>(StringComparer.OrdinalIgnoreCase);
                for (int index = 0; index < messageGroups.Length; index++)
                {
                    MessageGroup messageGroup = messageGroups[index];
                    messageDictionary.Add(messageGroup.Key, messageGroup);
                }
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Retrieve an error message.
        /// </summary>
        /// <param name="rule">The <see cref="Rule"/> that is requesting the error message.</param>
        /// <param name="targetObjectValue">The value of the object containing the member to validate.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the <see cref="Rule"/> to validate.</param>
        /// <returns>An error message.</returns>
        public string RetrieveErrorMessage(Rule rule, object targetObjectValue, object targetMemberValue, object context)
        {
            CultureInfo cultureInfo = CultureInfo.CurrentCulture;

            MessageGroup messageGroup;
            if (messageDictionary.TryGetValue(rule.ErrorMessage, out messageGroup))
            {
                CultureMessage currentCultureMessage;
                CultureMessage twoLetterISOLanguageName;
                if (messageGroup.CultureDictionary.TryGetValue(cultureInfo.TwoLetterISOLanguageName, out twoLetterISOLanguageName))
                {
                    return twoLetterISOLanguageName.Text;
                }
                else if (messageGroup.CultureDictionary.TryGetValue(cultureInfo.Name, out currentCultureMessage))
                {
                    return currentCultureMessage.Text;
                }
            }
            return null;
        }

        #endregion
    }
}