using System;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using ValidationFramework.Reflection;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// Allow the addition of <see cref="Rule"/>s via xml.
    /// </summary>
    /// <example>
    /// <code source="Examples\ExampleLibraryCSharp\Configuration\ConfigurationServiceSample.cs" title="The following example shows how to programmatically add Rules via an embedded resource." lang="cs"/>
    /// <code source="Examples\ExampleLibraryCSharp\Configuration\ValidatableClass.validation.xml" title="This C# example assumes there is an embedded resource, named 'ValidatableClass.validation.xml' in the current Assembly, containing the following xml." lang="xml"/>
    /// <code source="Examples\ExampleLibraryVB\Configuration\ConfigurationServiceSample.vb" title="The following example shows how to programmatically add Rules via an embedded resource." lang="vbnet"/>
    /// <code source="Examples\ExampleLibraryVB\Configuration\ValidatableClass.validation.xml" title="This VB example assumes there is an embedded resource, named 'ValidatableClass.validation.xml' in the current Assembly, containing the following xml." lang="xml"/>
    /// </example>
    public static class ConfigurationService
    {
        #region Fields

        private static readonly XmlReaderSettings xmlReaderSettings = new XmlReaderSettings();
        private static readonly XmlSerializer xmlSerializer = new XmlSerializer(typeof (ValidationMappingData));
		private static readonly object initializedLock = new object();
        private const string ValidationDefinitionsSchemaResource = "ValidationFramework.validation-definition.xsd";

        /// <summary>
        /// The XML Namespace for the validation-mapping. ("urn:validationFramework-validationDefinition-1.5")
        /// </summary>
        public const string ValidationDefinitionsSchemaXMLNS = "urn:validationFramework-validationDefinition-1.5";

        private static IErrorMessageProvider errorMessageProvider;
        private static bool initialized = false;

        #endregion

       
        #region Constructors
        
        static ConfigurationService()
        {

            xmlReaderSettings.ValidationEventHandler += ValidationHandler;
            xmlReaderSettings.ValidationType = ValidationType.Schema;

            XmlSchemaSet validationDefinitionSchemaCollection;
            validationDefinitionSchemaCollection = new XmlSchemaSet();
            validationDefinitionSchemaCollection.Add(XmlSchema.Read(Assembly.GetExecutingAssembly().GetManifestResourceStream(ValidationDefinitionsSchemaResource), null));

            xmlReaderSettings.Schemas.Add(validationDefinitionSchemaCollection);
        }

        #endregion


        #region Methods

        /// <summary>
        /// Initializes the <see cref="ConfigurationService"/>.
        /// </summary>
        /// <remarks>
		/// Retrieves <see cref="ValidationConfigurationSection"/>from the current application's default configuration. 
		/// For that <see cref="ValidationConfigurationSection"/> it does the following.
		/// <list type="bullet">
		/// <item>
		/// Configures <see cref="ErrorMessageProvider"/> base on <see cref="ValidationConfigurationSection.ErrorMessageProvider"/>.
		/// </item>
		/// <item>
		/// Goes through each <see cref="ValidationConfigurationSection.MappingDocuments"/> and calls <see cref="AddUrl(string)"/> for each <see cref="MappingDocumentElement.Url"/>.
		/// </item>
		/// </list>
		/// Calling this only performs these action on the first call. Each successive call will be ignored.
		/// If this method is called simultaneous on two different threads one thread will obtain a lock and the other thread will have to wait. 
		/// </remarks>
		/// <exception cref="ArgumentNullException">Any <see cref="MappingDocumentElement.Url"/> is null.</exception>
		/// <exception cref="ArgumentException">Any <see cref="MappingDocumentElement.Url"/>  is a <see cref="string.Empty"/>.</exception>
		/// <exception cref="FileNotFoundException">Any <see cref="MappingDocumentElement.Url"/>  cannot be found.</exception>
		/// <exception cref="WebException">The remote filename, defined by Any <see cref="MappingDocumentElement.Url"/>, cannot be resolved.-or-An error occurred while processing the request.</exception>
		/// <exception cref="DirectoryNotFoundException">Part of the filename or directory cannot be found.</exception>
		/// <exception cref="UriFormatException">Any <see cref="MappingDocumentElement.Url"/> is not a valid URI.</exception>
		[SuppressMessage("Microsoft.Usage", "CA2234:PassSystemUriObjectsInsteadOfStrings")]
		public static void Initialize()
        {
        	if (!initialized)
        	{
        		lock (initializedLock)
        		{
        			if (!initialized)
        			{
        				object section = ConfigurationManager.GetSection("validationFrameworkConfiguration");
        				if (section != null)
        				{
        					ValidationConfigurationSection validationConfigurationSection = (ValidationConfigurationSection) section;
        					ErrorMessageProviderElement errorMessageProviderElement = validationConfigurationSection.ErrorMessageProvider;
        					if (errorMessageProviderElement != null)
        					{
        						Type type = Type.GetType(errorMessageProviderElement.TypeName, true);
        						XmlSerializer errorMessageProviderXmlSerializer = new XmlSerializer(type);

        						errorMessageProvider = (IErrorMessageProvider) errorMessageProviderXmlSerializer.Deserialize(new StringReader(errorMessageProviderElement.InnerXml));
        					}

        					if (validationConfigurationSection.MappingDocuments != null)
        					{
        						foreach (MappingDocumentElement mappingDocument in validationConfigurationSection.MappingDocuments)
        						{
        							AddUrl(mappingDocument.Url);
        						}
        					}
        				}
        				initialized = true;
        			}
        		}
        	}
        }


    	/// <summary>
        /// Add validation from a particular XML file.
        /// </summary>
        /// <param name="xmlFileInfo">The <see cref="FileInfo"/> to the XML data.</param>
        /// <exception cref="ArgumentNullException"><paramref name="xmlFileInfo"/> is null.</exception>
        /// <exception cref="FileNotFoundException">The file represented by <paramref name="xmlFileInfo"/> cannot be found.</exception>
        /// <exception cref="WebException">The remote filename cannot be resolved.-or-An error occurred while processing the request.</exception>
        /// <exception cref="DirectoryNotFoundException">Part of the filename or directory cannot be found.</exception>
        [SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        public static void AddXmlFile(FileInfo xmlFileInfo)
        {
            Guard.ArgumentNotNull(xmlFileInfo, "xmlFileInfo");
            AddXmlFile(xmlFileInfo.FullName);
        }


        /// <summary>
        /// Add validation from a particular XML file.
        /// </summary>
        /// <param name="xmlFileUrl">The URL for the file containing the XML data.</param>
        /// <exception cref="ArgumentNullException"><paramref name="xmlFileUrl"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="xmlFileUrl"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="FileNotFoundException"><paramref name="xmlFileUrl"/> cannot be found.</exception>
        /// <exception cref="WebException">The remote filename cannot be resolved.-or-An error occurred while processing the request.</exception>
        /// <exception cref="DirectoryNotFoundException">Part of the filename or directory cannot be found.</exception>
        /// <exception cref="UriFormatException"><paramref name="xmlFileUrl"/> is not a valid URI.</exception>
        [SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
        public static void AddXmlFile(string xmlFileUrl)
        {
            Guard.ArgumentNotNullOrEmptyString(xmlFileUrl, "xmlFileUrl");
            using (XmlTextReader textReader = new XmlTextReader(xmlFileUrl))
            {
                AddXmlReader(textReader);
            }
        }


        /// <summary>
        /// Add all validation definitions from a directory tree.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Assume that any file named <c>*.validation.xml</c> is a validation definition document.
        /// </para>
        /// <para>
        /// This method is recursive.
        /// </para>
        /// </remarks>
        /// <param name="directoryInfo">a directory</param>
        /// <exception cref="ArgumentNullException"><paramref name="directoryInfo"/> is null.</exception>
        /// <exception cref="DirectoryNotFoundException">The path encapsulated in <paramref name="directoryInfo"/> is invalid, such as being on an unmapped drive.</exception>
        /// <exception cref="FileNotFoundException">A file in one of the directories cannot be found.</exception>
        /// <exception cref="WebException">The remote filename cannot be resolved.-or-An error occurred while processing the request.</exception>
        /// <exception cref="DirectoryNotFoundException">Part of the filename or directory cannot be found.</exception>
        public static void AddDirectory(DirectoryInfo directoryInfo)
        {
            Guard.ArgumentNotNull(directoryInfo, "directoryInfo");
            DirectoryInfo[] directoryInfos = directoryInfo.GetDirectories();
            for (int directoryIndex = 0; directoryIndex < directoryInfos.Length; directoryIndex++)
            {
                DirectoryInfo subDirectory = directoryInfos[directoryIndex];
                AddDirectory(subDirectory);
            }

            FileInfo[] fileInfos = directoryInfo.GetFiles("*.validation.xml");
            for (int fileIndex = 0; fileIndex < fileInfos.Length; fileIndex++)
            {
                FileInfo validationFileInfo = fileInfos[fileIndex];
                AddXmlFile(validationFileInfo);
            }
        }


        /// <summary>
        /// Add validation definitions from a <c>string</c>
        /// </summary>
        /// <param name="xml">The <see cref="string"/> containing the XML data.</param>
        /// <exception cref="ArgumentNullException"><paramref name="xml"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="xml"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="XmlException"><paramref name="xml"/> is not a valid <see cref="XmlNodeType.Document"/>.</exception>
        public static void AddXmlString(string xml)
        {
            Guard.ArgumentNotNullOrEmptyString(xml, "xml");
            using (XmlTextReader reader = new XmlTextReader(xml, XmlNodeType.Document, null))
            {
                // make a StringReader for the string passed in - the StringReader
                // inherits from TextReader.  We can use the XmlTextReader.ctor that
                // takes the TextReader to build from a string...
                AddXmlReader(reader);
            }
        }


        /// <summary>
        /// Adds the validation in the <see cref="XmlTextReader"/> after validating it against the validationFramework-validationDefinition-1.5 schema.
        /// </summary>
        /// <param name="xmlTextReader">The XmlTextReader that contains the validation.</param>
        /// <exception cref="ArgumentNullException"><paramref name="xmlTextReader"/> is null.</exception>
        public static void AddXmlReader(XmlTextReader xmlTextReader)
        {
            Guard.ArgumentNotNull(xmlTextReader, "xmlTextReader");
            XmlReader validatingXmlTextReader = XmlReader.Create(xmlTextReader, xmlReaderSettings);
            ValidationMappingData validationMappingData = (ValidationMappingData)xmlSerializer.Deserialize(validatingXmlTextReader);
            ClassData[] datas = validationMappingData.ClassDatas;
            for (int classDataIndex = 0; classDataIndex < datas.Length; classDataIndex++)
            {
                ClassData classData = datas[classDataIndex];
                Type classType = Type.GetType(classData.TypeName, true);
                ProcessProperties(classData, classType);
                ProcessMethods(classData, classType);
            }
        }




        /// <summary>
        /// Read validation definitions from a URL.
        /// </summary>
        /// <param name="url">a URL</param>
        /// <exception cref="ArgumentNullException"><paramref name="url"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="url"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="FileNotFoundException"><paramref name="url"/> cannot be found.</exception>
        /// <exception cref="WebException">The remote filename cannot be resolved.-or-An error occurred while processing the request.</exception>
        /// <exception cref="DirectoryNotFoundException">Part of the filename or directory cannot be found.</exception>
        /// <exception cref="UriFormatException"><paramref name="url"/> is not a valid URI.</exception>
        [SuppressMessage("Microsoft.Design", "CA1057:StringUriOverloadsCallSystemUriOverloads")]
        public static void AddUrl(string url)
        {
            Guard.ArgumentNotNullOrEmptyString(url, "url");
            AddXmlFile(url);
        }


        /// <summary>
        /// Read validation definitions from a <see cref="Uri"/>.
        /// </summary>
        /// <param name="uri">a <see cref="Uri" /> to read the mappings from.</param>
        /// <returns>This configuration object.</returns>
        /// <exception cref="ArgumentNullException"><paramref name="uri"/> is null.</exception>
        [SuppressMessage("Microsoft.Usage", "CA2234:PassSystemUriObjectsInsteadOfStrings")]
        public static void AddUrl(Uri uri)
        {
            Guard.ArgumentNotNull(uri, "uri");
            AddUrl(uri.AbsolutePath);
        }


        /// <summary>
        /// Read validation definitions from an <see cref="XmlDocument"/>.
        /// </summary>
        /// <param name="xmlDocument">A loaded <see cref="XmlDocument"/> that contains the validation.</param>
        /// <exception cref="ArgumentNullException"><paramref name="xmlDocument"/> is null.</exception>
        [SuppressMessage("Microsoft.Design", "CA1059:MembersShouldNotExposeCertainConcreteTypes", MessageId = "System.Xml.XmlNode")]
        public static void AddDocument(XmlDocument xmlDocument)
        {
            Guard.ArgumentNotNull(xmlDocument, "xmlDocument");
            using (MemoryStream memoryStream = new MemoryStream())
            {
                xmlDocument.Save(memoryStream);
                memoryStream.Position = 0;
                AddInputStream(memoryStream);
            }
        }


     


        private static void ProcessMethods(ClassData classData, Type classType)
        {
            if ((classData.Methods != null) && (classData.Methods.Length > 0))
            {
                for (int methodIndex = 0; methodIndex < classData.Methods.Length; methodIndex++)
                {
                    MethodData methodData = classData.Methods[methodIndex];
                    MethodInfo methodInfo;
                    if (methodData.OverloadTypes == null)
                    {
                        methodInfo = classType.GetMethod(methodData.Name);
                    }
                    else
                    {
                        Type[] types = new Type[methodData.OverloadTypes.Length];
                        for (int overloadTypeIndex = 0; overloadTypeIndex < methodData.OverloadTypes.Length; overloadTypeIndex++)
                        {
                            TypeData typeData = methodData.OverloadTypes[overloadTypeIndex];
                            types[overloadTypeIndex] = Type.GetType(typeData.TypeName, true);
                        }
                        methodInfo = classType.GetMethod(methodData.Name, types);
                    }
                    MethodDescriptor methodDescriptor = MethodCache.GetMethod(methodInfo.MethodHandle);
                    for (int parameterIndex = 0; parameterIndex < methodData.Parameters.Length; parameterIndex++)
                    {
                        ParameterData parameterData = methodData.Parameters[parameterIndex];
                        ParameterDescriptor parameterDescriptor = methodDescriptor.Parameters[parameterData.Name];
                        AddRuleToInfoDescriptor(parameterData.RuleDatas, parameterDescriptor);
                    }
                }
            }
        }


        private static void ProcessProperties(ClassData classData, Type classType)
        {
            if ((classData.Properties != null) && (classData.Properties.Length > 0))
            {
                RuntimeTypeHandle runtimeTypeHandle = classType.TypeHandle;
                TypeDescriptor typeDescriptor = TypeCache.GetType(runtimeTypeHandle);
                for (int propertyIndex = 0; propertyIndex < classData.Properties.Length; propertyIndex++)
                {
                    PropertyData propertyData = classData.Properties[propertyIndex];
                    PropertyDescriptor propertyDescriptor;
                    if (!typeDescriptor.Properties.TryGetValue(propertyData.Name, out propertyDescriptor))
                    {
                        propertyDescriptor = typeDescriptor.GetOrCreatePropertyDescriptor(propertyData.Name);
                    }
                    AddRuleToInfoDescriptor(propertyData.RuleDatas, propertyDescriptor);
                }
            }
        }


        private static void AddRuleToInfoDescriptor(RuleData[] list, InfoDescriptor infoDescriptor)
        {
            for (int ruleDateIndex = 0; ruleDateIndex < list.Length; ruleDateIndex++)
            {
                RuleData ruleData = list[ruleDateIndex];
                RuntimeTypeHandle runtimeTypeHandle = infoDescriptor.RuntimeTypeHandle;
                Rule rule = GetRule(ruleData, runtimeTypeHandle);
                infoDescriptor.Rules.Add(rule);
            }
        }


        /// <summary>
        /// Made public for unit testing purposes.
        /// </summary>
        /// <exclude/>
        public static Rule GetRule(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            Type ruleConfigReaderType;

            string typeName = ruleData.TypeName;
            bool containsCommas = ruleData.TypeName.Contains(",");

            if (containsCommas)
            {
                Type type = Type.GetType(typeName, true);
                //is it a IRuleConfigReader
                if (ReflectionUtilities.IsSubclassOf(type, typeof(IRuleConfigReader)))
                {
                    ruleConfigReaderType = type;
                }
                else //not a IRuleConfigReader so assume it is a Rule and try to derive. 
                {
                    string assemblyName = type.Assembly.FullName;
                    string namespaceName = type.Namespace;

                    //Assumes ConfigReader is of the form {RuleName}ConfigReader in the same assembly and namespace
                    string configReaderTypeName = string.Format("{0}.{1}ConfigReader,{2}", namespaceName, type.Name, assemblyName);
                    try
                    {
                        ruleConfigReaderType = Type.GetType(configReaderTypeName, true);
                    }
                    catch (Exception e)
                    {
                        throw new ArgumentException(string.Format("Could not load IRuleConfigReader type. Tried '{0}'", configReaderTypeName), "runtimeTypeHandle", e);
                    }
                }
            }
            else
            {
                string internalTypeName;
                if (typeName.Contains("ConfigReader"))
                {
                    internalTypeName = string.Format("ValidationFramework.Configuration.{0},ValidationFramework", typeName);
                }
                else
                {
                    internalTypeName = string.Format("ValidationFramework.Configuration.{0}ConfigReader,ValidationFramework", typeName);
                }

                try
                {
                    ruleConfigReaderType = Type.GetType(internalTypeName, true);
                }
                catch (Exception e)
                {
                    throw new ArgumentException(string.Format("Could not load IRuleConfigReader type. Tried '{0}'", internalTypeName), "runtimeTypeHandle", e);
                }
            }
            IRuleConfigReader ruleConfigReader = (IRuleConfigReader)Activator.CreateInstance(ruleConfigReaderType);
            return ruleConfigReader.ReadConfig(ruleData, runtimeTypeHandle);
        }


        /// <summary>
        /// Add validation definition from a <see cref="Stream"/>.
        /// </summary>
        /// <param name="xmlInputStream">The stream containing XML</param>
        /// <remarks>
        /// The <see cref="Stream"/> passed in through the parameter <c>xmlInputStream</c> is not <b>guaranteed</b> to be cleaned up by this method.  It is the callers responsibility to ensure that the <c>xmlInputStream</c> is properly handled when this method completes.
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="xmlInputStream"/> is null.</exception>
        public static void AddInputStream(Stream xmlInputStream)
        {
            Guard.ArgumentNotNull(xmlInputStream, "xmlInputStream");
            using (XmlTextReader textReader = new XmlTextReader(xmlInputStream))
            {
                AddXmlReader(textReader);
            }
        }


        /// <summary>
        /// Adds the validation definitions in the Resource of the <see cref="Assembly"/>.
        /// </summary>
        /// <param name="path">The path to the Resource file in the <see cref="Assembly"/></param>
        /// <param name="assembly">The <see cref="Assembly"/> that contains the Resource file.</param>
        /// <exception cref="ArgumentNullException"><paramref name="assembly"/> is null.</exception>
        /// <exception cref="ArgumentNullException"><paramref name="path"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="path"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="FileLoadException"><paramref name="path"/> could not be loaded.</exception>
        /// <exception cref="FileNotFoundException"><paramref name="path"/> was not found.</exception>
        /// <exception cref="BadImageFormatException"><paramref name="assembly"/> is not a valid assembly.</exception>
        public static void AddResource(string path, Assembly assembly)
        {
            Guard.ArgumentNotNullOrEmptyString(path, "path");
            Guard.ArgumentNotNull(assembly, "assembly");
            using (Stream resourceStream = assembly.GetManifestResourceStream(path))
            {

                AddInputStream(resourceStream);
            }
        }


        /// <summary>
        /// Add validation definitions a specific <see cref="Type"/>.
        /// </summary>
        /// <param name="type">The type to map.</param>
        /// <returns>This configuration object.</returns>
        /// <remarks>
        /// <para>If <paramref name="type"/> has a full name of <c>MyNameSpace.MyClass</c> the the resource named <c>MyNameSpace.MyClass.validation.xml</c>, embedded in the class' assembly, will be added.</para>
        /// <para>If the mappings and classes are defined in different assemblies or don't follow the naming convention, then this method cannot be used.</para>
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="type"/> is null.</exception>
        /// <exception cref="FileLoadException">The resource for <paramref name="type"/> could not be loaded.</exception>
        /// <exception cref="FileNotFoundException">The resource for <paramref name="type"/> was not found.</exception>
        public static void AddClass(Type type)
        {
            Guard.ArgumentNotNull(type, "type");
            AddResource(string.Format("{0}.validation.xml", type.FullName), type.Assembly);
        }


        /// <summary>
        /// Adds all of the Assembly's Resource files that end with "<c>.validation.xml</c>"
        /// </summary>
        /// <param name="assemblyName">The name of the <see cref="Assembly"/> to load.</param>
        /// <remarks>
        /// <para>The <see cref="Assembly"/> must be in the local bin, probing path, or GAC so that the <see cref="Assembly"/> can be loaded by name.  
        /// If these conditions are not satisfied then your code should load the <see cref="Assembly"/> and call the override <see cref="AddAssembly(Assembly)"/> instead.</para> 
        /// <para>This method is case sensitive, hence the resource files must end with lower case "<c>.validation.xml</c>".</para>
        /// </remarks>
        /// <exception cref="ArgumentNullException"><paramref name="assemblyName"/> is null.</exception>
        /// <exception cref="ArgumentException"><paramref name="assemblyName"/> is a <see cref="string.Empty"/>.</exception>
        /// <exception cref="FileLoadException"><paramref name="assemblyName"/> was found but could not be loaded.</exception>
        /// <exception cref="FileNotFoundException"><paramref name="assemblyName"/> is not found.</exception>
        /// <exception cref="BadImageFormatException"><paramref name="assemblyName"/> is not a valid assembly.</exception>
        public static void AddAssembly(string assemblyName)
        {
            Guard.ArgumentNotNullOrEmptyString(assemblyName, "assemblyName");
            AddAssembly(Assembly.Load(assemblyName));
        }


        /// <summary>
        /// Adds all of the <paramref name="assembly"/> resource files that end with "<c>.validation.xml</c>".
        /// </summary>
        /// <remarks>This method is case sensitive, hence the resource files must end with lower case "<c>.validation.xml</c>".</remarks>
        /// <param name="assembly">The <see cref="Assembly"/> to load.</param>
        /// <exception cref="ArgumentNullException"><paramref name="assembly"/> is null.</exception>
        public static void AddAssembly(Assembly assembly)
        {
            Guard.ArgumentNotNull(assembly, "assembly");
            string[] resources = assembly.GetManifestResourceNames();

            for (int resourceIndex = 0; resourceIndex < resources.Length; resourceIndex++)
            {
                string fileName = resources[resourceIndex];
                if ((fileName != null) && (fileName.EndsWith(".validation.xml")))
                {
                    //TODO: some logging here???
                    AddResource(fileName, assembly);
                }
            }
        }


        private static void ValidationHandler(object o, ValidationEventArgs args)
        {
            XmlSchemaException exception = args.Exception;
            string message = string.Format("LineNumber:{0}, LinePosition:{1}: XML validation error: {2}", exception.LineNumber, exception.LinePosition, exception.Message);
            throw new InvalidOperationException(message, exception);
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets or sets the <see cref="IErrorMessageProvider"/> to use.
        /// </summary>
        public static IErrorMessageProvider ErrorMessageProvider
        {
            get
            {
                return errorMessageProvider;
            }
            set
            {
                errorMessageProvider = value;
            }
        }

        #endregion
    }
}