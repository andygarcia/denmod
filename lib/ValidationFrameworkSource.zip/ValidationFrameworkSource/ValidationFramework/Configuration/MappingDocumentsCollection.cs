using System.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A custom <see cref="ConfigurationElementCollection"/> to contain <see cref="MappingDocumentElement"/>s.
    /// </summary>
    [SuppressMessage("Microsoft.Design", "CA1010:CollectionsShouldImplementGenericInterface")]
    public sealed class MappingDocumentsCollection : ConfigurationElementCollection
    {
        #region Methods

        /// <summary>
        /// Creates a new <see cref="ConfigurationElement"/>.
        /// </summary>
        /// <returns>A new <see cref="ConfigurationElement"/>.</returns>
        protected override ConfigurationElement CreateNewElement()
        {
            return new MappingDocumentElement();
        }


        /// <summary>
        /// Gets the element key for a specified configuration element when overridden in a derived class.
        /// </summary>
        /// <param name="element">The <see cref="ConfigurationElement"/> to return the key for.</param>
        /// <returns>An System.Object that acts as the key for the specified <see cref="ConfigurationElement"/>.</returns>
        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((MappingDocumentElement) element).Url;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Get the <see cref="MappingDocumentElement"/> at the specified index location.
        /// </summary>
        /// <param name="index">The index location of the <see cref="MappingDocumentElement"/> to return.</param>
        /// <returns>The <see cref="MappingDocumentElement"/> at the specified index.</returns>
        public MappingDocumentElement this[int index]
        {
            get
            {
                return (MappingDocumentElement) BaseGet(index);
            }
        }


        /// <summary>
        /// Gets the type of the <see cref="ConfigurationElementCollection"/>.
        /// </summary>
        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.BasicMap;
            }
        }


        /// <summary>
        /// Gets the name used to identify this collection of elements.
        /// </summary>
        protected override string ElementName
        {
            get
            {
                return "mappingDocument";
            }
        }

        #endregion
    }
}