using System;
using System.Collections.Generic;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A <see cref="IRuleConfigReader"/> that creates a <see cref="CustomRule"/> from a <see cref="RuleData"/>.
    /// </summary>
    /// <remarks>
    ///   <see cref="RuleData"/> for default attributes.
    ///   <b>Extra Attributes</b>
    ///   <ul>
    ///     <li>
    ///       <c>ruleInterpretation</c> (required): Used to populate <see cref="CustomRule.RuleInterpretation"/>.  
    ///     </li>
    ///     <li>
    ///       <c>validationMethod</c> (required): Used to populate <see cref="CustomRule.Handler"/>.   
    ///     </li>
    ///     <li>
    ///       <c>validationTypeName</c> (required): Used to populate <see cref="CustomRule.Handler"/>.   
    ///     </li>
    ///   </ul>
    /// </remarks>
    /// <example>
    /// <code lang="xml" title="This example shows an xml configuration for CustomRuleConfigReader">
    /// <rule 
    /// ruleInterpretation="This is a custom rule" 
    /// validationMethod="ValMethod" 
    /// validationTypeName="MyNamespace.MyType,MyAssembly" 
    /// errorMessage="hello" 
    /// typeName="CustomRule"/>
    /// </code>
    /// </example>
    /// <example>
    /// The following example shows how to add a <see cref="CustomRule"/> using xml configuration. 
    /// <code source="Examples\ExampleLibraryCSharp\Configuration\CustomRuleConfigReaderSample.cs" lang="cs"/>
    /// </example>
    /// <seealso cref="CustomRule"/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class CustomRuleConfigReader : IRuleConfigReader
    {
        #region Methods

        /// <summary>
        /// Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
        /// </summary>
        /// <param name="ruleData">The <see cref="RuleData"/> that represent the xml to create the <see cref="Rule"/> for.</param>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
        /// <returns>A <see cref="Rule"/> that <paramref name="ruleData"/> represented</returns>
        /// <exception cref="ArgumentNullException"><paramref name="ruleData"/> is null.</exception>
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            Guard.ArgumentNotNull(ruleData, "ruleData");
            IDictionary<string, string> attributesAsDictionary = RuleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes);
            string validationTypeName = attributesAsDictionary["validationTypeName"];
            string validationMethod = attributesAsDictionary["validationMethod"];
            string ruleInterpretation = attributesAsDictionary["ruleInterpretation"];
            return new CustomRule(ruleData.ErrorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider, validationTypeName, validationMethod, ruleInterpretation);
        }

        #endregion
    }
}