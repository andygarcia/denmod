using System;
using System.Xml;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A <see cref="IRuleConfigReader"/> that creates a <see cref="RequiredRule{T}"/> from a <see cref="RuleData"/>.
    /// </summary>
    /// <remarks>
    ///   <see cref="RuleData"/> for default attributes.
    ///   <b>Extra Elements</b>
    ///   <ul>
    ///     <li>
    ///       Any element (optional): Only 1 allowed. Used to populate <see cref="RequiredRule{T}.InitialValue"/>. It is converted to an object using a <see cref="System.Xml.Serialization.XmlSerializer"/>.   
    ///     </li>
    ///   </ul>
    /// </remarks>
    /// <example>
    /// <code lang="xml" title="This example shows an xml configuration for RequiredObjectRuleConfigReader">
    /// <rule 
    /// errorMessage="hello" 
    /// typeName="RequiredObjectRule">
    /// <person name="aaa"/>
    /// </rule>
    /// </code>
    /// </example>
    /// <seealso cref="RequiredRule{T}"/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class RequiredObjectRuleConfigReader : IRuleConfigReader
    {
        #region Methods

        /// <summary>
        /// Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
        /// </summary>
        /// <param name="ruleData">The <see cref="RuleData"/> that represent the xml to create the <see cref="Rule"/> for.</param>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
        /// <returns>A <see cref="Rule"/> that <paramref name="ruleData"/> represented</returns>
        /// <exception cref="ArgumentNullException"><paramref name="ruleData"/> is null.</exception>
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            Guard.ArgumentNotNull(ruleData, "ruleData");

            string errorMessage = ruleData.ErrorMessage;
            XmlReader initialValueXmlReader = null;
            if ((ruleData.XmlElements != null) && (ruleData.XmlElements.Length == 1))
            {
                initialValueXmlReader = new XmlNodeReader(ruleData.XmlElements[0]);
            }
            return RequiredObjectRuleCreator.ReadConfig(errorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider, initialValueXmlReader, runtimeTypeHandle);
        }

        #endregion
    }
}