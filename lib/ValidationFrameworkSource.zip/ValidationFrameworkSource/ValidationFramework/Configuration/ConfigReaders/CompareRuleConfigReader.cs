using System;
using System.Collections.Generic;
using ValidationFramework.Reflection;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A <see cref="IRuleConfigReader"/> that creates a <see cref="CompareRule{T}"/> from a <see cref="RuleData"/>.
    /// </summary>
    /// <remarks>
    ///   <see cref="RuleData"/> for default attributes.
    ///   <b>Extra Attributes</b>
    ///   <ul>
    ///     <li>
    ///       <c>valueToCompare</c> (required): Used to populate <see cref="ValidationFramework.CompareRule{T}.ValueToCompare"/>.  Accepted formats for <see cref="DateTime"/> are "dd MMM yyyy HH:mm:ss.ff", "yyyy-MM-ddTHH:mm:ss", "dd MMM yyyy hh:mm tt", "dd MMM yyyy hh:mm:ss tt", "dd MMM yyyy HH:mm:ss", "dd MMM yyyy HH:mm" and "dd MMM yyyy" 
    ///     </li>
    ///     <li>
    ///       <c>compareOperator</c> (required): Used to populate <see cref="CompareRule{T}.CompareOperator"/>.   
    ///     </li>
    ///   </ul>
    /// </remarks>
    /// <example>
    /// <code lang="xml" title="This example shows an xml configuration for CompareRuleConfigReader">
    /// <rule 
    /// errorMessage="hello" 
    /// typeName="CompareRule" 
    /// valueToCompare="1" 
    /// compareOperator="Equal"/>
    /// </code>
    /// </example>
    /// <seealso cref="CompareRule{T}"/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class CompareRuleConfigReader : IRuleConfigReader
    {
        #region Methods

        /// <summary>
        /// Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
        /// </summary>
        /// <param name="ruleData">The <see cref="RuleData"/> that represent the xml to create the <see cref="Rule"/> for.</param>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
        /// <returns>A <see cref="Rule"/> that <paramref name="ruleData"/> represented</returns>
        /// <exception cref="ArgumentNullException"><paramref name="ruleData"/> is null.</exception>
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            Guard.ArgumentNotNull(ruleData, "ruleData");

            Type genericCompareStructRuleType = typeof (CompareRule<>);
            Type genericType = Type.GetTypeFromHandle(runtimeTypeHandle);
			if (genericType.IsGenericType &&  (genericType.GetGenericTypeDefinition().TypeHandle.Equals(TypePointers.NullableTypeHandle)))
			{
				genericType = genericType.GetGenericArguments()[0];
			}
            Type[] typeArgs = {genericType};
            Type constructedCompareStructRuleType = genericCompareStructRuleType.MakeGenericType(typeArgs);

            IDictionary<string, string> attributesAsDictionary = RuleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes);

            object valueToCompare = TypeConverterEx.ChangeType(attributesAsDictionary["valueToCompare"], genericType);
            CompareOperator compareOperator = (CompareOperator) Enum.Parse(typeof (CompareOperator), attributesAsDictionary["compareOperator"]);

            return (Rule) Activator.CreateInstance(constructedCompareStructRuleType, ruleData.ErrorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider, valueToCompare, compareOperator);
        }

        #endregion
    }
}