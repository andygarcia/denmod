using System;
using System.Collections.Generic;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A <see cref="IRuleConfigReader"/> that creates a <see cref="RequiredRule{T}"/> from a <see cref="RuleData"/>.
    /// </summary>
    /// <remarks>
    ///   <see cref="RuleData"/> for default attributes.
    ///   <b>Extra Attributes</b>
    ///   <ul>
    ///     <li>
    ///       <c>initialValue</c> (optional): Used to populate <see cref="RequiredRule{T}.InitialValue"/>.   
    ///     </li>
    ///   </ul>
    /// </remarks>
    /// <example>
    /// <code lang="xml" title="This example shows an xml configuration for RequiredEnumRuleConfigReader">
    /// <rule 
    /// errorMessage="hello" 
    /// initialValue="One" 
    /// typeName="RequiredEnumRule"/>
    /// </code>
    /// </example>
    /// <seealso cref="RequiredRule{T}"/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class RequiredEnumRuleConfigReader : IRuleConfigReader
    {
        #region Methods

        /// <summary>
        /// Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
        /// </summary>
        /// <param name="ruleData">The <see cref="RuleData"/> that represent the xml to create the <see cref="Rule"/> for.</param>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
        /// <returns>A <see cref="Rule"/> that <paramref name="ruleData"/> represented</returns>
        /// <exception cref="ArgumentNullException"><paramref name="ruleData"/> is null.</exception>
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            Guard.ArgumentNotNull(ruleData, "ruleData");

            string initialValue = null;
            if (ruleData.XmlAttributes != null)
            {
                IDictionary<string, string> attributesAsDictionary = RuleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes);
                string initialValueString;
                if (attributesAsDictionary.TryGetValue("initialValue", out initialValueString))
                {
                    initialValue = initialValueString;
                }
            }

            return RequiredEnumRuleCreator.ReadConfig(initialValue, ruleData.ErrorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider, runtimeTypeHandle);
        }

        #endregion
    }
}