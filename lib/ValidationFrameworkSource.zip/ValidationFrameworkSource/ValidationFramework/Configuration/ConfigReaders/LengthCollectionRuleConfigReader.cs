using System;
using System.Collections;
using System.Collections.Generic;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A <see cref="IRuleConfigReader"/> that creates a <see cref="LengthCollectionRule"/> from a <see cref="RuleData"/>.
    /// </summary>
    /// <remarks>
    ///   <see cref="RuleData"/> for default attributes.
    ///   <b>Extra Attributes</b>
    ///   <ul>
    ///     <li>
    ///       <c>excludeDuplicatesFromCount</c> (optional): Used to populate <see cref="ValidationFramework.LengthCollectionRule.ExcludeDuplicatesFromCount"/>.  
    ///     </li>
    ///     <li>
    ///       <c>minimum</c> (optional): Used to populate <see cref="ValidationFramework.LengthRule.Maximum"/>.   
    ///     </li>
    ///     <li>
    ///       <c>maximum</c> (required): Used to populate <see cref="ValidationFramework.LengthRule.Minimum"/>.   
    ///     </li>
    ///   </ul>
    /// </remarks>
    /// <example>
    /// <code lang="xml" title="This example shows an xml configuration for LengthCollectionRuleConfigReader">
    /// <rule 
    /// errorMessage="hello" 
    /// excludeDuplicatesFromCount="true" 
    /// typeName="LengthCollectionRule" 
    /// minimum="1" 
    /// maximum="5"/>
    /// </code>
    /// </example>
    /// <seealso cref="LengthCollectionRule"/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class LengthCollectionRuleConfigReader : IRuleConfigReader
    {
        #region Methods

        /// <summary>
        /// Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
        /// </summary>
        /// <param name="ruleData">The <see cref="RuleData"/> that represent the xml to create the <see cref="Rule"/> for.</param>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
        /// <returns>A <see cref="Rule"/> that <paramref name="ruleData"/> represented</returns>
        /// <exception cref="ArgumentNullException"><paramref name="ruleData"/> is null.</exception>
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            Guard.ArgumentNotNull(ruleData, "ruleData");
            IDictionary<string, string> attributesAsDictionary = RuleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes);

            string minimumAsString;
            int minimum = 0;
            if (attributesAsDictionary.TryGetValue("minimum", out minimumAsString))
            {
              minimum = int.Parse(minimumAsString);
            }

            int maximum = int.Parse(attributesAsDictionary["maximum"]);
         
            string excludeDuplicatesFromCountAsString;
            bool excludeDuplicatesFromCount = true;
            if (attributesAsDictionary.TryGetValue("excludeDuplicatesFromCount", out excludeDuplicatesFromCountAsString))
            {
              excludeDuplicatesFromCount = bool.Parse(excludeDuplicatesFromCountAsString);
            }


            IEqualityComparer equalityComparer = null;
            string equalityComparerTypeName;
            if (attributesAsDictionary.TryGetValue("equalityComparerTypeName", out equalityComparerTypeName))
            {
                equalityComparer = (IEqualityComparer) ReflectionUtilities.GetStaticProperty(equalityComparerTypeName, attributesAsDictionary["equalityComparerPropertyName"]);
            }

            return new LengthCollectionRule(ruleData.ErrorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider, minimum, maximum, excludeDuplicatesFromCount, equalityComparer);
        }

        #endregion
    }
}