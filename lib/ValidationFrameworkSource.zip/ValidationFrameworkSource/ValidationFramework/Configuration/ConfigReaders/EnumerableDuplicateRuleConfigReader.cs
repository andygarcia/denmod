using System;
using System.Collections;
using System.Collections.Generic;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A <see cref="IRuleConfigReader"/> that creates a <see cref="EnumerableDuplicateRule"/> from a <see cref="RuleData"/>.
    /// </summary>
    /// <remarks>
    /// <see cref="RuleData"/> for default attributes.
    /// </remarks>
    /// <example>
    /// <code lang="xml" title="This example shows an xml configuration for EnumerableDuplicateRuleConfigReader">
    /// <rule 
    /// errorMessage="hello" 
    /// typeName="EnumerableDuplicateRule"
    /// equalityComparerTypeName="System.StringComparer"
    /// equalityComparerPropertyName="InvariantCulture"
    /// />
    /// </code>
    /// </example>
    /// <seealso cref="EnumerableDuplicateRule"/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class EnumerableDuplicateRuleConfigReader : IRuleConfigReader
    {
        #region Methods

        /// <summary>
        /// Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
        /// </summary>
        /// <param name="ruleData">The <see cref="RuleData"/> that represent the xml to create the <see cref="Rule"/> for.</param>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
        /// <returns>A <see cref="Rule"/> that <paramref name="ruleData"/> represented</returns>
        /// <exception cref="ArgumentNullException"><paramref name="ruleData"/> is null.</exception>
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            Guard.ArgumentNotNull(ruleData, "ruleData");
            if (ruleData.XmlAttributes == null)
            {
                return new EnumerableDuplicateRule(ruleData.ErrorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider, null);
            }
            else
            {
                IDictionary<string, string> attributesAsDictionary = RuleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes);
                IEqualityComparer equalityComparer = (IEqualityComparer) ReflectionUtilities.GetStaticProperty(attributesAsDictionary["equalityComparerTypeName"], attributesAsDictionary["equalityComparerPropertyName"]);
                return new EnumerableDuplicateRule(ruleData.ErrorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider, equalityComparer);
            }
        }

        #endregion
    }
}