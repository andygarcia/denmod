using System;
using System.Collections.Generic;

namespace ValidationFramework.Configuration
{
    /// <summary>
    /// A <see cref="IRuleConfigReader"/> that creates a <see cref="ValidatableRule"/> from a <see cref="RuleData"/>.
    /// </summary>
    /// <code lang="xml" title="This example shows an xml configuration for ValidatableRuleConfigReader.">
    /// <rule 
    /// errorMessage="hello" 
    /// typeName="ValidatableRule"/>
    /// </code>
    /// </example>
    /// <seealso cref="ValidatableRule"/>
    /// <seealso cref="ConfigurationService"/>
    public sealed class ValidatableRuleConfigReader : IRuleConfigReader
    {


        #region Methods

        /// <summary>
        /// Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
        /// </summary>
        /// <param name="ruleData">The <see cref="RuleData"/> that represent the xml to create the <see cref="Rule"/> for.</param>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
        /// <returns>A <see cref="Rule"/> that <paramref name="ruleData"/> represented</returns>
        /// <exception cref="ArgumentNullException"><paramref name="ruleData"/> is null.</exception>
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            Guard.ArgumentNotNull(ruleData, "ruleData");

            bool useMemberErrorMessages = false;
            if (ruleData.XmlAttributes != null)
            {
                IDictionary<string, string> attributesAsDictionary = RuleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes);

                string useMemberErrorMessagesString;
                if (attributesAsDictionary.TryGetValue("useMemberErrorMessages", out useMemberErrorMessagesString))
                {
                    useMemberErrorMessages = bool.Parse(useMemberErrorMessagesString);
                }
            }
            //TODO: refactor with ValidatableRuleAttribute
            if (useMemberErrorMessages)
            {
                if (ruleData.ErrorMessage == null)
                {
                    return new ValidatableRule(true, ruleData.RuleSet, ruleData.UseErrorMessageProvider);
                }
                else
                {
                    throw new InvalidOperationException("Cannot use 'useMemberErrorMessages'");
                }
            }
            else
            {
                return new ValidatableRule(ruleData.ErrorMessage, ruleData.RuleSet, ruleData.UseErrorMessageProvider);
            }
        }

        #endregion
    }
}