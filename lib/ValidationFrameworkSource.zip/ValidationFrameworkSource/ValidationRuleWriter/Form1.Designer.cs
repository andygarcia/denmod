namespace ValidationRuleWriter
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.browseButton = new System.Windows.Forms.Button();
      this.resultsTextBox = new System.Windows.Forms.TextBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.includeNamespacesCheckBox = new System.Windows.Forms.CheckBox();
      this.startButton = new System.Windows.Forms.Button();
      this.pathLabel = new System.Windows.Forms.Label();
      this.pathComboBox = new ValidationRuleWriter.RememberComboBox();
      this.includeBaseClassCheckBox = new System.Windows.Forms.CheckBox();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // browseButton
      // 
      this.browseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.browseButton.Location = new System.Drawing.Point(529, 3);
      this.browseButton.Name = "browseButton";
      this.browseButton.Size = new System.Drawing.Size(22, 23);
      this.browseButton.TabIndex = 0;
      this.browseButton.Text = "...";
      this.browseButton.UseVisualStyleBackColor = true;
      this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
      // 
      // resultsTextBox
      // 
      this.resultsTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.resultsTextBox.Location = new System.Drawing.Point(0, 75);
      this.resultsTextBox.Multiline = true;
      this.resultsTextBox.Name = "resultsTextBox";
      this.resultsTextBox.ReadOnly = true;
      this.resultsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.resultsTextBox.Size = new System.Drawing.Size(644, 369);
      this.resultsTextBox.TabIndex = 1;
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.includeBaseClassCheckBox);
      this.panel1.Controls.Add(this.includeNamespacesCheckBox);
      this.panel1.Controls.Add(this.startButton);
      this.panel1.Controls.Add(this.pathLabel);
      this.panel1.Controls.Add(this.pathComboBox);
      this.panel1.Controls.Add(this.browseButton);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Location = new System.Drawing.Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(644, 75);
      this.panel1.TabIndex = 2;
      // 
      // includeNamespacesCheckBox
      // 
      this.includeNamespacesCheckBox.AutoSize = true;
      this.includeNamespacesCheckBox.Checked = global::ValidationRuleWriter.Properties.Settings.Default.IncludeNamespaces;
      this.includeNamespacesCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ValidationRuleWriter.Properties.Settings.Default, "IncludeNamespaces", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.includeNamespacesCheckBox.Location = new System.Drawing.Point(12, 33);
      this.includeNamespacesCheckBox.Name = "includeNamespacesCheckBox";
      this.includeNamespacesCheckBox.Size = new System.Drawing.Size(126, 17);
      this.includeNamespacesCheckBox.TabIndex = 4;
      this.includeNamespacesCheckBox.Text = "Include Namespaces";
      this.includeNamespacesCheckBox.UseVisualStyleBackColor = true;
      this.includeNamespacesCheckBox.CheckedChanged += new System.EventHandler(this.includeNamespacesCheckBox_CheckedChanged);
      // 
      // startButton
      // 
      this.startButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.startButton.Location = new System.Drawing.Point(557, 3);
      this.startButton.Name = "startButton";
      this.startButton.Size = new System.Drawing.Size(75, 23);
      this.startButton.TabIndex = 3;
      this.startButton.Text = "Start";
      this.startButton.UseVisualStyleBackColor = true;
      this.startButton.Click += new System.EventHandler(this.startButton_Click);
      // 
      // pathLabel
      // 
      this.pathLabel.AutoSize = true;
      this.pathLabel.Location = new System.Drawing.Point(3, 8);
      this.pathLabel.Name = "pathLabel";
      this.pathLabel.Size = new System.Drawing.Size(79, 13);
      this.pathLabel.TabIndex = 2;
      this.pathLabel.Text = "Assembly Path:";
      // 
      // pathComboBox
      // 
      this.pathComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.pathComboBox.Location = new System.Drawing.Point(86, 5);
      this.pathComboBox.MaximumRememberedValues = 10;
      this.pathComboBox.Name = "pathComboBox";
      this.pathComboBox.SettingsKey = "AssemblyPath";
      this.pathComboBox.Size = new System.Drawing.Size(437, 21);
      this.pathComboBox.TabIndex = 1;
      // 
      // includeBaseClassCheckBox
      // 
      this.includeBaseClassCheckBox.AutoSize = true;
      this.includeBaseClassCheckBox.Checked = global::ValidationRuleWriter.Properties.Settings.Default.IncludeBaseClasses;
      this.includeBaseClassCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
      this.includeBaseClassCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ValidationRuleWriter.Properties.Settings.Default, "IncludeBaseClasses", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.includeBaseClassCheckBox.Location = new System.Drawing.Point(141, 32);
      this.includeBaseClassCheckBox.Name = "includeBaseClassCheckBox";
      this.includeBaseClassCheckBox.Size = new System.Drawing.Size(116, 17);
      this.includeBaseClassCheckBox.TabIndex = 5;
      this.includeBaseClassCheckBox.Text = "Include Base Class";
      this.includeBaseClassCheckBox.UseVisualStyleBackColor = true;
      this.includeBaseClassCheckBox.CheckedChanged += new System.EventHandler(this.includeBaseClassCheckBox_CheckedChanged);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(644, 444);
      this.Controls.Add(this.resultsTextBox);
      this.Controls.Add(this.panel1);
      this.Name = "Form1";
      this.Text = "Validation Rule Writer";
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button browseButton;
		private System.Windows.Forms.TextBox resultsTextBox;
		private System.Windows.Forms.Panel panel1;
		private RememberComboBox pathComboBox;
		private System.Windows.Forms.Button startButton;
		private System.Windows.Forms.Label pathLabel;
    private System.Windows.Forms.CheckBox includeNamespacesCheckBox;
    private System.Windows.Forms.CheckBox includeBaseClassCheckBox;
	}
}

