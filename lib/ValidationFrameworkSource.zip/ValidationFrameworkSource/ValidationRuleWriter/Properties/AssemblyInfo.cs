﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ValidationRuleWriter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("ValidationRuleWriter")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("d19c05a9-ad58-423d-86f9-01fbcd5d8279")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
