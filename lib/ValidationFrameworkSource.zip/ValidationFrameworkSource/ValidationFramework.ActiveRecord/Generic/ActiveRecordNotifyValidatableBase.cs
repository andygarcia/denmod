using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace ValidationFramework.ActiveRecord
{
    /// <summary>
    /// Provides base class that developer can (optionally) inherit from to provide <see cref="INotifyPropertyChanged"/> and <see cref="IDataErrorInfo"/> functionality for all sub-classes.
    /// </summary>
    /// <remarks>
    /// This ideal for windows forms applications to get immediate validation feedback on data bound controls.
    /// </remarks>
    [Serializable]
    public abstract class ActiveRecordNotifyValidatableBase<T> : ActiveRecordDataErrorInfoValidatableBase<T>, INotifyPropertyChanged
    {

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ActiveRecordNotifyValidatableBase{T}"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        protected ActiveRecordNotifyValidatableBase(bool validateOnConstruction)
            : base(validateOnConstruction, null)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ActiveRecordNotifyValidatableBase{T}"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        protected ActiveRecordNotifyValidatableBase(bool validateOnConstruction, string ruleSet)
            : base(validateOnConstruction, ruleSet)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ActiveRecordNotifyValidatableBase{T}"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        protected ActiveRecordNotifyValidatableBase(bool validateOnConstruction, string ruleSet, object context)
            : base(validateOnConstruction, ruleSet, context)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ActiveRecordNotifyValidatableBase{T}"/> class.
        /// </summary>
        /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
        /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
        /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
        /// <param name="ignoreNoRules">Set to <c>true</c> to ignore the fact that no <see cref="Rule"/>s exists on the current type.</param>
        protected ActiveRecordNotifyValidatableBase(bool validateOnConstruction, string ruleSet, object context, bool ignoreNoRules)
            : base(validateOnConstruction, ruleSet, context, ignoreNoRules)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ActiveRecordNotifyValidatableBase{T}"/> class.
        /// </summary>
        protected ActiveRecordNotifyValidatableBase()
            : base(false, null)
        {
        }

        #endregion


        #region Methods

        /// <summary>
        /// Perform validation and <see cref="INotifyPropertyChanged"/> functionality for specified property.
        /// </summary>
        /// <param name="propertyName">The name of the property to validate.  The parameter is case sensitive.</param>
        protected void NotifyAndValidate(string propertyName)
        {
            ValidateProperty(propertyName);
            NotifyPropertyChanged(propertyName);
            //TODO: should we fire a notify on isValid??
        }


        /// <summary>
        /// Performs INotifyPropertyChanged functionality for specified property.
        /// </summary>
        /// <param name="propertyName">The name of the property that has changed. The parameter is case sensitive.</param>
        protected void NotifyPropertyChanged(string propertyName)
        {
            OnPropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }


        /// <summary>
        /// Raises the <see cref="PropertyChanged"/> event.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">A <see cref="PropertyChangedEventArgs"/> that contains the event data.</param>
        [SuppressMessage("Microsoft.Security", "CA2109:ReviewVisibleEventHandlers")]
        protected virtual void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (propertyChanged != null)
            {
                propertyChanged(sender, e);
            }
        }

        #endregion


        #region Properties

        //TODO: work out how to make this not serialize. 
        //[field:NonSerialized]
        private event PropertyChangedEventHandler propertyChanged;

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        /// <remarks>
        /// The <see cref="PropertyChanged"/> event can indicate all properties on the object have changed by using either a null reference or <see cref="String.Empty"/> as the <see cref="PropertyChangedEventArgs.PropertyName"/> in the <see cref="PropertyChangedEventArgs"/>.
        /// </remarks>
        public event PropertyChangedEventHandler PropertyChanged
        {
            add
            {
                propertyChanged += value;
            }
            remove
            {
                propertyChanged -= value;
            }
        }


        #endregion
    }
}