﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ValidationFramework.ActiveRecord")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("ValidationFramework.ActiveRecord")]
[assembly: AssemblyCopyright("http://www.codeplex.com/ValidationFramework/Project/License.aspx")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("0fdcf413-efe2-4d8e-93d1-994152ade34f")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
