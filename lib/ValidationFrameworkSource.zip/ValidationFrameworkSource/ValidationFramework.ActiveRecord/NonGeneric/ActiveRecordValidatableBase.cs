using System;
using System.Collections.Generic;
using Castle.ActiveRecord;
using Castle.Components.Validator;

namespace ValidationFramework.ActiveRecord
{
  /// <summary>
  /// Base class that provides minimal validation logic.
  /// </summary>
  [Serializable]
  public abstract class ActiveRecordValidatableBase : ActiveRecordBase, NHibernate.Classic.IValidatable, IValidatable
  {
    #region Fields

    [NonSerialized]
    private readonly PropertyValidationManager propertyValidationManager;
    private readonly bool validateOnConstruction;
    private readonly bool ignoreNoRules;

    #endregion


    #region Constructors

    /// <summary>
    /// Initializes a new instance of the <see cref="ActiveRecordValidatableBase{T}"/> class.
    /// </summary>
    /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
    protected ActiveRecordValidatableBase(bool validateOnConstruction)
      : this(validateOnConstruction, null)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="ActiveRecordValidatableBase{T}"/> class.
    /// </summary>
    /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
    /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
    protected ActiveRecordValidatableBase(bool validateOnConstruction, string ruleSet)
      : this(validateOnConstruction, ruleSet, null)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="ValidatableBase"/> class.
    /// </summary>
    /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
    /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
    /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
    protected ActiveRecordValidatableBase(bool validateOnConstruction, string ruleSet, object context)
      : this(validateOnConstruction, ruleSet, context, false)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="ValidatableBase"/> class.
    /// </summary>
    /// <param name="validateOnConstruction">A <see langword="bool"/> indicating if the properties, of the instance being created, should be validated on construction.</param>
    /// <param name="ruleSet">The rule set to validate. Use null to validate all rules.</param>
    /// <param name="context">An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. Use a null for a non value.</param>
    /// <param name="ignoreNoRules">Set to <c>true</c> to ignore the fact that no <see cref="Rule"/>s exists on the current type.</param>
    protected ActiveRecordValidatableBase(bool validateOnConstruction, string ruleSet, object context, bool ignoreNoRules)
    {
      this.validateOnConstruction = validateOnConstruction;
      this.ignoreNoRules = ignoreNoRules;
      propertyValidationManager = new PropertyValidationManager(this, ruleSet, context);
      if (validateOnConstruction)
      {
        propertyValidationManager.ValidateAllProperties();
      }
    }


    /// <summary>
    /// Initializes a new instance of the <see cref="ValidatableBase"/> class.
    /// </summary>
    /// <remarks><see cref="ValidatableBase.ValidateOnConstruction"/> will default to <see langword="false"/>.</remarks>
    protected ActiveRecordValidatableBase()
      : this(false)
    {
    }

    #endregion


    #region Properties


    /// <summary>
    /// An <see cref="object"/> to pass as the context parameter when calling <see cref="Rule.Validate"/>. The default is null.
    /// </summary>
    public virtual object Context
    {
      get
      {
        return propertyValidationManager.Context;
      }
    }

    /// <summary>
    /// Gets the the rule set to validate.
    /// </summary>
    /// <remarks>Will be a null to validate all <see cref="Rule"/>s.</remarks>
    public virtual string RuleSet
    {
      get
      {
        return propertyValidationManager.RuleSet;
      }
    }
    /// <summary>
    /// Gets a <see cref="IList{T}"/> containing all <see cref="ValidationResult"/> in error.
    /// </summary>
    public virtual IList<ValidationResult> ValidatorResultsInError
    {
      get
      {
        return propertyValidationManager.ValidatorResultsInError;
      }
    }

    /// <summary>
    /// Gets the <see cref="ValidationFramework.PropertyValidationManager"/>.
    /// </summary>
    public virtual PropertyValidationManager PropertyValidationManager
    {
      get
      {
        return propertyValidationManager;
      }
    }

    /// <summary>
    /// Gets a <see lanword="bool"/> indicating if the current state is valid.
    /// </summary>
    /// <remarks>
    /// Base behavior is to validate all properties and return boolean value.
    /// Sub-class can override this if, for example, they are validating on the fly.
    /// </remarks>
    public virtual bool IsValid
    {
      get
      {
        if (ignoreNoRules)
        {
          propertyValidationManager.TryValidateAllProperties();
        }
        else
        {
          propertyValidationManager.ValidateAllProperties();
        }
        return propertyValidationManager.IsValid;
      }
    }


    /// <summary>
    /// Gets a <see see="IList{T}"/> of <see langword="string"/>s that contain all the error messages.
    /// </summary>
    public virtual IList<string> ErrorMessages
    {
      get
      {
        return ResultFormatter.GetErrorMessages(propertyValidationManager.ValidatorResultsInError);
      }
    }


    /// <summary>
    /// Gets a <see langword="bool"/> indicating if the <see cref="ValidatableBase"/> has been validated on construction.
    /// </summary>
    public virtual bool ValidateOnConstruction
    {
      get
      {
        return validateOnConstruction;
      }
    }

    /// <summary>
    /// Gets a value indicating that, if no <see cref="Rule"/>s exists, it will be ignored.
    /// </summary>
    public virtual bool IgnoreNoRules
    {
      get
      {
        return ignoreNoRules;
      }
    }

    #endregion


    #region Methods

    /// <summary>
    /// Throws an exception explaining why the save or update cannot be executed when fields are not ok to pass.
    /// </summary>
    /// <exception cref="ValidationException"><see cref="IsValid"/> is <c>false</c>.</exception>
    void NHibernate.Classic.IValidatable.Validate()
    {
      if (!IsValid)
      {
        List<string> errorsList = new List<string>(ErrorMessages);
        throw new ValidationException(
            "Can't save or update as there is one (or more) field that has not passed the validation test",
            errorsList.ToArray());
      }
    }

    #endregion
  }
}