using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using QSBusinessLayerCSharp;
using ValidationFramework;

namespace QSWindowsApplicationCSharp
{
    public partial class RuleSetForm : Form
    {
        private Vehicle vehicle;
        public RuleSetForm()
        {
            InitializeComponent();
            vehicle = new Vehicle();
        }

        private void RuleSetForm_Load(object sender, EventArgs e)
        {
            vehicleBindingSource.Add(vehicle);
            ruleSetListBox.SelectedIndex = 0;
        }

        private void validateButton_Click(object sender, EventArgs e)
        {
            string selectedText = (string)ruleSetListBox.SelectedItem;
            PropertyValidationManager manager = new PropertyValidationManager(vehicle, selectedText);
            manager.ValidateAllProperties();
            errorTreeView.Nodes.Clear();
            foreach (ValidationResult result in manager.ValidatorResultsInError)
            {

                TreeNode node = new TreeNode(result.ErrorMessage);
                node.Nodes.Add(String.Format("RuleInterpretation = '{0}'", result.Rule.RuleInterpretation));
                node.Nodes.Add(String.Format("Rule = '{0}'", result.Rule.GetType()));
                errorTreeView.Nodes.Add(node);
            }
        }
    }
}