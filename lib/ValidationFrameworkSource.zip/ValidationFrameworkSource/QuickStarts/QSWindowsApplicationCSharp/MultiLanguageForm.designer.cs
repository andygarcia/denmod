namespace QSWindowsApplicationCSharp
{
    partial class MultiLanguageForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
        this.addressTextBox = new System.Windows.Forms.TextBox();
        this.registrationBindingSource = new System.Windows.Forms.BindingSource(this.components);
        this.addressLabel = new System.Windows.Forms.Label();
        this.licenseLabel = new System.Windows.Forms.Label();
        this.seatsTextBox = new System.Windows.Forms.TextBox();
        this.validateButton = new System.Windows.Forms.Button();
        this.errorTreeView = new System.Windows.Forms.TreeView();
        this.cultureLabel = new System.Windows.Forms.Label();
        this.cultureListBox = new System.Windows.Forms.ListBox();
        this.noteLabel = new System.Windows.Forms.Label();
        ((System.ComponentModel.ISupportInitialize)(this.registrationBindingSource)).BeginInit();
        this.SuspendLayout();
        // 
        // addressTextBox
        // 
        this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.registrationBindingSource, "Address", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
        this.addressTextBox.Location = new System.Drawing.Point(76, 33);
        this.addressTextBox.Name = "addressTextBox";
        this.addressTextBox.Size = new System.Drawing.Size(100, 20);
        this.addressTextBox.TabIndex = 0;
        // 
        // registrationBindingSource
        // 
        this.registrationBindingSource.DataSource = typeof(QSBusinessLayerCSharp.Registration);
        // 
        // addressLabel
        // 
        this.addressLabel.AutoSize = true;
        this.addressLabel.Location = new System.Drawing.Point(12, 36);
        this.addressLabel.Name = "addressLabel";
        this.addressLabel.Size = new System.Drawing.Size(45, 13);
        this.addressLabel.TabIndex = 3;
        this.addressLabel.Text = "Address";
        // 
        // licenseLabel
        // 
        this.licenseLabel.AutoSize = true;
        this.licenseLabel.Location = new System.Drawing.Point(12, 62);
        this.licenseLabel.Name = "licenseLabel";
        this.licenseLabel.Size = new System.Drawing.Size(44, 13);
        this.licenseLabel.TabIndex = 7;
        this.licenseLabel.Text = "License";
        // 
        // seatsTextBox
        // 
        this.seatsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.registrationBindingSource, "LicenceNumber", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
        this.seatsTextBox.Location = new System.Drawing.Point(76, 59);
        this.seatsTextBox.Name = "seatsTextBox";
        this.seatsTextBox.Size = new System.Drawing.Size(100, 20);
        this.seatsTextBox.TabIndex = 6;
        // 
        // validateButton
        // 
        this.validateButton.Location = new System.Drawing.Point(386, 52);
        this.validateButton.Name = "validateButton";
        this.validateButton.Size = new System.Drawing.Size(75, 23);
        this.validateButton.TabIndex = 9;
        this.validateButton.Text = "Validate";
        this.validateButton.UseVisualStyleBackColor = true;
        this.validateButton.Click += new System.EventHandler(this.validateButton_Click);
        // 
        // errorTreeView
        // 
        this.errorTreeView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                    | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.errorTreeView.Location = new System.Drawing.Point(12, 93);
        this.errorTreeView.Name = "errorTreeView";
        this.errorTreeView.Size = new System.Drawing.Size(520, 94);
        this.errorTreeView.TabIndex = 24;
        // 
        // cultureLabel
        // 
        this.cultureLabel.AutoSize = true;
        this.cultureLabel.Location = new System.Drawing.Point(206, 33);
        this.cultureLabel.Name = "cultureLabel";
        this.cultureLabel.Size = new System.Drawing.Size(38, 13);
        this.cultureLabel.TabIndex = 25;
        this.cultureLabel.Text = "Culture";
        // 
        // cultureListBox
        // 
        this.cultureListBox.FormattingEnabled = true;
        this.cultureListBox.Items.AddRange(new object[] {
            "fr-CA",
            "zh-TW",
            "en-AU",
            "en-US"});
        this.cultureListBox.Location = new System.Drawing.Point(270, 33);
        this.cultureListBox.Name = "cultureListBox";
        this.cultureListBox.Size = new System.Drawing.Size(58, 56);
        this.cultureListBox.TabIndex = 26;
        this.cultureListBox.SelectedIndexChanged += new System.EventHandler(this.cultureListBox_SelectedIndexChanged);
        // 
        // noteLabel
        // 
        this.noteLabel.AutoSize = true;
        this.noteLabel.Location = new System.Drawing.Point(12, 9);
        this.noteLabel.Name = "noteLabel";
        this.noteLabel.Size = new System.Drawing.Size(362, 13);
        this.noteLabel.TabIndex = 27;
        this.noteLabel.Text = "Note: control texts are not localised as it is not what is being illustrated here" +
            ".";
        // 
        // MultiLanguageForm
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(544, 194);
        this.Controls.Add(this.noteLabel);
        this.Controls.Add(this.cultureListBox);
        this.Controls.Add(this.cultureLabel);
        this.Controls.Add(this.errorTreeView);
        this.Controls.Add(this.validateButton);
        this.Controls.Add(this.licenseLabel);
        this.Controls.Add(this.seatsTextBox);
        this.Controls.Add(this.addressLabel);
        this.Controls.Add(this.addressTextBox);
        this.Name = "MultiLanguageForm";
        this.Text = "MultiLanguageSample";
        this.Load += new System.EventHandler(this.RuleSetForm_Load);
        ((System.ComponentModel.ISupportInitialize)(this.registrationBindingSource)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.BindingSource registrationBindingSource;
    private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.Label addressLabel;
    private System.Windows.Forms.Label licenseLabel;
		private System.Windows.Forms.TextBox seatsTextBox;
		private System.Windows.Forms.Button validateButton;
		private System.Windows.Forms.TreeView errorTreeView;
		private System.Windows.Forms.Label cultureLabel;
		private System.Windows.Forms.ListBox cultureListBox;
        private System.Windows.Forms.Label noteLabel;
  }
}