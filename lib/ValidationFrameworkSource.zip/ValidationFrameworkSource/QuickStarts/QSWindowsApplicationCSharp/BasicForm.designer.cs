using System.Windows.Forms;

namespace QSWindowsApplicationCSharp
{
	partial class BasicForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
      this.personBindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.closeButton = new System.Windows.Forms.Button();
      this.firstNameLabel = new System.Windows.Forms.Label();
      this.firstNameTextBox = new System.Windows.Forms.TextBox();
      this.lastNameTextbox = new System.Windows.Forms.TextBox();
      this.lastNameLabel = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.ageTextBox = new System.Windows.Forms.TextBox();
      this.emailTextbox = new System.Windows.Forms.TextBox();
      this.emailLabel = new System.Windows.Forms.Label();
      this.creditCardNumberTextBox = new System.Windows.Forms.TextBox();
      this.creditCardLabel = new System.Windows.Forms.Label();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.cardTypeLabel = new System.Windows.Forms.Label();
      this.phoneNumberTextbox = new System.Windows.Forms.TextBox();
      this.phoneNumberLabel = new System.Windows.Forms.Label();
      this.errorTreeView = new System.Windows.Forms.TreeView();
      this.amexRadioButton = new QSWindowsApplicationCSharp.DataBindableRadioButton();
      this.masterRadioButton = new QSWindowsApplicationCSharp.DataBindableRadioButton();
      this.visaRadioButton = new QSWindowsApplicationCSharp.DataBindableRadioButton();
      ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.personBindingSource)).BeginInit();
      this.SuspendLayout();
      // 
      // errorProvider1
      // 
      this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
      this.errorProvider1.ContainerControl = this;
      this.errorProvider1.DataSource = this.personBindingSource;
      // 
      // personBindingSource
      // 
      this.personBindingSource.DataSource = typeof(QSBusinessLayerCSharp.Person);
      // 
      // closeButton
      // 
      this.closeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.closeButton.Location = new System.Drawing.Point(517, 322);
      this.closeButton.Name = "closeButton";
      this.closeButton.Size = new System.Drawing.Size(116, 23);
      this.closeButton.TabIndex = 4;
      this.closeButton.Text = "Validate and Close";
      this.closeButton.UseVisualStyleBackColor = true;
      this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
      // 
      // firstNameLabel
      // 
      this.firstNameLabel.AutoSize = true;
      this.firstNameLabel.Location = new System.Drawing.Point(34, 33);
      this.firstNameLabel.Name = "firstNameLabel";
      this.firstNameLabel.Size = new System.Drawing.Size(57, 13);
      this.firstNameLabel.TabIndex = 5;
      this.firstNameLabel.Text = "First Name";
      // 
      // firstNameTextBox
      // 
      this.firstNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.personBindingSource, "FirstName", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.firstNameTextBox.Location = new System.Drawing.Point(135, 33);
      this.firstNameTextBox.Name = "firstNameTextBox";
      this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
      this.firstNameTextBox.TabIndex = 6;
      // 
      // lastNameTextbox
      // 
      this.lastNameTextbox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.personBindingSource, "LastName", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.lastNameTextbox.Location = new System.Drawing.Point(135, 59);
      this.lastNameTextbox.Name = "lastNameTextbox";
      this.lastNameTextbox.Size = new System.Drawing.Size(100, 20);
      this.lastNameTextbox.TabIndex = 8;
      // 
      // lastNameLabel
      // 
      this.lastNameLabel.AutoSize = true;
      this.lastNameLabel.Location = new System.Drawing.Point(34, 59);
      this.lastNameLabel.Name = "lastNameLabel";
      this.lastNameLabel.Size = new System.Drawing.Size(58, 13);
      this.lastNameLabel.TabIndex = 7;
      this.lastNameLabel.Text = "Last Name";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(33, 85);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(26, 13);
      this.label1.TabIndex = 9;
      this.label1.Text = "Age";
      // 
      // ageTextBox
      // 
      this.ageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.personBindingSource, "Age", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.ageTextBox.Location = new System.Drawing.Point(135, 85);
      this.ageTextBox.Name = "ageTextBox";
      this.ageTextBox.Size = new System.Drawing.Size(53, 20);
      this.ageTextBox.TabIndex = 10;
      // 
      // emailTextbox
      // 
      this.emailTextbox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.personBindingSource, "EmailAddress", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.emailTextbox.Location = new System.Drawing.Point(135, 111);
      this.emailTextbox.Name = "emailTextbox";
      this.emailTextbox.Size = new System.Drawing.Size(197, 20);
      this.emailTextbox.TabIndex = 12;
      // 
      // emailLabel
      // 
      this.emailLabel.AutoSize = true;
      this.emailLabel.Location = new System.Drawing.Point(33, 114);
      this.emailLabel.Name = "emailLabel";
      this.emailLabel.Size = new System.Drawing.Size(32, 13);
      this.emailLabel.TabIndex = 11;
      this.emailLabel.Text = "Email";
      // 
      // creditCardNumberTextBox
      // 
      this.creditCardNumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.personBindingSource, "CreditCardNumber", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.creditCardNumberTextBox.Location = new System.Drawing.Point(135, 237);
      this.creditCardNumberTextBox.Name = "creditCardNumberTextBox";
      this.creditCardNumberTextBox.Size = new System.Drawing.Size(197, 20);
      this.creditCardNumberTextBox.TabIndex = 14;
      // 
      // creditCardLabel
      // 
      this.creditCardLabel.AutoSize = true;
      this.creditCardLabel.Location = new System.Drawing.Point(33, 240);
      this.creditCardLabel.Name = "creditCardLabel";
      this.creditCardLabel.Size = new System.Drawing.Size(99, 13);
      this.creditCardLabel.TabIndex = 13;
      this.creditCardLabel.Text = "Credit Card Number";
      // 
      // textBox1
      // 
      this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.personBindingSource, "OrderTotal", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.textBox1.Location = new System.Drawing.Point(135, 263);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(62, 20);
      this.textBox1.TabIndex = 16;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(33, 266);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(60, 13);
      this.label2.TabIndex = 15;
      this.label2.Text = "Order Total";
      // 
      // cardTypeLabel
      // 
      this.cardTypeLabel.AutoSize = true;
      this.cardTypeLabel.Location = new System.Drawing.Point(34, 165);
      this.cardTypeLabel.Name = "cardTypeLabel";
      this.cardTypeLabel.Size = new System.Drawing.Size(53, 13);
      this.cardTypeLabel.TabIndex = 20;
      this.cardTypeLabel.Text = "CardType";
      // 
      // phoneNumberTextbox
      // 
      this.phoneNumberTextbox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.personBindingSource, "PhoneNumber", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
      this.phoneNumberTextbox.Location = new System.Drawing.Point(135, 137);
      this.phoneNumberTextbox.Name = "phoneNumberTextbox";
      this.phoneNumberTextbox.Size = new System.Drawing.Size(197, 20);
      this.phoneNumberTextbox.TabIndex = 22;
      // 
      // phoneNumberLabel
      // 
      this.phoneNumberLabel.AutoSize = true;
      this.phoneNumberLabel.Location = new System.Drawing.Point(33, 140);
      this.phoneNumberLabel.Name = "phoneNumberLabel";
      this.phoneNumberLabel.Size = new System.Drawing.Size(38, 13);
      this.phoneNumberLabel.TabIndex = 21;
      this.phoneNumberLabel.Text = "Phone";
      // 
      // errorTreeView
      // 
      this.errorTreeView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.errorTreeView.Location = new System.Drawing.Point(362, 12);
      this.errorTreeView.Name = "errorTreeView";
      this.errorTreeView.Size = new System.Drawing.Size(271, 304);
      this.errorTreeView.TabIndex = 23;
      // 
      // amexRadioButton
      // 
      this.amexRadioButton.AutoSize = true;
      this.amexRadioButton.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.personBindingSource, "CardType", true));
      this.amexRadioButton.Key = "Amex";
      this.amexRadioButton.Location = new System.Drawing.Point(135, 209);
      this.amexRadioButton.Name = "amexRadioButton";
      this.amexRadioButton.Size = new System.Drawing.Size(51, 17);
      this.amexRadioButton.TabIndex = 19;
      this.amexRadioButton.TabStop = true;
      this.amexRadioButton.Text = "Amex";
      this.amexRadioButton.UseVisualStyleBackColor = true;
      this.amexRadioButton.Value = null;
      // 
      // masterRadioButton
      // 
      this.masterRadioButton.AutoSize = true;
      this.masterRadioButton.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.personBindingSource, "CardType", true));
      this.masterRadioButton.Key = "MasterCard";
      this.masterRadioButton.Location = new System.Drawing.Point(135, 186);
      this.masterRadioButton.Name = "masterRadioButton";
      this.masterRadioButton.Size = new System.Drawing.Size(82, 17);
      this.masterRadioButton.TabIndex = 18;
      this.masterRadioButton.TabStop = true;
      this.masterRadioButton.Text = "Master Card";
      this.masterRadioButton.UseVisualStyleBackColor = true;
      this.masterRadioButton.Value = null;
      // 
      // visaRadioButton
      // 
      this.visaRadioButton.AutoSize = true;
      this.visaRadioButton.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.personBindingSource, "CardType", true));
      this.visaRadioButton.Key = "Visa";
      this.visaRadioButton.Location = new System.Drawing.Point(135, 163);
      this.visaRadioButton.Name = "visaRadioButton";
      this.visaRadioButton.Size = new System.Drawing.Size(45, 17);
      this.visaRadioButton.TabIndex = 17;
      this.visaRadioButton.TabStop = true;
      this.visaRadioButton.Text = "Visa";
      this.visaRadioButton.UseVisualStyleBackColor = true;
      this.visaRadioButton.Value = null;
      // 
      // BasicForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
      this.ClientSize = new System.Drawing.Size(645, 354);
      this.Controls.Add(this.errorTreeView);
      this.Controls.Add(this.phoneNumberTextbox);
      this.Controls.Add(this.phoneNumberLabel);
      this.Controls.Add(this.cardTypeLabel);
      this.Controls.Add(this.amexRadioButton);
      this.Controls.Add(this.masterRadioButton);
      this.Controls.Add(this.visaRadioButton);
      this.Controls.Add(this.textBox1);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.creditCardNumberTextBox);
      this.Controls.Add(this.creditCardLabel);
      this.Controls.Add(this.emailTextbox);
      this.Controls.Add(this.emailLabel);
      this.Controls.Add(this.ageTextBox);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.lastNameTextbox);
      this.Controls.Add(this.lastNameLabel);
      this.Controls.Add(this.firstNameTextBox);
      this.Controls.Add(this.firstNameLabel);
      this.Controls.Add(this.closeButton);
      this.Name = "BasicForm";
      this.Text = "MainForm";
      this.Load += new System.EventHandler(this.Form1_Load);
      ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.personBindingSource)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

		}

		#endregion

		private ErrorProvider errorProvider1;
		private Button closeButton;
		private TextBox firstNameTextBox;
		private BindingSource personBindingSource;
		private Label firstNameLabel;
		private TextBox lastNameTextbox;
		private Label lastNameLabel;
		private TextBox ageTextBox;
		private Label label1;
		private TextBox emailTextbox;
		private Label emailLabel;
		private TextBox creditCardNumberTextBox;
		private Label creditCardLabel;
		private TextBox textBox1;
		private Label label2;
		private DataBindableRadioButton amexRadioButton;
		private DataBindableRadioButton masterRadioButton;
		private DataBindableRadioButton visaRadioButton;
		private Label cardTypeLabel;
		private TextBox phoneNumberTextbox;
		private Label phoneNumberLabel;
    private TreeView errorTreeView;
	}
}

