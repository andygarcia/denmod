using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Forms;

namespace QSWindowsApplicationCSharp
{

	public class DataBindableRadioButton : RadioButton
	{
		private string value;
		private string key;
		private bool respondToCheckEvent = true;

		[SuppressMessage("Microsoft.Maintainability", "CA1500:VariableNamesShouldNotMatchFieldNames", MessageId = "value")]
		[BindableAttribute(true)] 
		public string Value
		{
			get
			{
				return value;
			}
			set
			{
				if (this.value != value)
				{
					this.value = value;
					if (!DesignMode && LicenseManager.UsageMode != LicenseUsageMode.Designtime)
					{
						respondToCheckEvent = false;
						if (key == this.value)
						{
							Checked = true;
						}
						else
						{
							Checked = false;
						}
						respondToCheckEvent = true;
					}
				}
			}
		}

		[SuppressMessage("Microsoft.Maintainability", "CA1500:VariableNamesShouldNotMatchFieldNames", MessageId = "value")]
		public string Key
		{
			get
			{
				return key;
			}
			set
			{
				key = value;
			}
		}

		public DataBindableRadioButton()
		{
			CheckedChanged += new EventHandler(DataBindableRadioButton_CheckedChanged);
		}

		private void DataBindableRadioButton_CheckedChanged(object sender, EventArgs e)
		{
			if (respondToCheckEvent)
			{
				if (Checked)
				{
					value = key;
					Binding dataBinding = DataBindings["Value"];
					if (dataBinding != null)
					{
						dataBinding.WriteValue();
					}
				}
			}
		}
	}
}
