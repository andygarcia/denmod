namespace QSWindowsApplicationCSharp
{
    partial class RuleSetForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.wheelsTextBox = new System.Windows.Forms.TextBox();
            this.vehicleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wheelsLabel = new System.Windows.Forms.Label();
            this.doorsLabel = new System.Windows.Forms.Label();
            this.doorsTextBox = new System.Windows.Forms.TextBox();
            this.seatsLabel = new System.Windows.Forms.Label();
            this.seatsTextBox = new System.Windows.Forms.TextBox();
            this.validateButton = new System.Windows.Forms.Button();
            this.errorTreeView = new System.Windows.Forms.TreeView();
            this.ruleSetLabel = new System.Windows.Forms.Label();
            this.ruleSetListBox = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.vehicleBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // wheelsTextBox
            // 
            this.wheelsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vehicleBindingSource, "Wheels", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.wheelsTextBox.Location = new System.Drawing.Point(80, 12);
            this.wheelsTextBox.Name = "wheelsTextBox";
            this.wheelsTextBox.Size = new System.Drawing.Size(100, 20);
            this.wheelsTextBox.TabIndex = 0;
            // 
            // vehicleBindingSource
            // 
            this.vehicleBindingSource.DataSource = typeof(QSBusinessLayerCSharp.Vehicle);
            // 
            // wheelsLabel
            // 
            this.wheelsLabel.AutoSize = true;
            this.wheelsLabel.Location = new System.Drawing.Point(16, 15);
            this.wheelsLabel.Name = "wheelsLabel";
            this.wheelsLabel.Size = new System.Drawing.Size(43, 13);
            this.wheelsLabel.TabIndex = 3;
            this.wheelsLabel.Text = "Wheels";
            // 
            // doorsLabel
            // 
            this.doorsLabel.AutoSize = true;
            this.doorsLabel.Location = new System.Drawing.Point(16, 67);
            this.doorsLabel.Name = "doorsLabel";
            this.doorsLabel.Size = new System.Drawing.Size(35, 13);
            this.doorsLabel.TabIndex = 5;
            this.doorsLabel.Text = "Doors";
            // 
            // doorsTextBox
            // 
            this.doorsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vehicleBindingSource, "Doors", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.doorsTextBox.Location = new System.Drawing.Point(80, 64);
            this.doorsTextBox.Name = "doorsTextBox";
            this.doorsTextBox.Size = new System.Drawing.Size(100, 20);
            this.doorsTextBox.TabIndex = 4;
            // 
            // seatsLabel
            // 
            this.seatsLabel.AutoSize = true;
            this.seatsLabel.Location = new System.Drawing.Point(16, 41);
            this.seatsLabel.Name = "seatsLabel";
            this.seatsLabel.Size = new System.Drawing.Size(34, 13);
            this.seatsLabel.TabIndex = 7;
            this.seatsLabel.Text = "Seats";
            // 
            // seatsTextBox
            // 
            this.seatsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.vehicleBindingSource, "Seats", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.seatsTextBox.Location = new System.Drawing.Point(80, 38);
            this.seatsTextBox.Name = "seatsTextBox";
            this.seatsTextBox.Size = new System.Drawing.Size(100, 20);
            this.seatsTextBox.TabIndex = 6;
            // 
            // validateButton
            // 
            this.validateButton.Location = new System.Drawing.Point(240, 64);
            this.validateButton.Name = "validateButton";
            this.validateButton.Size = new System.Drawing.Size(75, 23);
            this.validateButton.TabIndex = 9;
            this.validateButton.Text = "Validate";
            this.validateButton.UseVisualStyleBackColor = true;
            this.validateButton.Click += new System.EventHandler(this.validateButton_Click);
            // 
            // errorTreeView
            // 
            this.errorTreeView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                                    | System.Windows.Forms.AnchorStyles.Left)
                                    | System.Windows.Forms.AnchorStyles.Right)));
            this.errorTreeView.Location = new System.Drawing.Point(12, 93);
            this.errorTreeView.Name = "errorTreeView";
            this.errorTreeView.Size = new System.Drawing.Size(520, 94);
            this.errorTreeView.TabIndex = 24;
            // 
            // ruleSetLabel
            // 
            this.ruleSetLabel.AutoSize = true;
            this.ruleSetLabel.Location = new System.Drawing.Point(210, 12);
            this.ruleSetLabel.Name = "ruleSetLabel";
            this.ruleSetLabel.Size = new System.Drawing.Size(45, 13);
            this.ruleSetLabel.TabIndex = 25;
            this.ruleSetLabel.Text = "RuleSet";
            // 
            // ruleSetListBox
            // 
            this.ruleSetListBox.FormattingEnabled = true;
            this.ruleSetListBox.Items.AddRange(new object[] {
            "car",
            "truck",
            "bike"});
            this.ruleSetListBox.Location = new System.Drawing.Point(274, 12);
            this.ruleSetListBox.Name = "ruleSetListBox";
            this.ruleSetListBox.Size = new System.Drawing.Size(58, 43);
            this.ruleSetListBox.TabIndex = 26;
            // 
            // RuleSetForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 194);
            this.Controls.Add(this.ruleSetListBox);
            this.Controls.Add(this.ruleSetLabel);
            this.Controls.Add(this.errorTreeView);
            this.Controls.Add(this.validateButton);
            this.Controls.Add(this.seatsLabel);
            this.Controls.Add(this.seatsTextBox);
            this.Controls.Add(this.doorsLabel);
            this.Controls.Add(this.doorsTextBox);
            this.Controls.Add(this.wheelsLabel);
            this.Controls.Add(this.wheelsTextBox);
            this.Name = "RuleSetForm";
            this.Text = "RuleSetSample";
            this.Load += new System.EventHandler(this.RuleSetForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vehicleBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource vehicleBindingSource;
        private System.Windows.Forms.TextBox wheelsTextBox;
        private System.Windows.Forms.Label wheelsLabel;
        private System.Windows.Forms.Label doorsLabel;
        private System.Windows.Forms.TextBox doorsTextBox;
        private System.Windows.Forms.Label seatsLabel;
        private System.Windows.Forms.TextBox seatsTextBox;
        private System.Windows.Forms.Button validateButton;
        private System.Windows.Forms.TreeView errorTreeView;
        private System.Windows.Forms.Label ruleSetLabel;
        private System.Windows.Forms.ListBox ruleSetListBox;
    }
}