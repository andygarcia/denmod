using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace QSWindowsApplicationCSharp
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void ruleSetButton_Click(object sender, EventArgs e)
        {
            using (RuleSetForm ruleSetForm = new RuleSetForm())
            {
                ruleSetForm.ShowDialog(this);
            }
        }

        private void basicSampleButton_Click(object sender, EventArgs e)
        {
            using (BasicForm basicForm = new BasicForm())
            {
                basicForm.ShowDialog(this);
            }
        }

        private void multiLanguageButton_Click(object sender, EventArgs e)
        {

            using (MultiLanguageForm multiLanguageForm = new MultiLanguageForm())
            {
                multiLanguageForm.ShowDialog(this);
            }
        }
    }
}