using System;
using System.Windows.Forms;
using QSBusinessLayerCSharp;
using ValidationFramework;

namespace QSWindowsApplicationCSharp
{
  public partial class BasicForm : Form
  {
    private Person person;


    public BasicForm()
    {
      InitializeComponent();
    }


    private void Form1_Load(object sender, EventArgs e)
    {
      PersonMapper mapper = new PersonMapper();
      person = mapper.GetItem(1);
      personBindingSource.Add(person);
    }


    private void closeButton_Click(object sender, EventArgs e)
    {
      if (person.IsValid)
      {
        Close();
      }
      else
      {
        errorTreeView.Nodes.Clear();
        foreach (ValidationResult result in person.ValidatorResultsInError)
        {
          TreeNode node = new TreeNode(result.ErrorMessage);
          node.Nodes.Add(String.Format("RuleInterpretation = '{0}'", result.Rule.RuleInterpretation));
          node.Nodes.Add(String.Format("Rule = '{0}'", result.Rule.GetType()));
          errorTreeView.Nodes.Add(node);
        }
        MessageBox.Show(string.Format("Data is invalid. Errors:\r\n{0}", person.Error));
      }
    }
  }
}