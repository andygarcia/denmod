namespace QSWindowsApplicationCSharp
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.basicSampleButton = new System.Windows.Forms.Button();
            this.ruleSetButton = new System.Windows.Forms.Button();
            this.multiLanguageButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // basicSampleButton
            // 
            this.basicSampleButton.Location = new System.Drawing.Point(12, 12);
            this.basicSampleButton.Name = "basicSampleButton";
            this.basicSampleButton.Size = new System.Drawing.Size(113, 23);
            this.basicSampleButton.TabIndex = 0;
            this.basicSampleButton.Text = "BasicSample";
            this.basicSampleButton.UseVisualStyleBackColor = true;
            this.basicSampleButton.Click += new System.EventHandler(this.basicSampleButton_Click);
            // 
            // ruleSetButton
            // 
            this.ruleSetButton.Location = new System.Drawing.Point(12, 55);
            this.ruleSetButton.Name = "ruleSetButton";
            this.ruleSetButton.Size = new System.Drawing.Size(113, 23);
            this.ruleSetButton.TabIndex = 1;
            this.ruleSetButton.Text = "RuleSetSample";
            this.ruleSetButton.UseVisualStyleBackColor = true;
            this.ruleSetButton.Click += new System.EventHandler(this.ruleSetButton_Click);
            // 
            // multiLanguageButton
            // 
            this.multiLanguageButton.Location = new System.Drawing.Point(12, 95);
            this.multiLanguageButton.Name = "multiLanguageButton";
            this.multiLanguageButton.Size = new System.Drawing.Size(113, 23);
            this.multiLanguageButton.TabIndex = 2;
            this.multiLanguageButton.Text = "MultiLangSample";
            this.multiLanguageButton.UseVisualStyleBackColor = true;
            this.multiLanguageButton.Click += new System.EventHandler(this.multiLanguageButton_Click);
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this.multiLanguageButton);
            this.Controls.Add(this.ruleSetButton);
            this.Controls.Add(this.basicSampleButton);
            this.Name = "StartForm";
            this.Text = "StartForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button basicSampleButton;
        private System.Windows.Forms.Button ruleSetButton;
        private System.Windows.Forms.Button multiLanguageButton;
    }
}