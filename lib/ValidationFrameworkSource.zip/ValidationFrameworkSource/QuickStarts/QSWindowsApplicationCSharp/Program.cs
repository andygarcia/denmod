using System;
using System.Windows.Forms;
using QSWindowsApplicationCSharp;
using ValidationFramework.Configuration;

namespace QSWindowsApplicationCSharp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ConfigurationService.Initialize();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new StartForm());
        }
    }
}