using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using QSBusinessLayerCSharp;
using ValidationFramework.Web;

namespace QSWebApplicationCSharp
{
    public partial class GridViewMasterDetailsEditForm : Page
    {
        private Person editingPerson;
        protected void Page_Load(object sender, EventArgs e)
        {
            CreateValidations();
        }



        protected void validatorGenerator_TargetObjectRequired(object sender, TargetObjectRequiredEventArgs e)
        {
            if (editingPerson == null)
            {
                DetailsViewRow row = personDetailsView.Rows[personDetailsView.DataItemIndex];
                editingPerson = Helper.GetPerson(row.FindControl);
            }
            e.TargetObject = editingPerson;
        }


        protected void personDetailsView_DataBound(object sender, EventArgs e)
        {
            CreateValidations();
        }

        private void CreateValidations()
        {
            if (personDetailsView.CurrentMode == DetailsViewMode.Edit)
            {
                DetailsViewRow row = personDetailsView.Rows[personDetailsView.DataItemIndex];
                Helper.AddValidation(validatorGenerator.GetValidatorGenerator(), row.FindControl);
            }
        }

        protected void personGridView_SelectedIndexChanged(object sender, EventArgs e)
        {
            personDetailsView.ChangeMode(DetailsViewMode.ReadOnly);
        }

        protected void personGridView_Sorted(object sender, EventArgs e)
        {
            personDetailsView.ChangeMode(DetailsViewMode.ReadOnly);
        }


        protected void personDetailsView_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
        {
            e.Cancel = !IsValid;
        }

        protected void personDetailsViewObjectDataSource_Updated(object sender, ObjectDataSourceStatusEventArgs e)
        {
            personGridView.DataBind();
        }
    }
}