using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using QSBusinessLayerCSharp;
using ValidationFramework.Web;

namespace QSWebApplicationCSharp
{


	internal delegate Control FindControl(string name); 

	/// <summary>
	/// This helper class only exists because I am updating and validating the same data in several web forms.
	/// </summary>
	internal static class Helper
	{
		internal static Person GetPerson(FindControl findControl)
		{

			TextBox firstNameTextBox = (TextBox)findControl("firstNameTextBox");
			TextBox lastNameTextBox = (TextBox)findControl("lastNameTextBox");
			TextBox emailAddressTextBox = (TextBox)findControl("emailAddressTextBox");
			TextBox creditCardNumberTextBox = (TextBox)findControl("creditCardNumberTextBox");
			TextBox ageTextBox = (TextBox)findControl("ageTextBox");
			TextBox orderTotalTextBox = (TextBox)findControl("orderTotalTextBox");
			TextBox phoneNumberTextBox = (TextBox)findControl("phoneNumberTextBox");
			DropDownList cardTypeDropDownList = (DropDownList)findControl("cardTypeDropDownList");
			Person person = new Person();
			person.FirstName = firstNameTextBox.Text;
			person.LastName = lastNameTextBox.Text;
			person.EmailAddress = emailAddressTextBox.Text;
			person.PhoneNumber = phoneNumberTextBox.Text;
			person.CreditCardNumber = creditCardNumberTextBox.Text;
			person.CardType = (CardType)Enum.Parse(typeof(CardType), cardTypeDropDownList.SelectedValue);
			int age;
			if (int.TryParse(ageTextBox.Text, out age))
			{
				person.Age = age;
			}
			decimal orderTotal;
			object o = orderTotalTextBox.Text;
			if (decimal.TryParse((string)o, out orderTotal))
			{
				person.OrderTotal = orderTotal;
			}
			return person;
		}

        internal static void AddValidation(PropertyValidatorGenerator validatorGenerator, FindControl findControl)
		{
			TextBox firstNameTextBox = (TextBox)findControl("firstNameTextBox");
			TextBox lastNameTextBox = (TextBox)findControl("lastNameTextBox");
			TextBox emailAddressTextBox = (TextBox)findControl("emailAddressTextBox");
			TextBox creditCardNumberTextBox = (TextBox)findControl("creditCardNumberTextBox");
			TextBox ageTextBox = (TextBox)findControl("ageTextBox");
			TextBox orderTotalTextBox = (TextBox)findControl("orderTotalTextBox");
			TextBox phoneNumberTextBox = (TextBox)findControl("phoneNumberTextBox");
			//DropDownList cardTypeDropDownList = (DropDownList) findControl("cardTypeDropDownList");
			validatorGenerator.AddAssociation(firstNameTextBox, Person.FirstNameMember);
			validatorGenerator.AddAssociation(lastNameTextBox, Person.LastNameMember);
			validatorGenerator.AddAssociation(emailAddressTextBox, Person.EmailAddressMember);
			validatorGenerator.AddAssociation(creditCardNumberTextBox, Person.CreditCardNumberMember);
			validatorGenerator.AddAssociation(ageTextBox, Person.AgeMember);
			validatorGenerator.AddAssociation(orderTotalTextBox, Person.OrderTotalMember);
			validatorGenerator.AddAssociation(phoneNumberTextBox, Person.PhoneNumberMember);
			validatorGenerator.GenerateValidators();
		}

	}
}
