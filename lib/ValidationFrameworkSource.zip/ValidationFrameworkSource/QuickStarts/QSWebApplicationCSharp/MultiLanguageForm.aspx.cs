using System;
using System.Web.UI;
using QSBusinessLayerCSharp;
using ValidationFramework.Web;

namespace QSWebApplicationCSharp
{
    public partial class MultiLanguageForm : Page
    {
        #region Fields

        private Person editPerson;
        #endregion


        #region Methods

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                PopulatePerson();
            }
            validatorGenerator.AddAssociation(firstNameTextBox, Person.FirstNameMember, firstNamePlaceHolder);
            validatorGenerator.AddAssociation(lastNameTextBox, Person.LastNameMember, lastNamePlaceHolder);
            validatorGenerator.AddAssociation(ageTextBox, Person.AgeMember, agePlaceHolder);
            validatorGenerator.AddAssociation(emailAddressTextBox, Person.EmailAddressMember, emailPlaceHolder);
            validatorGenerator.AddAssociation(creditCardNumberTextBox, Person.CreditCardNumberMember, cardNumberPlaceHolder);
            validatorGenerator.AddAssociation(orderTotalTextBox, Person.OrderTotalMember, orderTotalPlaceHolder);
            validatorGenerator.AddAssociation(phoneNumberTextBox, Person.PhoneNumberMember, phoneNumberPlaceholder);

            validatorGenerator.GenerateValidators();
        }

        public override void Validate()
        {
            editPerson = new Person(false);
            editPerson.FirstName = firstNameTextBox.Text;
            editPerson.LastName = lastNameTextBox.Text;
            editPerson.EmailAddress = emailAddressTextBox.Text;
            editPerson.PhoneNumber = phoneNumberTextBox.Text;
            editPerson.CreditCardNumber = creditCardNumberTextBox.Text;
            editPerson.CardType = (CardType)Enum.Parse(typeof(CardType), cardTypeDropDownList.SelectedValue);
            int age;
            if (int.TryParse(ageTextBox.Text, out age))
            {
                editPerson.Age = age;
            }

            decimal orderTotal;
            if (decimal.TryParse(orderTotalTextBox.Text, out orderTotal))
            {
                editPerson.OrderTotal = age;
            }
            base.Validate();
        }

        protected void updateLinkButton_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                new PersonMapper().SaveOrUpdate(editPerson);
            }
        }


        private void PopulatePerson()
        {
            Person person = new PersonMapper().GetItem(1);
            firstNameTextBox.Text = person.FirstName;
            lastNameTextBox.Text = person.LastName;
            ageTextBox.Text = person.Age.ToString();
            phoneNumberTextBox.Text = person.PhoneNumber.ToString();
            emailAddressTextBox.Text = person.EmailAddress;
            cardTypeDropDownList.SelectedValue = person.CardType.ToString();
            creditCardNumberTextBox.Text = person.CreditCardNumber;
            orderTotalTextBox.Text = person.OrderTotal.ToString();

        }

        protected void validatorGenerator_TargetObjectRequired(object sender, TargetObjectRequiredEventArgs e)
        {
            e.TargetObject = editPerson;
        }
        #endregion

    }
}