using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using QSBusinessLayerCSharp;
using ValidationFramework.Web;

namespace QSWebApplicationCSharp
{
    public partial class FormViewForm : Page
    {

        Person editingPersonTemp;
        protected void Page_Load(object sender, EventArgs e)
        {

            Helper.AddValidation(validatorGenerator.GetValidatorGenerator(), personFormView.FindControl);
        }


        protected void OnPersonSourceUpdated(object sender, ObjectDataSourceStatusEventArgs e)
        {
            if (e.Exception != null && e.Exception.InnerException is ArgumentException)
            {
                //In reality, you'd have a more robust display here
                errorsLabel.Text = e.Exception.InnerException.Message;
                e.ExceptionHandled = true;
            }
            else
            {
                errorsLabel.Text = string.Empty;
                personFormView.DataBind();
            }
        }


        protected void validatorGenerator_TargetObjectRequired(object sender, TargetObjectRequiredEventArgs e)
        {
            if (editingPersonTemp == null)
            {
                editingPersonTemp = Helper.GetPerson(personFormView.FindControl);
            }
            e.TargetObject = editingPersonTemp;
        }


        protected void personFormView_ItemUpdating(object sender, FormViewUpdateEventArgs e)
        {
            e.Cancel = !IsValid;
        }


    }
}