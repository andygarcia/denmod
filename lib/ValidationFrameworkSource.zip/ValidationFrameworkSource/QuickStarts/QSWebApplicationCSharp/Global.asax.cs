using System;
using System.Web;
using ValidationFramework.Configuration;

namespace QSWebApplicationCSharp
{
    public class Global : HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            ConfigurationService.Initialize();
        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}