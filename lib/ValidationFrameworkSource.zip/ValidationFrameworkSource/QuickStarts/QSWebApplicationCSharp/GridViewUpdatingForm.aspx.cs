using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using QSBusinessLayerCSharp;

namespace QSWebApplicationCSharp
{
	public partial class GridViewUpdatingForm : Page
	{
		private Person editingPerson;
		protected void Page_Load(object sender, EventArgs e)
		{
			CreateValidations();
		}
		protected void validatorGenerator_TargetObjectRequired(object sender, ValidationFramework.Web.TargetObjectRequiredEventArgs e)
		{
			if (editingPerson == null)
			{
				GridViewRow row = personGridView.Rows[personGridView.EditIndex];
				editingPerson = Helper.GetPerson(row.FindControl);
			}

			e.TargetObject = editingPerson;
		}

		protected void personGridView_DataBound(object sender, EventArgs e)
		{
			CreateValidations();
		}

		private void CreateValidations()
		{
			if (personGridView.EditIndex > -1)
			{
				GridViewRow row = personGridView.Rows[personGridView.EditIndex];
                Helper.AddValidation(validatorGenerator.GetValidatorGenerator(), row.FindControl);
			}
		}



		protected void personGridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
		{
			e.Cancel = !IsValid;
		}
	}

}