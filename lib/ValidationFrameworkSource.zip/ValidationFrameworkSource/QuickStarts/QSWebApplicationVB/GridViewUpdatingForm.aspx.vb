Imports ValidationFramework
Imports ValidationFramework.Web
Imports QSBusinessLayerVB
Imports System


Partial Public Class GridViewUpdatingForm
  Inherits Page
  ' Methods
  Private Sub CreateValidations()
    If (Me.personGridView.EditIndex > -1) Then
      Dim row As GridViewRow = Me.personGridView.Rows.Item(Me.personGridView.EditIndex)
            Helper.AddValidation(Me.validatorGenerator.GetValidatorGenerator(), New FindControl(AddressOf row.FindControl))
    End If
  End Sub

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
    Me.CreateValidations()
  End Sub

  Protected Sub personGridView_DataBound(ByVal sender As Object, ByVal e As EventArgs)
    Me.CreateValidations()
  End Sub

  Protected Sub personGridView_RowUpdating(ByVal sender As Object, ByVal e As GridViewUpdateEventArgs)
    e.Cancel = Not MyBase.IsValid
  End Sub

  Protected Sub validatorGenerator_TargetObjectRequired(ByVal sender As Object, ByVal e As TargetObjectRequiredEventArgs)
    If (Me.editingPerson Is Nothing) Then
      Dim row As GridViewRow = Me.personGridView.Rows.Item(Me.personGridView.EditIndex)
      Me.editingPerson = Helper.GetPerson(New FindControl(AddressOf row.FindControl))
    End If
    e.TargetObject = Me.editingPerson
  End Sub


  ' Fields
  Private editingPerson As Person
End Class


