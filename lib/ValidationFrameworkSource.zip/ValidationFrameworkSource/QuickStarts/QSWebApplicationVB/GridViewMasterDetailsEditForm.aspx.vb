Imports ValidationFramework
Imports ValidationFramework.Web
Imports QSBusinessLayerVB
Imports System

Partial Public Class GridViewMasterDetailsEditForm
  Inherits Page
  ' Methods
  Private Sub CreateValidations()
    If (Me.personDetailsView.CurrentMode = DetailsViewMode.Edit) Then
      Dim row As DetailsViewRow = Me.personDetailsView.Rows.Item(Me.personDetailsView.DataItemIndex)
            Helper.AddValidation(Me.validatorGenerator.GetValidatorGenerator(), New FindControl(AddressOf row.FindControl))
    End If
  End Sub

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
    Me.CreateValidations()
  End Sub

  Protected Sub personDetailsView_DataBound(ByVal sender As Object, ByVal e As EventArgs)
    Me.CreateValidations()
  End Sub

  Protected Sub personDetailsView_ItemUpdating(ByVal sender As Object, ByVal e As DetailsViewUpdateEventArgs)
    e.Cancel = Not MyBase.IsValid
  End Sub

  Protected Sub personDetailsViewObjectDataSource_Updated(ByVal sender As Object, ByVal e As ObjectDataSourceStatusEventArgs)
    Me.personGridView.DataBind()
  End Sub

  Protected Sub personGridView_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
    Me.personDetailsView.ChangeMode(DetailsViewMode.ReadOnly)
  End Sub

  Protected Sub personGridView_Sorted(ByVal sender As Object, ByVal e As EventArgs)
    Me.personDetailsView.ChangeMode(DetailsViewMode.ReadOnly)
  End Sub

  Protected Sub validatorGenerator_TargetObjectRequired(ByVal sender As Object, ByVal e As TargetObjectRequiredEventArgs)
    If (Me.editingPerson Is Nothing) Then
      Dim row As DetailsViewRow = Me.personDetailsView.Rows.Item(Me.personDetailsView.DataItemIndex)
      Me.editingPerson = Helper.GetPerson(New FindControl(AddressOf row.FindControl))
    End If
    e.TargetObject = Me.editingPerson
  End Sub


  Private editingPerson As Person
End Class


