Imports QSBusinessLayerVB
Imports System
Imports ValidationFramework
Imports ValidationFramework.Web


Friend Delegate Function FindControl(ByVal name As String) As Control



Friend Class Helper
  ' Methods
    Friend Shared Sub AddValidation(ByVal validatorGenerator As PropertyValidatorGenerator, ByVal findControl As FindControl)
        Dim firstNameTextBox As TextBox = DirectCast(findControl("firstNameTextBox"), TextBox)
        Dim lastNameTextBox As TextBox = DirectCast(findControl("lastNameTextBox"), TextBox)
        Dim emailAddressTextBox As TextBox = DirectCast(findControl("emailAddressTextBox"), TextBox)
        Dim creditCardNumberTextBox As TextBox = DirectCast(findControl("creditCardNumberTextBox"), TextBox)
        Dim ageTextBox As TextBox = DirectCast(findControl("ageTextBox"), TextBox)
        Dim orderTotalTextBox As TextBox = DirectCast(findControl("orderTotalTextBox"), TextBox)
        Dim phoneNumberTextBox As TextBox = DirectCast(findControl("phoneNumberTextBox"), TextBox)
        validatorGenerator.AddAssociation(firstNameTextBox, "FirstName")
        validatorGenerator.AddAssociation(lastNameTextBox, "LastName")
        validatorGenerator.AddAssociation(emailAddressTextBox, "EmailAddress")
        validatorGenerator.AddAssociation(creditCardNumberTextBox, "CreditCardNumber")
        validatorGenerator.AddAssociation(ageTextBox, "Age")
        validatorGenerator.AddAssociation(orderTotalTextBox, "OrderTotal")
        validatorGenerator.AddAssociation(phoneNumberTextBox, "PhoneNumber")
        validatorGenerator.GenerateValidators()
    End Sub

  Friend Shared Function GetPerson(ByVal findControl As FindControl) As Person
    Dim age As Integer
    Dim orderTotal As Decimal
    Dim firstNameTextBox As TextBox = DirectCast(findControl("firstNameTextBox"), TextBox)
    Dim lastNameTextBox As TextBox = DirectCast(findControl("lastNameTextBox"), TextBox)
    Dim emailAddressTextBox As TextBox = DirectCast(findControl("emailAddressTextBox"), TextBox)
    Dim creditCardNumberTextBox As TextBox = DirectCast(findControl("creditCardNumberTextBox"), TextBox)
    Dim ageTextBox As TextBox = DirectCast(findControl("ageTextBox"), TextBox)
    Dim orderTotalTextBox As TextBox = DirectCast(findControl("orderTotalTextBox"), TextBox)
    Dim phoneNumberTextBox As TextBox = DirectCast(findControl("phoneNumberTextBox"), TextBox)
    Dim cardTypeDropDownList As DropDownList = DirectCast(findControl("cardTypeDropDownList"), DropDownList)
    Dim person As New Person
    person.FirstName = firstNameTextBox.Text
    person.LastName = lastNameTextBox.Text
    person.EmailAddress = emailAddressTextBox.Text
    person.PhoneNumber = phoneNumberTextBox.Text
    person.CreditCardNumber = creditCardNumberTextBox.Text
    person.CardType = New Nullable(Of CardType)(DirectCast([Enum].Parse(GetType(CardType), cardTypeDropDownList.SelectedValue), CardType))
    If Integer.TryParse(ageTextBox.Text, age) Then
      person.Age = age
    End If
    If Decimal.TryParse(orderTotalTextBox.Text, orderTotal) Then
      person.OrderTotal = orderTotal
    End If
    Return person
  End Function

End Class




