Imports ValidationFramework
Imports ValidationFramework.Web
Imports QSBusinessLayerVB
Imports System


Partial Public Class TraditionalForm
  Inherits Page
  ' Methods
  Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
    If Not MyBase.IsPostBack Then
      Me.PopulatePerson()
    End If
    Me.validatorGenerator.AddAssociation(Me.firstNameTextBox, "FirstName", Me.firstNamePlaceHolder)
    Me.validatorGenerator.AddAssociation(Me.lastNameTextBox, "LastName", Me.lastNamePlaceHolder)
    Me.validatorGenerator.AddAssociation(Me.ageTextBox, "Age", Me.agePlaceHolder)
    Me.validatorGenerator.AddAssociation(Me.emailAddressTextBox, "EmailAddress", Me.emailPlaceHolder)
    Me.validatorGenerator.AddAssociation(Me.creditCardNumberTextBox, "CreditCardNumber", Me.cardNumberPlaceHolder)
    Me.validatorGenerator.AddAssociation(Me.orderTotalTextBox, "OrderTotal", Me.orderTotalPlaceHolder)
    Me.validatorGenerator.AddAssociation(Me.phoneNumberTextBox, "PhoneNumber", Me.phoneNumberPlaceholder)
    Me.validatorGenerator.GenerateValidators()
  End Sub

  Private Sub PopulatePerson()
    Dim person As Person = New PersonMapper().GetItem(1)
    Me.firstNameTextBox.Text = person.FirstName
    Me.lastNameTextBox.Text = person.LastName
    Me.ageTextBox.Text = person.Age.ToString
    Me.phoneNumberTextBox.Text = person.PhoneNumber.ToString
    Me.emailAddressTextBox.Text = person.EmailAddress
    Me.cardTypeDropDownList.SelectedValue = person.CardType.ToString
    Me.creditCardNumberTextBox.Text = person.CreditCardNumber
    Me.orderTotalTextBox.Text = person.OrderTotal.ToString
  End Sub

  Protected Sub updateLinkButton_Click(ByVal sender As Object, ByVal e As EventArgs)
    If MyBase.IsValid Then
      Dim personMapper As PersonMapper = New PersonMapper()
      personMapper.SaveOrUpdate(Me.editPerson)
    End If
  End Sub

  Public Overrides Sub Validate()
    Dim age As Integer
    Dim orderTotal As Decimal
    Me.editPerson = New Person(False)
    Me.editPerson.FirstName = Me.firstNameTextBox.Text
    Me.editPerson.LastName = Me.lastNameTextBox.Text
    Me.editPerson.EmailAddress = Me.emailAddressTextBox.Text
    Me.editPerson.PhoneNumber = Me.phoneNumberTextBox.Text
    Me.editPerson.CreditCardNumber = Me.creditCardNumberTextBox.Text
    Me.editPerson.CardType = New Nullable(Of CardType)(DirectCast([Enum].Parse(GetType(CardType), Me.cardTypeDropDownList.SelectedValue), CardType))
    If Integer.TryParse(Me.ageTextBox.Text, age) Then
      Me.editPerson.Age = age
    End If
    If Decimal.TryParse(Me.orderTotalTextBox.Text, orderTotal) Then
      Me.editPerson.OrderTotal = age
    End If
    MyBase.Validate()
  End Sub

  Protected Sub validatorGenerator_TargetObjectRequired(ByVal sender As Object, ByVal e As TargetObjectRequiredEventArgs)
    e.TargetObject = Me.editPerson
  End Sub


  ' Fields
  Private editPerson As Person
End Class


