Imports ValidationFramework
Imports ValidationFramework.Web
Imports QSBusinessLayerVB
Imports System

Partial Public Class FormViewForm
  Inherits Page
  ' Methods
  Protected Sub OnPersonSourceUpdated(ByVal sender As Object, ByVal e As ObjectDataSourceStatusEventArgs)
    If ((Not e.Exception Is Nothing) AndAlso TypeOf e.Exception.InnerException Is ArgumentException) Then
      Me.errorsLabel.Text = e.Exception.InnerException.Message
      e.ExceptionHandled = True
    Else
      Me.errorsLabel.Text = String.Empty
      Me.personFormView.DataBind()
    End If
  End Sub

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
        Helper.AddValidation(Me.validatorGenerator.GetValidatorGenerator(), New FindControl(AddressOf Me.personFormView.FindControl))
  End Sub

  Protected Sub personFormView_ItemUpdating(ByVal sender As Object, ByVal e As FormViewUpdateEventArgs)
    e.Cancel = Not MyBase.IsValid
  End Sub

  Protected Sub validatorGenerator_TargetObjectRequired(ByVal sender As Object, ByVal e As TargetObjectRequiredEventArgs)
    If (Me.editingPersonTemp Is Nothing) Then
      Me.editingPersonTemp = Helper.GetPerson(New FindControl(AddressOf Me.personFormView.FindControl))
    End If
    e.TargetObject = Me.editingPersonTemp
  End Sub


  ' Fields
  Private editingPersonTemp As Person
End Class


