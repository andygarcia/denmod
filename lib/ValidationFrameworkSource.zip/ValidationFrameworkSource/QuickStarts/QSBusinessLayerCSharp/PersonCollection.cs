using ValidationFramework;

namespace QSBusinessLayerCSharp
{
    public class PersonCollection : AutoKeyDictionary<int, Person>
    {
        protected override int GetKeyForItem(Person item)
        {
            return item.Id;
        }
    }
}