using System;
using System.Collections.Generic;
using ValidationFramework;
using System.Web;

namespace QSBusinessLayerCSharp
{
    /// <summary>
    /// PersonMapper would perform all data persistence for the Person business object.
    /// </summary>
    public class PersonMapper
    {
        private static PersonCollection people;

        private PersonCollection GetPeople()
        {
            if (people == null)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    object sessionObject = context.Session["people"];
                    if (sessionObject != null)
                    {
                        people = (PersonCollection)sessionObject;
                    }

                }
            }
            if (people == null)
            {
                people = GetDefaultPeople();
                TrySaveToSession();
            }
            return people;
        }

        private void TrySaveToSession()
        {
            HttpContext context = HttpContext.Current;
            if (context != null)
            {
                context.Session["people"] = people;
            }
        }

        private PersonCollection GetDefaultPeople()
        {

            Person person1 = new Person(false);
            person1.FirstName = "John";
            person1.Id = 0;
            person1.LastName = "Smith";
            person1.Age = 31;
            person1.EmailAddress = "John.Smith@b.com";
            person1.PhoneNumber = "02-1234-1234";
            person1.CardType = CardType.Visa;
            person1.CreditCardNumber = "1234567890123456";
            person1.OrderTotal = 21.99M;

            Person person2 = new Person(false);
            person1.Id = 1;
            person2.FirstName = "Jane";
            person2.LastName = "Doe";
            person2.Age = 56;
            person2.EmailAddress = "Jane.Doe@b.com";
            person2.PhoneNumber = "05-4224-7337";
            person2.CardType = CardType.Amex;
            person2.CreditCardNumber = "123456789012345";
            person2.OrderTotal = 56.22M;

            PersonCollection list = new PersonCollection();
            list.Add(person1);
            list.Add(person2);
            return list;
        }

        public IList<Person> GetAllPeople()
        {
            List<Person> people = new List<Person>(GetPeople());
            return people;
        }

        public Person GetItem(int id)
        {

            PersonCollection collection = GetPeople();
            return collection[id];
        }

        public void Save(Person person)
        {
            if (!person.IsValid)
            {
                throw new ArgumentException("Person is not valid.  Save is not allowed.", "person");
            }

            PersonCollection collection = GetPeople();
            collection.Add(person);
            TrySaveToSession();
        }

        public void Delete(Person person)
        {
            if (!person.IsValid)
            {
                throw new ArgumentException("Person is not valid.  Delete is not allowed.", "person");
            }

            PersonCollection collection = GetPeople();
            collection.Remove(person);
            TrySaveToSession();
        }
        public void SaveOrUpdate(Person person)
        {
            if (!person.IsValid)
            {
                throw new ArgumentException("Person is not valid.  SaveOrUpdate is not allowed.", "person");
            }
            PersonCollection collection = GetPeople();
            if (collection.Contains(person))
            {
                collection.Remove(person);
            }
            collection.Add(person);
            TrySaveToSession();
        }

    }
}