using ValidationFramework;

namespace QSBusinessLayerCSharp
{
    public class Registration
    {

        [RequiredStringRule(ErrorMessage = "LicenseIsRequired", UseErrorMessageProvider = true)]
        public string LicenceNumber
        {
            get;
            set;
        }

        [RequiredStringRule(ErrorMessage = "AddressIsRequired", UseErrorMessageProvider = true)]
        public string Address
        {
            get;
            set;
        }
    }
}
