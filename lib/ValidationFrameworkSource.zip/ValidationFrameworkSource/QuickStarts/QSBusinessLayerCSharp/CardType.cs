namespace QSBusinessLayerCSharp
{
	public enum CardType
	{
		Visa,
		MasterCard,
		Amex
	}
}