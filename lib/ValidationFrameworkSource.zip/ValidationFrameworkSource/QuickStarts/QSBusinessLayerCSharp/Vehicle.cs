using ValidationFramework;

namespace QSBusinessLayerCSharp
{
    public class Vehicle
    {

        [RangeIntRule(3, 4, RuleSet = "Car", ErrorMessage = "A car should have between 3 and 4 wheels.")]
        [RangeIntRule(2, 4, RuleSet = "Bike", ErrorMessage = "A bike should have between 2 and 4 wheels.")]
        [RangeIntRule(4, 12, RuleSet = "Truck", ErrorMessage = "A truck should have between 4 and 12 wheels.")]
        public int Wheels
        {
            get;
            set;
        }

        [RangeIntRule(2, 5, RuleSet = "Car", ErrorMessage = "A car should have between 2 and 5 doors.")]
        [CompareIntRule(0, CompareOperator.Equal, RuleSet = "Bike", ErrorMessage = "A bike should have no doors.")]
        [RangeIntRule(2, 4, RuleSet = "Truck", ErrorMessage = "A truck should have between 2 and 4 doors.")]
        public int Doors
        {
            get;
            set;
        }

        [RangeIntRule(2, 7, RuleSet = "Car", ErrorMessage = "A car should have between 2 and 7 seats.")]
        [CompareIntRule(1, CompareOperator.Equal, RuleSet = "Bike", ErrorMessage = "A bike should have 1 seat.")]
        [RangeIntRule(2, 5, RuleSet = "Truck", ErrorMessage = "A truck should have between 2 and 5 seats.")]
        public int Seats
        {
            get;
            set;
        }
    }
}