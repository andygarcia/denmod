Imports ValidationFramework

Public Class Registration

    Private _address As String
    Private _licenceNumber As String

    <RequiredStringRule(ErrorMessage:="AddressIsRequired", UseErrorMessageProvider:=True)> _
    Public Property Address() As String
        Get
            Return Me._address
        End Get
        Set(ByVal value As String)
            Me._address = value
        End Set
    End Property

    <RequiredStringRule(ErrorMessage:="LicenseIsRequired", UseErrorMessageProvider:=True)> _
    Public Property LicenceNumber() As String
        Get
            Return Me._licenceNumber
        End Get
        Set(ByVal value As String)
            Me._licenceNumber = value
        End Set
    End Property

End Class

