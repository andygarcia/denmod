Imports ValidationFramework

Public Class PersonCollection
  Inherits AutoKeyDictionary(Of Integer, Person)
  ' Methods
  Protected Overrides Function GetKeyForItem(ByVal item As Person) As Integer
    Return item.Id
  End Function

End Class



