Imports ValidationFramework

Public Class Vehicle
  ' Properties
  <RangeIntRule(2, 4, RuleSet:="Truck", ErrorMessage:="A truck should have between 2 and 4 doors."), CompareIntRule(0, CompareOperator.Equal, RuleSet:="Bike", ErrorMessage:="A bike should have no doors."), RangeIntRule(2, 5, RuleSet:="Car", ErrorMessage:="A car should have between 2 and 5 doors.")> _
  Public Property Doors() As Integer
    Get
      Return Me._doors
    End Get
    Set(ByVal value As Integer)
      Me._doors = value
    End Set
  End Property

  <RangeIntRule(2, 5, RuleSet:="Truck", ErrorMessage:="A truck should have between 2 and 5 seats."), RangeIntRule(2, 7, RuleSet:="Car", ErrorMessage:="A car should have between 2 and 7 seats."), CompareIntRule(1, CompareOperator.Equal, RuleSet:="Bike", ErrorMessage:="A bike should have 1 seat.")> _
  Public Property Seats() As Integer
    Get
      Return Me._seats
    End Get
    Set(ByVal value As Integer)
      Me._seats = value
    End Set
  End Property

  <RangeIntRule(2, 4, RuleSet:="Bike", ErrorMessage:="A bike should have between 2 and 4 wheels."), RangeIntRule(4, 12, RuleSet:="Truck", ErrorMessage:="A truck should have between 4 and 12 wheels."), RangeIntRule(3, 4, RuleSet:="Car", ErrorMessage:="A car should have between 3 and 4 wheels.")> _
  Public Property Wheels() As Integer
    Get
      Return Me._wheels
    End Get
    Set(ByVal value As Integer)
      Me._wheels = value
    End Set
  End Property


  ' Fields
  Private _doors As Integer
  Private _seats As Integer
  Private _wheels As Integer
End Class


