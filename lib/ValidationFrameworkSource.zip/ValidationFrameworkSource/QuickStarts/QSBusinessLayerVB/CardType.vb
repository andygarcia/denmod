Public Enum CardType
  ' Fields
  Amex = 2
  MasterCard = 1
  Visa = 0
End Enum





