Imports ValidationFramework
Imports System.Reflection
  
Public Class Person
  Inherits NotifyValidatableBase
  ' Methods
  Public Sub New()
    MyBase.New(True)
  End Sub

  Public Sub New(ByVal validateOnConstruction As Boolean)
    MyBase.New(validateOnConstruction, Nothing, "sdsd")
  End Sub

  Private Shared Sub CheckValidCreditCard(ByVal sender As Object, ByVal e As CustomValidationEventArgs)
    Dim person As Person = DirectCast(e.TargetObjectValue, Person)
    Dim cardType As Nullable(Of CardType) = person.CardType
    Dim cardNumber As String = person.CreditCardNumber
    If Not ((Not cardNumber Is Nothing) AndAlso cardType.HasValue) Then
      e.IsValid = False
    Else
      Select Case cardType.Value
        Case QSBusinessLayerVB.CardType.Visa, QSBusinessLayerVB.CardType.MasterCard
          e.IsValid = (cardNumber.Length = 16)
          e.ErrorMessage = "VISA/MasterCard has to have 16 characters"
          Return
        Case QSBusinessLayerVB.CardType.Amex
          e.IsValid = (cardNumber.Length = 15)
          e.ErrorMessage = "AMEX has to have 15 characters."
          Return
      End Select
      Throw New ArgumentException("Invalid CardType")
    End If
  End Sub

  Public Sub Hello(<RequiredStringRule()> ByVal [text] As String)
    Dim validate As IList(Of ValidationResult) = ParameterValidationManager.Validate(Me, MethodBase.GetCurrentMethod.MethodHandle, [text], New Object(0 - 1) {})
  End Sub


  ' Properties
  <RequiredIntRule(), CompareIntRule(100, CompareOperator.LessThanEqual), CompareIntRule(18, CompareOperator.GreaterThanEqual)> _
  Public Property Age() As Integer
    Get
      Return Me._age
    End Get
    Set(ByVal value As Integer)
      If (value <> Me._age) Then
        Me._age = value
        MyBase.NotifyAndValidate("Age")
      End If
    End Set
  End Property

    <RequiredEnumRule> _
    Public Property CardType As Nullable(OF CardType)
    Get
      Return Me._cardType
    End Get
    Set(ByVal value As Nullable(Of CardType))
      Me._cardType = value
      MyBase.NotifyAndValidate("CardType")
      MyBase.NotifyAndValidate("CreditCardNumber")
    End Set
  End Property

  <LengthStringRule(16), RequiredStringRule(), CustomRule("QSBusinessLayerVB.Person,QSBusinessLayerVB", "CheckValidCreditCard", "Validate based on credit card rules.", ErrorMessage:="Credit card is invalid.")> _
  Public Property CreditCardNumber() As String
    Get
      Return Me._creditCardNumber
    End Get
    Set(ByVal value As String)
      If (Not value Is Me._creditCardNumber) Then
        Me._creditCardNumber = value
        MyBase.NotifyAndValidate("CreditCardNumber")
      End If
    End Set
  End Property

  <RequiredStringRule(), RegexRule("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage:="Invalid email format."), LengthStringRule(50)> _
  Public Property EmailAddress() As String
    Get
      Return Me._emailAddress
    End Get
    Set(ByVal value As String)
      If (Not value Is Me._emailAddress) Then
        Me._emailAddress = value
        MyBase.NotifyAndValidate("EmailAddress")
      End If
    End Set
  End Property

  <RequiredStringRule(InitialValue:="aaa", IgnoreCase:=True, TrimWhiteSpace:=False), LengthStringRule(50), RequiredStringRule()> _
  Public Property FirstName() As String
    Get
      Return Me._firstName
    End Get
    Set(ByVal value As String)
      If (Not value Is Me._firstName) Then
        Me._firstName = value
        MyBase.NotifyAndValidate("FirstName")
      End If
    End Set
  End Property

  Public Property Id() As Integer
    Get
      Return Me._id
    End Get
    Set(ByVal value As Integer)
      Me._id = value
    End Set
  End Property

  <RequiredStringRule(), LengthStringRule(50, Minimum:=2)> _
  Public Property LastName() As String
    Get
      Return Me._lastName
    End Get
    Set(ByVal value As String)
      If (Not value Is Me._lastName) Then
        Me._lastName = value
        MyBase.NotifyAndValidate("LastName")
      End If
    End Set
  End Property

  <RequiredDecimalRule(), RangeDecimalRule(10, 1000)> _
  Public Property OrderTotal() As Decimal
    Get
      Return Me._orderTotal
    End Get
    Set(ByVal value As Decimal)
      If (value <> Me._orderTotal) Then
        Me._orderTotal = value
        MyBase.NotifyAndValidate("OrderTotal")
      End If
    End Set
  End Property

  <RegexRule("\d{2}-\d{4}-\d{4}", ErrorMessage:="Phone number must be of the format 11-1111-1111")> _
  Public Property PhoneNumber() As String
    Get
      Return Me._phoneNumber
    End Get
    Set(ByVal value As String)
      If (Not value Is Me._phoneNumber) Then
        Me._phoneNumber = value
        MyBase.NotifyAndValidate("PhoneNumber")
      End If
    End Set
  End Property


  ' Fields
  Private _age As Integer
  Public Const AgeMember As String = "Age"
  Public Const CardTypeMember As String = "CardType"
  Public Const CreditCardNumberMember As String = "CreditCardNumber"
  Public Const EmailAddressMember As String = "EmailAddress"
  Public Const FirstNameMember As String = "FirstName"
  Public Const LastNameMember As String = "LastName"
  Public Const OrderTotalMember As String = "OrderTotal"
  Public Const PhoneNumberMember As String = "PhoneNumber"

  Private _cardType As Nullable(Of CardType)
  Private _creditCardNumber As String
  Private _emailAddress As String
  Private _firstName As String
  Private _id As Integer
  Private _lastName As String
  Private _orderTotal As Decimal
  Private _phoneNumber As String
End Class
