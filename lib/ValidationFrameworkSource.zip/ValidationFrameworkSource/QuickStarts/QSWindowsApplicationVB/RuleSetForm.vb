Imports ValidationFramework
Imports QSBusinessLayerVB

Public Class RuleSetForm

  Private Sub validateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles validateButton.Click
    Dim selectedText As String = CStr(Me.ruleSetListBox.SelectedItem)
    Dim manager As New PropertyValidationManager(Me.vehicle, selectedText)
    manager.ValidateAllProperties()
    Me.errorTreeView.Nodes.Clear()
    Dim result As ValidationResult
    For Each result In manager.ValidatorResultsInError
      Dim node As New TreeNode(result.ErrorMessage)
      node.Nodes.Add(String.Format("RuleInterpretation = '{0}'", result.Rule.RuleInterpretation))
      node.Nodes.Add(String.Format("Rule = '{0}'", result.Rule.GetType))
      Me.errorTreeView.Nodes.Add(node)
    Next

  End Sub

  Private vehicle As Vehicle

  Private Sub RuleSetForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    vehicle = New Vehicle()

    	vehicleBindingSource.Add(vehicle)
    ruleSetListBox.SelectedIndex = 0
  End Sub
End Class