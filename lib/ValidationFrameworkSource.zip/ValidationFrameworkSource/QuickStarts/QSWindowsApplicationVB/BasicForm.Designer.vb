<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BasicForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container
    Me.errorTreeView = New System.Windows.Forms.TreeView
    Me.phoneNumberTextbox = New System.Windows.Forms.TextBox
    Me.PersonBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.phoneNumberLabel = New System.Windows.Forms.Label
    Me.cardTypeLabel = New System.Windows.Forms.Label
    Me.textBox1 = New System.Windows.Forms.TextBox
    Me.label2 = New System.Windows.Forms.Label
    Me.creditCardNumberTextBox = New System.Windows.Forms.TextBox
    Me.creditCardLabel = New System.Windows.Forms.Label
    Me.emailTextbox = New System.Windows.Forms.TextBox
    Me.emailLabel = New System.Windows.Forms.Label
    Me.ageTextBox = New System.Windows.Forms.TextBox
    Me.label1 = New System.Windows.Forms.Label
    Me.lastNameTextbox = New System.Windows.Forms.TextBox
    Me.lastNameLabel = New System.Windows.Forms.Label
    Me.firstNameTextBox = New System.Windows.Forms.TextBox
    Me.firstNameLabel = New System.Windows.Forms.Label
    Me.closeButton = New System.Windows.Forms.Button
    Me.visaDataBindableRadioButton = New QSWindowsApplicationVB.DataBindableRadioButton
    Me.amexDataBindableRadioButton = New QSWindowsApplicationVB.DataBindableRadioButton
    Me.masterCardBindableRadioButton = New QSWindowsApplicationVB.DataBindableRadioButton
    Me.errorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
    CType(Me.PersonBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.errorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'errorTreeView
    '
    Me.errorTreeView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.errorTreeView.Location = New System.Drawing.Point(348, 12)
    Me.errorTreeView.Name = "errorTreeView"
    Me.errorTreeView.Size = New System.Drawing.Size(218, 223)
    Me.errorTreeView.TabIndex = 40
    '
    'phoneNumberTextbox
    '
    Me.phoneNumberTextbox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PersonBindingSource, "PhoneNumber", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
    Me.phoneNumberTextbox.Location = New System.Drawing.Point(121, 137)
    Me.phoneNumberTextbox.Name = "phoneNumberTextbox"
    Me.phoneNumberTextbox.Size = New System.Drawing.Size(197, 20)
    Me.phoneNumberTextbox.TabIndex = 39
    '
    'PersonBindingSource
    '
    Me.PersonBindingSource.DataSource = GetType(QSBusinessLayerVB.Person)
    '
    'phoneNumberLabel
    '
    Me.phoneNumberLabel.AutoSize = True
    Me.phoneNumberLabel.Location = New System.Drawing.Point(19, 140)
    Me.phoneNumberLabel.Name = "phoneNumberLabel"
    Me.phoneNumberLabel.Size = New System.Drawing.Size(38, 13)
    Me.phoneNumberLabel.TabIndex = 38
    Me.phoneNumberLabel.Text = "Phone"
    '
    'cardTypeLabel
    '
    Me.cardTypeLabel.AutoSize = True
    Me.cardTypeLabel.Location = New System.Drawing.Point(20, 165)
    Me.cardTypeLabel.Name = "cardTypeLabel"
    Me.cardTypeLabel.Size = New System.Drawing.Size(53, 13)
    Me.cardTypeLabel.TabIndex = 37
    Me.cardTypeLabel.Text = "CardType"
    '
    'textBox1
    '
    Me.textBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PersonBindingSource, "OrderTotal", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
    Me.textBox1.Location = New System.Drawing.Point(121, 263)
    Me.textBox1.Name = "textBox1"
    Me.textBox1.Size = New System.Drawing.Size(62, 20)
    Me.textBox1.TabIndex = 36
    '
    'label2
    '
    Me.label2.AutoSize = True
    Me.label2.Location = New System.Drawing.Point(19, 266)
    Me.label2.Name = "label2"
    Me.label2.Size = New System.Drawing.Size(60, 13)
    Me.label2.TabIndex = 35
    Me.label2.Text = "Order Total"
    '
    'creditCardNumberTextBox
    '
    Me.creditCardNumberTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PersonBindingSource, "CreditCardNumber", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
    Me.creditCardNumberTextBox.Location = New System.Drawing.Point(121, 237)
    Me.creditCardNumberTextBox.Name = "creditCardNumberTextBox"
    Me.creditCardNumberTextBox.Size = New System.Drawing.Size(197, 20)
    Me.creditCardNumberTextBox.TabIndex = 34
    '
    'creditCardLabel
    '
    Me.creditCardLabel.AutoSize = True
    Me.creditCardLabel.Location = New System.Drawing.Point(19, 240)
    Me.creditCardLabel.Name = "creditCardLabel"
    Me.creditCardLabel.Size = New System.Drawing.Size(99, 13)
    Me.creditCardLabel.TabIndex = 33
    Me.creditCardLabel.Text = "Credit Card Number"
    '
    'emailTextbox
    '
    Me.emailTextbox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PersonBindingSource, "EmailAddress", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
    Me.emailTextbox.Location = New System.Drawing.Point(121, 111)
    Me.emailTextbox.Name = "emailTextbox"
    Me.emailTextbox.Size = New System.Drawing.Size(197, 20)
    Me.emailTextbox.TabIndex = 32
    '
    'emailLabel
    '
    Me.emailLabel.AutoSize = True
    Me.emailLabel.Location = New System.Drawing.Point(19, 114)
    Me.emailLabel.Name = "emailLabel"
    Me.emailLabel.Size = New System.Drawing.Size(32, 13)
    Me.emailLabel.TabIndex = 31
    Me.emailLabel.Text = "Email"
    '
    'ageTextBox
    '
    Me.ageTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PersonBindingSource, "Age", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
    Me.ageTextBox.Location = New System.Drawing.Point(121, 85)
    Me.ageTextBox.Name = "ageTextBox"
    Me.ageTextBox.Size = New System.Drawing.Size(53, 20)
    Me.ageTextBox.TabIndex = 30
    '
    'label1
    '
    Me.label1.AutoSize = True
    Me.label1.Location = New System.Drawing.Point(19, 85)
    Me.label1.Name = "label1"
    Me.label1.Size = New System.Drawing.Size(26, 13)
    Me.label1.TabIndex = 29
    Me.label1.Text = "Age"
    '
    'lastNameTextbox
    '
    Me.lastNameTextbox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PersonBindingSource, "FirstName", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
    Me.lastNameTextbox.Location = New System.Drawing.Point(121, 59)
    Me.lastNameTextbox.Name = "lastNameTextbox"
    Me.lastNameTextbox.Size = New System.Drawing.Size(100, 20)
    Me.lastNameTextbox.TabIndex = 28
    '
    'lastNameLabel
    '
    Me.lastNameLabel.AutoSize = True
    Me.lastNameLabel.Location = New System.Drawing.Point(20, 59)
    Me.lastNameLabel.Name = "lastNameLabel"
    Me.lastNameLabel.Size = New System.Drawing.Size(58, 13)
    Me.lastNameLabel.TabIndex = 27
    Me.lastNameLabel.Text = "Last Name"
    '
    'firstNameTextBox
    '
    Me.firstNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PersonBindingSource, "FirstName", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
    Me.firstNameTextBox.Location = New System.Drawing.Point(121, 33)
    Me.firstNameTextBox.Name = "firstNameTextBox"
    Me.firstNameTextBox.Size = New System.Drawing.Size(100, 20)
    Me.firstNameTextBox.TabIndex = 26
    '
    'firstNameLabel
    '
    Me.firstNameLabel.AutoSize = True
    Me.firstNameLabel.Location = New System.Drawing.Point(20, 33)
    Me.firstNameLabel.Name = "firstNameLabel"
    Me.firstNameLabel.Size = New System.Drawing.Size(57, 13)
    Me.firstNameLabel.TabIndex = 25
    Me.firstNameLabel.Text = "First Name"
    '
    'closeButton
    '
    Me.closeButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.closeButton.Location = New System.Drawing.Point(450, 256)
    Me.closeButton.Name = "closeButton"
    Me.closeButton.Size = New System.Drawing.Size(116, 23)
    Me.closeButton.TabIndex = 24
    Me.closeButton.Text = "Validate and Close"
    Me.closeButton.UseVisualStyleBackColor = True
    '
    'visaDataBindableRadioButton
    '
    Me.visaDataBindableRadioButton.AutoSize = True
    Me.visaDataBindableRadioButton.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PersonBindingSource, "CardType", True))
    Me.visaDataBindableRadioButton.Key = "Visa"
    Me.visaDataBindableRadioButton.Location = New System.Drawing.Point(121, 165)
    Me.visaDataBindableRadioButton.Name = "visaDataBindableRadioButton"
    Me.visaDataBindableRadioButton.Size = New System.Drawing.Size(45, 17)
    Me.visaDataBindableRadioButton.TabIndex = 41
    Me.visaDataBindableRadioButton.TabStop = True
    Me.visaDataBindableRadioButton.Text = "Visa"
    Me.visaDataBindableRadioButton.UseVisualStyleBackColor = True
    Me.visaDataBindableRadioButton.Value = Nothing
    '
    'amexDataBindableRadioButton
    '
    Me.amexDataBindableRadioButton.AutoSize = True
    Me.amexDataBindableRadioButton.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PersonBindingSource, "CardType", True))
    Me.amexDataBindableRadioButton.Key = "Amex"
    Me.amexDataBindableRadioButton.Location = New System.Drawing.Point(121, 211)
    Me.amexDataBindableRadioButton.Name = "amexDataBindableRadioButton"
    Me.amexDataBindableRadioButton.Size = New System.Drawing.Size(51, 17)
    Me.amexDataBindableRadioButton.TabIndex = 42
    Me.amexDataBindableRadioButton.TabStop = True
    Me.amexDataBindableRadioButton.Text = "Amex"
    Me.amexDataBindableRadioButton.UseVisualStyleBackColor = True
    Me.amexDataBindableRadioButton.Value = Nothing
    '
    'masterCardBindableRadioButton
    '
    Me.masterCardBindableRadioButton.AutoSize = True
    Me.masterCardBindableRadioButton.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PersonBindingSource, "CardType", True))
    Me.masterCardBindableRadioButton.Key = "MasterCard"
    Me.masterCardBindableRadioButton.Location = New System.Drawing.Point(121, 188)
    Me.masterCardBindableRadioButton.Name = "masterCardBindableRadioButton"
    Me.masterCardBindableRadioButton.Size = New System.Drawing.Size(82, 17)
    Me.masterCardBindableRadioButton.TabIndex = 43
    Me.masterCardBindableRadioButton.TabStop = True
    Me.masterCardBindableRadioButton.Text = "Master Card"
    Me.masterCardBindableRadioButton.UseVisualStyleBackColor = True
    Me.masterCardBindableRadioButton.Value = Nothing
    '
    'errorProvider1
    '
    Me.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
    Me.errorProvider1.ContainerControl = Me
    Me.errorProvider1.DataSource = Me.PersonBindingSource
    '
    'BasicForm
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(578, 291)
    Me.Controls.Add(Me.masterCardBindableRadioButton)
    Me.Controls.Add(Me.amexDataBindableRadioButton)
    Me.Controls.Add(Me.visaDataBindableRadioButton)
    Me.Controls.Add(Me.errorTreeView)
    Me.Controls.Add(Me.phoneNumberTextbox)
    Me.Controls.Add(Me.phoneNumberLabel)
    Me.Controls.Add(Me.cardTypeLabel)
    Me.Controls.Add(Me.textBox1)
    Me.Controls.Add(Me.label2)
    Me.Controls.Add(Me.creditCardNumberTextBox)
    Me.Controls.Add(Me.creditCardLabel)
    Me.Controls.Add(Me.emailTextbox)
    Me.Controls.Add(Me.emailLabel)
    Me.Controls.Add(Me.ageTextBox)
    Me.Controls.Add(Me.label1)
    Me.Controls.Add(Me.lastNameTextbox)
    Me.Controls.Add(Me.lastNameLabel)
    Me.Controls.Add(Me.firstNameTextBox)
    Me.Controls.Add(Me.firstNameLabel)
    Me.Controls.Add(Me.closeButton)
    Me.Name = "BasicForm"
    Me.Text = "BasicForm"
    CType(Me.PersonBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.errorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Private WithEvents errorTreeView As System.Windows.Forms.TreeView
  Private WithEvents phoneNumberTextbox As System.Windows.Forms.TextBox
  Private WithEvents phoneNumberLabel As System.Windows.Forms.Label
  Private WithEvents cardTypeLabel As System.Windows.Forms.Label
  Private WithEvents textBox1 As System.Windows.Forms.TextBox
  Private WithEvents label2 As System.Windows.Forms.Label
  Private WithEvents creditCardNumberTextBox As System.Windows.Forms.TextBox
  Private WithEvents creditCardLabel As System.Windows.Forms.Label
  Private WithEvents emailTextbox As System.Windows.Forms.TextBox
  Private WithEvents emailLabel As System.Windows.Forms.Label
  Private WithEvents ageTextBox As System.Windows.Forms.TextBox
  Private WithEvents label1 As System.Windows.Forms.Label
  Private WithEvents lastNameTextbox As System.Windows.Forms.TextBox
  Private WithEvents lastNameLabel As System.Windows.Forms.Label
  Private WithEvents firstNameTextBox As System.Windows.Forms.TextBox
  Private WithEvents firstNameLabel As System.Windows.Forms.Label
  Private WithEvents closeButton As System.Windows.Forms.Button
  Friend WithEvents PersonBindingSource As System.Windows.Forms.BindingSource
  Friend WithEvents visaDataBindableRadioButton As QSWindowsApplicationVB.DataBindableRadioButton
  Friend WithEvents amexDataBindableRadioButton As QSWindowsApplicationVB.DataBindableRadioButton
  Friend WithEvents masterCardBindableRadioButton As QSWindowsApplicationVB.DataBindableRadioButton
  Private WithEvents errorProvider1 As System.Windows.Forms.ErrorProvider
End Class
