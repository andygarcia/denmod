<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MultiLanguageForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.noteLabel = New System.Windows.Forms.Label
        Me.cultureListBox = New System.Windows.Forms.ListBox
        Me.cultureLabel = New System.Windows.Forms.Label
        Me.errorTreeView = New System.Windows.Forms.TreeView
        Me.validateButton = New System.Windows.Forms.Button
        Me.licenseLabel = New System.Windows.Forms.Label
        Me.seatsTextBox = New System.Windows.Forms.TextBox
        Me.addressLabel = New System.Windows.Forms.Label
        Me.addressTextBox = New System.Windows.Forms.TextBox
        Me.RegistrationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.RegistrationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'noteLabel
        '
        Me.noteLabel.AutoSize = True
        Me.noteLabel.Location = New System.Drawing.Point(12, 6)
        Me.noteLabel.Name = "noteLabel"
        Me.noteLabel.Size = New System.Drawing.Size(362, 13)
        Me.noteLabel.TabIndex = 36
        Me.noteLabel.Text = "Note: control texts are not localised as it is not what is being illustrated here" & _
            "."
        '
        'cultureListBox
        '
        Me.cultureListBox.FormattingEnabled = True
        Me.cultureListBox.Items.AddRange(New Object() {"fr-CA", "zh-TW", "en-AU", "en-US"})
        Me.cultureListBox.Location = New System.Drawing.Point(270, 30)
        Me.cultureListBox.Name = "cultureListBox"
        Me.cultureListBox.Size = New System.Drawing.Size(58, 56)
        Me.cultureListBox.TabIndex = 35
        '
        'cultureLabel
        '
        Me.cultureLabel.AutoSize = True
        Me.cultureLabel.Location = New System.Drawing.Point(206, 30)
        Me.cultureLabel.Name = "cultureLabel"
        Me.cultureLabel.Size = New System.Drawing.Size(38, 13)
        Me.cultureLabel.TabIndex = 34
    Me.cultureLabel.Text = "Culture"
        '
        'errorTreeView
        '
        Me.errorTreeView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.errorTreeView.Location = New System.Drawing.Point(12, 90)
        Me.errorTreeView.Name = "errorTreeView"
        Me.errorTreeView.Size = New System.Drawing.Size(507, 97)
        Me.errorTreeView.TabIndex = 33
        '
        'validateButton
        '
        Me.validateButton.Location = New System.Drawing.Point(386, 49)
        Me.validateButton.Name = "validateButton"
        Me.validateButton.Size = New System.Drawing.Size(75, 23)
        Me.validateButton.TabIndex = 32
        Me.validateButton.Text = "Validate"
        Me.validateButton.UseVisualStyleBackColor = True
        '
        'licenseLabel
        '
        Me.licenseLabel.AutoSize = True
        Me.licenseLabel.Location = New System.Drawing.Point(12, 59)
        Me.licenseLabel.Name = "licenseLabel"
        Me.licenseLabel.Size = New System.Drawing.Size(44, 13)
        Me.licenseLabel.TabIndex = 31
        Me.licenseLabel.Text = "License"
        '
        'seatsTextBox
        '
        Me.seatsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.RegistrationBindingSource, "LicenceNumber", True))
        Me.seatsTextBox.Location = New System.Drawing.Point(76, 56)
        Me.seatsTextBox.Name = "seatsTextBox"
        Me.seatsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.seatsTextBox.TabIndex = 30
        '
        'addressLabel
        '
        Me.addressLabel.AutoSize = True
        Me.addressLabel.Location = New System.Drawing.Point(12, 33)
        Me.addressLabel.Name = "addressLabel"
        Me.addressLabel.Size = New System.Drawing.Size(45, 13)
        Me.addressLabel.TabIndex = 29
        Me.addressLabel.Text = "Address"
        '
        'addressTextBox
        '
        Me.addressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.RegistrationBindingSource, "Address", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.addressTextBox.Location = New System.Drawing.Point(76, 30)
        Me.addressTextBox.Name = "addressTextBox"
        Me.addressTextBox.Size = New System.Drawing.Size(100, 20)
        Me.addressTextBox.TabIndex = 28
        '
        'RegistrationBindingSource
        '
        Me.RegistrationBindingSource.DataSource = GetType(QSBusinessLayerVB.Registration)
        '
        'MultiLanguageForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(525, 188)
        Me.Controls.Add(Me.noteLabel)
        Me.Controls.Add(Me.cultureListBox)
        Me.Controls.Add(Me.cultureLabel)
        Me.Controls.Add(Me.errorTreeView)
        Me.Controls.Add(Me.validateButton)
        Me.Controls.Add(Me.licenseLabel)
        Me.Controls.Add(Me.seatsTextBox)
        Me.Controls.Add(Me.addressLabel)
        Me.Controls.Add(Me.addressTextBox)
        Me.Name = "MultiLanguageForm"
        Me.Text = "MultiLanguageForm"
        CType(Me.RegistrationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents noteLabel As System.Windows.Forms.Label
    Private WithEvents cultureListBox As System.Windows.Forms.ListBox
    Private WithEvents cultureLabel As System.Windows.Forms.Label
    Private WithEvents errorTreeView As System.Windows.Forms.TreeView
    Private WithEvents validateButton As System.Windows.Forms.Button
    Private WithEvents licenseLabel As System.Windows.Forms.Label
    Private WithEvents seatsTextBox As System.Windows.Forms.TextBox
    Private WithEvents addressLabel As System.Windows.Forms.Label
    Private WithEvents addressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RegistrationBindingSource As System.Windows.Forms.BindingSource
End Class
