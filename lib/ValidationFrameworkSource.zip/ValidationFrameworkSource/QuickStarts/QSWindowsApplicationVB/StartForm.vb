

Public Class StartForm

    Private Sub basicSampleButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles basicSampleButton.Click
        Using basicForm As BasicForm = New BasicForm
            basicForm.ShowDialog(Me)
        End Using
    End Sub

    Private Sub ruleSetButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ruleSetButton.Click
        Using ruleSetForm As RuleSetForm = New RuleSetForm
            ruleSetForm.ShowDialog(Me)
        End Using
    End Sub

    Private Sub multiLanguageButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles multiLanguageButton.Click
        Using multiLanguageForm As MultiLanguageForm = New MultiLanguageForm
            multiLanguageForm.ShowDialog(Me)
        End Using
    End Sub

End Class
