Imports QSBusinessLayerVB
Imports ValidationFramework

Public Class BasicForm

  Private Sub closeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closeButton.Click
    If Me.person.IsValid Then
      MyBase.Close()
    Else
      Me.errorTreeView.Nodes.Clear()
      Dim result As ValidationResult
      For Each result In Me.person.ValidatorResultsInError
        Dim node As New TreeNode(result.ErrorMessage)
        node.Nodes.Add(String.Format("RuleInterpretation = '{0}'", result.Rule.RuleInterpretation))
        node.Nodes.Add(String.Format("Rule = '{0}'", result.Rule.GetType))
        Me.errorTreeView.Nodes.Add(node)
      Next
      MessageBox.Show(String.Format("Data is invalid. Errors:" & ChrW(13) & ChrW(10) & "{0}", Me.person.Error))
    End If

  End Sub

  Private person As Person




  Private Sub BasicForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Me.person = New PersonMapper().GetItem(1)
    Me.PersonBindingSource.Add(Me.person)

  End Sub
End Class