<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RuleSetForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container
    Me.ruleSetListBox = New System.Windows.Forms.ListBox
    Me.ruleSetLabel = New System.Windows.Forms.Label
    Me.errorTreeView = New System.Windows.Forms.TreeView
    Me.validateButton = New System.Windows.Forms.Button
    Me.seatsLabel = New System.Windows.Forms.Label
    Me.seatsTextBox = New System.Windows.Forms.TextBox
    Me.vehicleBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.doorsLabel = New System.Windows.Forms.Label
    Me.doorsTextBox = New System.Windows.Forms.TextBox
    Me.wheelsLabel = New System.Windows.Forms.Label
    Me.wheelsTextBox = New System.Windows.Forms.TextBox
    CType(Me.vehicleBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'ruleSetListBox
    '
    Me.ruleSetListBox.FormattingEnabled = True
    Me.ruleSetListBox.Items.AddRange(New Object() {"car", "truck", "bike"})
    Me.ruleSetListBox.Location = New System.Drawing.Point(274, 11)
    Me.ruleSetListBox.Name = "ruleSetListBox"
    Me.ruleSetListBox.Size = New System.Drawing.Size(58, 43)
    Me.ruleSetListBox.TabIndex = 36
    '
    'ruleSetLabel
    '
    Me.ruleSetLabel.AutoSize = True
    Me.ruleSetLabel.Location = New System.Drawing.Point(210, 11)
    Me.ruleSetLabel.Name = "ruleSetLabel"
    Me.ruleSetLabel.Size = New System.Drawing.Size(45, 13)
    Me.ruleSetLabel.TabIndex = 35
    Me.ruleSetLabel.Text = "RuleSet"
    '
    'errorTreeView
    '
    Me.errorTreeView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.errorTreeView.Location = New System.Drawing.Point(12, 92)
    Me.errorTreeView.Name = "errorTreeView"
    Me.errorTreeView.Size = New System.Drawing.Size(499, 97)
    Me.errorTreeView.TabIndex = 34
    '
    'validateButton
    '
    Me.validateButton.Location = New System.Drawing.Point(240, 63)
    Me.validateButton.Name = "validateButton"
    Me.validateButton.Size = New System.Drawing.Size(75, 23)
    Me.validateButton.TabIndex = 33
    Me.validateButton.Text = "Validate"
    Me.validateButton.UseVisualStyleBackColor = True
    '
    'seatsLabel
    '
    Me.seatsLabel.AutoSize = True
    Me.seatsLabel.Location = New System.Drawing.Point(16, 40)
    Me.seatsLabel.Name = "seatsLabel"
    Me.seatsLabel.Size = New System.Drawing.Size(34, 13)
    Me.seatsLabel.TabIndex = 32
    Me.seatsLabel.Text = "Seats"
    '
    'seatsTextBox
    '
    Me.seatsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.vehicleBindingSource, "Seats", True))
    Me.seatsTextBox.Location = New System.Drawing.Point(80, 37)
    Me.seatsTextBox.Name = "seatsTextBox"
    Me.seatsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.seatsTextBox.TabIndex = 31
    '
    'vehicleBindingSource
    '
    Me.vehicleBindingSource.DataSource = GetType(QSBusinessLayerVB.Vehicle)
    '
    'doorsLabel
    '
    Me.doorsLabel.AutoSize = True
    Me.doorsLabel.Location = New System.Drawing.Point(16, 66)
    Me.doorsLabel.Name = "doorsLabel"
    Me.doorsLabel.Size = New System.Drawing.Size(35, 13)
    Me.doorsLabel.TabIndex = 30
    Me.doorsLabel.Text = "Doors"
    '
    'doorsTextBox
    '
    Me.doorsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.vehicleBindingSource, "Doors", True))
    Me.doorsTextBox.Location = New System.Drawing.Point(80, 63)
    Me.doorsTextBox.Name = "doorsTextBox"
    Me.doorsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.doorsTextBox.TabIndex = 29
    '
    'wheelsLabel
    '
    Me.wheelsLabel.AutoSize = True
    Me.wheelsLabel.Location = New System.Drawing.Point(16, 14)
    Me.wheelsLabel.Name = "wheelsLabel"
    Me.wheelsLabel.Size = New System.Drawing.Size(43, 13)
    Me.wheelsLabel.TabIndex = 28
    Me.wheelsLabel.Text = "Wheels"
    '
    'wheelsTextBox
    '
    Me.wheelsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.vehicleBindingSource, "Wheels", True))
    Me.wheelsTextBox.Location = New System.Drawing.Point(80, 11)
    Me.wheelsTextBox.Name = "wheelsTextBox"
    Me.wheelsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.wheelsTextBox.TabIndex = 27
    '
    'RuleSetForm
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(545, 240)
    Me.Controls.Add(Me.ruleSetListBox)
    Me.Controls.Add(Me.ruleSetLabel)
    Me.Controls.Add(Me.errorTreeView)
    Me.Controls.Add(Me.validateButton)
    Me.Controls.Add(Me.seatsLabel)
    Me.Controls.Add(Me.seatsTextBox)
    Me.Controls.Add(Me.doorsLabel)
    Me.Controls.Add(Me.doorsTextBox)
    Me.Controls.Add(Me.wheelsLabel)
    Me.Controls.Add(Me.wheelsTextBox)
    Me.Name = "RuleSetForm"
    Me.Text = "RuleSetForm"
    CType(Me.vehicleBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Private WithEvents ruleSetListBox As System.Windows.Forms.ListBox
  Private WithEvents ruleSetLabel As System.Windows.Forms.Label
  Private WithEvents errorTreeView As System.Windows.Forms.TreeView
  Private WithEvents validateButton As System.Windows.Forms.Button
  Private WithEvents seatsLabel As System.Windows.Forms.Label
  Private WithEvents seatsTextBox As System.Windows.Forms.TextBox
  Private WithEvents doorsLabel As System.Windows.Forms.Label
  Private WithEvents doorsTextBox As System.Windows.Forms.TextBox
  Private WithEvents wheelsLabel As System.Windows.Forms.Label
  Private WithEvents wheelsTextBox As System.Windows.Forms.TextBox
  Friend WithEvents vehicleBindingSource As System.Windows.Forms.BindingSource
End Class
