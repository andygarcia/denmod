<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StartForm
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
        Me.ruleSetButton = New System.Windows.Forms.Button
        Me.basicSampleButton = New System.Windows.Forms.Button
        Me.multiLanguageButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'ruleSetButton
        '
        Me.ruleSetButton.Location = New System.Drawing.Point(12, 55)
        Me.ruleSetButton.Name = "ruleSetButton"
        Me.ruleSetButton.Size = New System.Drawing.Size(94, 23)
        Me.ruleSetButton.TabIndex = 3
        Me.ruleSetButton.Text = "RuleSetSample"
        Me.ruleSetButton.UseVisualStyleBackColor = True
        '
        'basicSampleButton
        '
        Me.basicSampleButton.Location = New System.Drawing.Point(12, 12)
        Me.basicSampleButton.Name = "basicSampleButton"
        Me.basicSampleButton.Size = New System.Drawing.Size(94, 23)
        Me.basicSampleButton.TabIndex = 2
        Me.basicSampleButton.Text = "BasicSample"
        Me.basicSampleButton.UseVisualStyleBackColor = True
        '
        'multiLanguageButton
        '
        Me.multiLanguageButton.Location = New System.Drawing.Point(12, 95)
        Me.multiLanguageButton.Name = "multiLanguageButton"
        Me.multiLanguageButton.Size = New System.Drawing.Size(113, 23)
        Me.multiLanguageButton.TabIndex = 4
        Me.multiLanguageButton.Text = "MultiLangSample"
        Me.multiLanguageButton.UseVisualStyleBackColor = True
        '
        'StartForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 264)
        Me.Controls.Add(Me.multiLanguageButton)
        Me.Controls.Add(Me.ruleSetButton)
        Me.Controls.Add(Me.basicSampleButton)
        Me.Name = "StartForm"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
  Private WithEvents ruleSetButton As System.Windows.Forms.Button
    Private WithEvents basicSampleButton As System.Windows.Forms.Button
    Private WithEvents multiLanguageButton As System.Windows.Forms.Button

End Class
