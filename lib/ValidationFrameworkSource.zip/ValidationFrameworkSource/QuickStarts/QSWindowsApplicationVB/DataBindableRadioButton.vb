Imports System.ComponentModel
Imports System.Windows.Forms

Public Class DataBindableRadioButton
  Inherits RadioButton
  ' Methods
  Public Sub New()
    AddHandler MyBase.CheckedChanged, New EventHandler(AddressOf Me.DataBindableRadioButton_CheckedChanged)
  End Sub

  Private Sub DataBindableRadioButton_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
    If (Me.respondToCheckEvent AndAlso MyBase.Checked) Then
      Me._value = Me._key
      Dim dataBinding As Binding = MyBase.DataBindings.Item("Value")
      If (Not dataBinding Is Nothing) Then
        dataBinding.WriteValue()
      End If
    End If
  End Sub


  ' Properties
  Public Property Key() As String
    Get
      Return Me._key
    End Get
    Set(ByVal value2 As String)
      Me._key = value2
    End Set
  End Property

  <Bindable(True)> _
  Public Property Value() As String
    Get
      Return Me._value
    End Get
    Set(ByVal value2 As String)
      If (Not String.Equals(Me._value, value2)) Then
        Me._value = value2
        If (Not MyBase.DesignMode AndAlso (LicenseManager.UsageMode <> LicenseUsageMode.Designtime)) Then
          Me.respondToCheckEvent = False
          If (String.Equals(Me.Key, Me._value)) Then
            MyBase.Checked = True
          Else
            MyBase.Checked = False
          End If
          Me.respondToCheckEvent = True
        End If
      End If
    End Set
  End Property


  ' Fields
  Private _key As String
  Private respondToCheckEvent As Boolean = True
  Private _value As String
End Class


