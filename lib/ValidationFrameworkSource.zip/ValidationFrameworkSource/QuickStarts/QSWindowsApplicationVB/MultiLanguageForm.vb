Imports System.Globalization
Imports System.Threading
Imports System.Windows.Forms
Imports QSBusinessLayerVB
Imports ValidationFramework

Public Class MultiLanguageForm

    Private registration As Registration

    Private Sub cultureListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cultureListBox.SelectedIndexChanged
        Thread.CurrentThread.CurrentCulture = New CultureInfo(CStr(Me.cultureListBox.SelectedItem))
    End Sub

    Private Sub validateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles validateButton.Click
        Dim manager As New PropertyValidationManager(Me.registration)
        manager.ValidateAllProperties()
        Me.errorTreeView.Nodes.Clear()
        Dim result As ValidationResult
        For Each result In manager.ValidatorResultsInError
            Dim node As New TreeNode(result.ErrorMessage)
            node.Nodes.Add(String.Format("RuleInterpretation = '{0}'", result.Rule.RuleInterpretation))
            node.Nodes.Add(String.Format("Rule = '{0}'", result.Rule.GetType))
            Me.errorTreeView.Nodes.Add(node)
        Next

    End Sub

    Private Sub MultiLanguageForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.RegistrationBindingSource.Add(Me.registration)
        Me.cultureListBox.SelectedIndex = 0
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        Me.registration = New Registration

    End Sub
End Class