Imports System
Imports System.Reflection
Imports ValidationFramework
Imports ValidationFramework.Reflection

Public Class GetReflectionInfoFromValidationResult
	' Methods
    Public Shared Function GetMethodInfoFromParameterValidationResult( _
ByVal result As ValidationResult) As MethodBase
        Dim parameterDescriptor As ParameterDescriptor = _
        DirectCast(result.Rule.InfoDescriptor, ParameterDescriptor)
        Return MethodBase.GetMethodFromHandle( _
        parameterDescriptor.Method.RuntimeMethodHandle)
    End Function

    Public Shared Function GetTypeFromPropertyValidationResult( _
    ByVal result As ValidationResult) As Type
        Dim propertyDescriptor As PropertyDescriptor = _
        DirectCast(result.Rule.InfoDescriptor, PropertyDescriptor)
        Return Type.GetTypeFromHandle( _
        propertyDescriptor.TypeDescriptor.RuntimeTypeHandle)
    End Function

End Class

