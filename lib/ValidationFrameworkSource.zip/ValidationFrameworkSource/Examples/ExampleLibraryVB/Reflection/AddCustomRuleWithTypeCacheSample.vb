Imports System
Imports NUnit.Framework
Imports ValidationFramework
Imports ValidationFramework.Reflection

Public Class AddCustomRuleWithTypeCacheSample

    Private _foo As String
    Private _validationManager As PropertyValidationManager


  Public Sub New()
    Me._validationManager = New PropertyValidationManager(Me)
  End Sub



    Public Shared Sub CheckIsNotEmpty(ByVal sender As Object, _
    ByVal e As CustomValidationEventArgs)
        Dim foo As String = CStr(e.TargetMemberValue)
        If String.IsNullOrEmpty(foo) Then
            e.IsValid = False
        Else
            e.IsValid = True
        End If
    End Sub





    Public Function Validate() As Boolean

        ' Use TryValidateProperty in case rules have not yet been applied
        Me._validationManager.TryValidateProperty("Foo")
        Return Me._validationManager.IsValid
    End Function


    Public Property Foo() As String
        Get
            Return Me._foo
        End Get
        Set(ByVal value As String)
            Me._foo = value
        End Set
    End Property


End Class

<TestFixture()> _
Public Class AddCustomRuleWithTypeCacheTests
    <Test()> _
    Public Sub TestAddCustomPropertyValidation()
        Dim fooType As Type = GetType(AddCustomRuleWithTypeCacheSample)
        Dim propertyDescriptor As PropertyDescriptor = _
        TypeCache.GetType(fooType.TypeHandle).GetOrCreatePropertyDescriptor("Foo")
        Dim rule As New CustomRule("Foo cannot be empty.", Nothing, False, _
        New CustomValidationHandler(AddressOf AddCustomRuleWithTypeCacheSample.CheckIsNotEmpty) _
        , "Foo cannot be empty.")
        propertyDescriptor.Rules.Add(rule)
        Dim sample As New AddCustomRuleWithTypeCacheSample
        Assert.IsFalse(sample.Validate)
        sample.Foo = "Hello"
        Assert.IsTrue(sample.Validate)
    End Sub

End Class








