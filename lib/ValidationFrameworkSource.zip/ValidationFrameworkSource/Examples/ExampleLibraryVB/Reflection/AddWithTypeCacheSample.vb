Imports System
Imports NUnit.Framework
Imports ValidationFramework
Imports ValidationFramework.Reflection

Public Class AddWithTypeCacheSample

    Private _foo As Integer
    Private _validationManager As PropertyValidationManager

	Public Sub New()
		Me._validationManager = New PropertyValidationManager(Me)
	End Sub



	Public Function Validate() As Boolean
        Me._validationManager.ValidateProperty("Foo")
		Return Me._validationManager.IsValid
	End Function


	' Properties
	Public Property Foo() As Integer
		Get
			Return Me._foo
		End Get
		Set(ByVal value As Integer)
			Me._foo = value
		End Set
	End Property


End Class


<TestFixture()> _
Public Class AddWithTypeCacheTests

    <Test()> _
    Public Sub Run()
        Dim fooType As Type = GetType(AddWithTypeCacheSample)
        Dim propertyDescriptor As PropertyDescriptor = _
        TypeCache.GetType(fooType.TypeHandle).GetOrCreatePropertyDescriptor("Foo")
        Dim rule As New RequiredRule(Of Integer)(Nothing, Nothing, False)
        propertyDescriptor.Rules.Add(rule)
        Dim sample As New AddWithTypeCacheSample
        Assert.IsFalse(sample.Validate)
        sample.Foo = 10
        Assert.IsTrue(sample.Validate)
    End Sub

End Class


