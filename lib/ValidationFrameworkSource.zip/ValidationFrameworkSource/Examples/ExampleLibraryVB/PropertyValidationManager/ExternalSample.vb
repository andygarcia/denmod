Imports System
Imports NUnit.Framework
Imports ValidationFramework

Namespace ExampleLibraryVBPropertyValidationManager
	Public Class ClassToValidate
		' Properties
		<RequiredIntRule()> _
		Public Property Data() As Integer
			Get
				Return Me._data
			End Get
			Set(ByVal value As Integer)
				Me._data = value
			End Set
		End Property


		' Fields
		Private _data As Integer
	End Class



	<TestFixture()> _
	Public Class ExternalTests
		' Methods
		<Test()> _
		Public Sub Run()
			Dim classToValidate As New ClassToValidate
			Dim propertyValidationManager As New PropertyValidationManager(classToValidate)
			'Could have called propertyValidationManager.Validate() here to validate all 
			' properties
			propertyValidationManager.ValidateProperty("Data")
			Assert.IsFalse(propertyValidationManager.IsValid)
			classToValidate.Data = 99
			' Could have called propertyValidationManager.Validate() here to validate all 
			' properties()
			propertyValidationManager.ValidateProperty("Data")
			Assert.IsTrue(propertyValidationManager.IsValid)
		End Sub

	End Class
End Namespace



