Imports System
Imports ValidationFramework


Public Class CompareStringRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<CompareStringRule("a", CompareOperator.LessThan)> ByVal paramData As String)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<CompareStringRule("d", CompareOperator.LessThan)> _
	<CompareStringRule("a", CompareOperator.GreaterThan, _
	ErrorMessage:="Data must be greater than a.")> _
	Public Property Data() As String
		Get
			Return Me._data
		End Get
		Set(ByVal value As String)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As String
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(CompareStringRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

