Imports System
Imports ValidationFramework


Public Class CompareShortRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<CompareShortRule(5, CompareOperator.LessThan)> ByVal paramData As Short)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<CompareShortRule(5, CompareOperator.LessThan)> _
	<CompareShortRule(2, CompareOperator.GreaterThan, _
	ErrorMessage:="Data must be greater than 2.")> _
	Public Property Data() As Short
		Get
			Return Me._data
		End Get
		Set(ByVal value As Short)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Short
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(CompareShortRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

