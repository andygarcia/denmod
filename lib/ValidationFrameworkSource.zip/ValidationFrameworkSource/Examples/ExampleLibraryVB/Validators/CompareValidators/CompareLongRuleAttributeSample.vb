Imports System
Imports ValidationFramework


Public Class CompareLongRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<CompareLongRule(5, CompareOperator.LessThan)> ByVal paramData As Long)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<CompareLongRule(5, CompareOperator.LessThan)> _
	<CompareLongRule(2, CompareOperator.GreaterThan, _
	ErrorMessage:="Data must be greater than 2.")> _
	Public Property Data() As Long
		Get
			Return Me._data
		End Get
		Set(ByVal value As Long)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Long
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(CompareLongRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

