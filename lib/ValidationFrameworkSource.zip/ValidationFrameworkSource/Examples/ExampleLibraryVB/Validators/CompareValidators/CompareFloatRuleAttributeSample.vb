Imports System
Imports ValidationFramework

Public Class CompareFloatRuleAttributeSample

    'Methods
    Public Sub DoSomething( _
 <CompareFloatRule(5.0!, CompareOperator.LessThan)> ByVal paramData As Single)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
    End Sub


    ' Properties
    <CompareFloatRule(2.0!, CompareOperator.GreaterThan, _
    ErrorMessage:="Data must be greater than 2.")> _
    <CompareFloatRule(5.0!, CompareOperator.LessThan)> _
    Public Property Data() As Single
        Get
            Return Me._data
        End Get
        Set(ByVal value As Single)
            Me._data = value
        End Set
    End Property


    ' Fields
    Private _data As Single
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(CompareFloatRuleAttributeSample).GetMethod("DoSomething").MethodHandle

End Class
