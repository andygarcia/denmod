Imports System
Imports ValidationFramework


Public Class CompareByteRuleAttributeSample

    'Methods
    Public Sub DoSomething( _
     <CompareByteRule(5, CompareOperator.LessThan)> ByVal paramData As Byte)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
    End Sub


    ' Properties
    <CompareByteRule(5, CompareOperator.LessThan)> _
    <CompareByteRule(2, CompareOperator.GreaterThan, _
    ErrorMessage:="Data must be greater than 2.")> _
    Public Property Data() As Byte
        Get
            Return Me._data
        End Get
        Set(ByVal value As Byte)
            Me._data = value
        End Set
    End Property


    ' Fields
    Private _data As Byte
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(CompareByteRuleAttributeSample).GetMethod("DoSomething").MethodHandle

End Class

