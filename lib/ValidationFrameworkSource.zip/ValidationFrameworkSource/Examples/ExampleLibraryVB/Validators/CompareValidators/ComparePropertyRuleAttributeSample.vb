Imports System
Imports ValidationFramework


Public Class ComparePropertyRuleAttributeSample

	' Properties

	Public Property StartDateTime() As DateTime
		Get
			Return Me._startDateTime
		End Get
		Set(ByVal value As DateTime)
			Me._startDateTime = value
		End Set
	End Property


	<ComparePropertyRule("StartDateTime", CompareOperator.GreaterThan)> _
 Public Property EndDateTime() As DateTime
		Get
			Return Me._endDateTime
		End Get
		Set(ByVal value As DateTime)
			Me._endDateTime = value
		End Set
	End Property


	' Fields
	Private _startDateTime As DateTime
	Private _endDateTime As DateTime
End Class

