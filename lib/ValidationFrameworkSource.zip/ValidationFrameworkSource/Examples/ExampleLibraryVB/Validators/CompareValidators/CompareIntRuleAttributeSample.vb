Imports System
Imports ValidationFramework


Public Class CompareIntRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<CompareIntRule(5, CompareOperator.LessThan)> ByVal paramData As Integer)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<CompareIntRule(2, CompareOperator.GreaterThan, _
	ErrorMessage:="Data must be greater than 2.")> _
	<CompareIntRule(5, CompareOperator.LessThan)> _
	Public Property Data() As Integer
		Get
			Return Me._data
		End Get
		Set(ByVal value As Integer)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Integer
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(CompareIntRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

