Imports System
Imports ValidationFramework

Public Class CompareDoubleRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<CompareDoubleRule(5, CompareOperator.LessThan)> ByVal paramData As Double)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<CompareDoubleRule(2, CompareOperator.GreaterThan, _
	ErrorMessage:="Data must be greater than 2.")> _
	<CompareDoubleRule(5, CompareOperator.LessThan)> _
	Public Property Data() As Double
		Get
			Return Me._data
		End Get
		Set(ByVal value As Double)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Double
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(CompareDoubleRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class
