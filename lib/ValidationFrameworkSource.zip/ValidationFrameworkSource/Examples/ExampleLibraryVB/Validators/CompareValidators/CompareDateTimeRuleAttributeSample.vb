Imports System
Imports ValidationFramework

Public Class CompareDateTimeRuleAttributeSample

    'Methods
    Public Sub DoSomething( _
     <CompareDateTimeRule( _
     "05 Jan 2006", CompareOperator.LessThan)> ByVal paramData As DateTime)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
    End Sub


    ' Properties
    <CompareDateTimeRule("01 Jan 2006", CompareOperator.GreaterThan, _
    ErrorMessage:="Data must be greater than 01 Jan 2006.")> _
    <CompareDateTimeRule("05 Jan 2006", CompareOperator.LessThan)> _
    Public Property Data() As DateTime
        Get
            Return Me._data
        End Get
        Set(ByVal value As DateTime)
            Me._data = value
        End Set
    End Property


    ' Fields
    Private _data As DateTime
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(CompareDateTimeRuleAttributeSample).GetMethod("DoSomething").MethodHandle

End Class
