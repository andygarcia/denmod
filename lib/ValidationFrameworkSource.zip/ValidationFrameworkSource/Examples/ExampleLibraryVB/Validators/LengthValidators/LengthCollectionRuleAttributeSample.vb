Imports System
Imports System.Collections.Generic
Imports ValidationFramework


Public Class LengthCollectionRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<LengthCollectionRule(5)> ByVal paramData As IList(Of Integer))
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<LengthCollectionRule(5)> _
	<LengthCollectionRule(4, Minimum:=2, _
	ExcludeDuplicatesFromCount:=True, _
 ErrorMessage:="Length of data must be at least 2 and no greater that 4.")> _
	Public Property Data() As IList(Of Integer)
		Get
			Return Me._data
		End Get
		Set(ByVal value As IList(Of Integer))
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As IList(Of Integer)
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(LengthCollectionRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

