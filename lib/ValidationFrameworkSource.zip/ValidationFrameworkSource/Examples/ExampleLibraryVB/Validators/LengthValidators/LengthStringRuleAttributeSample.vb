Imports System
Imports ValidationFramework


Public Class LengthStringRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <LengthStringRule(5)> ByVal paramData As String)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<LengthStringRule(5)> _
	<LengthStringRule(4, Minimum:=2, _
 ErrorMessage:="Length of data must be at least 2 and no greater that 4.")> _
	Public Property Data() As String
		Get
			Return Me._data
		End Get
		Set(ByVal value As String)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As String
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(LengthStringRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

