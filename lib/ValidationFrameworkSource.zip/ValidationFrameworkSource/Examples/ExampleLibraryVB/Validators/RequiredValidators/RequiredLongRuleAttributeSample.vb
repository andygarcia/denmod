Imports System
Imports ValidationFramework


Public Class RequiredLongRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredLongRule()> ByVal paramData As Long)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RequiredLongRule(InitialValue:=2, _
 ErrorMessage:="2 is an invalid value.")> _
	<RequiredLongRule()> _
	Public Property Data() As Long
		Get
			Return Me._data
		End Get
		Set(ByVal value As Long)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Long
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredLongRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

