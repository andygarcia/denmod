Imports System
Imports ValidationFramework


Public Class RequiredBoolRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredBoolRule()> ByVal paramData As Nullable(Of Boolean))
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties

  <RequiredBoolRule(ErrorMessage:="2 is an invalid value.", RuleSet:="Custom")> _
 <RequiredBoolRule()> _
 Public Property Data() As Nullable(Of Boolean)
    Get
      Return Me._data
    End Get
    Set(ByVal value As Nullable(Of Boolean))
      Me._data = value
    End Set
  End Property


	' Fields
    Private _data As Nullable(Of Boolean)
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredBoolRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

