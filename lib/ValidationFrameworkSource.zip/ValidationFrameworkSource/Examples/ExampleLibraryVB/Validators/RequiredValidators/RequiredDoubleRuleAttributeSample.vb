Imports System
Imports ValidationFramework


Public Class RequiredDoubleRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredDoubleRule()> ByVal paramData As Double)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RequiredDoubleRule()> _
	<RequiredDoubleRule(InitialValue:=2, _
 ErrorMessage:="2 is an invalid value.")> _
	Public Property Data() As Double
		Get
			Return Me._data
		End Get
		Set(ByVal value As Double)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Double
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredDoubleRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

