Imports System
Imports ValidationFramework


Public Class RequiredFloatRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredFloatRule()> ByVal paramData As Single)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RequiredFloatRule(InitialValue:=2.0!, _
 ErrorMessage:="2 is an invalid value.")> _
	<RequiredFloatRule()> _
	Public Property Data() As Single
		Get
			Return Me._data
		End Get
		Set(ByVal value As Single)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Single
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredFloatRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

