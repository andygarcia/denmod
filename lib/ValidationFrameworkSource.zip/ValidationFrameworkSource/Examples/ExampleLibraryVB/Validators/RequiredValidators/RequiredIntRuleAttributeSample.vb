Imports System
Imports ValidationFramework


Public Class RequiredIntRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
<RequiredIntRule()> ByVal paramData As Integer)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RequiredIntRule()> _
	<RequiredIntRule(InitialValue:=2, _
	ErrorMessage:="2 is an invalid value.")> _
	Public Property Data() As Integer
		Get
			Return Me._data
		End Get
		Set(ByVal value As Integer)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Integer
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredIntRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

