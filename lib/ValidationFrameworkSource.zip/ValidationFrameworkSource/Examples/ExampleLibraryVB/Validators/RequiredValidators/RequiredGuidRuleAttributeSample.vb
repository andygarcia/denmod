Imports System
Imports ValidationFramework


Public Class RequiredGuidRuleAttributeSample
	' Methods
  Public Sub DoSomething( _
  <RequiredGuidRule()> ByVal paramData As Guid)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
  End Sub


	' Properties
	<RequiredGuidRule()> _
	<RequiredGuidRule(InitialValue:="11111111-1111-1111-1111-111111111111", _
 ErrorMessage:="11111111-1111-1111-1111-111111111111 is an invalid value.")> _
	Public Property Data() As Guid
		Get
			Return Me._data
		End Get
		Set(ByVal value As Guid)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Guid
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredGuidRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

