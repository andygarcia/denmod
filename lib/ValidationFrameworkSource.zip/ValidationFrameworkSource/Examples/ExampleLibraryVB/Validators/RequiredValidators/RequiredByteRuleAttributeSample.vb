Imports System
Imports ValidationFramework


Public Class RequiredByteRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredByteRule()> ByVal paramData As Byte)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RequiredByteRule(InitialValue:=2, _
 ErrorMessage:="2 is an invalid value.")> _
	<RequiredByteRule()> _
	Public Property Data() As Byte
		Get
			Return Me._data
		End Get
		Set(ByVal value As Byte)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Byte
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredByteRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

