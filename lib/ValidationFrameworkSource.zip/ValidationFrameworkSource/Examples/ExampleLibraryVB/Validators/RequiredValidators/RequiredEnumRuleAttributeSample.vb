Imports System
Imports ValidationFramework

Public Enum Numbers
	' Fields
	One = 0
	Three = 2
	Two = 1
End Enum


Public Class RequiredEnumRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredEnumRule()> ByVal paramData As Numbers)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
  <RequiredEnumRule()> _
  <RequiredEnumRule(InitialValue:="Two", _
  ErrorMessage:="Two is an invalid value.")> _
  Public Property Data() As Numbers
    Get
      Return Me._data
    End Get
    Set(ByVal value As Numbers)
      Me._data = value
    End Set
  End Property


	' Fields
    Private _data As Numbers
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredEnumRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

