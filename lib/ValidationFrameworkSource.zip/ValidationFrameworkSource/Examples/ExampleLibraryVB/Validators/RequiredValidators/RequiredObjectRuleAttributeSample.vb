Imports System
Imports System.Xml.Serialization
Imports ValidationFramework


Public Class RequiredObjectRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredObjectRule()> ByVal paramData As Person)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
  <RequiredObjectRule()> _
  <RequiredObjectRule(InitialValue:="<person name='john' age='23'/>")> _
  Public Property Data() As Person
    Get
      Return Me._data
    End Get
    Set(ByVal value As Person)
      Me._data = value
    End Set
  End Property


	' Fields
    Private _data As Person
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredObjectRuleAttributeSample).GetMethod("DoSomething").MethodHandle

	' Nested Types
	<XmlRoot("person")> _
	Public Class Person
		' Properties
		<XmlAttribute("age")> _
		Public Property Age() As Integer
			Get
				Return Me._age
			End Get
			Set(ByVal value As Integer)
				Me._age = value
			End Set
		End Property

		<XmlAttribute("name")> _
		Public Property Name() As String
			Get
				Return Me._name
			End Get
			Set(ByVal value As String)
				Me._name = value
			End Set
		End Property


		' Fields
		Private _age As Integer
		Private _name As String
	End Class
End Class

