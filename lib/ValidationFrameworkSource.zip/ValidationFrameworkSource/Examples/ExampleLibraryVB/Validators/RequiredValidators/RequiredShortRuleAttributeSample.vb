Imports System
Imports ValidationFramework


Public Class RequiredShortRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredShortRule()> ByVal paramData As Short)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RequiredShortRule()> _
	<RequiredShortRule(InitialValue:=2, _
 ErrorMessage:="2 is an invalid value.")> _
	Public Property Data() As Short
		Get
			Return Me._data
		End Get
		Set(ByVal value As Short)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Short
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredShortRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

