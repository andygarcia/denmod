Imports System
Imports ValidationFramework


Public Class RequiredDecimalRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredDecimalRule()> ByVal paramData As Decimal)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RequiredDecimalRule(InitialValue:=2, _
 ErrorMessage:="2 is an invalid value.")> _
	<RequiredDecimalRule()> _
	Public Property Data() As Decimal
		Get
			Return Me._data
		End Get
		Set(ByVal value As Decimal)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Decimal
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredDecimalRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

