Imports System
Imports ValidationFramework


Public Class RequiredDateTimeRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <RequiredDateTimeRule()> ByVal paramData As DateTime)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RequiredDateTimeRule(InitialValue:="05 Jan 2006", _
 ErrorMessage:="05 Jan 2006 is an invalid value.")> _
	<RequiredDateTimeRule()> _
	Public Property Data() As DateTime
		Get
			Return Me._data
		End Get
		Set(ByVal value As DateTime)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As DateTime
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RequiredDateTimeRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

