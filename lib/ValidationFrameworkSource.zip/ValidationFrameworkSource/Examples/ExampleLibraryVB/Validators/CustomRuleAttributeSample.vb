Imports System
Imports ValidationFramework


Public Enum CardType
	' Fields
	Amex = 2
	MasterCard = 1
	Visa = 0
End Enum


Public Class Person
	' Methods
	Private Shared Sub CheckValidCreditCard( _
 ByVal sender As Object, ByVal e As CustomValidationEventArgs)
		Dim person As Person = DirectCast(e.TargetObjectValue, Person)
		Dim cardType As Nullable(Of CardType) = person.CardType
		Dim cardNumber As String = person.CreditCardNumber
		If Not ((Not cardNumber Is Nothing) AndAlso cardType.HasValue) Then
			e.IsValid = False
		Else
			Select Case cardType.Value
				Case ExampleLibraryVB.CardType.Visa, ExampleLibraryVB.CardType.MasterCard
					e.IsValid = (cardNumber.Length = 16)
					Return
				Case ExampleLibraryVB.CardType.Amex
					e.IsValid = (cardNumber.Length = 15)
					Return
			End Select
			Throw New ArgumentException("Invalid CardType")
		End If
	End Sub


	' Properties
	<RequiredEnumRule()> _
	Public Property CardType() As Nullable(Of CardType)
		Get
			Return Me._cardType
		End Get
		Set(ByVal value As Nullable(Of CardType))
			Me._cardType = value
		End Set
	End Property

	<CustomRule("ExampleLibraryVB.Person,ExampleLibraryVB", _
 "CheckValidCreditCard", _
 "Validate based on credit card rules.", _
 ErrorMessage:="Credit card is invalid.")> _
 Public Property CreditCardNumber() As String
		Get
			Return Me._creditCardNumber
		End Get
		Set(ByVal value As String)
			Me._creditCardNumber = value
		End Set
	End Property


	' Fields
	Private _cardType As Nullable(Of CardType)
	Private _creditCardNumber As String
End Class

