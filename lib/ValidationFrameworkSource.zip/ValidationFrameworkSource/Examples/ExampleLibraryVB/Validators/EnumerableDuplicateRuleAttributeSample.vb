Imports System
Imports System.Collections.Generic
Imports ValidationFramework


Public Class EnumerableDuplicateRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
 <EnumerableDuplicateRule()> ByVal paramData As IList(Of String))
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<EnumerableDuplicateRule()> _
	<EnumerableDuplicateRule(ErrorMessage:="No duplicates are allowed.", _
	EqualityComparerTypeName:="System.StringComparer", _
 EqualityComparerPropertyName:="InvariantCulture")> _
	Public Property Data() As IList(Of String)
		Get
			Return Me._data
		End Get
		Set(ByVal value As IList(Of String))
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As IList(Of String)
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(EnumerableDuplicateRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

