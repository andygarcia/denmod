Imports System
Imports ValidationFramework


Public Class RangeByteRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeByteRule(3, 7)> ByVal paramData As Byte)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeByteRule(3, 7)> _
	<RangeByteRule(2, 4, _
 ErrorMessage:="Data must be between 2 and 4.")> _
	Public Property Data() As Byte
		Get
			Return Me._data
		End Get
		Set(ByVal value As Byte)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Byte
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeByteRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

