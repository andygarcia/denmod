Imports System
Imports ValidationFramework


Public Class RangeDateTimeRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeDateTimeRule("07 Jan 2006", "09 Jan 2006")> ByVal paramData As DateTime)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeDateTimeRule("07 Jan 2006", "09 Jan 2006")> _
	<RangeDateTimeRule("05 Jan 2006", "08 Jan 2006", _
 ErrorMessage:="Data must be between 05 Jan 2006 and 08 Jan 2006.")> _
	Public Property Data() As DateTime
		Get
			Return Me._data
		End Get
		Set(ByVal value As DateTime)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As DateTime
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeDateTimeRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

