Imports System
Imports ValidationFramework


Public Class RangeDecimalRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeDecimalRule(3, 7)> ByVal paramData As Decimal)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeDecimalRule(2, 4, _
 ErrorMessage:="Data must be between 2 and 4.")> _
	<RangeDecimalRule(3, 7)> _
	Public Property Data() As Decimal
		Get
			Return Me._data
		End Get
		Set(ByVal value As Decimal)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Decimal
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeDecimalRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

