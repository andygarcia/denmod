Imports System
Imports ValidationFramework

Public Class RangeDoubleRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeDoubleRule(3, 7)> ByVal paramData As Double)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeDoubleRule(3, 7)> _
	<RangeDoubleRule(2, 4, _
 ErrorMessage:="Data must be between 2 and 4.")> _
	Public Property Data() As Double
		Get
			Return Me._data
		End Get
		Set(ByVal value As Double)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Double
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeDoubleRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class
