Imports System
Imports ValidationFramework


Public Class RangeLongRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeLongRule(3, 7)> ByVal paramData As Long)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeLongRule(2, 4, _
 ErrorMessage:="Data must be between 2 and 4.")> _
	<RangeLongRule(3, 7)> _
	Public Property Data() As Long
		Get
			Return Me._data
		End Get
		Set(ByVal value As Long)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Long
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeLongRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

