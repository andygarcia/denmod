Imports System
Imports ValidationFramework


Public Class RangeFloatRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeFloatRule(3.0!, 7.0!)> ByVal paramData As Single)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeFloatRule(3.0!, 7.0!)> _
	<RangeFloatRule(2.0!, 4.0!, _
 ErrorMessage:="Data must be between 2 and 4.")> _
	Public Property Data() As Single
		Get
			Return Me._data
		End Get
		Set(ByVal value As Single)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Single
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeFloatRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

