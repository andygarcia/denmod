Imports System
Imports ValidationFramework


Public Class RangeStringRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeStringRule("c", "h")> ByVal paramData As String)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeStringRule("b", "d", _
 ErrorMessage:="Data must be between b and d.")> _
	<RangeStringRule("c", "h")> _
	Public Property Data() As String
		Get
			Return Me._data
		End Get
		Set(ByVal value As String)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As String
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeStringRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

