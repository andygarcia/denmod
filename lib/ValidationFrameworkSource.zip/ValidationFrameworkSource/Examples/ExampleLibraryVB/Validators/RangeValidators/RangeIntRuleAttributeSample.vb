Imports System
Imports ValidationFramework


Public Class RangeIntRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeIntRule(3, 7)> ByVal paramData As Integer)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeIntRule(3, 7)> _
 <RangeIntRule(2, 4, ErrorMessage:="Data must be between 2 and 4.")> _
 Public Property Data() As Integer
		Get
			Return Me._data
		End Get
		Set(ByVal value As Integer)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Integer
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeIntRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

