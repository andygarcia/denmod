Imports System
Imports ValidationFramework


Public Class RangeShortRuleAttributeSample
	' Methods
	Public Sub DoSomething( _
	<RangeShortRule(3, 7)> ByVal paramData As Short)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
	End Sub


	' Properties
	<RangeShortRule(3, 7)> _
	<RangeShortRule(2, 4, _
 ErrorMessage:="Data must be between 2 and 4.")> _
	Public Property Data() As Short
		Get
			Return Me._data
		End Get
		Set(ByVal value As Short)
			Me._data = value
		End Set
	End Property


	' Fields
    Private _data As Short
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RangeShortRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

