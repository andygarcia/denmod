Imports System
Imports ValidationFramework


Public Class RegexRuleAttributeSample
	' Methods
	Public Sub SendEmail( _
 <RegexRule("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")> ByVal emailAddress As String)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, emailAddress)
	End Sub


	' Properties
	<RegexRule("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", _
 ErrorMessage:="Invalid email format.")> _
	Public Property Email() As String
		Get
			Return Me._email
		End Get
		Set(ByVal value As String)
			Me._email = value
		End Set
	End Property


	' Fields
    Private _email As String
    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(RegexRuleAttributeSample).GetMethod("DoSomething").MethodHandle
End Class

