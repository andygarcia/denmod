Imports System
Imports System.ComponentModel
Imports NUnit.Framework
Imports ValidationFramework

Public Class PersonNotifyValidatableBaseSample
    Inherits NotifyValidatableBase


    ' Fields
    Private _emailAddress As String
    Public Const EmailAddressMember As String = "EmailAddress"
    Private _firstName As String
    Public Const FirstNameMember As String = "FirstName"
    Private _lastName As String
    Public Const LastNameMember As String = "LastName"

    ' Methods
    Public Sub New()
        MyBase.New(True)
    End Sub


    ' Properties
    <RequiredStringRule(), RegexRule("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", _
    ErrorMessage:="Invalid email format."), LengthStringRule(50)> _
    Public Property EmailAddress() As String
        Get
            Return Me._emailAddress
        End Get
        Set(ByVal value As String)
            If (Not Me.EmailAddress Is value) Then
                Me._emailAddress = value
                MyBase.NotifyAndValidate(EmailAddressMember)
            End If
        End Set
    End Property

    <RequiredStringRule(), LengthStringRule(4)> _
    Public Property FirstName() As String
        Get
            Return Me._firstName
        End Get
        Set(ByVal value As String)
            If (Not Me.firstName Is value) Then
                Me._firstName = value
                MyBase.NotifyAndValidate(FirstNameMember)
            End If
        End Set
    End Property

    <LengthStringRule(50, Minimum:=2), RequiredStringRule()> _
    Public Property LastName() As String
        Get
            Return Me._lastName
        End Get
        Set(ByVal value As String)
            If (Not Me.lastName Is value) Then
                Me._lastName = value
                MyBase.NotifyAndValidate(LastNameMember)
            End If
        End Set
    End Property


End Class


<TestFixture()> _
Public Class NotifyValidatableBaseTests


    ' Fields
    Private firstNameEventFired As Boolean

    ' Methods
    Private Sub sample_PropertyChanged(ByVal sender As Object, ByVal e As _
PropertyChangedEventArgs)
        ' Check that it is the property we are interested in
        If (e.PropertyName Is PersonNotifyValidatableBaseSample.FirstNameMember) Then
            Me.firstNameEventFired = True
        End If
    End Sub

    <Test()> _
    Public Sub TestEvent()
        Dim sample As New PersonNotifyValidatableBaseSample

        ' Attach to PropertyChanged so we are notified 
        AddHandler sample.PropertyChanged, New PropertyChangedEventHandler(AddressOf _
        Me.sample_PropertyChanged)

        ' Set FirstName and hence firing the event
        sample.FirstName = "John"

        ' Since the event has fired the firstNameEventFired flag will be true;
        Assert.IsTrue(Me.firstNameEventFired)
    End Sub

    <Test()> _
    Public Sub TestIsValid()
        Dim sample As New PersonNotifyValidatableBaseSample

        ' Initially not valid
        Assert.IsFalse(sample.IsValid)

        ' Set FirstName, LastName and EmailAddress
        sample.FirstName = "John"
        sample.LastName = "Smith"
        sample.EmailAddress = "John.Smith@email.com"

        ' It is now valid
        Assert.IsTrue(sample.IsValid)
    End Sub

    <Test()> _
    Public Sub TestSpecificProperty()
        Dim sample As New PersonNotifyValidatableBaseSample

        ' LastName initially has an ErrorMessage because it is invalid
        Dim lastNameErrorMessage As String = _
        sample.Item(PersonNotifyValidatableBaseSample.LastNameMember)
        Assert.IsNotNull(lastNameErrorMessage)

        ' Set LastName and it will then have no ErrorMessage
        sample.LastName = "Smith"
        ' No need to call IsValid (to force a validation) because properties are validated
        ' during each set
        lastNameErrorMessage = _
        sample.Item(PersonNotifyValidatableBaseSample.LastNameMember)
        Assert.IsEmpty(lastNameErrorMessage)
    End Sub

    <Test()> _
    Public Sub TestValidatorResultsInError()
        Dim sample As New PersonNotifyValidatableBaseSample
        ' Initially there should be 3 items in ValidatorResultsInError as only 3
        ' properties have required rules.
        Assert.AreEqual(3, sample.ValidatorResultsInError.Count)

        ' Set LastName to a value and count goes down to 2
        sample.LastName = "Smith"
        ' No need to call IsValid (to force a validation) because properties are 
        ' validated during each set
        Assert.AreEqual(2, sample.ValidatorResultsInError.Count)
    End Sub


End Class


