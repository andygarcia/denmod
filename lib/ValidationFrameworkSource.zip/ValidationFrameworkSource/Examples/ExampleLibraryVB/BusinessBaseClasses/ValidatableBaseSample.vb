Imports System
Imports NUnit.Framework
Imports ValidationFramework

Public Class PersonValidatableBaseExample
    Inherits ValidatableBase

    ' Fields
    Private _emailAddress As String
    Public Const EmailAddressMember As String = "EmailAddress"
    Private _firstName As String
    Public Const FirstNameMember As String = "FirstName"
    Private _lastName As String
    Public Const LastNameMember As String = "LastName"


    ' Methods
    Public Sub New()
        MyBase.New(True)
    End Sub


    ' Properties
    <RegexRule("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", _
    ErrorMessage:="Invalid email format."), _
    RequiredStringRule(), _
    LengthStringRule(50)> _
    Public Property EmailAddress() As String
        Get
            Return Me._emailAddress
        End Get
        Set(ByVal value As String)
            Me._emailAddress = value
        End Set
    End Property

    <LengthStringRule(4), _
    RequiredStringRule()> _
    Public Property FirstName() As String
        Get
            Return Me._firstName
        End Get
        Set(ByVal value As String)
            Me._firstName = value
        End Set
    End Property

    <LengthStringRule(50, Minimum:=2), _
    RequiredStringRule()> _
    Public Property LastName() As String
        Get
            Return Me._lastName
        End Get
        Set(ByVal value As String)
            Me._lastName = value
        End Set
    End Property


End Class


<TestFixture()> _
Public Class ValidatableBaseTest
    ' Methods
    <Test()> _
    Public Sub TestIsValid()
        Dim sample As New PersonValidatableBaseExample

        ' Initially not valid
        Assert.IsFalse(sample.IsValid)

        ' Set FirstName, LastName and EmailAddress
        sample.FirstName = "John"
        sample.LastName = "Smith"
        sample.EmailAddress = "John.Smith@email.com"

        ' It is now valid
        Assert.IsTrue(sample.IsValid)
    End Sub

    <Test()> _
    Public Sub TestValidatorResultsInError()
        Dim sample As New PersonValidatableBaseExample
        ' Initially there should be 3 items in ValidatorResultsInError as only 3 
        ' properties have required rules.
        Assert.AreEqual(3, sample.ValidatorResultsInError.Count)

        ' Set LastName to a value and count goes down to 2
        sample.LastName = "Smith"

        ' Since IsValid has not been called the count will not have changed
        Assert.AreEqual(3, sample.ValidatorResultsInError.Count)
        Assert.IsFalse(sample.IsValid)
        ' Since IsValid has now been called the count will have changed
        Assert.AreEqual(2, sample.ValidatorResultsInError.Count)
    End Sub

End Class




