Imports System
Imports NUnit.Framework
Imports ValidationFramework

Public Class PersonDataErrorInfoValidatableBaseSample
    Inherits DataErrorInfoValidatableBase


    ' Define run-time constants here so UI code has compile-time
    ' checks against misspellings in data binding expressions.
    Private _emailAddress As String
    Public Const EmailAddressMember As String = "EmailAddress"
    Private _firstName As String
    Public Const FirstNameMember As String = "FirstName"
    Private _lastName As String
    Public Const LastNameMember As String = "LastName"


    Public Sub New()
        MyBase.New(True)
    End Sub


    ' Properties
    <RegexRule("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", _
    ErrorMessage:="Invalid email format."), _
    RequiredStringRule(), _
    LengthStringRule(50)> _
    Public Property EmailAddress() As String
        Get
            Return Me._emailAddress
        End Get
        Set(ByVal value As String)
            If (Not Me.EmailAddress Is value) Then
                Me._emailAddress = value
                MyBase.ValidateProperty(EmailAddressMember)
            End If
        End Set
    End Property

    <LengthStringRule(4), _
    RequiredStringRule()> _
    Public Property FirstName() As String
        Get
            Return Me._firstName
        End Get
        Set(ByVal value As String)
            If (Not Me.FirstName Is value) Then
                Me._firstName = value
                MyBase.ValidateProperty(FirstNameMember)
            End If
        End Set
    End Property

    <RequiredStringRule(), _
    LengthStringRule(50, Minimum:=2)> _
    Public Property LastName() As String
        Get
            Return Me._lastName
        End Get
        Set(ByVal value As String)
            If (Not Me.LastName Is value) Then
                Me._lastName = value
                MyBase.ValidateProperty(LastNameMember)
            End If
        End Set
    End Property


End Class


<TestFixture()> _
Public Class DataErrorInfoValidatableBaseTest
    ' Methods
    <Test()> _
    Public Sub TestIsValid()
        Dim sample As New PersonDataErrorInfoValidatableBaseSample

        ' Initially not valid
        Assert.IsFalse(sample.IsValid)

        ' Set FirstName, LastName and EmailAddress
        sample.FirstName = "John"
        sample.LastName = "Smith"
        sample.EmailAddress = "John.Smith@email.com"

        ' It is now valid
        Assert.IsTrue(sample.IsValid)
    End Sub

    <Test()> _
    Public Sub TestSpecificProperty()
        Dim sample As New PersonDataErrorInfoValidatableBaseSample

        ' LastName initially has an ErrorMessage because it is invalid
        Dim lastNameErrorMessage As String = _
        sample.Item(PersonDataErrorInfoValidatableBaseSample.LastNameMember)
        Assert.IsNotNull(lastNameErrorMessage)

        ' Set LastName and it will then have no ErrorMessage
        sample.LastName = "Smith"
        ' No need to call IsValid (to force a validation) because properties are validated
        ' during each set
        lastNameErrorMessage = sample.Item("LastName")
        Assert.IsEmpty(lastNameErrorMessage)
    End Sub

    <Test()> _
    Public Sub TestValidatorResultsInError()
        Dim sample As New PersonDataErrorInfoValidatableBaseSample
        ' Initially there should be 3 items in ValidatorResultsInError as only 3 
        ' properties have required rules.
        Assert.AreEqual(3, sample.ValidatorResultsInError.Count)

        ' Set LastName to a value and count goes down to 2
        sample.LastName = "Smith"
        ' No need to call IsValid (to force a validation) because properties are validated 
        'during each set
        Assert.AreEqual(2, sample.ValidatorResultsInError.Count)
    End Sub

End Class





