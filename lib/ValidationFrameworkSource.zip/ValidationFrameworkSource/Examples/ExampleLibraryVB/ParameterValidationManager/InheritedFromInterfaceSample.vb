Imports NUnit.Framework
Imports ValidationFramework

Public Interface IInheritedFromInterfaceSample
    Sub DoSomething(<CompareByteRule(5, CompareOperator.LessThan)> ByVal paramData As Byte)
End Interface


Public Class InheritedFromInterfaceSample
    Implements IInheritedFromInterfaceSample

    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
GetType(IInheritedFromInterfaceSample).GetMethod("DoSomething").MethodHandle

    Public Sub DoSomething(ByVal paramData As Byte) _
    Implements IInheritedFromInterfaceSample.DoSomething
        ParameterValidationManager.ThrowException(Me, _
        InheritedFromInterfaceSample.doSomethingHandle, New Object() {paramData})
    End Sub

    
End Class


<TestFixture()> _
Public Class ParameterValidationManagerInheritedFromInterfaceTests

    <Test(), ExpectedException(GetType(ArgumentException))> _
    Public Sub TestInvalidData()
        Dim sample As IInheritedFromInterfaceSample = New InheritedFromInterfaceSample
        sample.DoSomething(7)
    End Sub

    <Test()> _
    Public Sub TestValidData()
        Dim sample As IInheritedFromInterfaceSample = New InheritedFromInterfaceSample
        sample.DoSomething(2)
    End Sub

End Class




