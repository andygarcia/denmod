Imports System
Imports NUnit.Framework
Imports ValidationFramework


Public Class ParameterValidationManagerSample
	' Methods
    Public Sub DoSomething( _
<CompareByteRule(5, CompareOperator.LessThan)> ByVal paramData As Byte)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
        '' business code goes here.
    End Sub


    Private Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
    GetType(ParameterValidationManagerSample).GetMethod("DoSomething").MethodHandle

End Class

<TestFixture()> _
Public Class ParameterValidationManagerTests
    <ExpectedException(GetType(ArgumentException)), Test()> _
    Public Sub TestInvalidData()

        Dim parameterValidationManagerSample As New ParameterValidationManagerSample()
        parameterValidationManagerSample.DoSomething(7)
    End Sub

    <Test()> _
    Public Sub TestValidData()
        Dim parameterValidationManagerSample As New ParameterValidationManagerSample()
        parameterValidationManagerSample.DoSomething(2)
    End Sub

End Class




