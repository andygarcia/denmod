Imports System
Imports ValidationFramework


Public Class ParameterValidationManagerSampleWithHandle
	' Methods
	Public Sub DoSomething( _
	 <CompareByteRule(5, CompareOperator.LessThan)> ByVal paramData As Byte)
        ParameterValidationManager.ThrowException(Me, doSomethingHandle, paramData)
		'' business code goes here.
	End Sub


	' Fields
    Public Shared ReadOnly doSomethingHandle As RuntimeMethodHandle = _
 GetType(ParameterValidationManagerSampleWithHandle).GetMethod("DoSomething").MethodHandle
End Class

