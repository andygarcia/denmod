Imports System
Imports System.Collections.Generic
Imports NUnit.Framework
Imports ValidationFramework



Namespace ExampleLibraryVBFieldValidationManager
	Public Class CustomClass
		
		<RequiredIntRule()> _
		Public data As Integer
		Private fieldValidationManager As FieldValidationManager

		''' <summary>
		''' Initializes a new instance of the <see cref="CustomClass"/> 
		''' class.
		''' </summary>
		Public Sub New()
			Me.fieldValidationManager = New FieldValidationManager(Me)
		End Sub

		''' <summary>
		''' Gets a <see lanword="bool"/> indicating if the current state is valid.
		''' </summary>
		Public Function Validate() As Boolean
			Me.fieldValidationManager.ValidateAllFields()
			Return Me.fieldValidationManager.IsValid
		End Function



		''' <summary>
		''' Gets a <see see="ICollection"/> of <see langword="string"/>s that contain all 
		''' the <see cref="ValidationResult.ErrorMessage"/>s for all the 
		''' <see cref="ValidationResult"/>s in <see cref="ValidatorResultsInError"/>.
		''' </summary>
		Public Overridable ReadOnly Property ErrorMessages() As IList(Of String)
			Get
				Return ResultFormatter.GetErrorMessages( _
				Me.fieldValidationManager.ValidatorResultsInError)
			End Get
		End Property

		''' <summary>
		''' Gets <see cref="IList(Of T)"/> containing all <see cref="ValidationResult"/> for 
		''' <see cref="Rule"/>s that have failed validation.
		''' </summary>
		Public Overridable ReadOnly Property ValidatorResultsInError() _
		As IList(Of ValidationResult)
			Get
				Return Me.fieldValidationManager.ValidatorResultsInError
			End Get
		End Property


	End Class


	<TestFixture()> _
	Public Class CustomClassTests
		' Methods
		<Test()> _
		Public Sub TestIsValid()
			Dim sample As New CustomClass

			' Initially not valid
			Assert.IsFalse(sample.Validate)

			' Set Data
			sample.data = 10

			' It is now valid
			Assert.IsTrue(sample.Validate)
		End Sub

		<Test()> _
		Public Sub TestValidatorResultsInError()
			Dim sample As New CustomClass
			Assert.IsFalse(sample.Validate)
			' Initially there will be 1 item in ValidatorResultsInError.
			Assert.AreEqual(1, sample.ValidatorResultsInError.Count)

			' Set Data
			sample.data = 10

			' Since Validate has not been called the count will not have changed
			Assert.AreEqual(1, sample.ValidatorResultsInError.Count)
			Assert.IsTrue(sample.Validate)
			' Since Validate has now been called the count will have changed
			Assert.AreEqual(0, sample.ValidatorResultsInError.Count)
		End Sub

	End Class


End Namespace