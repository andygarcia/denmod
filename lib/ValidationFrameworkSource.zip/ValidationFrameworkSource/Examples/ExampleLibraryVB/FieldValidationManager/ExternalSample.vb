Imports NUnit.Framework
Imports ValidationFramework


Namespace ExampleLibraryVBFieldValidationManager
	Public Class ClassToValidate

		' Fields
		<RequiredIntRule()> _
		Public data As Integer
	End Class



	<TestFixture()> _
	Public Class ExternalTests
		' Methods
		<Test()> _
		Public Sub Run()
			Dim classToValidate As New ClassToValidate
			Dim fieldValidationManager As New FieldValidationManager(classToValidate)
			'Could have called fieldValidationManager.Validate() here to validate all 
			' fields
			fieldValidationManager.ValidateField("data")
			Assert.IsFalse(fieldValidationManager.IsValid)
			classToValidate.data = 99
			' Could have called fieldValidationManager.Validate() here to validate all 
			' fields
			fieldValidationManager.ValidateField("data")
			Assert.IsTrue(fieldValidationManager.IsValid)
		End Sub

	End Class
End Namespace



