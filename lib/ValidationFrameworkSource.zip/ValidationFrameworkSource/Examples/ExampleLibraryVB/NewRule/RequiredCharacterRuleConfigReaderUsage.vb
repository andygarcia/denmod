Imports ValidationFramework.Configuration
Imports ValidationFramework
Imports NUnit.Framework

<TestFixture()> _
Public Class RequiredCharacterRuleConfigReaderUsage


    Public Class Dinosaur

        Private _name As String

        Public Property Name() As String
            Get
                Return _name
            End Get
            Set(ByVal value As String)
                _name = value
            End Set
        End Property

    End Class



    Private ReadOnly propertyXmlString As String = "<?xml version='1.0' encoding='utf-8' ?>" & _
    "<validationMapping xmlns='urn:validationFramework-validationDefinition-1.5'>" & _
    "  <class typeName='ExampleLibraryVB.RequiredCharacterRuleConfigReaderUsage+Dinosaur, ExampleLibraryVB'>" & _
    "    <property name='Name'>" & _
    "      <rule typeName='ExampleLibraryVB.RequiredCharacterRuleConfigReader, ExampleLibraryVB' requiredCharacter='s'/>" & _
    "    </property>" & _
    "  </class>" & _
    "</validationMapping>"

    <Test()> _
    Public Sub Test()

        Dim dinosaur As New Dinosaur
        Dim s As String
        s = dinosaur.GetType().FullName
        ConfigurationService.AddXmlString(Me.propertyXmlString)
        Dim propertyValidationManager As New PropertyValidationManager(dinosaur)

        propertyValidationManager.ValidateProperty("Name")
        ' Valid dinosaur.Name is Null
        Assert.IsTrue(propertyValidationManager.IsValid)

        dinosaur.Name = "Frog"
        propertyValidationManager.ValidateProperty("Name")
        ' Invalid because dinosaur.Name does not contain 's'
        Assert.IsFalse(propertyValidationManager.IsValid)

        dinosaur.Name = "Allosaurus"
        propertyValidationManager.ValidateProperty("Name")
        ' Valid because dinosaur.Name does contain 's'
        Assert.IsTrue(propertyValidationManager.IsValid)
    End Sub

End Class


