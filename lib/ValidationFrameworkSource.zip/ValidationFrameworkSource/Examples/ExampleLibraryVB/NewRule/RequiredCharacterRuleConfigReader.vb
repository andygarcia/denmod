Imports System
Imports ValidationFramework
Imports ValidationFramework.Configuration

Public Class RequiredCharacterRuleConfigReader
	Implements IRuleConfigReader

	''' <summary>
	''' Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
	''' </summary>
	''' <param name="ruleData">The <see cref="RuleData"/> that represent the xml to 
	''' create the <see cref="Rule"/> for.</param>
	''' <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> 
	''' for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
	''' <returns>A <see cref="Rule"/> that <paramref name="ruleData"/> represented</returns>
    Public Function ReadConfig(ByVal ruleData As RuleData, _
    ByVal runtimeTypeHandle As RuntimeTypeHandle) As Rule _
    Implements IRuleConfigReader.ReadConfig

        If (ruleData Is Nothing) Then
            Throw New ArgumentNullException("ruleData")
        End If
        Dim attributesAsDictionary As IDictionary(Of String, String) = _
        ruleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes)
        Dim toChar As Char = Convert.ToChar(attributesAsDictionary.Item("requiredCharacter"))
        Return New RequiredCharacterRule(ruleData.ErrorMessage, ruleData.RuleSet, _
        ruleData.UseErrorMessageProvider, toChar)
    End Function

End Class

