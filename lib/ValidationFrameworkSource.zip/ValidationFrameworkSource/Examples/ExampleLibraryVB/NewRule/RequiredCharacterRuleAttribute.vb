Imports System
Imports ValidationFramework
Imports ValidationFramework.Reflection

Public Class RequiredCharacterRuleAttribute
	Inherits RuleAttribute
  Implements IParameterRuleAttribute, _
  IPropertyRuleAttribute, _
  IFieldRuleAttribute, _
  IRuleAttribute
	' Methods
	''' <summary>
	''' Initializes a new instance of the <see cref="RequiredCharacterRuleAttribute"/>.
	''' </summary>
	''' <param name="requiredCharacter">The required character.</param>
	Public Sub New(ByVal requiredCharacter As Char)
		Me._requiredCharacter = requiredCharacter
	End Sub

	''' <summary>
	''' Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
	''' </summary>
    Public Function CreateParameterRule(ByVal parameterDescriptor As ParameterDescriptor) _
 As Rule Implements IParameterRuleAttribute.CreateParameterRule
        Return Me.CreateRule
  End Function

  ''' <summary>
  ''' Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
  ''' </summary>
  Public Function CreatePropertyRule(ByVal propertyDescriptor As PropertyDescriptor) _
  As Rule Implements IPropertyRuleAttribute.CreatePropertyRule
    Return Me.CreateRule
  End Function

  ''' <summary>
  ''' Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
  ''' </summary>
  Public Function CreatePropertyRule(ByVal fieldDescriptor As FieldDescriptor) _
  As Rule Implements IFieldRuleAttribute.CreateFieldRule
    Return Me.CreateRule
  End Function

    Private Function CreateRule() As RequiredCharacterRule
        Return New RequiredCharacterRule(MyBase.ErrorMessage, MyBase.RuleSet, _
        MyBase.UseErrorMessageProvider, Me._requiredCharacter)
    End Function


    ' Properties
    ''' <summary>
    ''' Gets the required character.
    ''' </summary>
    Public ReadOnly Property RequiredCharacter() As Char
        Get
            Return Me._requiredCharacter
        End Get
    End Property


    ' Fields
    Private ReadOnly _requiredCharacter As Char
End Class
