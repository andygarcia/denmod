Imports System
Imports System.Web
Imports System.Collections.Generic
Imports ValidationFramework
Imports ValidationFramework.Reflection
Imports System.Web.UI.WebControls
Imports ValidationFramework.Web


Public Class RequiredCharacterRule
	Inherits Rule
	Implements ISupportWebClientValidation
	' Methods

  
	''' <summary>
	''' Initialize a new instance of the <see cref="RequiredCharacterRule"/> class.
	''' </summary>
	''' <param name="errorMessage">The custom error message to use. Pass a null to 
	''' use the default value.</param>
	''' <param name="requiredCharacter">The invalid character.</param>
	''' <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s.
	'''  Use a null to indicate no grouping.</param>
    Public Sub New(ByVal errorMessage As String, ByVal ruleSet As String, _
    ByVal useErrorMessageProvider As Boolean, ByVal requiredCharacter As Char)
        MyBase.New(RequiredCharacterRule._runtimeTypeHandle, errorMessage, ruleSet, _
        useErrorMessageProvider)
        Me._requiredCharacter = requiredCharacter
    End Sub

	''' <summary>
	''' Get a list of <see cref="BaseValidator"/>s to perform the client side validation.
	''' </summary>
	''' <remarks>The <see cref="BaseValidator"/>s returned should only perform client 
	''' validation.</remarks>
	''' <returns>The<see cref="IList(OF T)"/> of <see cref="BaseValidator"/>s to perform 
	''' the client side validation.</returns>
    Public Function CreateWebClientValidators() As IList(Of BaseValidator) _
    Implements ISupportWebClientValidation.CreateWebClientValidators
        Dim webValidator As New ClientRegularExpressionWebValidator
        webValidator.ValidationExpression = String.Format(".*[{0}].*", _
        Me.RequiredCharacter)
        Return New BaseValidator() {webValidator}
    End Function

	''' <summary>
	''' Called after <see cref="Rule.InfoDescriptor"/> is set but only when 
	''' <see cref="Rule.ErrorMessage"/> is null.
	''' </summary>
	''' <returns>The error message for the <see cref="Rule"/>.</returns>
	''' <param name="tokenizedMemberName">A user friendly representation of the 
  ''' member name.</param>
  ''' <param name="descriptorType">
  ''' If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
  ''' If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
  ''' </param>
  Protected Overrides Function GetComputedErrorMessage(ByVal tokenizedMemberName As _
  String, ByVal descriptorType As _
    String) As String
    Return String.Format("The {0} '{1}' must contain the character '{2}'", _
    descriptorType, tokenizedMemberName, Me.RequiredCharacter)
  End Function


	''' <summary>
    ''' Checks if the current <see cref="Rule"/> is equivalent to another 
    ''' <see cref="Rule"/>.
	''' </summary>
	''' <remarks>
	''' Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new 
	''' <see cref="Rule"/> is added. This method is only called when both the existing 
    ''' <see cref="Rule"/> and the <see cref="Rule"/> being are of the same 
    ''' <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe to 
    ''' directly cast <paramref name="rule"/> to the current type. All properties in 
    ''' <paramref name="rule"/> should be compared to the propeties of the current 
    ''' <see cref="Rule"/>.
    ''' </remarks>
	''' <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
	''' <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to the 
	''' current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
	Public Overrides Function IsEquivalent(ByVal rule As Rule) As Boolean
        Dim requiredCharacterRule As RequiredCharacterRule = DirectCast(rule, _
        RequiredCharacterRule)
		Return (Me.RequiredCharacter = requiredCharacterRule.RequiredCharacter)
	End Function

	''' <summary>
	''' Validate the member this <see cref="Rule"/> is applied to.
	''' </summary>
	''' <param name="targetObjectValue">The value of the object containing the member to 
	''' validate.</param>
	''' <param name="context">An <see cref="object"/> that contains data for the 
	''' <see cref="Rule"/> to validate. The default is null.</param>
	''' <param name="targetMemberValue">The value of the member to validate.</param>
    Public Overrides Function Validate(ByVal targetObjectValue As Object, ByVal _
    targetMemberValue As Object, ByVal context As Object) As ValidationResult
        If (Not targetMemberValue Is Nothing) Then
            Dim valueAsString As String = CStr(targetMemberValue)
            If (valueAsString.IndexOf(Me.RequiredCharacter) = -1) Then
                Return New ValidationResult(Me, MyBase.ErrorMessage)
            End If
        End If
        Return Nothing
    End Function


	' Properties
	''' <summary>
	''' Gets the required character.
	''' </summary>
	Public ReadOnly Property RequiredCharacter() As Char
		Get
			Return Me._requiredCharacter
		End Get
	End Property

	''' <summary>
    ''' Gets a <see cref="string"/> that is a business interpretation of the 
    ''' <see cref="Rule"/>.
	''' </summary>
	Public Overrides ReadOnly Property RuleInterpretation() As String
		Get
            Return String.Format("The value must contain the character '{0}'", _
            Me.RequiredCharacter)
		End Get
	End Property


	' Fields
	Private ReadOnly _requiredCharacter As Char

	'' RequiredCharacterRule can only be applied to strings. So pass the 
	'' <see cref="RuntimeTypeHandle"/> for string to the base constructor.
	Private Shared _runtimeTypeHandle As RuntimeTypeHandle = GetType(String).TypeHandle
End Class
