Imports System
Imports System.Web.UI.WebControls


  
''' <summary>
''' Provides control capability to validate, on the client side, that another
''' control's value matches a provided regular expression. 
''' </summary>
Friend Class ClientRegularExpressionWebValidator
	Inherits RegularExpressionValidator
	' Methods

	''' <summary>
	''' Overrides <see cref="RegularExpressionValidator.EvaluateIsValid"/> to 
	''' always return <see langword="true"/>.
	''' </summary>
	''' <returns><see langword="true"/></returns>
	''' <remarks></remarks>
	Protected Overrides Function EvaluateIsValid() As Boolean
		Return True
	End Function

End Class

