Imports NUnit.Framework
Imports ValidationFramework
<TestFixture()> _
Public Class RequiredCharacterRuleAttributeUsage

    Public Class Dinosaur
        Private _name As String

        <RequiredCharacterRule("s"c)> _
        Public Property Name() As String
            Get
                Return _name
            End Get
            Set(ByVal value As String)
                _name = value
            End Set
        End Property

    End Class

    <Test()> _
    Public Sub Test()
        Dim dinosaur As New Dinosaur
        Dim propertyValidationManager As New PropertyValidationManager(dinosaur)

        propertyValidationManager.ValidateProperty("Name")
        Assert.IsTrue(propertyValidationManager.IsValid)

        dinosaur.Name = "Frog"
        propertyValidationManager.ValidateProperty("Name")
        ' Invalid because dinosaur.Name does not contain an 's'
        Assert.IsFalse(propertyValidationManager.IsValid)

        dinosaur.Name = "Allosaurus"
        propertyValidationManager.ValidateProperty("Name")
        ' Valid because dinosaur.Name does contain an 's'
        Assert.IsTrue(propertyValidationManager.IsValid)
    End Sub
End Class


