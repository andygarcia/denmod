Imports System
Imports NUnit.Framework
Imports ValidationFramework
Imports ValidationFramework.Configuration
Imports ValidationFramework.Reflection


<TestFixture()> _
Public Class ConfigurationServiceSample


    <Test()> _
 Public Sub Test()
        ConfigurationService.AddAssembly(GetType(ConfigurationServiceSample).Assembly)
        Dim type As Type = GetType(Person)
        Dim typeDescriptor As TypeDescriptor = TypeCache.GetType(type.TypeHandle)
        Assert.AreEqual(1, typeDescriptor.Properties.Item("Age").Rules.Count)
        Dim methodHandle As RuntimeMethodHandle = type.GetMethod("SetTheAge").MethodHandle
        Dim methodDescriptor As MethodDescriptor = MethodCache.GetMethod(methodHandle)
        Assert.AreEqual(1, methodDescriptor.Parameters.Item("age").Rules.Count)
    End Sub


    ' Nested Types
    Public Class Person
        ' Methods
        Public Sub SetTheAge(ByVal age As Integer)
            ParameterValidationManager.ThrowException(Me, setTheAgeHandle, age)
            Me.Age = age
        End Sub


        ' Properties
        Public Property Age() As Integer
            Get
                Return Me._age
            End Get
            Set(ByVal value As Integer)
                Me._age = value
            End Set
        End Property

        Public Property Name() As String
            Get
                Return Me._name
            End Get
            Set(ByVal value As String)
                Me._name = value
            End Set
        End Property


        ' Fields
        Private _age As Integer
        Private _name As String
        Private Shared ReadOnly setTheAgeHandle As RuntimeMethodHandle = _
        GetType(Person).GetMethod("SetTheAge").MethodHandle
    End Class
End Class

