Imports System
Imports NUnit.Framework
Imports ValidationFramework
Imports ValidationFramework.Configuration

Friend Class CustomRuleConfigReaderSampleData
	' Methods
    Private Shared Sub ValidateFoo(ByVal sender As Object, ByVal e As _
    CustomValidationEventArgs)
        Dim foo As String = CStr(e.TargetMemberValue)
        If String.IsNullOrEmpty(foo) Then
            e.IsValid = False
        Else
            e.IsValid = True
        End If
    End Sub


	' Properties
	Public Property Foo() As String
		Get
			Return Me._foo
		End Get
		Set(ByVal value As String)
			Me._foo = value
		End Set
	End Property


	' Fields
	Private _foo As String
End Class


<TestFixture()> _
Public Class CustomRuleConfigReaderTests

    <Test()> _
    Public Sub TestCustomRuleConfigReader()
        ConfigurationService.AddXmlString(CustomRuleConfigReaderTests.propertyXmlString)
        Dim data As New CustomRuleConfigReaderSampleData
        Dim propertyValidationManager As New PropertyValidationManager(data)
        propertyValidationManager.ValidateAllProperties()
        Assert.IsFalse(propertyValidationManager.IsValid)
        data.Foo = "sdfsdf"
        propertyValidationManager.ValidateAllProperties()
        Assert.IsTrue(propertyValidationManager.IsValid)
    End Sub


    ' Fields
    Private Shared propertyXmlString As String = "<?xml version='1.0' encoding='utf-8' ?>" & _
    "<validationMapping xmlns='urn:validationFramework-validationDefinition-1.5'>" & _
    "  <class typeName='ExampleLibraryVB.CustomRuleConfigReaderSampleData, ExampleLibraryVB'>" & _
    "    <property name='Foo'>" & _
    "      <rule typeName='CustomRule' " & _
    "            ruleInterpretation='This is a custom rule' " & _
    "            validationMethod='ValidateFoo' " & _
    "            validationTypeName='ExampleLibraryVB.CustomRuleConfigReaderSampleData, ExampleLibraryVB' " & _
    "            errorMessage='hello' />" & _
    "    </property>" & _
    "  </class>" & _
    "</validationMapping>"
End Class


