Imports System
Imports ValidationFramework
Imports ValidationFramework.Configuration

Friend Class CustomRuleConfigReaderSampleData
	' Methods
	Private Shared Sub ValidateFoo(ByVal sender As Object, ByVal e As CustomValidationEventArgs)
		Dim foo As String = CStr(e.TargetMemberValue)
		If String.IsNullOrEmpty(foo) Then
			e.IsValid = False
		Else
			e.IsValid = True
		End If
	End Sub


	' Properties
	Public Property Foo() As String
		Get
			Return Me._foo
		End Get
		Set(ByVal value As String)
			Me._foo = value
		End Set
	End Property


	' Fields
	Private _foo As String
End Class


Public Class CustomRuleConfigReaderSampleProgram
	' Methods
	Private Shared Sub Main()
		ConfigurationService.AddXmlString(CustomRuleConfigReaderSampleProgram.propertyXmlString)
		Dim data As New CustomRuleConfigReaderSampleData
		Dim propertyValidationManager As New PropertyValidationManager(data)
		propertyValidationManager.Validate()
		Debug.WriteLine(propertyValidationManager.IsValid)
		data.Foo = "sdfsdf"
		propertyValidationManager.Validate()
		Debug.WriteLine(propertyValidationManager.IsValid)
	End Sub


	' Fields
	Private Shared propertyXmlString As String = "<?xml version='1.0' encoding='utf-8' ?>" & _
	"<validationMapping xmlns='urn:validationFramework-validationDefinition-1.5'>" & _
	"  <class typeName='ExampleLibraryVB.CustomRuleConfigReaderSampleData, SamplesLibrary'>" & _
	"    <property name='Foo'>" & _
	"      <rule typeName='CustomRuleConfigReader' " & _
	"            ruleInterpretation='This is a custom rule' " & _
	"            validationMethod='ValidateFoo' " & _
	"            validationTypeName='ExampleLibraryVB.CustomRuleConfigReaderSampleData, SamplesLibrary' " & _
	"            errorMessage='hello' />" & _
	"    </property>" & _
	"  </class>" & _
	"</validationMapping>"
End Class


