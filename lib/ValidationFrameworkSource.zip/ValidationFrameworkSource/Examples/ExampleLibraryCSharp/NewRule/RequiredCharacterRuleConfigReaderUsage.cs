using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Configuration;

namespace ExampleLibraryCSharp
{
    [TestFixture]
    public class RequiredCharacterRuleConfigReaderUsage
    {

        public class Dinosaur
        {
            public string Name
            {
                get;
                set;
            }
        }



       readonly string propertyXmlString = @"<?xml version='1.0' encoding='utf-8' ?>
<validationMapping xmlns='urn:validationFramework-validationDefinition-1.5'>
  <class 
    typeName='ExampleLibraryCSharp.RequiredCharacterRuleConfigReaderUsage+Dinosaur, ExampleLibraryCSharp'>
    <property name='Name'>
      <rule 
        typeName='ExampleLibraryCSharp.RequiredCharacterRuleConfigReader, ExampleLibraryCSharp' requiredCharacter='s'/>
    </property>
  </class>
</validationMapping>";

        [Test]
        public void Test()
        {

            Dinosaur dinosaur = new Dinosaur();
            ConfigurationService.AddXmlString(propertyXmlString);
            PropertyValidationManager propertyValidationManager =
              new PropertyValidationManager(dinosaur);

            propertyValidationManager.ValidateProperty("Name");
            // Valid dinosaur.Name is Null
            Assert.IsTrue(propertyValidationManager.IsValid);

            dinosaur.Name = "Frog";
            propertyValidationManager.ValidateProperty("Name");
            // Invalid because dinosaur.Name does not contain 's'
            Assert.IsFalse(propertyValidationManager.IsValid);

            dinosaur.Name = "Allosaurus";
            propertyValidationManager.ValidateProperty("Name");
            // Valid because dinosaur.Name does contain 's'
            Assert.IsTrue(propertyValidationManager.IsValid);
        }
    }
}
