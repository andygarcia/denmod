using System.Web.UI.WebControls;

namespace ExampleLibraryCSharp
{
    /// <summary>
    /// Provides control capability to validate, on the client side, that another
    ///  control's value matches a provided regular expression. 
    /// </summary>
    internal class ClientRegularExpressionWebValidator : RegularExpressionValidator
    {
        #region Methods

        /// <summary>
        /// Overrides <see cref="RegularExpressionValidator.EvaluateIsValid"/> to 
        /// always return <see langword="true"/>.
        /// </summary>
        /// <returns><see langword="true"/></returns>
        protected override bool EvaluateIsValid()
        {
            return true;
        }

        #endregion
    }
}