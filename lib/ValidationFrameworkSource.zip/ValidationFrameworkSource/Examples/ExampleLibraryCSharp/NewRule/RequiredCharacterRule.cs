using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using ValidationFramework;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;
using ValidationFramework.Web;

namespace ExampleLibraryCSharp
{
    public class RequiredCharacterRule : Rule, ISupportWebClientValidation
    {
        #region Fields

        // RequiredCharacterRule can only be applied to strings. So pass the 
        // <see cref="RuntimeTypeHandle"/> for string to the base constructor.
        private static RuntimeTypeHandle runtimeTypeHandle = typeof(string).TypeHandle;
        //the required character
        private readonly char requiredCharacter;

        #endregion


        #region Constructors

        /// <summary>
        /// Initialize a new instance of the <see cref="RequiredCharacterRule"/> class.
        /// </summary>
        /// <param name="errorMessage">The custom error message to use. Pass a null to 
        /// use the default value.</param>
        /// <param name="requiredCharacter">The invalid character.</param>
        /// <param name="useErrorMessageProvider"><c>true</c> to use 
        /// <see cref="ConfigurationService.ErrorMessageProvider"/> when determining the 
        /// error message for this <see cref="Rule"/>; otherwise <c>false</c>.</param>
        /// <param name="ruleSet">A <see cref="string"/> used to group <see cref="Rule"/>s.
        ///  Use a null to indicate no grouping.</param>
        public RequiredCharacterRule(string errorMessage, string ruleSet, 
            bool useErrorMessageProvider, char requiredCharacter)
            : base(runtimeTypeHandle, errorMessage, ruleSet, useErrorMessageProvider)
        {
            this.requiredCharacter = requiredCharacter;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the required character.
        /// </summary>
        public char RequiredCharacter
        {
            get
            {
                return requiredCharacter;
            }
        }

        /// <summary>
        /// Gets a <see cref="string"/> that is a business interpretation of the 
        /// <see cref="Rule"/>.
        /// </summary>
        public override string RuleInterpretation
        {
            get
            {
                return string.Format("The value must contain the character '{0}'", 
                    requiredCharacter);
            }
        }


        #endregion


        #region Methods

        /// <summary>
        /// Called after <see cref="InfoDescriptor"/> is set but only when <see cref="Rule.ErrorMessage"/> is null.
        /// </summary>
        /// <remarks>
        /// Used by inheritors to provide a customized default <see cref="Rule.ErrorMessage"/>.
        /// </remarks>
        /// <returns>The error message for the <see cref="Rule"/>.</returns>
        /// <param name="tokenizedMemberName">A user friendly representation of the member name.</param>
        /// <param name="descriptorType">
        /// If <see cref="InfoDescriptor"/> is a <see cref="PropertyDescriptor"/> then <paramref name="descriptorType"/> will be 'property'.
        /// If <see cref="InfoDescriptor"/> is a <see cref="ParameterDescriptor"/> then <paramref name="descriptorType"/> will be 'parameter'.
        /// </param>
        protected override string GetComputedErrorMessage(string tokenizedMemberName, string descriptorType)
        {
            return string.Format("The {0} '{1}' must contain the character '{2}'",
             descriptorType, tokenizedMemberName, requiredCharacter);
        }


        /// <summary>
        /// Validate the member this <see cref="Rule"/> is applied to.
        /// </summary>
        /// <param name="targetObjectValue">The value of the object containing the member 
        /// to validate.</param>
        /// <param name="context">An <see cref="object"/> that contains data for the 
        /// <see cref="Rule"/> to validate. The default is null.</param>
        /// <param name="targetMemberValue">The value of the member to validate.</param>
        public override ValidationResult Validate(
          object targetObjectValue,
          object targetMemberValue,
          object context)
        {
            if (targetMemberValue != null)
            {
                string valueAsString = (string)targetMemberValue;
                if (valueAsString.IndexOf(requiredCharacter) == -1)
                {
                    return new ValidationResult(this, ErrorMessage);
                }
            }
            return null;
        }


        /// <summary>
        /// Get a list of <see cref="BaseValidator"/>s to perform the client side 
        /// validation.
        /// </summary>
        /// <remarks>The <see cref="BaseValidator"/>s returned should only perform client 
        /// validation.</remarks>
        /// <returns>The<see cref="IList{T}"/> of <see cref="BaseValidator"/>s to perform 
        /// the client side validation.</returns>
        public IList<BaseValidator> CreateWebClientValidators()
        {
            ClientRegularExpressionWebValidator webValidator = 
                new ClientRegularExpressionWebValidator();
            webValidator.ValidationExpression = string.Format(".*[{0}].*", 
                requiredCharacter);
            BaseValidator[] array = new BaseValidator[1];
            array[0] = webValidator;
            return array;
        }

        /// <summary>
        /// Checks if the current <see cref="Rule"/> is equivalent to another 
        /// <see cref="Rule"/>.
        /// </summary>
        /// <remarks>
        /// Called for each <see cref="Rule"/> in <see cref="RuleCollection"/> when a new 
        /// <see cref="Rule"/> is added. This method is only called when both the existing 
        /// <see cref="Rule"/> and the <see cref="Rule"/> being are of the same 
        /// <see cref="Type"/> and have the same <see cref="Rule.RuleSet"/>. So it is safe
        ///  to directly cast <paramref name="rule"/> to the current type. All properties 
        /// in <paramref name="rule"/> should be compared to the propeties of the current 
        /// <see cref="Rule"/>.
        /// </remarks>
        /// <param name="rule">The <see cref="Rule"/> to check for equivalence.</param>
        /// <returns><see langword="true"/> if <paramref name="rule"/> is equivalent to 
        /// the current <see cref="Rule"/>; otherwise <see langword="false"/>.</returns>
        public override bool IsEquivalent(Rule rule)
        {
            RequiredCharacterRule requiredCharacterRule = (RequiredCharacterRule)rule;
            return requiredCharacter == requiredCharacterRule.requiredCharacter;
        }

        #endregion


    }
}