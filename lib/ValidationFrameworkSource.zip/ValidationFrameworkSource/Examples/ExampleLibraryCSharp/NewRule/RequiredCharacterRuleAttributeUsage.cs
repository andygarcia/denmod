using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharp
{
    [TestFixture]
    public class RequiredCharacterRuleAttributeUsage
    {
        public class Dinosaur
        {

            [RequiredCharacterRule('s')]
            public string Name
            {
                get;
                set;
            }
        }

        [Test]
        public void Test()
        {
            Dinosaur dinosaur = new Dinosaur();
            PropertyValidationManager propertyValidationManager =
              new PropertyValidationManager(dinosaur);

            propertyValidationManager.ValidateProperty("Name");
            // Valid because dinosaur.Name is Null
            Assert.IsTrue(propertyValidationManager.IsValid);

            dinosaur.Name = "Frog";
            propertyValidationManager.ValidateProperty("Name");
            // Invalid because dinosaur.Name does not contain an 's'
            Assert.IsFalse(propertyValidationManager.IsValid);

            dinosaur.Name = "Allosaurus";
            propertyValidationManager.ValidateProperty("Name");
            // Valid because dinosaur.Name does contain an 's'
            Assert.IsTrue(propertyValidationManager.IsValid);
        }
    }
}
