using System;
using System.Collections.Generic;
using ValidationFramework;
using ValidationFramework.Configuration;

namespace ExampleLibraryCSharp
{
    public class RequiredCharacterRuleConfigReader : IRuleConfigReader
    {
        /// <summary>
        /// Create a <see cref="Rule"/> from a <see cref="RuleData"/>.
        /// </summary>
        /// <param name="ruleData">The <see cref="RuleData"/> that represent the xml to 
        /// create the <see cref="Rule"/> for.</param>
        /// <param name="runtimeTypeHandle">The <see cref="System.RuntimeTypeHandle"/> 
        /// for the <see cref="Type"/> to create the <see cref="Rule"/> for.</param>
        /// <returns>
        /// A <see cref="Rule"/> that <paramref name="ruleData"/> represented
        /// </returns>
        public Rule ReadConfig(RuleData ruleData, RuntimeTypeHandle runtimeTypeHandle)
        {
            if (ruleData == null)
            {
                throw new ArgumentNullException("ruleData");
            }
            IDictionary<string, string> attributesAsDictionary =
              RuleData.ConvertExtraAttributesAsDictionary(ruleData.XmlAttributes);
            char requiredCharacter = 
                Convert.ToChar(attributesAsDictionary["requiredCharacter"]);
            return new RequiredCharacterRule(ruleData.ErrorMessage, ruleData.RuleSet, 
                ruleData.UseErrorMessageProvider, requiredCharacter);
        }
    }
}
