using ValidationFramework;
using ValidationFramework.Reflection;

namespace ExampleLibraryCSharp
{
    public class RequiredCharacterRuleAttribute : RuleAttribute,
      IParameterRuleAttribute, IPropertyRuleAttribute, IFieldRuleAttribute
    {
        #region Fields

        //the required character
        private readonly char requiredCharacter;

        #endregion


        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RequiredCharacterRuleAttribute"/>.
        /// </summary>
        /// <param name="requiredCharacter">The required character.</param>
        public RequiredCharacterRuleAttribute(char requiredCharacter)
        {
            this.requiredCharacter = requiredCharacter;
        }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the required character.
        /// </summary>
        public char RequiredCharacter
        {
            get
            {
                return requiredCharacter;
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IParameterRuleAttribute"/>.
        /// </summary>
        public Rule CreateParameterRule(ParameterDescriptor parameterDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IPropertyRuleAttribute"/>.
        /// </summary>
        public Rule CreatePropertyRule(PropertyDescriptor propertyDescriptor)
        {
            return CreateRule();
        }


        /// <summary>
        /// Create the <see cref="Rule"/> for this <see cref="IFieldRuleAttribute"/>.
        /// </summary>
        public Rule CreateFieldRule(FieldDescriptor fieldDescriptor)
        {
            return CreateRule();
        }


        private RequiredCharacterRule CreateRule()
        {
            return new RequiredCharacterRule(ErrorMessage, RuleSet, 
                UseErrorMessageProvider, requiredCharacter);
        }

        #endregion
    }
}