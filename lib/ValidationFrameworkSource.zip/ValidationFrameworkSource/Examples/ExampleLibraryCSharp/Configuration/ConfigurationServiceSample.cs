using System;
using System.Diagnostics;
using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Configuration;
using ValidationFramework.Reflection;

namespace ExampleLibraryCSharp
{

    [TestFixture]
    public class ConfigurationServiceSample
    {
        
        public class Person
        {
            private static readonly RuntimeMethodHandle setTheAgeHandle = 
                typeof(Person).GetMethod("SetTheAge").MethodHandle;
   

            public string Name
            {
                get;
                set;
            }

            public int Age
            {
                get;
                set;
            }

            public void SetTheAge(int age)
            {
                ParameterValidationManager.ThrowException(this, setTheAgeHandle, age);
                Age = age;
            }
        }

        [Test]
        public void Test()
        {
            ConfigurationService.AddAssembly(typeof(ConfigurationServiceSample).Assembly);
            Type type = typeof(Person);
            TypeDescriptor typeDescriptor = TypeCache.GetType(type.TypeHandle);
            Assert.AreEqual(1, typeDescriptor.Properties["Age"].Rules.Count);

            MethodDescriptor methodDescriptor = 
                MethodCache.GetMethod(type.GetMethod("SetTheAge").MethodHandle);
            Assert.AreEqual(1, methodDescriptor.Parameters["age"].Rules.Count);
        }
    }
}