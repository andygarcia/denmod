using System.Diagnostics;
using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Configuration;

namespace ExampleLibraryCSharp
{
    class CustomRuleConfigReaderSampleData
    {

        public string Foo
        {
            get;
            set;
        }
        private static void ValidateFoo(object sender, CustomValidationEventArgs e)
        {
            string foo = (string)e.TargetMemberValue;
            if (string.IsNullOrEmpty(foo))
            {
                e.IsValid = false;
            }
            else
            {
                e.IsValid = true;
            }
        }
    }

    [TestFixture]
    public class CustomRuleConfigReaderTests
    {

        static readonly string propertyXmlString = @"<?xml version='1.0' encoding='utf-8' ?>
<validationMapping xmlns='urn:validationFramework-validationDefinition-1.5'>
  <class typeName='ExampleLibraryCSharp.CustomRuleConfigReaderSampleData, ExampleLibraryCSharp'>
    <property name='Foo'>
      <rule typeName='CustomRule' 
				ruleInterpretation='This is a custom rule' 
				validationMethod='ValidateFoo' 
				validationTypeName='ExampleLibraryCSharp.CustomRuleConfigReaderSampleData, ExampleLibraryCSharp' 
				errorMessage='hello' />
    </property>
  </class>
</validationMapping>";

        [Test]
        public void TestCustomRuleConfigReader()
        {
            ConfigurationService.AddXmlString(propertyXmlString);
            CustomRuleConfigReaderSampleData data = new CustomRuleConfigReaderSampleData();
            PropertyValidationManager propertyValidationManager = 
                new PropertyValidationManager(data);
            propertyValidationManager.ValidateAllProperties();
            Assert.IsFalse(propertyValidationManager.IsValid);
            data.Foo = "sdfsdf";
            propertyValidationManager.ValidateAllProperties();
            Assert.IsTrue(propertyValidationManager.IsValid);


        }
    }
}