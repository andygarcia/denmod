using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharpFieldValidationManager
{
    public class ClassToValidate
    {

        #region Properties

    	[RequiredIntRule] public int data;

        #endregion
    }


    [TestFixture]
    public class ExternalTests
    {
        [Test]
        public void Run()
        {
            ClassToValidate classToValidate = new ClassToValidate();
            FieldValidationManager fieldValidationManager =
			  new FieldValidationManager(classToValidate);
			// Could have called fieldValidationManager.Validate() here to validate all
            // properties 
            fieldValidationManager.ValidateField("data");
            Assert.IsFalse(fieldValidationManager.IsValid);
            classToValidate.data = 99;
			// Could have called fieldValidationManager.Validate() here to validate all 
            // properties 
            fieldValidationManager.ValidateField("data");
            Assert.IsTrue(fieldValidationManager.IsValid);
        }
    }
}