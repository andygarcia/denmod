using System;
using System.Reflection;
using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public interface IParameterValidationManagerExplicitSample
    {
        void DoSomething(byte paramData);
    }

    public class ParameterValidationManagerExplicitSample :
      IParameterValidationManagerExplicitSample
    {
        private const string methodName = "ExampleLibraryCSharp.IParameterValidationManagerExplicitSample.DoSomething";
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(ParameterValidationManagerExplicitSample).GetMethod(methodName, 
            BindingFlags.NonPublic | BindingFlags.Instance).MethodHandle;

        void IParameterValidationManagerExplicitSample.DoSomething(
          [CompareByteRule(5, CompareOperator.LessThan)] byte paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
            //business code goes here.
        }
    }


    [TestFixture]
    public class ParameterValidationManagerExplicitTests
    {
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidData()
        {
            IParameterValidationManagerExplicitSample sample = 
                new ParameterValidationManagerExplicitSample();
            sample.DoSomething(7);
        }


        [Test]
        public void TestValidData()
        {
            IParameterValidationManagerExplicitSample sample = 
                new ParameterValidationManagerExplicitSample();
            sample.DoSomething(2);
        }
    }
}
