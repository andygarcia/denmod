using System;
using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public interface IInheritedFromInterfaceSample
    {
        void DoSomething([CompareByteRule(5, CompareOperator.LessThan)] byte paramData);
    }

    public class InheritedFromInterfaceSample :
      IInheritedFromInterfaceSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(IInheritedFromInterfaceSample).GetMethod("DoSomething").MethodHandle;

       public void DoSomething(byte paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
            //business code goes here.
        }
    }


    [TestFixture]
    public class ParameterValidationManagerInheritedFromInterfaceTests
    {
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidData()
        {
            IInheritedFromInterfaceSample sample = new InheritedFromInterfaceSample();
            sample.DoSomething(7);
        }


        [Test]
        public void TestValidData()
        {
            IInheritedFromInterfaceSample sample = new InheritedFromInterfaceSample();
            sample.DoSomething(2);
        }
    }
}
