using System;
using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class Basic
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(Basic).GetMethod("DoSomething").MethodHandle;

        public void DoSomething(
          [CompareByteRule(5, CompareOperator.LessThan)] byte paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);

            //business code goes here.
        }
    }

    [TestFixture]
    public class ParameterValidationManagerBasicTests
    {
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidData()
        {
            Basic sample = new Basic();
            sample.DoSomething(7);
        }


        [Test]
        public void TestValidData()
        {
            Basic sample = new Basic();
            sample.DoSomething(2);
        }
    }
}