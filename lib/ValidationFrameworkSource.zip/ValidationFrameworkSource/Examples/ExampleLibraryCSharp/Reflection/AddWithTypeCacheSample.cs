using System;
using NUnit.Framework;
using ValidationFramework.Reflection;
using ValidationFramework;

namespace ExampleLibraryCSharp
{
    public class AddWithTypeCacheSample
    {
        private readonly PropertyValidationManager validationManager;


        public AddWithTypeCacheSample()
        {
            validationManager = new PropertyValidationManager(this);
        }

        public int Foo
        {
            get;
            set;
        }

        

        public bool Validate()
        {
            validationManager.ValidateProperty("Foo");
            return validationManager.IsValid;
        }
    }

    [TestFixture]
    public class AddWithTypeCacheTests
    {

        [Test]
        public void Run()
        {
            Type fooType = typeof(AddWithTypeCacheSample);
            TypeDescriptor typeDescriptor = TypeCache.GetType(fooType.TypeHandle);
            PropertyDescriptor propertyDescriptor = 
                typeDescriptor.GetOrCreatePropertyDescriptor("Foo");
            RequiredRule<int> rule = new RequiredRule<int>(null, null, false);
            propertyDescriptor.Rules.Add(rule);


            AddWithTypeCacheSample sample = new AddWithTypeCacheSample();
            Assert.IsFalse(sample.Validate());
            sample.Foo = 10;
            Assert.IsTrue(sample.Validate());
        } 
    }
}