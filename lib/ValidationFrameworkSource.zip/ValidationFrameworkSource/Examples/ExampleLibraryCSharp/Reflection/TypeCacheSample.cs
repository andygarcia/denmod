using System;
using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ExampleLibraryCSharp
{
    public class Car
    {

        //Assume for the purposes of this sample that cars can have between 2 and 5 doors.
        public int NumberOfDoors
        {
            get;
            set;
        }
    }

    [TestFixture]
    public class TypeCacheTests
    {
        [Test]
        public void Run()
        {
            Car car = new Car();

            //Create a PropertyValidationManager for Car
            PropertyValidationManager manager = new PropertyValidationManager(car);

            Assert.IsTrue(manager.IsValid);

            Type carType = typeof(Car);

            RangeRule<int> rangeRule = new RangeRule<int>(null, null, false, 2, 5, true, 
                true);

            TypeDescriptor typeDescriptor = TypeCache.GetType(carType.TypeHandle);
            //create a PropertyDescriptor for NumberOfDoors and add a RangeRule to it.  
            PropertyDescriptor propertyDescriptor = 
                typeDescriptor.GetOrCreatePropertyDescriptor("NumberOfDoors");
            propertyDescriptor.Rules.Add(rangeRule);


            // 0 is an invalid NumberOfDoors 
            manager.ValidateAllProperties();
            Assert.IsFalse(manager.IsValid);

            // 1 is an invalid NumberOfDoors 
            car.NumberOfDoors = 1;
            manager.ValidateAllProperties();
            Assert.IsFalse(manager.IsValid);

            // 2 is an invalid NumberOfDoors 
            car.NumberOfDoors = 2;
            manager.ValidateAllProperties();
            Assert.IsTrue(manager.IsValid);


            // 6 is an invalid NumberOfDoors 
            car.NumberOfDoors = 6;
            manager.ValidateAllProperties();
            Assert.IsFalse(manager.IsValid);

            // clear the rule
            propertyDescriptor.Rules.Clear();


            // 6 is now a valid NumberOfDoors because the validation rule has been 
            // removed.
            // use TryValidateAllProperties. Since there are no rules 
            // ValidateAllProperties would throw an exception. 
            manager.TryValidateAllProperties();
            Assert.IsTrue(manager.IsValid);
        }
    }
}