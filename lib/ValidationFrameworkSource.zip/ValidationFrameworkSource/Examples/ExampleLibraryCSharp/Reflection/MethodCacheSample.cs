using System;
using NUnit.Framework;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ExampleLibraryCSharp
{
    public class Bike
    {
        public static readonly RuntimeMethodHandle ChangeWheelsMethodHandle =
      typeof(Bike).GetMethod("ChangeWheels").MethodHandle;

        //Assume for the purposes of this sample that a bike can have between 1 
        // and 2 wheels changed at a time.
        public void ChangeWheels(int numberOfWheels)
        {
            ParameterValidationManager.TryThrowException(this, ChangeWheelsMethodHandle,
                numberOfWheels);
            // Business code goes here
        }

    }

    [TestFixture]
    public class MethodCacheTests
    {
        [Test]
        public void TestMethodCache()
        {
            bool thrownOnTooFew = false;
            bool thrownOnTooMany = false;
            Bike bike = new Bike();

            // 0 is valid numberOfWheels because there are no validation rules yet.
            bike.ChangeWheels(0);

            RangeRule<int> rangeRule = new RangeRule<int>(null, null, false, 1, 2, true,
                true);

            MethodDescriptor methodDescriptor = MethodCache.GetMethod(
                Bike.ChangeWheelsMethodHandle);
            ParameterDescriptor numberOfWheelsParameterDescriptor =
        methodDescriptor.Parameters["numberOfWheels"];
            numberOfWheelsParameterDescriptor.Rules.Add(rangeRule);

            // 0 is an invalid numberOfWheels 
            try
            {
                bike.ChangeWheels(0);
            }
            catch (ArgumentException)
            {
                thrownOnTooFew = true;
            }

            // 1 and 2 are a valid numberOfWheels 
            bike.ChangeWheels(1);
            bike.ChangeWheels(2);

            // 3 is an invalid numberOfWheels 
            try
            {
                bike.ChangeWheels(3);
            }
            catch (ArgumentException)
            {
                thrownOnTooMany = true;
            }

            numberOfWheelsParameterDescriptor.Rules.Clear();

            // 0 is valid numberOfWheels because the validation rule has been removed.
            bike.ChangeWheels(0);

            Assert.IsTrue(thrownOnTooMany);
            Assert.IsTrue(thrownOnTooFew);
        }
    }
}