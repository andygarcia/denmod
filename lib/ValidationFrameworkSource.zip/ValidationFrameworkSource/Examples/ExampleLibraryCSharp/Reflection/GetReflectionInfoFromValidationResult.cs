using System;
using System.Reflection;
using ValidationFramework;
using ValidationFramework.Reflection;

namespace ExampleLibraryCSharp
{
	public static class GetReflectionInfoFromValidationResult
	{
		public static Type GetTypeFromPropertyValidationResult(
            ValidationResult result)
		{
			InfoDescriptor infoDescriptor = result.Rule.InfoDescriptor;
			PropertyDescriptor propertyDescriptor = (PropertyDescriptor) infoDescriptor;
			TypeDescriptor typeDescriptor = propertyDescriptor.TypeDescriptor;
			return Type.GetTypeFromHandle(typeDescriptor.RuntimeTypeHandle);
		}

		
		public static MethodBase GetMethodInfoFromParameterValidationResult(
            ValidationResult result)
		{
			InfoDescriptor infoDescriptor = result.Rule.InfoDescriptor;
			ParameterDescriptor parameterDescriptor = (ParameterDescriptor)infoDescriptor;
			MethodDescriptor methodDescriptor = parameterDescriptor.Method;
			return MethodInfo.GetMethodFromHandle(methodDescriptor.RuntimeMethodHandle);
		}
		
	}
}
