using System;
using NUnit.Framework;
using ValidationFramework.Reflection;
using ValidationFramework;

namespace ExampleLibraryCSharp
{
    public class AddCustomRuleWithTypeCacheSample
    {
        private readonly PropertyValidationManager validationManager;

        public AddCustomRuleWithTypeCacheSample()
        {
            validationManager = new PropertyValidationManager(this);
        }

        public string Foo
        {
            get;
            set;
        }

      

        public static void CheckIsNotEmpty(object sender, CustomValidationEventArgs e)
        {
            string foo = (string)e.TargetMemberValue;
            if (string.IsNullOrEmpty(foo))
            {
                e.IsValid = false;
            }
            else
            {
                e.IsValid = true;
            }
        }

        public bool Validate()
        {
            // Use TryValidateProperty in case rules have not yet been applied
            validationManager.TryValidateProperty("Foo");
            return validationManager.IsValid;
        }
    }

    [TestFixture]
    public class AddCustomRuleWithTypeCacheTests
    {
        [Test]
        public void TestAddCustomPropertyValidation()
        {
            Type fooType = typeof(AddCustomRuleWithTypeCacheSample);
            TypeDescriptor typeDescriptor = TypeCache.GetType(fooType.TypeHandle);
            PropertyDescriptor propertyDescriptor = 
                typeDescriptor.GetOrCreatePropertyDescriptor("Foo");
            CustomRule rule = new CustomRule("Foo cannot be empty.", null, false, 
                AddCustomRuleWithTypeCacheSample.CheckIsNotEmpty, "Foo cannot be empty.");
            propertyDescriptor.Rules.Add(rule);

            AddCustomRuleWithTypeCacheSample addCustomRuleWithTypeCacheSample = new 
                AddCustomRuleWithTypeCacheSample();
            Assert.IsFalse(addCustomRuleWithTypeCacheSample.Validate());
            addCustomRuleWithTypeCacheSample.Foo = "Hello";
            Assert.IsTrue(addCustomRuleWithTypeCacheSample.Validate());
        }
    }
}