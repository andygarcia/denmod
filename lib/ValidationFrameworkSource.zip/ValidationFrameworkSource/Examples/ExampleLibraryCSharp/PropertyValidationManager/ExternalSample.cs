using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharpPropertyValidationManager
{
    public class ClassToValidate
    {

        #region Properties

        [RequiredIntRule]
        public int Data
        {
            get;
            set;
        }

        #endregion
    }


    [TestFixture]
    public class ExternalTests
    {
        [Test]
        public void Run()
        {
            ClassToValidate classToValidate = new ClassToValidate();
            PropertyValidationManager propertyValidationManager =
              new PropertyValidationManager(classToValidate);
            // Could have called propertyValidationManager.Validate() here to validate all
            // properties 
            propertyValidationManager.ValidateProperty("Data");
            Assert.IsFalse(propertyValidationManager.IsValid);
            classToValidate.Data = 99;
            // Could have called propertyValidationManager.Validate() here to validate all 
            // properties 
            propertyValidationManager.ValidateProperty("Data");
            Assert.IsTrue(propertyValidationManager.IsValid);
        }
    }
}