using System.Collections.Generic;
using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharpPropertyValidationManager
{
    public class CustomClass
    {
        #region Fields

        private readonly PropertyValidationManager propertyValidationManager;

        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomClassUsingPropertyValidationManager"/> 
        /// class.
        /// </summary>
        public CustomClass()
        {
            propertyValidationManager = new PropertyValidationManager(this);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets <see cref="IList{T}"/> containing all <see cref="ValidationResult"/> for <see cref="Rule"/>s that have failed validation.
        /// </summary>
        public virtual IList<ValidationResult> ValidatorResultsInError
        {
            get
            {
                return propertyValidationManager.ValidatorResultsInError;
            }
        }


        /// <summary>
        /// Gets a <see see="ICollection"/> of <see langword="string"/>s that contain all 
        /// the <see cref="ValidationResult.ErrorMessage"/>s for all the 
        /// <see cref="ValidationResult"/>s in <see cref="ValidatorResultsInError"/>.
        /// </summary>
        public virtual IList<string> ErrorMessages
        {
            get
            {
                return ResultFormatter.GetErrorMessages(propertyValidationManager.ValidatorResultsInError);
            }
        }


        [RequiredIntRule]
        public int Data
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets a <see lanword="bool"/> indicating if the current state is valid.
        /// </summary>
        public bool Validate()
        {
            //Base behavior is to perform validations and return boolean value.
            //Sub-class can override this if, for example, they are validating on the fly.
            propertyValidationManager.ValidateAllProperties();
            return propertyValidationManager.IsValid;
        }
        #endregion
    }

    [TestFixture]
    public class CustomClassTests
    {
        [Test]
        public void TestIsValid()
        {
            CustomClass sample = 
                new CustomClass();

            // Initially not valid
            Assert.IsFalse(sample.Validate());

            // Set Data
            sample.Data = 10;

            // It is now valid
            Assert.IsTrue(sample.Validate());
        }



        [Test]
        public void TestValidatorResultsInError()
        {
            CustomClass sample = 
                new CustomClass();
            Assert.IsFalse(sample.Validate());
            // Initially there will be 1 item in ValidatorResultsInError.
            Assert.AreEqual(1, sample.ValidatorResultsInError.Count);

            // Set Data
            sample.Data = 10;

            // Since Validate has not been called the count will not have changed
            Assert.AreEqual(1, sample.ValidatorResultsInError.Count);

            Assert.IsTrue(sample.Validate());
            // Since Validate has now been called the count will have changed
            Assert.AreEqual(0, sample.ValidatorResultsInError.Count);
        }


    }
}