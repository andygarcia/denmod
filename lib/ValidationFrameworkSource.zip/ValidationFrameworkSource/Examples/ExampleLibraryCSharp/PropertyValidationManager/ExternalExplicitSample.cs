using System;
using ValidationFramework;

namespace ExampleLibraryCSharpPropertyValidationManager
{
    public class ClassToValidateExplicit : IClassToValidateExplicit
    {

        #region Properties

        [RequiredIntRule]
        int IClassToValidateExplicit.Data
        {
            get;
            set;
        }



        #endregion
    }
    public interface IClassToValidateExplicit
    {
        [RequiredIntRule]
        int Data
        {
            get;
            set;
        }
    }

    class ProgramPerformingValidationExplicit
    {
        static void NotMain()
        {
            IClassToValidateExplicit classToValidate = new ClassToValidateExplicit();
            PropertyValidationManager propertyValidationManager =
              new PropertyValidationManager(classToValidate);
            //Could have called propertyValidationManager.Validate() here to validate all properties 
            propertyValidationManager.ValidateProperty("ExampleLibraryCSharp.IClassToValidateExplicit.Data");
            Console.WriteLine(propertyValidationManager.IsValid);
            classToValidate.Data = 99;
            //Could have called propertyValidationManager.Validate() here to validate all properties 
            propertyValidationManager.ValidateProperty("ExampleLibraryCSharp.IClassToValidateExplicit.Data");
            Console.WriteLine(propertyValidationManager.IsValid);
            Console.ReadLine();
        }
    }
}