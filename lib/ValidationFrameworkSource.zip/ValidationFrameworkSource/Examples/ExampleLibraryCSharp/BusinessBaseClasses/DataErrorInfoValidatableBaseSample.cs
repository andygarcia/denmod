using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharp
{
    public class PersonDataErrorInfoValidatableBaseSample : DataErrorInfoValidatableBase
    {
        #region Fields

        //Define run-time constants here so UI code has compile-time
        //checks against misspellings in data binding expressions.
        public const string FirstNameMember = "FirstName";
        public const string LastNameMember = "LastName";
        public const string EmailAddressMember = "EmailAddress";
        private string firstName;
        private string lastName;
        private string emailAddress;

        #endregion


        #region Constructor

        public PersonDataErrorInfoValidatableBaseSample()
            : base(true)
        {
        }

        #endregion


        #region Properties

        [RequiredStringRule]
        [LengthStringRule(4)]
        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                if (firstName != value)
                {
                    firstName = value;
                    ValidateProperty(FirstNameMember);
                }
            }
        }


        [RequiredStringRule]
        [LengthStringRule(50, Minimum = 2)]
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                if (lastName != value)
                {
                    lastName = value;
                    ValidateProperty(LastNameMember);
                }
            }
        }


        [RequiredStringRule]
        [RegexRule(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*",
          ErrorMessage = "Invalid email format.")]
        [LengthStringRule(50)]
        public string EmailAddress
        {
            get
            {
                return emailAddress;
            }
            set
            {
                if (emailAddress != value)
                {
                    emailAddress = value;
                    ValidateProperty(EmailAddressMember);
                }
            }
        }

  
        #endregion
    }

    [TestFixture]
    public class DataErrorInfoValidatableBaseTest
    {
        [Test]
        public void TestIsValid()
        {
            PersonDataErrorInfoValidatableBaseSample sample = 
                new PersonDataErrorInfoValidatableBaseSample();

            // Initially not valid
            Assert.IsFalse(sample.IsValid);

            // Set FirstName, LastName and EmailAddress
            sample.FirstName = "John";
            sample.LastName = "Smith";
            sample.EmailAddress = "John.Smith@email.com";

            // It is now valid
            Assert.IsTrue(sample.IsValid);
        }


        [Test]
        public void TestValidatorResultsInError()
        {
            PersonDataErrorInfoValidatableBaseSample sample = 
                new PersonDataErrorInfoValidatableBaseSample();
            // Initially there should be 3 items in ValidatorResultsInError as only 3 
            // properties have required rules.
            Assert.AreEqual(3, sample.ValidatorResultsInError.Count);

            // Set LastName to a value and count goes down to 2
            sample.LastName = "Smith";
            // No need to call IsValid (to force a validation) because properties are 
            // validated during each set
            Assert.AreEqual(2, sample.ValidatorResultsInError.Count);
        }


        [Test]
        public void TestSpecificProperty()
        {
            PersonDataErrorInfoValidatableBaseSample sample = 
                new PersonDataErrorInfoValidatableBaseSample();

            // LastName initially has an ErrorMessage because it is invalid
            string lastNameErrorMessage = 
                sample[PersonDataErrorInfoValidatableBaseSample.LastNameMember];
            Assert.IsNotNull(lastNameErrorMessage);

            // Set LastName and it will then have no ErrorMessage
            sample.LastName = "Smith";
            // No need to call IsValid (to force a validation) because properties are 
            // validated during each set
            lastNameErrorMessage = 
                sample[PersonDataErrorInfoValidatableBaseSample.LastNameMember];
            Assert.IsEmpty(lastNameErrorMessage);
        }

    }
}