using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharp
{
    public class PersonNotifyValidatableBaseSample : NotifyValidatableBase
    {
        #region Fields

        //Define run-time constants here so UI code has compile-time
        //checks against misspellings in data binding expressions.
        public const string FirstNameMember = "FirstName";
        public const string LastNameMember = "LastName";
        public const string EmailAddressMember = "EmailAddress";
        private string firstName;
        private string lastName;
        private string emailAddress;

        #endregion


        #region Constructor

        public PersonNotifyValidatableBaseSample()
            : base(true)
        {
        }

        #endregion


        #region Properties

        [RequiredStringRule]
        [LengthStringRule(4)]
        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                if (firstName != value)
                {
                    firstName = value;
                    NotifyAndValidate(FirstNameMember);
                }
            }
        }


        [RequiredStringRule]
        [LengthStringRule(50, Minimum = 2)]
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                if (lastName != value)
                {
                    lastName = value;
                    NotifyAndValidate(LastNameMember);
                }
            }
        }


        [RequiredStringRule]
        [RegexRule(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*",
          ErrorMessage = "Invalid email format.")]
        [LengthStringRule(50)]
        public string EmailAddress
        {
            get
            {
                return emailAddress;
            }
            set
            {
                if (emailAddress != value)
                {
                    emailAddress = value;
                    NotifyAndValidate(EmailAddressMember);
                }
            }
        }


        #endregion
    }

    [TestFixture]
    public class NotifyValidatableBaseTests
    {
        private bool firstNameEventFired;

        [Test]
        public void TestEvent()
        {
            PersonNotifyValidatableBaseSample sample = 
                new PersonNotifyValidatableBaseSample();

            // Attach to PropertyChanged so we are notified 
            sample.PropertyChanged += sample_PropertyChanged;

            // Set FirstName and hence firing the event
            sample.FirstName = "John";

            // Since the event has fired the firstNameEventFired flag will be true;
            Assert.IsTrue(firstNameEventFired);
        }


        void sample_PropertyChanged(object sender, 
            System.ComponentModel.PropertyChangedEventArgs e)
        {
            // Check that it is the property we are interested in
            if (e.PropertyName == PersonNotifyValidatableBaseSample.FirstNameMember)
            {
                firstNameEventFired = true;
            }
        }


        [Test]
        public void TestIsValid()
        {
            PersonNotifyValidatableBaseSample sample = 
                new PersonNotifyValidatableBaseSample();

            // Initially not valid
            Assert.IsFalse(sample.IsValid);

            // Set FirstName, LastName and EmailAddress
            sample.FirstName = "John";
            sample.LastName = "Smith";
            sample.EmailAddress = "John.Smith@email.com";

            // It is now valid
            Assert.IsTrue(sample.IsValid);
        }


        [Test]
        public void TestValidatorResultsInError()
        {
            PersonNotifyValidatableBaseSample sample = 
                new PersonNotifyValidatableBaseSample();
            // Initially there should be 3 items in ValidatorResultsInError as only 3 
            // properties have required rules.
            Assert.AreEqual(3, sample.ValidatorResultsInError.Count);

            // Set LastName to a value and count goes down to 2
            sample.LastName = "Smith";
            // No need to call IsValid (to force a validation) because properties are 
            // validated during each set
            Assert.AreEqual(2, sample.ValidatorResultsInError.Count);
        }


        [Test]
        public void TestSpecificProperty()
        {
            PersonNotifyValidatableBaseSample sample = 
                new PersonNotifyValidatableBaseSample();

            // LastName initially has an ErrorMessage because it is invalid
            string lastNameErrorMessage = 
                sample[PersonDataErrorInfoValidatableBaseSample.LastNameMember];
            Assert.IsNotNull(lastNameErrorMessage);

            // Set LastName and it will then have no ErrorMessage
            sample.LastName = "Smith";
            // No need to call IsValid (to force a validation) because properties are 
            // validated during each set
            lastNameErrorMessage = 
                sample[PersonDataErrorInfoValidatableBaseSample.LastNameMember];
            Assert.IsEmpty(lastNameErrorMessage);
        }

    }
}