using NUnit.Framework;
using ValidationFramework;

namespace ExampleLibraryCSharp
{
    public class PersonValidatableBaseExample : ValidatableBase
    {

        #region Fields

        //Define run-time constants here so UI code has compile-time
        //checks against misspellings in data binding expressions.
        public const string FirstNameMember = "FirstName";
        public const string LastNameMember = "LastName";
        public const string EmailAddressMember = "EmailAddress";

        #endregion


        #region Constructor

        public PersonValidatableBaseExample()
            : base(true)
        {
        }

        #endregion


        #region Properties

        [RequiredStringRule]
        [LengthStringRule(4)]
        public string FirstName
        {
            get;
            set;
        }


        [RequiredStringRule]
        [LengthStringRule(50, Minimum = 2)]
        public string LastName
        {
            get;
            set;
        }


        [RequiredStringRule]
        [RegexRule(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*",
          ErrorMessage = "Invalid email format.")]
        [LengthStringRule(50)]
        public string EmailAddress
        {
            get;
            set;
        }


        #endregion
    }


    [TestFixture]
    public class ValidatableBaseTest
    {
        [Test]
        public void TestIsValid()
        {
            PersonValidatableBaseExample sample = new PersonValidatableBaseExample();

            // Initially not valid
            Assert.IsFalse(sample.IsValid);

            // Set FirstName, LastName and EmailAddress
            sample.FirstName = "John";
            sample.LastName = "Smith";
            sample.EmailAddress = "John.Smith@email.com";

            // It is now valid
            Assert.IsTrue(sample.IsValid);
        }


        [Test]
        public void TestValidatorResultsInError()
        {
            PersonValidatableBaseExample sample = new PersonValidatableBaseExample();
            // Initially there should be 3 items in ValidatorResultsInError as only 3 
            // properties have required rules.
            Assert.AreEqual(3, sample.ValidatorResultsInError.Count);

            // Set LastName to a value and count goes down to 2
            sample.LastName = "Smith";

            // Since IsValid has not been called the count will not have changed
            Assert.AreEqual(3, sample.ValidatorResultsInError.Count);

            Assert.IsFalse(sample.IsValid);
            // Since IsValid has now been called the count will have changed
            Assert.AreEqual(2, sample.ValidatorResultsInError.Count);
        }


    }
}