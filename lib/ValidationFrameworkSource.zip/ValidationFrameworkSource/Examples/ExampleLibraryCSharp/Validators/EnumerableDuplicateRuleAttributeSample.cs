using System;
using System.Collections.Generic;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class EnumerableDuplicateRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(EnumerableDuplicateRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [EnumerableDuplicateRule]
        //Defined ErrorMessage and InitialValue
        [EnumerableDuplicateRule(ErrorMessage = "No duplicates are allowed.",
          EqualityComparerTypeName = "System.StringComparer",
          EqualityComparerPropertyName = "InvariantCulture")]
        public IList<string> Data
        {
            get;
            set;
        }

        public void DoSomething(
         [EnumerableDuplicateRule] IList<string> paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}