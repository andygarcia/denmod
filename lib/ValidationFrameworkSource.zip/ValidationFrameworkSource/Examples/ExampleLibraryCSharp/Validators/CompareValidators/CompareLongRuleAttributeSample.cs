using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class CompareLongRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(CompareLongRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [CompareLongRule(5, CompareOperator.LessThan)]
        //Defined ErrorMessage
        [CompareLongRule(2, CompareOperator.GreaterThan,
          ErrorMessage = "Data must be greater than 2.")]
        public long Data
        {
            get;
            set;
        }


        public void DoSomething(
         [CompareLongRule(5, CompareOperator.LessThan)] long paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}