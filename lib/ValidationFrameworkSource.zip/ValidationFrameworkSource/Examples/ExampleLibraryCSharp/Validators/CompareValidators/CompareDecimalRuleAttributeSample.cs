using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class CompareDecimalRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(CompareDecimalRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [CompareDecimalRule(5, CompareOperator.LessThan)]
        //Defined ErrorMessage
        [CompareDecimalRule(2, CompareOperator.GreaterThan,
          ErrorMessage = "Data must be greater than 2.")]
        public decimal Data
        {
            get;
            set;
        }

        public void DoSomething(
         [CompareDecimalRule(5, CompareOperator.LessThan)] decimal paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}