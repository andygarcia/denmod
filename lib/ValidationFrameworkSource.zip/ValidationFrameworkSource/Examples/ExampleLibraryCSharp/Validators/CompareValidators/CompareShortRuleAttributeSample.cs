using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class CompareShortRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(CompareShortRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [CompareShortRule(5, CompareOperator.LessThan)]
        //Defined ErrorMessage
        [CompareShortRule(2, CompareOperator.GreaterThan,
          ErrorMessage = "Data must be greater than 2.")]
        public short Data
        {
            get;
            set;
        }


        public void DoSomething(
         [CompareShortRule(5, CompareOperator.LessThan)] short paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}