using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class CompareStringRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(CompareStringRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [CompareStringRule("d", CompareOperator.LessThan)]
        //Defined ErrorMessage
        [CompareStringRule("a", CompareOperator.GreaterThan,
          ErrorMessage = "Data must be greater than a.")]
        public string Data
        {
            get;
            set;
        }


        public void DoSomething(
         [CompareStringRule("a", CompareOperator.LessThan)] string paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData );
        }
    }
}