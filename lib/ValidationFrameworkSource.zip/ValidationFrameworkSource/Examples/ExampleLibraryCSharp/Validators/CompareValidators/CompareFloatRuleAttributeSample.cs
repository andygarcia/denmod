using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class CompareFloatRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(CompareFloatRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [CompareFloatRule(5, CompareOperator.LessThan)]
        //Defined ErrorMessage
        [CompareFloatRule(2, CompareOperator.GreaterThan,
          ErrorMessage = "Data must be greater than 2.")]
        public float Data
        {
            get;
            set;
        }


        public void DoSomething(
         [CompareFloatRule(5, CompareOperator.LessThan)] float paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}