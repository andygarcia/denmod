using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class ComparePropertyRuleAttributeSample
    {

        public DateTime StartDateTime
        {
            get;
            set;
        }

        [ComparePropertyRule("StartDateTime", CompareOperator.GreaterThan)]
        public DateTime EndDateTime
        {
            get;
            set;
        }
    }
}