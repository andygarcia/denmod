using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class CompareDateTimeRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(CompareDateTimeRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [CompareDateTimeRule("05 Jan 2006", CompareOperator.LessThan)]
        //Defined ErrorMessage
        [CompareDateTimeRule("01 Jan 2006", CompareOperator.GreaterThan,
          ErrorMessage = "Data must be greater than 01 Jan 2006.")]
        public DateTime Data
        {
            get;
            set;
        }


        public void DoSomething(
          [CompareDateTimeRule("05 Jan 2006", CompareOperator.LessThan)] DateTime paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}