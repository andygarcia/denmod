using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class CompareByteRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(CompareByteRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [CompareByteRule(5, CompareOperator.LessThan)]
        //Defined ErrorMessage
        [CompareByteRule(2, CompareOperator.GreaterThan,
          ErrorMessage = "Data must be greater than 2.")]
        public byte Data
        {
            get;
            set;
        }


        public void DoSomething(
          [CompareByteRule(5, CompareOperator.LessThan)] byte paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}