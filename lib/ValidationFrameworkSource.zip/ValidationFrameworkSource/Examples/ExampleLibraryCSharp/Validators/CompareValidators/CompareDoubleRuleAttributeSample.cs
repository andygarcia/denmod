using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class CompareDoubleRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(CompareDoubleRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [CompareDoubleRule(5, CompareOperator.LessThan)]
        //Defined ErrorMessage
        [CompareDoubleRule(2, CompareOperator.GreaterThan,
          ErrorMessage = "Data must be greater than 2.")]
        public double Data
        {
            get;
            set;
        }


        public void DoSomething(
         [CompareDoubleRule(5, CompareOperator.LessThan)] double paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}