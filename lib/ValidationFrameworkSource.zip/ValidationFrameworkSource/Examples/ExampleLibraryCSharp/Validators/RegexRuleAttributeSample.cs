using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RegexRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RegexRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //Defined ErrorMessage
        [RegexRule(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*",
          ErrorMessage = "Invalid email format.")]
        public string Email
        {
            get;
            set;
        }

        public void SendEmail(
          [RegexRule(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")] string emailAddress)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, emailAddress);
        }
    }
}