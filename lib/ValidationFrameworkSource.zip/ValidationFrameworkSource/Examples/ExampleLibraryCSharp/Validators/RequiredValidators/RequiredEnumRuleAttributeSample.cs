using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public enum Numbers
    {
        One,
        Two,
        Three
    }

    public class RequiredEnumRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RequiredEnumRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute, 
        //The default value for the enum will be considered invalid
        [RequiredEnumRule]
        //Defined ErrorMessage and InitialValue
        [RequiredEnumRule(InitialValue = "Two", ErrorMessage = "Two is an invalid value.")]
        public Numbers Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredEnumRule] Numbers paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}
