using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredGuidRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RequiredGuidRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredGuidRule]
        //Defined ErrorMessage and InitialValue
        [RequiredGuidRule(InitialValue = "11111111-1111-1111-1111-111111111111",
          ErrorMessage = "11111111-1111-1111-1111-111111111111 is an invalid value.")]
        public Guid Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredGuidRule] Guid paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}