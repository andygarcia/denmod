using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredByteRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RequiredByteRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        [RequiredByteRule]
        [RequiredByteRule(InitialValue = 2, ErrorMessage = "2 is an invalid value.")]
        public byte Data
        {
            get;
            set;
        }


        public void DoSomething(
         [RequiredByteRule] byte paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}