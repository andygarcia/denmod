using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredDoubleRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RequiredDoubleRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredDoubleRule]
        //Defined ErrorMessage and InitialValue
        [RequiredDoubleRule(InitialValue = 2, ErrorMessage = "2 is an invalid value.")]
        public double Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredDoubleRule] double paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}
