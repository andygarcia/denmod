using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredIntRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RequiredIntRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredIntRule]
        //Defined ErrorMessage and InitialValue
        [RequiredIntRule(InitialValue = 2, ErrorMessage = "2 is an invalid value.")]
        public int Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredIntRule] int paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}