using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredShortRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RequiredShortRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredShortRule]
        //Defined ErrorMessage and InitialValue
        [RequiredShortRule(InitialValue = 2,
          ErrorMessage = "2 is an invalid value.")]
        public short Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredShortRule] short paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}