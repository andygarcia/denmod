using System;
using System.Xml.Serialization;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredObjectRuleAttributeSample
    {

        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RequiredObjectRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        [XmlRoot("person")]
        public class Person
        {
            [XmlAttribute("name")]
            public string Name
            {
                get;
                set;
            }

            [XmlAttribute("age")]
            public int Age
            {
                get;
                set;
            }

        }


        [RequiredObjectRule] //ErrorMessage will be generated for this attribute
        [RequiredObjectRule(InitialValue = "<person name='john' age='23'/>")]
        public Person Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredObjectRule] Person paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}