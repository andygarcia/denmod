using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredBoolRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RequiredBoolRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredBoolRule]
        //Defined ErrorMessage and InitialValue
        [RequiredBoolRule(ErrorMessage = "2 is an invalid value.", RuleSet = "Custom")]
        public bool? Data
        {
            get;
            set;
        }


        public void DoSomething(
         [RequiredBoolRule] bool? paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}