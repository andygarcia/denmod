using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredLongRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RequiredLongRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredLongRule]
        //Defined ErrorMessage and InitialValue
        [RequiredLongRule(InitialValue = 2, ErrorMessage = "2 is an invalid value.")]
        public long Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredLongRule] long paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}