using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredStringRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RequiredStringRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredStringRule]
        //Defined ErrorMessage and InitialValue
        [RequiredStringRule(InitialValue = "aaa",
          ErrorMessage = "aaa is an invalid value.")]
        public string Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredStringRule] string paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}