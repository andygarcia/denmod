using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredDateTimeRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RequiredDateTimeRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredDateTimeRule]
        //Defined ErrorMessage and InitialValue
        [RequiredDateTimeRule(InitialValue = "05 Jan 2006",
          ErrorMessage = "05 Jan 2006 is an invalid value.")]
        public DateTime? Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredDateTimeRule] DateTime paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}