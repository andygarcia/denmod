using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredFloatRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RequiredFloatRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredFloatRule]
        //Defined ErrorMessage and InitialValue
        [RequiredFloatRule(InitialValue = 2, ErrorMessage = "2 is an invalid value.")]
        public float Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredFloatRule] float paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}
