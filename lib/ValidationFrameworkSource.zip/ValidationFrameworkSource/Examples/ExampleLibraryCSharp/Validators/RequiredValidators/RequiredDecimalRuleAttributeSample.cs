using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RequiredDecimalRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RequiredDecimalRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RequiredDecimalRule]
        //Defined ErrorMessage and InitialValue
        [RequiredDecimalRule(InitialValue = 2, ErrorMessage = "2 is an invalid value.")]
        public decimal Data
        {
            get;
            set;
        }

        public void DoSomething(
         [RequiredDecimalRule] decimal paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}