using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeByteRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RangeByteRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeByteRule(3, 7)]
        //Defined ErrorMessage
        [RangeByteRule(2, 4, ErrorMessage = "Data must be between 2 and 4.")]
        public byte Data
        {
            get;
            set;
        }


        public void DoSomething(
             [RangeByteRule(3, 7)] byte paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}