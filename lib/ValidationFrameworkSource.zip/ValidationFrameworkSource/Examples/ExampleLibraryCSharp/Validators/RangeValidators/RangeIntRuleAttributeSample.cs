using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeIntRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RangeIntRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeIntRule(3, 7)]
        //Defined ErrorMessage
        [RangeIntRule(2, 4, ErrorMessage = "Data must be between 2 and 4.")]
        public int Data
        {
            get;
            set;
        }

        public void DoSomething(
             [RangeIntRule(3, 7)] int paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}