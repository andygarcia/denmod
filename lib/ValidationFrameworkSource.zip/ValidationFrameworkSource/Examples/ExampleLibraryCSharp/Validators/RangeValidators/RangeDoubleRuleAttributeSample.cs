using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeDoubleRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RangeDoubleRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeDoubleRule(3, 7)]
        //Defined ErrorMessage
        [RangeDoubleRule(2, 4, ErrorMessage = "Data must be between 2 and 4.")]
        public double Data
        {
            get;
            set;
        }


        public void DoSomething(
             [RangeDoubleRule(3, 7)] double paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}