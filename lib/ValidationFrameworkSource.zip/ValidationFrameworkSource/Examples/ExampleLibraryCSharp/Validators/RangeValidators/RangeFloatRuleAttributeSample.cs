using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeFloatRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RangeFloatRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeFloatRule(3, 7)]
        //Defined ErrorMessage
        [RangeFloatRule(2, 4, ErrorMessage = "Data must be between 2 and 4.")]
        public float Data
        {
            get;
            set;
        }

        public void DoSomething(
             [RangeFloatRule(3, 7)] float paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}