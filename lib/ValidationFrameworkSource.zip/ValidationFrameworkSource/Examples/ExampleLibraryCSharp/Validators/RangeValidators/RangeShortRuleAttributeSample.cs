using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeShortRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RangeShortRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeShortRule(3, 7)]
        //Defined ErrorMessage
        [RangeShortRule(2, 4,
          ErrorMessage = "Data must be between 2 and 4.")]
        public short Data
        {
            get;
            set;
        }


        public void DoSomething(
             [RangeShortRule(3, 7)] short paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}