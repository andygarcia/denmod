using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeLongRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RangeLongRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeLongRule(3, 7)]
        //Defined ErrorMessage
        [RangeLongRule(2, 4, ErrorMessage = "Data must be between 2 and 4.")]
        public long Data
        {
            get;
            set;
        }


        public void DoSomething(
             [RangeLongRule(3, 7)] long paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}
