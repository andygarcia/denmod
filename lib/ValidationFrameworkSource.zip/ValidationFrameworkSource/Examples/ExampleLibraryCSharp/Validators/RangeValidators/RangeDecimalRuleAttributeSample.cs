using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeDecimalRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RangeDecimalRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeDecimalRule(3, 7)]
        //Defined ErrorMessage
        [RangeDecimalRule(2, 4, ErrorMessage = "Data must be between 2 and 4.")]
        public decimal Data
        {
            get;
            set;
        }


        public void DoSomething(
             [RangeDecimalRule(3, 7)] decimal paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }

    }
}