using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeStringRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(RangeStringRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeStringRule("c", "h")]
        //Defined ErrorMessage
        [RangeStringRule("b", "d",
          ErrorMessage = "Data must be between b and d.")]
        public string Data
        {
            get;
            set;
        }


        public void DoSomething(
             [RangeStringRule("c", "h")] string paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}