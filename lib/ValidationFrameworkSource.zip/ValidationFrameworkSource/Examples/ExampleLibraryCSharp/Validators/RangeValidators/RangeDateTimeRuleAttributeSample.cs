using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class RangeDateTimeRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(RangeDateTimeRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [RangeDateTimeRule("07 Jan 2006", "09 Jan 2006")]
        //Defined ErrorMessage
        [RangeDateTimeRule("05 Jan 2006", "08 Jan 2006",
          ErrorMessage = "Data must be between 05 Jan 2006 and 08 Jan 2006.")]
        public DateTime Data
        {
            get;
            set;
        }


        public void DoSomething(
             [RangeDateTimeRule("07 Jan 2006", "09 Jan 2006")] DateTime paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}