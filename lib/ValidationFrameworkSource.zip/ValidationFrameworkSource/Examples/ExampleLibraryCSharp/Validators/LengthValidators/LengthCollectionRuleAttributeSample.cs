using System;
using System.Collections.Generic;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class LengthCollectionRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle = 
            typeof(LengthCollectionRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [LengthCollectionRule(5)]
        //Defined ErrorMessage, ExcludeDuplicatesFromCount and Minimum
        [LengthCollectionRule(4, Minimum = 2, ExcludeDuplicatesFromCount = true,
          ErrorMessage = "Length of data must be at least 2 and no greater that 4.")]
        public IList<int> Data
        {
            get;
            set;
        }


        public void DoSomething(
             [LengthCollectionRule(5)] IList<int> paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}