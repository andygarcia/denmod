using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public class LengthStringRuleAttributeSample
    {
        private static readonly RuntimeMethodHandle doSomethingHandle =
            typeof(LengthStringRuleAttributeSample).GetMethod("DoSomething").MethodHandle;

        //ErrorMessage will be generated for this attribute
        [LengthStringRule(5)]
        //Defined ErrorMessage and Minimum
        [LengthStringRule(4, Minimum = 2,
          ErrorMessage = "Length of data must be at least 2 and no greater that 4.")]
        public string Data
        {
            get;
            set;
        }


        public void DoSomething(
         [LengthStringRule(5)] string paramData)
        {
            ParameterValidationManager.ThrowException(this, doSomethingHandle, paramData);
        }
    }
}