using System;
using ValidationFramework;

namespace ExampleLibraryCSharp
{

    public enum CardType
    {
        Visa,
        MasterCard,
        Amex
    }
    public class Person
    {



        #region Properties
        [RequiredEnumRule]
        public CardType? CardType
        {
            get;
            set;
        }

        [CustomRule("ExampleLibraryCSharp.Person,ExampleLibraryCSharp", "CheckValidCreditCard",
      "Validate based on credit card rules.", ErrorMessage = "Credit card is invalid.")]
        public string CreditCardNumber
        {
            get;
            set;
        }


        #endregion


        #region Methods

        private static void CheckValidCreditCard(object sender, CustomValidationEventArgs e)
        {
            Person person = (Person)e.TargetObjectValue;
            CardType? cardType = person.CardType;
            string cardNumber = person.CreditCardNumber;
            if (cardNumber == null || cardType == null)
            {
                e.IsValid = false;
            }
            else
            {
                switch (cardType.Value)
                {
                    case ExampleLibraryCSharp.CardType.Visa:
                    case ExampleLibraryCSharp.CardType.MasterCard:
                        {
                            e.IsValid = (cardNumber.Length == 16);
                            break;
                        }
                    case ExampleLibraryCSharp.CardType.Amex:
                        {
                            e.IsValid = (cardNumber.Length == 15);
                            break;
                        }
                    default:
                        {
                            throw new ArgumentException("Invalid CardType");
                        }
                }
            }
        }

        #endregion

    }
}